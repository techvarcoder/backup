/**
 * @format
 */

import React from 'react';
import ReactTestRenderer from 'react-test-renderer';

jest.mock('../src/services/database', () => ({
  initializeDatabase: jest.fn().mockResolvedValue(undefined),
  getBooks: jest.fn().mockResolvedValue([
    {name: 'John', chapterCount: 1},
    {name: 'Romans', chapterCount: 1},
  ]),
  getChaptersForBook: jest.fn().mockResolvedValue([1]),
  getChapterVerses: jest.fn().mockResolvedValue([
    {
      book: 'John',
      bookOrder: 43,
      chapter: 1,
      verse: 1,
      reference: 'John 1:1',
      text: 'In the beginning was the Word.',
    },
  ]),
  searchVerses: jest.fn().mockResolvedValue([]),
}));

jest.mock('../src/services/userContentService', () => ({
  applyHighlight: jest.fn().mockResolvedValue(undefined),
  clearHighlight: jest.fn().mockResolvedValue(undefined),
  getContentForReferences: jest.fn().mockResolvedValue({}),
  getContentSummary: jest.fn().mockResolvedValue({
    bookmarkCount: 0,
    highlightCount: 0,
    noteCount: 0,
  }),
  saveNote: jest.fn().mockResolvedValue(undefined),
  setBookmarks: jest.fn().mockResolvedValue(undefined),
}));

import App from '../App';

test('renders welcome screen', async () => {
  let tree: ReactTestRenderer.ReactTestRenderer;

  await ReactTestRenderer.act(async () => {
    tree = ReactTestRenderer.create(<App />);
  });

  expect(tree!.root.findByProps({children: 'Start reading'})).toBeTruthy();
});
