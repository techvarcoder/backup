import React, {useEffect, useMemo, useRef, useState} from 'react';
import {Animated, useColorScheme} from 'react-native';
import {
  getBooks,
  getChapterVerses,
  getChaptersForBook,
  initializeDatabase,
  searchVerses,
} from './src/services/database';
import {
  applyHighlight,
  clearHighlight,
  deleteBookmark,
  deleteHighlight,
  deleteNote,
  getLibraryEntries,
  getContentForReferences,
  getContentSummary,
  saveNote,
  setBookmarks,
} from './src/services/userContentService';
import {PLAN_SCHEDULES} from './src/data/readingPlanSchedules';
import {getReadingTarget} from './src/data/readingPlanUtils';
import LoadingPage from './src/pages/LoadingPage';
import type {Plan} from './src/pages/PlansList.tsx';
import ReaderPage from './src/pages/ReaderPage.tsx';
import type {
  BookMeta,
  ContentSummary,
  HighlightColor,
  LibraryEntry,
  Verse,
  VerseContentState,
} from './src/types';

type AppTab = 'home' | 'bible' | 'plans' | 'saved';

const HIGHLIGHT_OPTIONS: HighlightColor[] = ['#F4D58D', '#B8D8BA', '#E7B8C8'];

const EMPTY_SUMMARY: ContentSummary = {
  bookmarkCount: 0,
  highlightCount: 0,
  noteCount: 0,
};

const EMPTY_VERSE_STATE: VerseContentState = {
  bookmark: false,
  highlightColor: null,
  note: null,
};

const SHEET_HIDDEN_OFFSET = 320;

function App() {
  const isDarkMode = useColorScheme() === 'dark';

  const [selectedLanguage, setSelectedLanguage] = useState<'en' | 'ta'>('en');
  const [isLoading, setIsLoading] = useState(true);
  const [isMutating, setIsMutating] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [books, setBooks] = useState<BookMeta[]>([]);
  const [chapters, setChapters] = useState<number[]>([]);
  const [selectedBook, setSelectedBook] = useState('');
  const [selectedChapter, setSelectedChapter] = useState(1);
  const [chapterVerses, setChapterVerses] = useState<Verse[]>([]);
  const [chapterContent, setChapterContent] = useState<
    Record<string, VerseContentState>
  >({});
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Verse[]>([]);
  const [searchContent, setSearchContent] = useState<
    Record<string, VerseContentState>
  >({});
  const [summary, setSummary] = useState<ContentSummary>(EMPTY_SUMMARY);
  const [libraryEntries, setLibraryEntries] = useState<LibraryEntry[]>([]);
  const [selectedReferences, setSelectedReferences] = useState<string[]>([]);
  const [activeReference, setActiveReference] = useState<string | null>(null);
  const [isActionSheetOpen, setIsActionSheetOpen] = useState(false);
  const [noteDraft, setNoteDraft] = useState('');
  const [activeTab, setActiveTab] = useState<AppTab>('home');
  const [selectedTestament, setSelectedTestament] = useState<'old' | 'new'>('old');
  const [planProgress, setPlanProgress] = useState<Record<string, number>>({});
  const [isBottomSheetMounted, setIsBottomSheetMounted] = useState(false);
  const bottomSheetTranslateY = useRef(
    new Animated.Value(SHEET_HIDDEN_OFFSET),
  ).current;

  const isSearching = searchQuery.trim().length >= 2;
  const visibleVerses = isSearching ? searchResults : chapterVerses;
  const visibleContent = isSearching ? searchContent : chapterContent;
  const selectionMode = selectedReferences.length > 0;

  const focusReference = useMemo(() => {
    if (selectionMode) {
      return selectedReferences.length === 1 ? selectedReferences[0] : null;
    }

    return activeReference;
  }, [activeReference, selectedReferences, selectionMode]);

  const selectedVerseStates = useMemo(
    () =>
      selectedReferences.map(reference =>
        searchContent[reference] ??
        chapterContent[reference] ??
        EMPTY_VERSE_STATE,
      ),
    [chapterContent, searchContent, selectedReferences],
  );

  const allSelectedBookmarked =
    selectedVerseStates.length > 0 &&
    selectedVerseStates.every(state => state.bookmark);

  useEffect(() => {
    let cancelled = false;

    const loadSummary = async () => {
      const nextSummary = await getContentSummary();
      if (!cancelled) {
        setSummary(nextSummary);
      }
    };

    const loadLibrary = async () => {
      const entries = await getLibraryEntries();
      if (!cancelled) {
        setLibraryEntries(entries);
      }
    };

    const loadChapter = async (book: string, chapter: number) => {
      const verses = await getChapterVerses(book, chapter);
      const nextContent = await getContentForReferences(
        verses.map(verse => verse.reference),
      );

      if (cancelled) {
        return;
      }

      setChapterVerses(verses);
      setChapterContent(nextContent);
      setSelectedReferences([]);
      setIsActionSheetOpen(false);
      setActiveReference(null);
    };

    const bootstrap = async () => {
      try {
        await initializeDatabase(selectedLanguage);
        const nextBooks = await getBooks();
        if (!nextBooks.length || cancelled) {
          return;
        }

        setBooks(nextBooks);
        const preferredBook = nextBooks[0].name;
        const nextChapters = await getChaptersForBook(preferredBook);
        const initialChapter = nextChapters[0] ?? 1;

        if (cancelled) {
          return;
        }

        setSelectedBook(preferredBook);
        setChapters(nextChapters);
        setSelectedChapter(initialChapter);
        await Promise.all([
          loadChapter(preferredBook, initialChapter),
          loadSummary(),
          loadLibrary(),
        ]);
      } catch (error) {
        if (!cancelled) {
          setErrorMessage(
            error instanceof Error ? error.message : 'Unable to load the Bible.',
          );
        }
      } finally {
        if (!cancelled) {
          setIsLoading(false);
        }
      }
    };

    void bootstrap();

    return () => {
      cancelled = true;
    };
  }, [selectedLanguage]);

  useEffect(() => {
    let cancelled = false;

    const runSearch = async () => {
      const query = searchQuery.trim();
      if (query.length < 2) {
        setSearchResults([]);
        setSearchContent({});
        return;
      }

      try {
        const results = await searchVerses(query);
        const nextContent = await getContentForReferences(
          results.map(verse => verse.reference),
        );

        if (cancelled) {
          return;
        }

        setSearchResults(results);
        setSearchContent(nextContent);
      } catch (error) {
        if (!cancelled) {
          setErrorMessage(
            error instanceof Error ? error.message : 'Search failed.',
          );
        }
      }
    };

    void runSearch();

    return () => {
      cancelled = true;
    };
  }, [searchQuery]);

  useEffect(() => {
    const nextDraft = focusReference
      ? searchContent[focusReference]?.note ??
        chapterContent[focusReference]?.note ??
        ''
      : '';

    setNoteDraft(nextDraft);
  }, [chapterContent, focusReference, searchContent]);

  const loadSummary = async () => {
    const nextSummary = await getContentSummary();
    setSummary(nextSummary);
  };

  const loadLibraryEntriesState = async () => {
    const entries = await getLibraryEntries();
    setLibraryEntries(entries);
  };

  const loadChapter = async (
    book: string,
    chapter: number,
    options?: {resetSelection?: boolean},
  ) => {
    const verses = await getChapterVerses(book, chapter);
    const nextContent = await getContentForReferences(
      verses.map(verse => verse.reference),
    );

    setChapterVerses(verses);
    setChapterContent(nextContent);

    if (options?.resetSelection !== false) {
      setSelectedReferences([]);
      setIsActionSheetOpen(false);
      setActiveReference(null);
    }
  };

  const runSearch = async (query: string) => {
    const trimmedQuery = query.trim();
    if (trimmedQuery.length < 2) {
      setSearchResults([]);
      setSearchContent({});
      return;
    }

    const results = await searchVerses(trimmedQuery);
    const nextContent = await getContentForReferences(
      results.map(verse => verse.reference),
    );

    setSearchResults(results);
    setSearchContent(nextContent);
  };

  const refreshVisibleData = async () => {
    if (selectedBook) {
      await loadChapter(selectedBook, selectedChapter, {
        resetSelection: false,
      });
    }

    if (searchQuery.trim().length >= 2) {
      await runSearch(searchQuery);
    }

    await Promise.all([loadSummary(), loadLibraryEntriesState()]);
  };

  const handleBookPress = async (book: string) => {
    try {
      setIsMutating(true);
      const nextChapters = await getChaptersForBook(book);
      const nextChapter = nextChapters[0] ?? 1;

      setSelectedBook(book);
      setSelectedChapter(nextChapter);
      setChapters(nextChapters);
      await loadChapter(book, nextChapter);
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Unable to change book.',
      );
    } finally {
      setIsMutating(false);
    }
  };

  const handleChapterPress = async (chapter: number) => {
    try {
      setIsMutating(true);
      setSelectedChapter(chapter);
      await loadChapter(selectedBook, chapter);
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Unable to change chapter.',
      );
    } finally {
      setIsMutating(false);
    }
  };

  const handleTestamentChange = async (testament: 'old' | 'new') => {
    setSelectedTestament(testament);

    const matchingBooks = books.filter(book =>
      testament === 'old' ? book.bookOrder <= 38 : book.bookOrder >= 39,
    );
    const firstBookInTestament = matchingBooks[0]?.name;

    if (!firstBookInTestament || firstBookInTestament === selectedBook) {
      return;
    }

    await handleBookPress(firstBookInTestament);
  };

  const toggleVerseSelection = (reference: string) => {
    setSelectedReferences(current => {
      const next = current.includes(reference)
        ? current.filter(item => item !== reference)
        : [...current, reference];

      if (next.length === 0) {
        setIsActionSheetOpen(false);
      }

      return next;
    });
  };

  const handleVersePress = (reference: string) => {
    toggleVerseSelection(reference);
  };

  const handleNavigateToVerse = (reference: string) => {
    setActiveReference(reference);
  };

  const getActionTargets = () => {
    if (selectionMode) {
      return selectedReferences;
    }

    return focusReference ? [focusReference] : [];
  };

  const isSingleFocusedBookmarked = focusReference
    ? (visibleContent[focusReference] ??
        chapterContent[focusReference] ??
        EMPTY_VERSE_STATE
      ).bookmark
    : false;

  const bookmarkActionLabel =
    selectedLanguage === 'ta'
      ? selectionMode
        ? allSelectedBookmarked
          ? 'புக்மார்க் நீக்கு'
          : 'தேர்வை புக்மார்க் செய்'
        : isSingleFocusedBookmarked
          ? 'புக்மார்க் நீக்கு'
          : 'வசனத்தை புக்மார்க் செய்'
      : selectionMode
        ? allSelectedBookmarked
          ? 'Remove bookmark'
          : 'Bookmark selection'
        : isSingleFocusedBookmarked
          ? 'Remove bookmark'
          : 'Bookmark verse';

  const handleBookmarkAction = async () => {
    const targetReferences = getActionTargets();

    if (!targetReferences.length) {
      return;
    }

    const shouldBookmark = selectionMode
      ? !allSelectedBookmarked
      : !isSingleFocusedBookmarked;

    try {
      setIsMutating(true);
      await setBookmarks(targetReferences, shouldBookmark);
      await refreshVisibleData();
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Unable to update bookmarks.',
      );
    } finally {
      setIsMutating(false);
    }
  };

  const handleHighlightAction = async (color: HighlightColor) => {
    const targetReferences = getActionTargets();

    if (!targetReferences.length) {
      return;
    }

    try {
      setIsMutating(true);
      await applyHighlight(targetReferences, color);
      await refreshVisibleData();
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Unable to save highlight.',
      );
    } finally {
      setIsMutating(false);
    }
  };

  const handleClearHighlight = async () => {
    const targetReferences = getActionTargets();

    if (!targetReferences.length) {
      return;
    }

    try {
      setIsMutating(true);
      await clearHighlight(targetReferences);
      await refreshVisibleData();
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Unable to clear highlight.',
      );
    } finally {
      setIsMutating(false);
    }
  };

  const handleSaveNote = async () => {
    const targetReferences = getActionTargets();

    if (!targetReferences.length) {
      return;
    }

    try {
      setIsMutating(true);
      await Promise.all(
        targetReferences.map(reference => saveNote(reference, noteDraft)),
      );
      await refreshVisibleData();
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Unable to save note.',
      );
    } finally {
      setIsMutating(false);
    }
  };

  const handleDeleteBookmark = async (verseRef: string) => {
    try {
      setIsMutating(true);
      await deleteBookmark(verseRef);
      await refreshVisibleData();
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Unable to delete bookmark.',
      );
    } finally {
      setIsMutating(false);
    }
  };

  const handleDeleteHighlight = async (verseRef: string) => {
    try {
      setIsMutating(true);
      await deleteHighlight(verseRef);
      await refreshVisibleData();
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Unable to delete highlight.',
      );
    } finally {
      setIsMutating(false);
    }
  };

  const handleDeleteNote = async (verseRef: string) => {
    try {
      setIsMutating(true);
      await deleteNote(verseRef);
      await refreshVisibleData();
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Unable to delete note.',
      );
    } finally {
      setIsMutating(false);
    }
  };

  const handleLibraryEntryPress = async (entry: LibraryEntry) => {
    try {
      setIsMutating(true);
      setActiveTab('bible');
      setSearchQuery('');
      setSelectedReferences([]);
      setIsActionSheetOpen(false);

      const entryBookMeta = books.find(book => book.name === entry.book);
      if (entryBookMeta) {
        setSelectedTestament(entryBookMeta.bookOrder <= 38 ? 'old' : 'new');
      }

      if (entry.book !== selectedBook) {
        const nextChapters = await getChaptersForBook(entry.book);
        setSelectedBook(entry.book);
        setChapters(nextChapters);
      }

      if (entry.book !== selectedBook || entry.chapter !== selectedChapter) {
        setSelectedChapter(entry.chapter);
        await loadChapter(entry.book, entry.chapter);
      }

      setActiveReference(entry.reference);
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Unable to open saved verse.',
      );
    } finally {
      setIsMutating(false);
    }
  };

  const handleMarkDayComplete = (plan: Plan) => {
    setPlanProgress(current => ({
      ...current,
      [plan.id]: Math.min((current[plan.id] ?? 0) + 1, plan.duration),
    }));
  };

  const handleResetPlan = (plan: Plan) => {
    setPlanProgress(current => ({
      ...current,
      [plan.id]: 0,
    }));
  };

  const handleStartPlan = async (plan: Plan) => {
    try {
      setIsMutating(true);

      const completedDays = planProgress[plan.id] ?? 0;
      const schedule = PLAN_SCHEDULES[plan.id] ?? [];
      const nextReadingDay = Math.min(completedDays + 1, Math.max(schedule.length, 1));
      const target = getReadingTarget(schedule[nextReadingDay - 1]);

      if (!target) {
        setErrorMessage('Unable to open this reading plan.');
        return;
      }

      setActiveTab('bible');
      setSearchQuery('');
      setSearchResults([]);
      setSearchContent({});
      setSelectedReferences([]);
      setIsActionSheetOpen(false);
      setActiveReference(null);

      const entryBookMeta = books.find(book => book.name === target.book);
      if (entryBookMeta) {
        setSelectedTestament(entryBookMeta.bookOrder <= 38 ? 'old' : 'new');
      }

      const nextChapters = await getChaptersForBook(target.book);
      setSelectedBook(target.book);
      setSelectedChapter(target.chapter);
      setChapters(nextChapters);
      await loadChapter(target.book, target.chapter);

      setPlanProgress(current => ({
        ...current,
        [plan.id]: completedDays,
      }));
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : 'Unable to open reading plan.',
      );
    } finally {
      setIsMutating(false);
    }
  };

  const shouldShowBottomSheet =
    activeTab === 'bible' &&
    isActionSheetOpen &&
    selectedReferences.length > 0;

  useEffect(() => {
    if (shouldShowBottomSheet) {
      if (!isBottomSheetMounted) {
        setIsBottomSheetMounted(true);
      }

      Animated.timing(bottomSheetTranslateY, {
        toValue: 0,
        duration: 220,
        useNativeDriver: true,
      }).start();
      return;
    }

    if (!isBottomSheetMounted) {
      return;
    }

    Animated.timing(bottomSheetTranslateY, {
      toValue: SHEET_HIDDEN_OFFSET,
      duration: 200,
      useNativeDriver: true,
    }).start(({finished}) => {
      if (finished) {
        setIsBottomSheetMounted(false);
      }
    });
  }, [
    bottomSheetTranslateY,
    isBottomSheetMounted,
    shouldShowBottomSheet,
  ]);

  if (isLoading) {
    return <LoadingPage isDarkMode={isDarkMode} />;
  }

  return (
    <ReaderPage
      errorMessage={errorMessage}
      books={books}
      chapters={chapters}
      selectedBook={selectedBook}
      selectedChapter={selectedChapter}
      chapterVerses={chapterVerses}
      selectionMode={selectionMode}
      selectedReferences={selectedReferences}
      activeReference={activeReference}
      searchQuery={searchQuery}
      activeTab={activeTab}
      visibleVerses={visibleVerses}
      visibleContent={visibleContent}
      focusReference={focusReference}
      isBottomSheetMounted={isBottomSheetMounted}
      shouldShowBottomSheet={shouldShowBottomSheet}
      bottomSheetTranslateY={bottomSheetTranslateY}
      isMutating={isMutating}
      bookmarkActionLabel={bookmarkActionLabel}
      highlightOptions={HIGHLIGHT_OPTIONS}
      noteDraft={noteDraft}
      summary={summary}
      libraryEntries={libraryEntries}
      planProgress={planProgress}
      selectedTestament={selectedTestament}
      selectedLanguage={selectedLanguage}
      onToggleSelectionMode={() => {
        setSelectedReferences([]);
        setActiveReference(null);
        setIsActionSheetOpen(false);
      }}
      onOpenBottomSheet={() => setIsActionSheetOpen(true)}
      onSearchChange={text => {
        setSearchQuery(text);
        if (text.trim().length >= 2) {
          setActiveTab('bible');
        }
      }}
      onBookPress={book => {
        void handleBookPress(book);
      }}
      onChapterPress={chapter => {
        void handleChapterPress(chapter);
      }}
      onVersePress={handleVersePress}
      onNavigateToVerse={handleNavigateToVerse}
      onCloseBottomSheet={() => setIsActionSheetOpen(false)}
      onBookmarkAction={() => {
        void handleBookmarkAction();
      }}
      onHighlightAction={color => {
        void handleHighlightAction(color);
      }}
      onClearHighlight={() => {
        void handleClearHighlight();
      }}
      onNoteChange={setNoteDraft}
      onSaveNote={() => {
        void handleSaveNote();
      }}
      onDeleteBookmark={verseRef => {
        void handleDeleteBookmark(verseRef);
      }}
      onDeleteHighlight={verseRef => {
        void handleDeleteHighlight(verseRef);
      }}
      onDeleteNote={verseRef => {
        void handleDeleteNote(verseRef);
      }}
      onLibraryEntryPress={entry => {
        void handleLibraryEntryPress(entry);
      }}
      onTestamentChange={testament => {
        void handleTestamentChange(testament);
      }}
      onSettingsPress={() => {
        setSelectedLanguage(current => (current === 'en' ? 'ta' : 'en'));
        setSelectedTestament('old');
        setActiveTab('home');
        setSearchQuery('');
      }}
      onStartPlan={plan => {
        void handleStartPlan(plan);
      }}
      onMarkDayComplete={handleMarkDayComplete}
      onResetPlan={handleResetPlan}
      onTabChange={setActiveTab}
    />
  );
}

export default App;
