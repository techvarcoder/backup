module.exports = {
  assets: [
    './src/assets/fonts',
    './node_modules/react-native-vector-icons/Fonts/MaterialCommunityIcons.ttf',
  ],
};
