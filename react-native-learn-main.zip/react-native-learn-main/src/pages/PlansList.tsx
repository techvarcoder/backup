import React from 'react';
import {
  FlatList,
  ImageBackground,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons.js';

const planBannerImage = require('../imgs/banner-plan-page.png');

export type Plan = {
  id: string;
  title: string;
  shortTitle: string;
  description: string;
  duration: number;
  durationLabel: string;
  frequency: string;
  dailyTime: string;
  participants: number;
  badgeValue: string;
  badgeUnit: string;
  badgeColor: string;
  heroImage: string;
};

export type PlansListProps = {
  selectedLanguage: 'en' | 'ta' | null;
  onBackPress: () => void;
  onPlanSelect: (plan: Plan) => void;
};

export const PLANS: Plan[] = [
  {
    id: 'plan-30',
    title: '30 Day Bible Reading Plan',
    shortTitle: '30 Day Bible Reading Plan',
    description: 'Build a habit. Start small. Stay consistent.',
    duration: 30,
    durationLabel: '30 Days',
    frequency: 'Daily',
    dailyTime: '15-20',
    participants: 128000,
    badgeValue: '30',
    badgeUnit: 'DAYS',
    badgeColor: '#F47E5A',
    heroImage: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'plan-60',
    title: '60 Day Bible Reading Plan',
    shortTitle: '60 Day Bible Reading Plan',
    description: 'Go deeper. Understand more.',
    duration: 60,
    durationLabel: '60 Days',
    frequency: 'Daily',
    dailyTime: '15-20',
    participants: 96000,
    badgeValue: '60',
    badgeUnit: 'DAYS',
    badgeColor: '#69B96F',
    heroImage: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'plan-90',
    title: '90 Day Bible Reading Plan',
    shortTitle: '90 Day Bible Reading Plan',
    description: 'Strengthen your faith. Transform your life.',
    duration: 90,
    durationLabel: '90 Days',
    frequency: 'Daily',
    dailyTime: '15-20',
    participants: 75000,
    badgeValue: '90',
    badgeUnit: 'DAYS',
    badgeColor: '#8C7AE7',
    heroImage: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'plan-6months',
    title: '6 Months Bible Reading Plan',
    shortTitle: '6 Months Bible Reading Plan',
    description: 'Half a year of growing with God.',
    duration: 180,
    durationLabel: '6 Months',
    frequency: 'Daily',
    dailyTime: '15-20',
    participants: 52000,
    badgeValue: '6',
    badgeUnit: 'MONTHS',
    badgeColor: '#5B95E0',
    heroImage: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
  },
  {
    id: 'plan-1year',
    title: '1 Year Bible Reading Plan',
    shortTitle: '1 Year Bible Reading Plan',
    description: 'Read the Bible in 365 days.',
    duration: 365,
    durationLabel: '365 Days',
    frequency: 'Daily',
    dailyTime: '15-20',
    participants: 210000,
    badgeValue: '1',
    badgeUnit: 'YEAR',
    badgeColor: '#E4B65A',
    heroImage: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80',
  },
];

const FILTERS = ['All Plans', 'Bible in a Year', 'New Testament', 'Topical'];

function PlansList({selectedLanguage, onBackPress, onPlanSelect}: PlansListProps) {
  const [activeFilter, setActiveFilter] = React.useState('All Plans');
  const isTamil = selectedLanguage === 'ta';

  const copy = isTamil
    ? {
        title: 'வாசிப்புத் திட்டங்கள்',
        subtitle: 'கட்டமைக்கப்பட்ட வேத வாசிப்புத் திட்டங்களுடன் உங்கள் விசுவாசத்தில் வளருங்கள்.',
        heroKicker: 'நிலையாக இருங்கள்.',
        heroTitle: 'ஆவிக்குரிய வளர்ச்சி.',
        heroSubtitle: 'ஒரு திட்டத்தைத் தேர்ந்தெடுத்து தேவனுடைய வார்த்தையில் ஒரு தினசரி பழக்கத்தை உருவாக்குங்கள்.',
        popularPlans: 'பிரபலமான திட்டங்கள்',
        viewAll: 'அனைத்தும்',
        rewardTitle: 'ஒரு திட்டத்தை முடித்து ஒரு பதக்கம் பெறுங்கள்.',
        rewardBody: 'தொடர்ச்சியாக இருந்து தேவனுடைய வார்த்தையில் வளர்ச்சியை சேகரியுங்கள்.',
      }
    : {
        title: 'Reading Plans',
        subtitle: 'Grow your faith with structured Bible reading plans.',
        heroKicker: 'Stay consistent.',
        heroTitle: 'Grow spiritually.',
        heroSubtitle: 'Choose a plan and build a daily habit in God\'s Word.',
        popularPlans: 'Popular Plans',
        viewAll: 'View All',
        rewardTitle: 'Complete a plan. Earn a badge.',
        rewardBody: 'Stay consistent and collect achievements as you grow in God\'s Word.',
      };

  const renderPlan = ({item}: {item: Plan}) => (
    <Pressable style={styles.planCard} onPress={() => onPlanSelect(item)}>
      <View style={[styles.planBadge, {backgroundColor: item.badgeColor}]}> 
        <MaterialCommunityIcons name="calendar-blank-outline" size={13} color="#FFFFFF" style={styles.planBadgeBook} />
        <Text style={styles.planBadgeValue}>{item.badgeValue}</Text>
        <Text style={styles.planBadgeUnit}>{item.badgeUnit}</Text>
      </View>

      <View style={styles.planContent}>
        <Text style={styles.planTitle}>{item.shortTitle}</Text>
        <Text style={styles.planDescription}>{item.description}</Text>
        <View style={styles.planMetaRow}>
          <View style={styles.planMetaItem}>
            <MaterialCommunityIcons name="book-open-outline" size={14} color="#7A7D84" />
            <Text style={styles.planMetaText}>{item.durationLabel}</Text>
          </View>
          <View style={styles.planMetaItem}>
            <MaterialCommunityIcons name="calendar-check-outline" size={14} color="#7A7D84" />
            <Text style={styles.planMetaText}>Daily</Text>
          </View>
          <View style={styles.planMetaItem}>
            <MaterialCommunityIcons name="account-group-outline" size={14} color="#7A7D84" />
            <Text style={styles.planMetaText}>{(item.participants / 1000).toFixed(0)}K</Text>
          </View>
        </View>
      </View>

      <MaterialCommunityIcons name="chevron-right" size={28} color="#ABA197" style={styles.planArrow} />
    </Pressable>
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <FlatList
        data={PLANS}
        renderItem={renderPlan}
        keyExtractor={item => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <>
            <View style={styles.headerRow}>
              <Pressable onPress={onBackPress} style={styles.backShell}>
                <MaterialCommunityIcons name="chevron-left" size={30} color="#1D1D1D" style={styles.backIcon} />
              </Pressable>
              <View style={styles.headerSpacer} />
              <Pressable style={styles.crownShell}>
                <MaterialCommunityIcons name="crown-outline" size={22} color="#D39533" style={styles.crownIcon} />
              </Pressable>
            </View>

            <Text style={styles.screenTitle}>{copy.title}</Text>
            <Text style={styles.screenSubtitle}>{copy.subtitle}</Text>

            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.filterRow}>
              {FILTERS.map(filter => {
                const isActive = activeFilter === filter;
                return (
                  <Pressable
                    key={filter}
                    onPress={() => setActiveFilter(filter)}
                    style={[styles.filterPill, isActive && styles.filterPillActive]}>
                    <Text style={[styles.filterText, isActive && styles.filterTextActive]}>{filter}</Text>
                  </Pressable>
                );
              })}
            </ScrollView>

            <ImageBackground
              source={planBannerImage}
              style={styles.heroCard}
              imageStyle={styles.heroImage}
            />

            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>{copy.popularPlans}</Text>
              <Pressable>
                <Text style={styles.viewAllText}>{copy.viewAll}</Text>
              </Pressable>
            </View>
          </>
        }
        ListFooterComponent={
          <Pressable style={styles.rewardCard}>
            <MaterialCommunityIcons name="trophy-outline" size={30} color="#D79A3A" style={styles.rewardIcon} />
            <View style={styles.rewardContent}>
              <Text style={styles.rewardTitle}>{copy.rewardTitle}</Text>
              <Text style={styles.rewardBody}>{copy.rewardBody}</Text>
            </View>
            <MaterialCommunityIcons name="chevron-right" size={28} color="#C4872E" style={styles.rewardArrow} />
          </Pressable>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FBF7F1',
  },
  listContent: {
    paddingHorizontal: 20,
    paddingBottom: 28,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  backShell: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  backIcon: {
    fontSize: 28,
    color: '#1D1D1D',
  },
  headerSpacer: {
    flex: 1,
  },
  crownShell: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    shadowColor: '#A98035',
    shadowOffset: {width: 0, height: 8},
    shadowOpacity: 0.1,
    shadowRadius: 18,
    elevation: 2,
  },
  crownIcon: {
    fontSize: 22,
    color: '#D39533',
  },
  screenTitle: {
    marginTop: 14,
    fontSize: 29,
    lineHeight: 35,
    color: '#1F2228',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '600',
  },
  screenSubtitle: {
    marginTop: 6,
    marginBottom: 18,
    fontSize: 14,
    lineHeight: 21,
    color: '#5E636B',
    fontFamily: 'Inter_400Regular',
  },
  filterRow: {
    gap: 12,
    paddingBottom: 16,
  },
  filterPill: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 999,
    backgroundColor: '#F4EFE8',
  },
  filterPillActive: {
    backgroundColor: '#B97B28',
  },
  filterText: {
    fontSize: 14,
    lineHeight: 18,
    color: '#534E47',
    fontFamily: 'Inter_400Regular',
    fontWeight: '500',
  },
  filterTextActive: {
    color: '#FFFFFF',
  },
  heroCard: {
    height: 218,
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: '#E7C88C',
    marginBottom: 20,
  },
  heroImage: {
    borderRadius: 18,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 18,
    lineHeight: 24,
    color: '#1E2227',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '600',
  },
  viewAllText: {
    fontSize: 13,
    lineHeight: 18,
    color: '#C4872E',
    fontFamily: 'Inter_400Regular',
    fontWeight: '600',
  },
  planCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    paddingHorizontal: 12,
    paddingVertical: 12,
    marginBottom: 12,
    shadowColor: '#A18046',
    shadowOffset: {width: 0, height: 10},
    shadowOpacity: 0.08,
    shadowRadius: 20,
    elevation: 2,
  },
  planBadge: {
    width: 74,
    height: 74,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  planBadgeBook: {
    fontSize: 12,
    color: '#FFFFFF',
    marginBottom: 1,
  },
  planBadgeValue: {
    fontSize: 26,
    lineHeight: 30,
    color: '#FFFFFF',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '700',
  },
  planBadgeUnit: {
    marginTop: 2,
    fontSize: 11,
    lineHeight: 13,
    color: '#FFFFFF',
    fontFamily: 'Inter_400Regular',
    fontWeight: '700',
  },
  planContent: {
    flex: 1,
  },
  planTitle: {
    fontSize: 15,
    lineHeight: 21,
    color: '#1A1D22',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '600',
  },
  planDescription: {
    marginTop: 3,
    fontSize: 13,
    lineHeight: 18,
    color: '#666B73',
    fontFamily: 'Inter_400Regular',
  },
  planMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 12,
    marginTop: 10,
  },
  planMetaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  planMetaText: {
    fontSize: 12,
    lineHeight: 16,
    color: '#70737A',
    fontFamily: 'Inter_400Regular',
  },
  planArrow: {
    marginLeft: 10,
  },
  rewardCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FBF3E6',
    borderRadius: 18,
    paddingHorizontal: 16,
    paddingVertical: 18,
    marginTop: 8,
  },
  rewardIcon: {
    marginRight: 14,
  },
  rewardContent: {
    flex: 1,
  },
  rewardTitle: {
    fontSize: 18,
    lineHeight: 22,
    color: '#22262C',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '600',
  },
  rewardBody: {
    marginTop: 4,
    fontSize: 13,
    lineHeight: 19,
    color: '#69685F',
    fontFamily: 'Inter_400Regular',
  },
  rewardArrow: {
    marginLeft: 10,
    fontSize: 28,
    lineHeight: 28,
    color: '#C4872E',
  },
});

export default PlansList;
