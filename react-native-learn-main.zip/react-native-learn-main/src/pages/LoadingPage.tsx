import React from 'react';
import {
  ActivityIndicator,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';

type LoadingPageProps = {
  isDarkMode: boolean;
};

function LoadingPage({isDarkMode}: LoadingPageProps) {
  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
      <View style={styles.centerState}>
        <ActivityIndicator size="large" color="#9E5A27" />
        <Text style={styles.loadingTitle}>Preparing your local Bible</Text>
        <Text style={styles.loadingText}>
          Seeding a persistent SQLite library and your local content store.
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F7F1EA',
  },
  centerState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
    gap: 12,
  },
  loadingTitle: {
    fontSize: 22,
    fontWeight: '700',
    fontFamily: 'Poppins_500Medium',
    color: '#2B1D18',
  },
  loadingText: {
    textAlign: 'center',
    color: '#6B5A50',
    fontSize: 15,
    lineHeight: 22,
    fontFamily: 'Inter_400Regular',
  },
});

export default LoadingPage;
