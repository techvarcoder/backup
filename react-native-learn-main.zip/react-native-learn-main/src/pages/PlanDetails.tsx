import React from 'react';
import {
  Alert,
  ImageBackground,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons.js';
import type {Plan} from './PlansList';
import {PLAN_SCHEDULES} from '../data/readingPlanSchedules';

const planDetailsHeroImage = require('../imgs/plan-page-30-60.png');

export type PlanDetailsProps = {
  plan: Plan;
  completedDays: number;
  selectedLanguage: 'en' | 'ta' | null;
  onBackPress: () => void;
  onStartPlan: (plan: Plan) => void;
  onMarkDayComplete: (plan: Plan) => void;
  onResetPlan: (plan: Plan) => void;
};

const MONTH_NAMES = [
  'January','February','March','April','May','June',
  'July','August','September','October','November','December',
];

function PlanDetails({
  plan,
  completedDays,
  selectedLanguage,
  onBackPress,
  onStartPlan,
  onMarkDayComplete,
  onResetPlan,
}: PlanDetailsProps) {
  const isTamil = selectedLanguage === 'ta';
  const now = new Date();
  const totalDays = plan.duration;
  const safeCompletedDays = Math.max(0, Math.min(completedDays, totalDays));
  // Only show current day marker if plan has been started (at least 1 day read)
  const hasStarted = safeCompletedDays > 0;
  const currentDay = hasStarted ? Math.min(safeCompletedDays + 1, totalDays) : 1;
  const isFullyComplete = safeCompletedDays >= totalDays;
  const monthName = MONTH_NAMES[now.getMonth()];
  const schedule = PLAN_SCHEDULES[plan.id] ?? [];
  const todayReading = schedule[Math.min(safeCompletedDays, Math.max(schedule.length - 1, 0))];
  const previewDays = schedule.slice(0, 5);
  const progressPercent = totalDays > 0 ? Math.round((safeCompletedDays / totalDays) * 100) : 0;

  const copy = isTamil
    ? {
        about: 'இந்த திட்டத்தைப் பற்றி',
        benefits: 'நீங்கள் பெறுவது',
        preview: 'திட்ட முன்னோட்டம்',
        startPlan: 'திட்டத்தைத் தொடங்குக',
        saveForLater: 'பின்னரில் சேமி',
        yourProgress: 'உங்கள் முன்னேற்றம்',
        dailyProgress: 'தினசரி முன்னேற்றம்',
        completed: 'முடிந்தது',
        today: 'இன்று',
        upcoming: 'வரவுள்ளது',
        todaysReading: 'இன்றைய வாசிப்பு',
        readNow: 'இப்போது வாசிக்க',
        resetPlan: 'திட்டத்தை மீட்டமை',
        aboutText:
          `இந்த ${plan.durationLabel} திட்டம் ஒழுங்கான வேதாகம வாசிப்பு பழக்கத்தை உருவாக்க உதவுகிறது. பழைய மற்றும் புதிய ஏற்பாட்டிலிருந்து முக்கிய பகுதிகளை நீங்கள் பயில்வீர்கள்.`,
        benefitsList: [
          'பழைய மற்றும் புதிய ஏற்பாட்டின் சமநிலை',
          '15-20 நிமிட குறுகிய வாசிப்புகள்',
          'தினசரி சிந்தனைக்கான ஊக்கம்',
          'ஆவிக்குரிய அடித்தளத்தை வலுப்படுத்தும்',
        ],
      }
    : {
        about: 'About This Plan',
        benefits: 'What You’ll Get',
        preview: 'Plan Preview',
        startPlan: 'Start Plan',
        saveForLater: 'Save for Later',
        yourProgress: 'Your Progress',
        dailyProgress: 'Daily Progress',
        completed: 'Completed',
        today: 'Today',
        upcoming: 'Upcoming',
        todaysReading: 'Today’s Reading',
        readNow: 'Read Now',
        resetPlan: 'Reset Plan',
        aboutText:
          `This ${plan.durationLabel} plan is designed to help you build a daily Bible reading habit. You'll explore key passages from both the Old and New Testament.`,
        benefitsList: [
          'A balanced mix of Old & New Testament',
          'Short daily readings (15-20 mins)',
          'Encouraging thoughts to reflect on',
          'Build a strong spiritual foundation',
        ],
      };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.topBar}>
          <Pressable onPress={onBackPress} style={styles.topIconShell}>
            <MaterialCommunityIcons name="chevron-left" size={30} color="#1D1D1D" style={styles.topIcon} />
          </Pressable>
          <Pressable style={styles.topIconShell}>
            <MaterialCommunityIcons name="share-variant-outline" size={21} color="#1D1D1D" style={styles.topShare} />
          </Pressable>
        </View>

        <ImageBackground source={planDetailsHeroImage} style={styles.heroCard} imageStyle={styles.heroImage}>
          <View style={styles.heroGlow} />
          <View style={styles.heroTextWrap}>
            <Text style={styles.heroTitle}>{plan.title}</Text>
            <Text style={styles.heroSubtitle}>{plan.description}</Text>
          </View>
        </ImageBackground>

        <View style={styles.statSheet}>
          <View style={styles.statCell}>
            <MaterialCommunityIcons name="book-open-outline" size={19} color="#BF842B" style={styles.statGlyph} />
            <Text style={styles.statValue}>{plan.duration}</Text>
            <Text style={styles.statLabel}>Days</Text>
          </View>
          <View style={styles.statCell}>
            <MaterialCommunityIcons name="calendar-check-outline" size={19} color="#BF842B" style={styles.statGlyph} />
            <Text style={styles.statValue}>Daily</Text>
            <Text style={styles.statLabel}>Frequency</Text>
          </View>
          <View style={styles.statCell}>
            <MaterialCommunityIcons name="chart-line" size={19} color="#BF842B" style={styles.statGlyph} />
            <Text style={styles.statValue}>{plan.dailyTime}</Text>
            <Text style={styles.statLabel}>Min / Day</Text>
          </View>
          <View style={styles.statCell}>
            <MaterialCommunityIcons name="account-group-outline" size={19} color="#BF842B" style={styles.statGlyph} />
            <Text style={styles.statValue}>{(plan.participants / 1000).toFixed(0)}K</Text>
            <Text style={styles.statLabel}>Participants</Text>
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{copy.about}</Text>
          <Text style={styles.bodyText}>{copy.aboutText}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{copy.benefits}</Text>
          {copy.benefitsList.map(item => (
            <View key={item} style={styles.benefitRow}>
              <MaterialCommunityIcons name="check-circle-outline" size={16} color="#C4862A" style={styles.benefitBullet} />
              <Text style={styles.benefitText}>{item}</Text>
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{copy.preview}</Text>
          <View style={styles.previewRow}>
            {previewDays.map((d, i) => {
              const isActive = i === 0;
              return (
                <View key={d.day} style={[styles.previewChip, isActive && styles.previewChipActive]}>
                  <Text style={[styles.previewDayLabel, isActive && styles.previewDayLabelActive]}>Day</Text>
                  <Text style={[styles.previewDayValue, isActive && styles.previewDayValueActive]}>{d.day}</Text>
                </View>
              );
            })}
            <View style={styles.previewLockedChip}>
              <MaterialCommunityIcons name="lock-outline" size={18} color="#8A847B" style={styles.previewLockedText} />
            </View>
          </View>
          {previewDays[0] && (
            <Text style={styles.previewPassageHint} numberOfLines={1}>
              Day 1: {previewDays[0].passages.join(', ')}
            </Text>
          )}
        </View>

        <Pressable style={styles.primaryButton} onPress={() => onStartPlan(plan)}>
          <Text style={styles.primaryButtonText}>{copy.startPlan}</Text>
        </Pressable>

        <Pressable style={styles.secondaryButton} onPress={() => Alert.alert(copy.saveForLater)}>
          <View style={styles.secondaryButtonContent}>
            <MaterialCommunityIcons name="bookmark-outline" size={16} color="#A56B1E" />
            <Text style={styles.secondaryButtonText}>{copy.saveForLater}</Text>
          </View>
        </Pressable>

        <View style={styles.progressCard}>
          <View style={styles.progressHeader}>
            <Pressable onPress={onBackPress} style={styles.inlineIcon}>
              <MaterialCommunityIcons name="chevron-left" size={24} color="#2B2B2B" style={styles.inlineIconText} />
            </Pressable>
            <Text style={styles.progressPlanTitle}>{plan.title}</Text>
            <Pressable style={styles.inlineIcon}>
              <MaterialCommunityIcons name="cog-outline" size={20} color="#2B2B2B" style={styles.inlineIconText} />
            </Pressable>
          </View>

          <View style={styles.progressSummaryCard}>
            <View style={styles.progressSummaryRow}>
              <Text style={styles.progressHeading}>{copy.yourProgress}</Text>
              <Text style={styles.progressNote}>Day {currentDay} of {totalDays}</Text>
            </View>
            <View style={styles.progressTrack}>
              <View style={[styles.progressFill, {width: `${progressPercent}%`}]} />
            </View>
            <View style={styles.progressSummaryRow}>
              <Text style={styles.progressNote}>{progressPercent}% Completed</Text>
              <Text style={styles.progressNote}>{safeCompletedDays}/{totalDays} Days</Text>
            </View>
          </View>

          <View style={styles.dailyHeader}>
            <Text style={styles.progressHeading}>{copy.dailyProgress}</Text>
            <View style={styles.legendRow}>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, {backgroundColor: '#D7EAD0'}]} />
                <Text style={styles.legendText}>{copy.completed}</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, {backgroundColor: '#B97B28'}]} />
                <Text style={styles.legendText}>{copy.today}</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendDot, {backgroundColor: '#ECE7E1'}]} />
                <Text style={styles.legendText}>{copy.upcoming}</Text>
              </View>
            </View>
          </View>

          <View style={styles.dayGrid}>
            {Array.from({length: totalDays}, (_, index) => index + 1).map(day => {
              const isToday = hasStarted && day === currentDay;
              const isCompleted = day <= safeCompletedDays;
              return (
                <Pressable
                  key={day}
                  style={[
                    styles.dayCell,
                    isCompleted && styles.dayCellCompleted,
                    isToday && styles.dayCellToday,
                  ]}>
                  <Text style={[styles.dayCellText, isToday && styles.dayCellTextToday]}>
                    {isCompleted ? '✓' : day}
                  </Text>
                </Pressable>
              );
            })}
          </View>

          <Text style={styles.progressHeading}>{copy.todaysReading}</Text>
          <View style={styles.readingCard}>
            <View style={styles.readingIconWrap}>
              <MaterialCommunityIcons name="book-open-outline" size={19} color="#A9701E" style={styles.readingIcon} />
            </View>
            <View style={styles.readingTextWrap}>
              <Text style={styles.readingMeta}>Day {hasStarted ? currentDay : 1} • {monthName} {now.getDate()}</Text>
              <Text style={styles.readingTitle} numberOfLines={2}>
                {todayReading ? todayReading.passages.join(', ') : '—'}
              </Text>
              <Text style={styles.readingBody} numberOfLines={2}>
                {todayReading ? todayReading.theme : ''}
              </Text>
            </View>
            <MaterialCommunityIcons name="chevron-right" size={24} color="#9C958C" style={styles.readingArrow} />
          </View>

          <Pressable style={[styles.primaryButton, styles.readNowButton]} onPress={() => onStartPlan(plan)}>
            <Text style={styles.primaryButtonText}>{copy.readNow}</Text>
          </Pressable>

          {!isFullyComplete && (
            <Pressable
              style={styles.markCompleteButton}
              onPress={() => onMarkDayComplete(plan)}>
              <MaterialCommunityIcons name="check-circle-outline" size={20} color="#FFFFFF" />
              <Text style={styles.markCompleteText}>
                {isTamil ? 'இன்றைய வாசிப்பை முடித்தேன்' : 'Mark Today as Complete'}
              </Text>
            </Pressable>
          )}

          {safeCompletedDays > 0 && (
            <Pressable
              style={styles.resetPlanButton}
              onPress={() => onResetPlan(plan)}>
              <MaterialCommunityIcons name="restart" size={18} color="#A14B15" />
              <Text style={styles.resetPlanText}>{copy.resetPlan}</Text>
            </Pressable>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FBF7F1',
  },
  content: {
    paddingBottom: 24,
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingTop: 6,
    paddingBottom: 8,
  },
  topIconShell: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
  },
  topIcon: {
    fontSize: 28,
    color: '#1D1D1D',
  },
  topShare: {
    fontSize: 20,
    color: '#1D1D1D',
  },
  heroCard: {
    height: 252,
    marginHorizontal: 16,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    backgroundColor: '#E8C67F',
  },
  heroImage: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
  },
  heroGlow: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(248, 204, 110, 0.18)',
  },
  heroTextWrap: {
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingTop: 26,
  },
  heroTitle: {
    fontSize: 22,
    lineHeight: 28,
    color: '#2B241E',
    textAlign: 'center',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '600',
  },
  heroSubtitle: {
    marginTop: 10,
    fontSize: 14,
    lineHeight: 20,
    color: '#40352C',
    textAlign: 'center',
    fontFamily: 'Inter_400Regular',
  },
  statSheet: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    marginHorizontal: 28,
    marginTop: -28,
    borderRadius: 18,
    paddingVertical: 16,
    paddingHorizontal: 8,
    shadowColor: '#8D6E37',
    shadowOffset: {width: 0, height: 10},
    shadowOpacity: 0.12,
    shadowRadius: 24,
    elevation: 3,
  },
  statCell: {
    flex: 1,
    alignItems: 'center',
  },
  statGlyph: {
    fontSize: 18,
    color: '#BF842B',
    marginBottom: 8,
  },
  statValue: {
    fontSize: 18,
    lineHeight: 22,
    color: '#23252A',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '600',
  },
  statLabel: {
    marginTop: 4,
    fontSize: 11,
    lineHeight: 14,
    color: '#7B7A78',
    textAlign: 'center',
    fontFamily: 'Inter_400Regular',
  },
  section: {
    paddingHorizontal: 20,
    marginTop: 18,
  },
  sectionTitle: {
    fontSize: 22,
    lineHeight: 26,
    color: '#1F2228',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '600',
    marginBottom: 10,
  },
  bodyText: {
    fontSize: 15,
    lineHeight: 24,
    color: '#4E5158',
    fontFamily: 'Inter_400Regular',
  },
  benefitRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  benefitBullet: {
    marginRight: 10,
    fontSize: 15,
    lineHeight: 20,
    color: '#C4862A',
  },
  benefitText: {
    flex: 1,
    fontSize: 15,
    lineHeight: 22,
    color: '#4E5158',
    fontFamily: 'Inter_400Regular',
  },
  previewRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  previewChip: {
    width: 54,
    height: 54,
    borderRadius: 14,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#EEE7DE',
    alignItems: 'center',
    justifyContent: 'center',
  },
  previewChipActive: {
    backgroundColor: '#B97B28',
    borderColor: '#B97B28',
  },
  previewDayLabel: {
    fontSize: 11,
    lineHeight: 13,
    color: '#79756D',
    fontFamily: 'Inter_400Regular',
  },
  previewDayLabelActive: {
    color: '#FFF4E8',
  },
  previewDayValue: {
    marginTop: 3,
    fontSize: 16,
    lineHeight: 20,
    color: '#24262A',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '600',
  },
  previewDayValueActive: {
    color: '#FFFFFF',
  },
  previewLockedChip: {
    width: 54,
    height: 54,
    borderRadius: 14,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#EEE7DE',
    alignItems: 'center',
    justifyContent: 'center',
  },
  previewLockedText: {
    fontSize: 16,
  },
  previewPassageHint: {
    marginTop: 8,
    fontSize: 12,
    lineHeight: 16,
    color: '#8A7E70',
    fontFamily: 'Inter_400Regular',
    fontStyle: 'italic',
  },
  primaryButton: {
    marginTop: 16,
    marginHorizontal: 20,
    height: 48,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#B97B28',
  },
  primaryButtonText: {
    fontSize: 15,
    lineHeight: 20,
    color: '#FFFFFF',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '600',
  },
  secondaryButton: {
    marginTop: 10,
    marginHorizontal: 20,
    height: 46,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: '#D8A050',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
  },
  secondaryButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  secondaryButtonText: {
    fontSize: 15,
    lineHeight: 20,
    color: '#A56B1E',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '500',
  },
  progressCard: {
    marginTop: 18,
    marginHorizontal: 16,
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderRadius: 22,
    backgroundColor: '#FFFFFF',
    shadowColor: '#8D6E37',
    shadowOffset: {width: 0, height: 10},
    shadowOpacity: 0.08,
    shadowRadius: 24,
    elevation: 2,
  },
  progressHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  inlineIcon: {
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  inlineIconText: {
    fontSize: 18,
    color: '#2B2B2B',
  },
  progressPlanTitle: {
    flex: 1,
    textAlign: 'center',
    fontSize: 18,
    lineHeight: 22,
    color: '#1E2227',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '600',
  },
  progressSummaryCard: {
    backgroundColor: '#FFFDFC',
    borderRadius: 16,
    padding: 14,
    borderWidth: 1,
    borderColor: '#F0EAE1',
    marginBottom: 16,
  },
  progressSummaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  progressHeading: {
    fontSize: 18,
    lineHeight: 22,
    color: '#1E2227',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '600',
    marginBottom: 10,
  },
  progressNote: {
    fontSize: 12,
    lineHeight: 16,
    color: '#7B7A78',
    fontFamily: 'Inter_400Regular',
  },
  progressTrack: {
    height: 6,
    borderRadius: 999,
    backgroundColor: '#ECE6DD',
    overflow: 'hidden',
    marginVertical: 10,
  },
  progressFill: {
    height: '100%',
    borderRadius: 999,
    backgroundColor: '#B97B28',
  },
  dailyHeader: {
    marginBottom: 10,
  },
  legendRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 16,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 999,
  },
  legendText: {
    fontSize: 11,
    lineHeight: 14,
    color: '#7B7A78',
    fontFamily: 'Inter_400Regular',
  },
  dayGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 18,
  },
  dayCell: {
    width: 38,
    height: 38,
    borderRadius: 999,
    backgroundColor: '#EEE9E3',
    alignItems: 'center',
    justifyContent: 'center',
  },
  dayCellCompleted: {
    backgroundColor: '#D7EAD0',
  },
  dayCellToday: {
    backgroundColor: '#B97B28',
  },
  dayCellText: {
    fontSize: 12,
    lineHeight: 14,
    color: '#45484E',
    fontFamily: 'Inter_400Regular',
    fontWeight: '600',
  },
  dayCellTextToday: {
    color: '#FFFFFF',
  },
  readingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFDFC',
    borderRadius: 16,
    padding: 14,
    borderWidth: 1,
    borderColor: '#F0EAE1',
  },
  readingIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F7EAD3',
    marginRight: 12,
  },
  readingIcon: {
    fontSize: 18,
  },
  readingTextWrap: {
    flex: 1,
  },
  readingMeta: {
    fontSize: 11,
    lineHeight: 14,
    color: '#8A867F',
    fontFamily: 'Inter_400Regular',
  },
  readingTitle: {
    marginTop: 3,
    fontSize: 14,
    lineHeight: 18,
    color: '#1C2025',
    fontFamily: 'Poppins_500Medium',
    fontWeight: '600',
  },
  readingBody: {
    marginTop: 4,
    fontSize: 12,
    lineHeight: 17,
    color: '#676B72',
    fontFamily: 'Inter_400Regular',
  },
  readingArrow: {
    marginLeft: 8,
    fontSize: 26,
    lineHeight: 26,
    color: '#9C958C',
  },
  readNowButton: {
    marginHorizontal: 0,
    marginTop: 14,
  },
  markCompleteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    paddingVertical: 14,
    marginTop: 14,
  },
  markCompleteText: {
    fontFamily: 'Poppins_500Medium',
    fontSize: 15,
    color: '#FFFFFF',
  },
  resetPlanButton: {
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#E7C9AF',
    backgroundColor: '#FFF4EA',
    borderRadius: 12,
    paddingVertical: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  resetPlanText: {
    fontFamily: 'Poppins_500Medium',
    fontSize: 14,
    color: '#A14B15',
  },
});

export default PlanDetails;
