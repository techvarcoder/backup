import React from 'react';
import {
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons.js';
import type {LibraryEntry} from '../types';
import type {Plan} from './PlansList';

type LibraryFilter = 'bookmark' | 'highlight' | 'note';

type HomeAppSearchProps = {
  selectedLanguage: 'en' | 'ta' | null;
  plans: Plan[];
  libraryEntries: LibraryEntry[];
  query: string;
  onQueryChange: (value: string) => void;
  onMicPress: () => void;
  isListening: boolean;
  onPlanPress: (plan: Plan) => void;
  onLibraryPress: (entry: LibraryEntry) => void;
  onLibraryFilterPress: (filter: LibraryFilter) => void;
};

function normalize(value: string) {
  return value.trim().toLowerCase();
}

function keywordMatchesQuery(keywords: string[], query: string) {
  return keywords.some(keyword => keyword.includes(query) || query.includes(keyword));
}

function HomeAppSearch({
  selectedLanguage,
  plans,
  libraryEntries,
  query,
  onQueryChange,
  onMicPress,
  isListening,
  onPlanPress,
  onLibraryPress,
  onLibraryFilterPress,
}: HomeAppSearchProps) {
  const isTamil = selectedLanguage === 'ta';

  const copy = isTamil
    ? {
        placeholder: 'திட்டங்கள் மற்றும் சேமிப்புகளில் தேடுங்கள்...',
        plans: 'திட்டங்கள்',
        library: 'நூலகம்',
        noResults: 'பொருத்தமான முடிவுகள் இல்லை.',
        saved: 'சேமிப்பு',
        highlights: 'ஹைலைட்',
        notes: 'குறிப்பு',
        openSaved: 'சேமிப்பை திறக்க',
        openHighlights: 'ஹைலைட்ஸை திறக்க',
        openNotes: 'குறிப்புகளை திறக்க',
      }
    : {
        placeholder: 'Search plans and saved library...',
        plans: 'Plans',
        library: 'Library',
        noResults: 'No matching results.',
        saved: 'Saved',
        highlights: 'Highlight',
        notes: 'Note',
        openSaved: 'Open Saved',
        openHighlights: 'Open Highlights',
        openNotes: 'Open Notes',
      };

  const normalizedQuery = normalize(query);
  const showResults = normalizedQuery.length >= 3;

  const planMatches = React.useMemo(() => {
    if (!showResults) {
      return [] as Plan[];
    }

    return plans
      .filter(plan => {
        const haystack = normalize(
          `${plan.title} ${plan.shortTitle} ${plan.description} ${plan.durationLabel}`,
        );
        return haystack.includes(normalizedQuery);
      })
      .slice(0, 5);
  }, [plans, normalizedQuery, showResults]);

  const libraryMatches = React.useMemo(() => {
    if (!showResults) {
      return [] as LibraryEntry[];
    }

    return libraryEntries
      .filter(item => {
        const noteText = item.note ?? '';
        const tags = [
          'library',
          'saved',
          'bookmark',
          item.highlightColor ? 'highlight' : '',
          item.note ? 'note' : '',
        ]
          .filter(Boolean)
          .join(' ');
        const haystack = normalize(
          `${item.reference} ${item.book} ${item.chapter} ${item.verse} ${item.text} ${noteText} ${tags}`,
        );
        return haystack.includes(normalizedQuery);
      })
      .slice(0, 6);
  }, [libraryEntries, normalizedQuery, showResults]);

  const libraryShortcutMatches = React.useMemo(() => {
    if (!showResults) {
      return [] as Array<{key: string; filter: LibraryFilter; label: string; icon: string}>;
    }

    const compact = normalizedQuery.replace(/[\s_-]/g, '');

    const hasAny = (terms: string[]) => keywordMatchesQuery(terms, compact);

    const rows: Array<{key: string; filter: LibraryFilter; label: string; icon: string}> = [];

    if (hasAny(['saved', 'saves', 'save', 'bookmark', 'bookmarks', 'library', 'lib'])) {
      rows.push({key: 'bookmark', filter: 'bookmark', label: copy.openSaved, icon: 'bookmark-outline'});
    }
    if (hasAny(['highlight', 'highlights', 'highligt', 'hilite', 'hilight'])) {
      rows.push({key: 'highlight', filter: 'highlight', label: copy.openHighlights, icon: 'star-outline'});
    }
    if (hasAny(['note', 'notes'])) {
      rows.push({key: 'note', filter: 'note', label: copy.openNotes, icon: 'notebook-outline'});
    }

    return rows;
  }, [copy.openHighlights, copy.openNotes, copy.openSaved, normalizedQuery, showResults]);

  const onSelectPlan = (plan: Plan) => {
    onQueryChange('');
    onPlanPress(plan);
  };

  const onSelectLibrary = (entry: LibraryEntry) => {
    onQueryChange('');
    onLibraryPress(entry);
  };

  const hasAnyResults =
    planMatches.length > 0 ||
    libraryShortcutMatches.length > 0 ||
    libraryMatches.length > 0;

  const getLibraryType = (entry: LibraryEntry) => {
    if (entry.note && entry.note.trim().length > 0) {
      return copy.notes;
    }
    if (entry.highlightColor) {
      return copy.highlights;
    }
    return copy.saved;
  };

  return (
    <View>
      <View style={styles.searchShell}>
        <MaterialCommunityIcons name="magnify" size={20} color="#757C86" />
        <TextInput
          placeholder={copy.placeholder}
          placeholderTextColor="#7B8088"
          onChangeText={onQueryChange}
          value={query}
          style={styles.searchInput}
        />
        <Pressable
          accessibilityRole="button"
          onPress={onMicPress}
          style={[styles.searchMicButton, isListening && styles.searchMicButtonActive]}>
          <MaterialCommunityIcons
            name={isListening ? 'stop-circle-outline' : 'microphone-outline'}
            size={20}
            color={isListening ? '#C64D53' : '#757C86'}
          />
        </Pressable>
      </View>

      {showResults ? (
        <View style={styles.resultsCard}>
          {planMatches.length > 0 ? (
            <>
              <Text style={styles.sectionTitle}>{copy.plans.toUpperCase()}</Text>
              {planMatches.map(plan => (
                <Pressable
                  key={plan.id}
                  style={styles.resultRow}
                  onPress={() => onSelectPlan(plan)}>
                  <MaterialCommunityIcons name="calendar-check-outline" size={18} color="#3F83C9" />
                  <View style={styles.resultTextWrap}>
                    <Text style={styles.resultTitle} numberOfLines={1}>{plan.shortTitle}</Text>
                    <Text style={styles.resultSub} numberOfLines={1}>{plan.description}</Text>
                  </View>
                </Pressable>
              ))}
            </>
          ) : null}

          {libraryShortcutMatches.length > 0 || libraryMatches.length > 0 ? (
            <>
              <Text style={[styles.sectionTitle, planMatches.length > 0 && styles.sectionTitleSpaced]}>
                {copy.library.toUpperCase()}
              </Text>
              {libraryShortcutMatches.map(shortcut => (
                <Pressable
                  key={shortcut.key}
                  style={styles.resultRow}
                  onPress={() => {
                    onQueryChange('');
                    onLibraryFilterPress(shortcut.filter);
                  }}>
                  <MaterialCommunityIcons name={shortcut.icon as any} size={18} color="#5B7A8F" />
                  <View style={styles.resultTextWrap}>
                    <Text style={styles.resultTitle} numberOfLines={1}>{shortcut.label}</Text>
                    <Text style={styles.resultSub} numberOfLines={1}>{copy.library}</Text>
                  </View>
                </Pressable>
              ))}
              {libraryMatches.map(entry => (
                <Pressable
                  key={`${entry.reference}-${entry.updatedAt}`}
                  style={styles.resultRow}
                  onPress={() => onSelectLibrary(entry)}>
                  <MaterialCommunityIcons name="bookmark-outline" size={18} color="#B27A2B" />
                  <View style={styles.resultTextWrap}>
                    <Text style={styles.resultTitle} numberOfLines={1}>
                      {entry.reference} • {getLibraryType(entry)}
                    </Text>
                    <Text style={styles.resultSub} numberOfLines={1}>
                      {entry.note ?? entry.text}
                    </Text>
                  </View>
                </Pressable>
              ))}
            </>
          ) : null}

          {!hasAnyResults ? <Text style={styles.emptyText}>{copy.noResults}</Text> : null}
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  searchShell: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#E2DBCF',
    backgroundColor: '#FFFDF9',
    paddingHorizontal: 12,
    height: 50,
  },
  searchInput: {
    flex: 1,
    marginLeft: 8,
    marginRight: 8,
    fontSize: 15,
    color: '#202938',
    fontFamily: 'Inter_400Regular',
  },
  searchMicButton: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchMicButtonActive: {
    backgroundColor: '#FCEEEF',
  },
  resultsCard: {
    marginTop: 10,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E4DDD0',
    backgroundColor: '#FFFCF8',
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 6,
  },
  sectionTitle: {
    fontSize: 12,
    fontFamily: 'Poppins_500Medium',
    color: '#2D3D59',
    letterSpacing: 0.5,
  },
  sectionTitleSpaced: {
    marginTop: 8,
  },
  resultRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    borderRadius: 10,
    paddingHorizontal: 6,
    paddingVertical: 7,
  },
  resultTextWrap: {
    flex: 1,
  },
  resultTitle: {
    fontSize: 14,
    color: '#1D2736',
    fontFamily: 'Poppins_500Medium',
  },
  resultSub: {
    marginTop: 1,
    fontSize: 12,
    color: '#6D7582',
    fontFamily: 'Inter_400Regular',
  },
  emptyText: {
    textAlign: 'center',
    paddingVertical: 8,
    fontSize: 13,
    color: '#7B8391',
    fontFamily: 'Inter_400Regular',
  },
});

export default HomeAppSearch;
