import React from 'react';
import {
  Alert,
  Animated,
  FlatList,
  ImageBackground,
  Modal,
  PermissionsAndroid,
  Platform,
  Pressable,
  SafeAreaView,
  Share,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import Voice from '@react-native-voice/voice/dist/index.js';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons.js';
import type {
  BookMeta,
  ContentSummary,
  HighlightColor,
  LibraryEntry,
  Verse,
  VerseContentState,
} from '../types';
import PlansList, {PLANS} from './PlansList.tsx';
import PlanDetails from './PlanDetails.tsx';
import type {Plan} from './PlansList.tsx';
import {PLAN_SCHEDULES} from '../data/readingPlanSchedules.ts';
import HomeAppSearch from './HomeAppSearch.tsx';

const verseOfDayBg = require('../imgs/verse-of-the-day-bg.png');
const VOTD_GRADIENT_STOPS = [0.72, 0.6, 0.48, 0.34, 0.22, 0.12, 0.05, 0];

type AppTab = 'home' | 'bible' | 'plans' | 'saved';
type LibraryFilter = 'bookmark' | 'highlight' | 'note';
type NavigatorCategory = 'law' | 'history' | 'wisdom' | 'prophets' | 'gospels' | 'church' | 'letters' | 'prophecy';

const OLD_CATEGORIES: {key: NavigatorCategory; icon: string; label: string}[] = [
  {key: 'law',      icon: '📜', label: 'Law'},
  {key: 'history',  icon: '♜', label: 'History'},
  {key: 'wisdom',   icon: '📖', label: 'Wisdom'},
  {key: 'prophets', icon: '📣', label: 'Prophets'},
];
const NEW_CATEGORIES: {key: NavigatorCategory; icon: string; label: string}[] = [
  {key: 'gospels',  icon: '✝',  label: 'Gospels'},
  {key: 'church',   icon: '⛪', label: 'Church'},
  {key: 'letters',  icon: '✉',  label: 'Letters'},
  {key: 'prophecy', icon: '☀', label: 'Prophecy'},
];

const HOME_PLAN_META: {id: string; duration: number; titleEn: string; titleTa: string}[] = [
  {id: 'plan-30', duration: 30, titleEn: '30 Day Bible Reading Plan', titleTa: '30 நாள் வேதாகம வாசிப்புத் திட்டம்'},
  {id: 'plan-60', duration: 60, titleEn: '60 Day Bible Reading Plan', titleTa: '60 நாள் வேதாகம வாசிப்புத் திட்டம்'},
  {id: 'plan-90', duration: 90, titleEn: '90 Day Bible Reading Plan', titleTa: '90 நாள் வேதாகம வாசிப்புத் திட்டம்'},
  {id: 'plan-6months', duration: 180, titleEn: '6 Months Bible Reading Plan', titleTa: '6 மாத வேதாகம வாசிப்புத் திட்டம்'},
  {id: 'plan-1year', duration: 365, titleEn: '1 Year Bible Reading Plan', titleTa: '1 ஆண்டு வேதாகம வாசிப்புத் திட்டம்'},
];

const CATEGORY_RANGE: Record<NavigatorCategory, (order: number) => boolean> = {
  law:      o => o >= 1  && o <= 5,
  history:  o => o >= 6  && o <= 17,
  wisdom:   o => o >= 18 && o <= 22,
  prophets: o => o >= 23 && o <= 38,
  gospels:  o => o >= 39 && o <= 42,
  church:   o => o === 43,
  letters:  o => o >= 44 && o <= 64,
  prophecy: o => o >= 65,
};

type ReaderPageProps = {
  errorMessage: string | null;
  books: BookMeta[];
  chapters: number[];
  selectedBook: string;
  selectedChapter: number;
  chapterVerses: Verse[];
  selectionMode: boolean;
  selectedReferences: string[];
  activeReference: string | null;
  searchQuery: string;
  activeTab: AppTab;
  visibleVerses: Verse[];
  visibleContent: Record<string, VerseContentState>;
  focusReference: string | null;
  isBottomSheetMounted: boolean;
  shouldShowBottomSheet: boolean;
  bottomSheetTranslateY: Animated.Value;
  isMutating: boolean;
  bookmarkActionLabel: string;
  highlightOptions: HighlightColor[];
  noteDraft: string;
  summary: ContentSummary;
  libraryEntries: LibraryEntry[];
  planProgress: Record<string, number>;
  selectedTestament: 'old' | 'new';
  selectedLanguage: 'en' | 'ta' | null;
  onToggleSelectionMode: () => void;
  onOpenBottomSheet: () => void;
  onSearchChange: (value: string) => void;
  onBookPress: (book: string) => void;
  onChapterPress: (chapter: number) => void;
  onVersePress: (reference: string) => void;
  onNavigateToVerse: (reference: string) => void;
  onCloseBottomSheet: () => void;
  onBookmarkAction: () => void;
  onHighlightAction: (color: HighlightColor) => void;
  onClearHighlight: () => void;
  onNoteChange: (value: string) => void;
  onSaveNote: () => void;
  onDeleteBookmark: (verseRef: string) => void;
  onDeleteHighlight: (verseRef: string) => void;
  onDeleteNote: (verseRef: string) => void;
  onLibraryEntryPress: (entry: LibraryEntry) => void;
  onTestamentChange: (testament: 'old' | 'new') => void;
  onSettingsPress: () => void;
  onStartPlan: (plan: Plan) => void;
  onMarkDayComplete: (plan: Plan) => void;
  onResetPlan: (plan: Plan) => void;
  onTabChange: (tab: AppTab) => void;
};

const TAMIL_BOOK_NAMES: Record<string, string> = {
  Genesis: 'ஆதியாகமம்',
  Exodus: 'யாத்திராகமம்',
  Leviticus: 'லேவியராகமம்',
  Numbers: 'எண்ணாகமம்',
  Deuteronomy: 'உபாகமம்',
  Joshua: 'யோசுவா',
  Judges: 'நியாயாதிபதிகள்',
  Ruth: 'ரூத்',
  '1 Samuel': '1 சாமுவேல்',
  '2 Samuel': '2 சாமுவேல்',
  '1 Kings': '1 இராஜாக்கள்',
  '2 Kings': '2 இராஜாக்கள்',
  '1 Chronicles': '1 நாளாகமம்',
  '2 Chronicles': '2 நாளாகமம்',
  Ezra: 'எஸ்றா',
  Nehemiah: 'நேகேமியா',
  Esther: 'எஸ்தர்',
  Job: 'யோபு',
  Psalm: 'சங்கீதம்',
  Proverbs: 'நீதிமொழிகள்',
  Ecclesiastes: 'பிரசங்கி',
  Isaiah: 'ஏசாயா',
  Jeremiah: 'எரேமியா',
  Lamentations: 'புலம்பல்',
  Ezekiel: 'எசேக்கியேல்',
  Daniel: 'தானியேல்',
  Hosea: 'ஓசியா',
  Joel: 'யோவேல்',
  Amos: 'ஆமோஸ்',
  Obadiah: 'ஒபதியா',
  Jonah: 'யோனா',
  Micah: 'மீகா',
  Nahum: 'நாகூம்',
  Habakkuk: 'ஆபகூக்',
  Zephaniah: 'செப்பனியா',
  Haggai: 'ஆகாய்',
  Zechariah: 'சகரியா',
  Malachi: 'மல்கியா',
  Matthew: 'மத்தேயு',
  Mark: 'மாற்கு',
  Luke: 'லூக்கா',
  John: 'யோவான்',
  Acts: 'அப்போஸ்தலர்',
  Romans: 'ரோமர்',
  '1 Corinthians': '1 கொரிந்தியர்',
  '2 Corinthians': '2 கொரிந்தியர்',
  Galatians: 'கலாத்தியர்',
  Ephesians: 'எபேசியர்',
  Philippians: 'பிலிப்பியர்',
  Colossians: 'கொலோசெயர்',
  '1 Thessalonians': '1 தெசலோனிக்கேயர்',
  '2 Thessalonians': '2 தெசலோனிக்கேயர்',
  '1 Timothy': '1 தீமோத்தேயு',
  '2 Timothy': '2 தீமோத்தேயு',
  Titus: 'தீத்து',
  Philemon: 'பிலேமோன்',
  Hebrews: 'எபிரெயர்',
  James: 'யாக்கோபு',
  '1 Peter': '1 பேதுரு',
  '2 Peter': '2 பேதுரு',
  '1 John': '1 யோவான்',
  '2 John': '2 யோவான்',
  '3 John': '3 யோவான்',
  Jude: 'யூதா',
  Revelation: 'வெளிப்படுத்தின விசேஷம்',
};

const EMPTY_VERSE_STATE: VerseContentState = {
  bookmark: false,
  highlightColor: null,
  note: null,
};

function ReaderPage({
  errorMessage,
  books,
  chapters,
  selectedBook,
  selectedChapter,
  chapterVerses,
  selectionMode,
  selectedReferences,
  searchQuery,
  activeTab,
  visibleVerses,
  visibleContent,
  focusReference,
  isBottomSheetMounted,
  shouldShowBottomSheet,
  bottomSheetTranslateY,
  isMutating,
  bookmarkActionLabel,
  highlightOptions,
  noteDraft,
  summary,
  libraryEntries,
  planProgress,
  selectedTestament,
  selectedLanguage,
  onToggleSelectionMode,
  onOpenBottomSheet,
  onSearchChange,
  onBookPress,
  onChapterPress,
  onVersePress,
  onNavigateToVerse,
  onCloseBottomSheet,
  onBookmarkAction,
  onHighlightAction,
  onClearHighlight,
  onNoteChange,
  onSaveNote,
  onDeleteBookmark,
  onDeleteHighlight,
  onDeleteNote,
  onLibraryEntryPress,
  onTestamentChange,
  onSettingsPress,
  onStartPlan,
  onMarkDayComplete,
  onResetPlan,
  onTabChange,
}: ReaderPageProps) {
  const [isNavigatorOpen, setIsNavigatorOpen] = React.useState(false);
  const [libraryFilter, setLibraryFilter] = React.useState<LibraryFilter>('bookmark');
  const [selectedOldCats, setSelectedOldCats] = React.useState<NavigatorCategory[]>(['law', 'history', 'wisdom', 'prophets']);
  const [selectedNewCats, setSelectedNewCats] = React.useState<NavigatorCategory[]>(['gospels', 'church', 'letters', 'prophecy']);
  const [verseFontSize, setVerseFontSize] = React.useState(16);
  const [isListening, setIsListening] = React.useState(false);
  const [homeSearchQuery, setHomeSearchQuery] = React.useState('');
  const [selectedPlan, setSelectedPlan] = React.useState<Plan | null>(null);

  const openNavigator = React.useCallback(() => {
    if (isMutating) {
      return;
    }

    setIsNavigatorOpen(true);
  }, [isMutating]);

  const increaseFontSize = () => setVerseFontSize(s => Math.min(s + 2, 28));
  const decreaseFontSize = () => setVerseFontSize(s => Math.max(s - 2, 12));

  const isTamil = selectedLanguage === 'ta';
  const copy = isTamil
    ? {
        greeting: 'காலை வணக்கம்',
        greetingSub: 'இன்று தேவவார்த்தையில் வளர்வோம்.',
        search: 'வேதாகமம், வசனம், தலைப்பு தேடுங்கள்...',
        continueReading: 'வாசிப்பைத் தொடரவும்',
        continueButton: 'தொடரவும்',
        lastRead: 'கடைசியாக வாசித்தது',
        currentPlanDay: 'திட்ட நாள்',
        planDaysLeft: 'நாட்கள் மீதம்',
        noPlanStartedShort: 'திட்டம் இன்னும் தொடங்கப்படவில்லை',
        startPlanHint: 'திட்டங்கள் தாவலில் ஒரு திட்டத்தை தொடங்குங்கள்.',
        verseOfDay: 'இன்றைய வசனம்',
        readFullChapter: 'முழு அதிகாரம் வாசிக்க',
        dailyWalk: 'தினசரி நடை',
        streak: 'நாள் தொடர்',
        keepGoing: 'தொடருங்கள்! நல்ல பழக்கம் உருவாகிறது.',
        noPlanProgress: 'இன்னும் திட்டம் தொடங்கவில்லை. திட்டங்களில் ஒரு நாளை முடித்தால் இங்கு முன்னேற்றம் தெரியும்.',
        activePlan: 'செயலில் உள்ள திட்டம்',
        completedLabel: 'முடிந்தது',
        quickActions: 'விரைவு செயல்கள்',
        highlights: 'ஹைலைட்ஸ்',
        notes: 'குறிப்புகள்',
        saved: 'சேமிப்பு',
        plans: 'திட்டங்கள்',
        quickHighlightsSub: 'உங்கள் ஹைலைட்ஸை பார்க்க',
        quickNotesSub: 'உங்கள் குறிப்புகளை பார்க்க',
        quickSavedSub: 'சேமித்த வசனங்களை பார்க்க',
        quickPlansSub: 'வாசிப்பு திட்டங்களை பார்க்க',
        shareApp: 'ஆப்பைப் பகிர்',
        shareMessage: 'Bible All ஆப்பைப் பயன்படுத்துங்கள். தினசரி வாசிப்புக்கும் திட்ட முன்னேற்றத்துக்கும் இது மிகவும் உதவும்.',
        shareFailed: 'ஆப்பைப் பகிர முடியவில்லை.',
        recent: 'சமீப செயல்பாடுகள்',
        viewAll: 'அனைத்தும்',
        home: 'முகப்பு',
        bible: 'வேதாகமம்',
        savedTab: 'நூலகம்',
        selectVerse: 'வசனத்தை தேர்வுசெய்',
        close: 'மூடு',
        old: 'பழைய ஏற்பாடு',
        new: 'புதிய ஏற்பாடு',
        books: 'புத்தகங்கள்',
        chapters: 'அதிகாரங்கள்',
        goTo: 'செல்',
        selectHighlight: 'நிறத்தைத் தேர்வுசெய்',
        saveNote: 'குறிப்பு சேமி',
        clear: 'அழி',
        notePlaceholder: 'தேர்ந்த வசனத்திற்கான குறிப்பை எழுதுங்கள்...',
        aiExplain: 'AI விளக்கம்',
        copyAction: 'நகல்',
        copiedTitle: 'நகலெடுக்கப்பட்டது',
        copiedMessage: 'தேர்ந்தெடுத்த வசனங்கள் கிளிப்போர்டுக்கு நகலெடுக்கப்பட்டன.',
        copyEmptyMessage: 'முதலில் குறைந்தது ஒரு வசனத்தைத் தேர்வு செய்யவும்.',
        clipboardUnavailable: 'கிளிப்போர்ட் இல்லை. அதற்குப் பதிலாக பகிர்வு திறக்கப்படுகிறது.',
        aiSoon: 'AI விளக்கம் விரைவில் வரும். தற்போது UI மட்டும் தயார்.',
        micPermissionNeeded: 'குரல் தேடலுக்கான மைக் அனுமதி தேவை.',
        micFailed: 'குரல் கேட்க முடியவில்லை. மீண்டும் முயற்சிக்கவும்.',
      }
    : {
        greeting: 'Good Morning',
        greetingSub: "Let's grow in God's Word today.",
        search: 'Search Bible, verses, topics...',
        continueReading: 'Continue Reading',
        continueButton: 'Continue',
        lastRead: 'Last read',
        currentPlanDay: 'Plan day',
        planDaysLeft: 'days left',
        noPlanStartedShort: 'Plan not started yet',
        startPlanHint: 'Start a plan from the Plans tab.',
        verseOfDay: 'Verse of the Day',
        readFullChapter: 'Read Full Chapter',
        dailyWalk: 'Your Daily Walk',
        streak: 'Day Streak',
        keepGoing: "Keep it up! You're building a strong habit.",
        noPlanProgress: 'No plan started yet. Complete a day from Plans to begin.',
        activePlan: 'Active plan',
        completedLabel: 'completed',
        quickActions: 'Quick Actions',
        highlights: 'Highlights',
        notes: 'Notes',
        saved: 'Saved',
        plans: 'Plans',
        quickHighlightsSub: 'View your highlights',
        quickNotesSub: 'View your notes',
        quickSavedSub: 'View saved verses',
        quickPlansSub: 'Browse reading plans',
        shareApp: 'Share App',
        shareMessage: 'Check out Bible All. It is great for daily reading and plan progress.',
        shareFailed: 'Unable to share the app.',
        recent: 'Recent Activity',
        viewAll: 'View all',
        home: 'Home',
        bible: 'Bible',
        savedTab: 'Library',
        selectVerse: 'Select verse',
        close: 'Close',
        old: 'Old Testament',
        new: 'New Testament',
        books: 'Books',
        chapters: 'Chapters',
        goTo: 'Go to',
        selectHighlight: 'Select highlight color',
        saveNote: 'Save Note',
        clear: 'Clear',
        notePlaceholder: 'Write a note for selected verses...',
        aiExplain: 'AI Explain',
        copyAction: 'Copy',
        copiedTitle: 'Copied',
        copiedMessage: 'Selected verses were copied to clipboard.',
        copyEmptyMessage: 'Select at least one verse first.',
        clipboardUnavailable: 'Clipboard is unavailable on this build. Opening share instead.',
        aiSoon: 'AI explain is UI-only for now. We can integrate later.',
        micPermissionNeeded: 'Microphone permission is required for voice search.',
        micFailed: 'Could not start listening. Please try again.',
      };

  React.useEffect(() => {
    Voice.onSpeechResults = event => {
      const spokenText = event.value?.[0]?.trim();
      if (spokenText) {
        if (activeTab === 'home') {
          setHomeSearchQuery(spokenText);
        } else {
          onSearchChange(spokenText);
        }
      }
      setIsListening(false);
    };

    Voice.onSpeechError = () => {
      setIsListening(false);
    };

    Voice.onSpeechEnd = () => {
      setIsListening(false);
    };

    return () => {
      void Voice.destroy().finally(Voice.removeAllListeners);
    };
  }, [activeTab, onSearchChange]);

  const requestMicPermission = React.useCallback(async () => {
    if (Platform.OS !== 'android') {
      return true;
    }

    const result = await PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.RECORD_AUDIO,
    );

    return result === PermissionsAndroid.RESULTS.GRANTED;
  }, []);

  const onMicPress = React.useCallback(async () => {
    try {
      if (isListening) {
        await Voice.stop();
        setIsListening(false);
        return;
      }

      const granted = await requestMicPermission();
      if (!granted) {
        Alert.alert(copy.micPermissionNeeded);
        return;
      }

      setIsListening(true);
      await Voice.start(isTamil ? 'ta-IN' : 'en-US');
    } catch {
      setIsListening(false);
      Alert.alert(copy.micFailed);
    }
  }, [copy.micFailed, copy.micPermissionNeeded, isListening, isTamil, requestMicPermission]);

  const getBookLabel = (bookName: string) => {
    const normalized = bookName === 'undefined' ? 'Revelation' : bookName;
    return isTamil ? TAMIL_BOOK_NAMES[normalized] ?? normalized : normalized;
  };

  const formatRef = (book: string, chapter: number, verse?: number) =>
    verse === undefined
      ? `${getBookLabel(book)} ${chapter}`
      : `${getBookLabel(book)} ${chapter}:${verse}`;

  const greetingLine = isTamil ? 'கர்த்தருக்கு ஸ்தோத்திரம்' : 'Praise the Lord';

  const filteredBooks = React.useMemo(
    () =>
      books.filter(book =>
        selectedTestament === 'old' ? book.bookOrder <= 38 : book.bookOrder >= 39,
      ),
    [books, selectedTestament],
  );

  const activeCats = selectedTestament === 'old' ? selectedOldCats : selectedNewCats;

  const categoryBooks = React.useMemo(() => {
    if (!activeCats.length) return filteredBooks;
    return filteredBooks.filter(book =>
      activeCats.some(cat => CATEGORY_RANGE[cat](book.bookOrder)),
    );
  }, [filteredBooks, activeCats]);

  const toggleCat = React.useCallback((cat: NavigatorCategory) => {
    if (selectedTestament === 'old') {
      setSelectedOldCats(prev =>
        prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat],
      );
    } else {
      setSelectedNewCats(prev =>
        prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat],
      );
    }
  }, [selectedTestament]);

  const chapterProgress = Math.min(100, Math.round((selectedChapter / Math.max(chapters.length, 1)) * 100));
  const currentVerse = chapterVerses[15] ?? chapterVerses[0] ?? visibleVerses[0] ?? null;
  const verseOfDay = chapterVerses[0] ?? visibleVerses[0] ?? null;

  const planSummaries = React.useMemo(
    () =>
      HOME_PLAN_META.map(plan => ({
        ...plan,
        completedDays: Math.max(0, Math.min(planProgress[plan.id] ?? 0, plan.duration)),
      })),
    [planProgress],
  );

  const activePlanSummary = React.useMemo(() => {
    return planSummaries.reduce<(typeof planSummaries)[number] | null>((best, current) => {
      if (!best) {
        return current;
      }
      return current.completedDays > best.completedDays ? current : best;
    }, null);
  }, [planSummaries]);

  const totalCompletedPlanDays = React.useMemo(
    () => planSummaries.reduce((sum, plan) => sum + plan.completedDays, 0),
    [planSummaries],
  );

  const hasPlanProgress = totalCompletedPlanDays > 0;
  const activeCompletedDays = activePlanSummary?.completedDays ?? 0;
  const weeklyCompletedDays = Math.min(activeCompletedDays % 7 || (hasPlanProgress ? 7 : 0), 7);
  const activePlanSchedule = activePlanSummary ? PLAN_SCHEDULES[activePlanSummary.id] ?? [] : [];
  const activePlanCurrentDay = activePlanSummary
    ? Math.min(activeCompletedDays + 1, activePlanSummary.duration)
    : 1;
  const activePlanTodayReading = activePlanSchedule[Math.min(activeCompletedDays, Math.max(activePlanSchedule.length - 1, 0))];
  const activePlanLastCompletedReading = activeCompletedDays > 0
    ? activePlanSchedule[Math.min(activeCompletedDays - 1, Math.max(activePlanSchedule.length - 1, 0))]
    : null;
  const activePlanProgressPercent = activePlanSummary
    ? Math.round((activeCompletedDays / Math.max(activePlanSummary.duration, 1)) * 100)
    : 0;
  const activePlanDaysLeft = activePlanSummary
    ? Math.max(activePlanSummary.duration - activeCompletedDays, 0)
    : 0;

  const bookmarkedEntries = libraryEntries.filter(entry => entry.bookmark);
  const highlightedEntries = libraryEntries.filter(entry => Boolean(entry.highlightColor));
  const notedEntries = libraryEntries.filter(entry => Boolean(entry.note));
  const recentEntries = [...libraryEntries].slice(0, 4);

  const focusVerse = focusReference
    ? visibleVerses.find(v => v.reference === focusReference) ??
      chapterVerses.find(v => v.reference === focusReference)
    : null;

  const displayEntries =
    libraryFilter === 'bookmark'
      ? bookmarkedEntries
      : libraryFilter === 'highlight'
        ? highlightedEntries
        : notedEntries;

  const onAiExplain = () => {
    Alert.alert(copy.aiExplain, copy.aiSoon);
  };

  const onCopySelectedVerses = React.useCallback(async () => {
    const versesToCopy = visibleVerses.filter(verse => selectedReferences.includes(verse.reference));

    if (!versesToCopy.length) {
      return;
    }

    const payload = versesToCopy
      .map(verse => `${formatRef(verse.book, verse.chapter, verse.verse)} ${verse.text}`)
      .join('\n\n');

    try {
      const clipboardModule = require('@react-native-clipboard/clipboard')?.default;
      if (typeof clipboardModule?.setString !== 'function') {
        throw new Error('Clipboard API unavailable');
      }

      clipboardModule.setString(payload);
    } catch {
      try {
        await Share.share({
          title: 'Bible All',
          message: payload,
        });
      } catch {
        // Ignore share cancellation/failure here because copy fallback already informed user.
      }
    }
  }, [formatRef, selectedReferences, visibleVerses]);

  const onShareApp = React.useCallback(async () => {
    try {
      await Share.share({
        title: 'Bible All',
        message: copy.shareMessage,
      });
    } catch {
      Alert.alert(copy.shareFailed);
    }
  }, [copy.shareFailed, copy.shareMessage]);

  const handlePlanSelect = (plan: Plan) => {
    setSelectedPlan(plan);
  };

  const handlePlanBackPress = () => {
    setSelectedPlan(null);
  };

  const handleStartPlan = (plan: Plan) => {
    onStartPlan(plan);
    setSelectedPlan(null);
  };

  const handleHomeSearchPlanPress = (plan: Plan) => {
    setSelectedPlan(plan);
    onTabChange('plans');
  };

  const handleHomeSearchChange = (value: string) => {
    setHomeSearchQuery(value);
  };

  const handleHomeSearchFilterPress = (filter: LibraryFilter) => {
    setLibraryFilter(filter);
    setHomeSearchQuery('');
    onTabChange('saved');
  };

  const handleHomeSearchLibraryPress = (entry: LibraryEntry) => {
    const nextFilter: LibraryFilter = entry.note
      ? 'note'
      : entry.highlightColor
        ? 'highlight'
        : 'bookmark';

    setLibraryFilter(nextFilter);
    onTabChange('saved');
  };

  const chapterIndex = chapters.indexOf(selectedChapter);
  const canGoPrevChapter = chapterIndex > 0;
  const canGoNextChapter = chapterIndex >= 0 && chapterIndex < chapters.length - 1;

  const handlePrevChapter = () => {
    if (!canGoPrevChapter) {
      return;
    }

    const prevChapter = chapters[chapterIndex - 1];
    if (typeof prevChapter === 'number') {
      onChapterPress(prevChapter);
    }
  };

  const handleNextChapter = () => {
    if (!canGoNextChapter) {
      return;
    }

    const nextChapter = chapters[chapterIndex + 1];
    if (typeof nextChapter === 'number') {
      onChapterPress(nextChapter);
    }
  };

  const renderVerseCard = ({item}: {item: Verse}) => {
    const state = visibleContent[item.reference] ?? EMPTY_VERSE_STATE;
    const isSelected = selectedReferences.includes(item.reference);
    const hasBookmark = state.bookmark === true;
    const hasNote = typeof state.note === 'string' && state.note.trim().length > 0;

    return (
      <Pressable
        accessibilityRole="button"
        onPress={() => onVersePress(item.reference)}
        style={[
          styles.verseCard,
          isSelected && styles.verseCardSelected,
          state.highlightColor ? {backgroundColor: state.highlightColor} : {backgroundColor: '#FFFDF9'},
        ]}>
        <Text style={[styles.verseText, {fontSize: verseFontSize, lineHeight: verseFontSize * 1.65}]}>
          <Text style={[styles.verseNo, {fontSize: verseFontSize - 2}]}>{item.verse} </Text>
          {item.text}
        </Text>
        {(hasBookmark || hasNote) ? (
          <View style={styles.verseMetaRow}>
            {hasBookmark ? <Text style={styles.verseMetaChip}>{copy.saved}</Text> : null}
            {hasNote ? <Text style={styles.verseMetaChip}>{copy.notes}</Text> : null}
          </View>
        ) : null}
      </Pressable>
    );
  };

  const renderHome = () => (
    <ScrollView style={styles.pageScroll} contentContainerStyle={styles.pageContent}>
      <View style={styles.brandRow}>
        <View style={styles.brandLeft}>
          <Text style={styles.brandLogo}>✣</Text>
          <Text style={styles.brandTitle}>Bible - Word of God</Text>
        </View>
        <Pressable style={styles.langBtn} accessibilityRole="button" onPress={onSettingsPress}>
          <Text style={styles.langBtnText}>{selectedLanguage === 'ta' ? 'TA' : 'EN'}</Text>
        </Pressable>
      </View>

      <View style={styles.heroTitleRow}>
        <Text style={styles.heroTitle}>{greetingLine}</Text>
        <Text style={styles.heroCrossIcon}>✝</Text>
      </View>
      <Text style={styles.heroSub}>{copy.greetingSub}</Text>

      <HomeAppSearch
        selectedLanguage={selectedLanguage}
        plans={PLANS}
        libraryEntries={libraryEntries}
        query={homeSearchQuery}
        onQueryChange={handleHomeSearchChange}
        onMicPress={() => {
          void onMicPress();
        }}
        isListening={isListening}
        onPlanPress={handleHomeSearchPlanPress}
        onLibraryPress={handleHomeSearchLibraryPress}
        onLibraryFilterPress={handleHomeSearchFilterPress}
      />

      <View style={styles.continueCard}>
        <View style={styles.continueLeftIcon}><Text style={styles.continueIconText}>📖</Text></View>
        <View style={styles.continueMain}>
          <Text style={styles.sectionKicker}>{copy.continueReading.toUpperCase()}</Text>
          <Text style={styles.continueTitle}>
            {hasPlanProgress && activePlanSummary
              ? (isTamil ? activePlanSummary.titleTa : activePlanSummary.titleEn)
              : copy.noPlanStartedShort}
          </Text>
          <Text style={styles.continueSub}>
            {hasPlanProgress && activePlanSummary
              ? `${copy.currentPlanDay} ${activePlanCurrentDay}: ${activePlanTodayReading ? activePlanTodayReading.passages.join(', ') : '—'}`
              : copy.noPlanProgress}
          </Text>
          {hasPlanProgress && activePlanSummary ? (
            <Text style={styles.continueSub}>
              {`${copy.lastRead}: ${activePlanLastCompletedReading ? activePlanLastCompletedReading.passages.join(', ') : '—'}`}
            </Text>
          ) : (
            <Text style={styles.continueSub}>{copy.startPlanHint}</Text>
          )}
          <View style={styles.progressTrack}>
            <View style={[styles.progressFill, {width: `${hasPlanProgress ? activePlanProgressPercent : 0}%`}]} />
          </View>
          {hasPlanProgress && activePlanSummary ? (
            <Text style={styles.continueSub}>{`${activePlanDaysLeft} ${copy.planDaysLeft}`}</Text>
          ) : null}
        </View>
        <Pressable style={styles.continueBtn} onPress={() => onTabChange('bible')}>
          <Text style={styles.continueBtnText}>{copy.continueButton}</Text>
        </Pressable>
      </View>

      <ImageBackground source={verseOfDayBg} style={styles.votdCard} imageStyle={styles.votdBgImage}>
        <View style={styles.votdOverlay} />
        <View style={styles.votdGradientWrap} pointerEvents="none">
          {VOTD_GRADIENT_STOPS.map((opacity, index) => (
            <View
              key={`votd-grad-${index}`}
              style={[styles.votdGradientStop, {backgroundColor: `rgba(255,255,255,${opacity})`}]} />
          ))}
        </View>
        <Text style={styles.votdKicker}>{copy.verseOfDay.toUpperCase()} ☀</Text>
        <Text style={styles.votdText} numberOfLines={4}>{`"${verseOfDay?.text ?? (isTamil ? 'இன்றைக்கான வசனம்' : 'Daily verse will appear here.')}"`}</Text>
        <Text style={styles.votdRef}>{verseOfDay ? formatRef(verseOfDay.book, verseOfDay.chapter, verseOfDay.verse) : ''}</Text>
        <Pressable
          style={styles.votdBtn}
          onPress={() => {
            if (verseOfDay) {
              onNavigateToVerse(verseOfDay.reference);
            }
            onTabChange('bible');
          }}>
          <Text style={styles.votdBtnText}>{copy.readFullChapter}</Text>
          <Text style={styles.votdBtnArrow}>›</Text>
        </Pressable>
      </ImageBackground>

      <View style={styles.streakCard}>
        <View style={styles.streakHeader}>
          <Text style={styles.streakTitle}>{copy.dailyWalk.toUpperCase()}</Text>
          <Text style={styles.streakCount}>
            {hasPlanProgress ? `${activeCompletedDays} ${copy.streak} 🔥` : `0 ${copy.streak}`}
          </Text>
        </View>

        {hasPlanProgress && activePlanSummary ? (
          <Text style={styles.planProgressMeta}>
            {`${copy.activePlan}: ${isTamil ? activePlanSummary.titleTa : activePlanSummary.titleEn} • ${activePlanSummary.completedDays}/${activePlanSummary.duration} ${copy.completedLabel}`}
          </Text>
        ) : null}

        <View style={styles.streakDays}>
          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, idx) => (
            <View key={day} style={styles.dayWrap}>
              <View
                style={[
                  styles.dayDot,
                  idx < weeklyCompletedDays && styles.dayDotDone,
                  hasPlanProgress && idx === weeklyCompletedDays % 7 && weeklyCompletedDays < 7 && styles.dayDotActive,
                ]}>
                <Text style={styles.dayTick}>{idx < weeklyCompletedDays ? '✓' : ''}</Text>
              </View>
              <Text style={styles.dayLabel}>{day}</Text>
            </View>
          ))}
        </View>
        <Text style={[styles.streakNote, !hasPlanProgress && styles.streakNoteEmpty]}>
          {hasPlanProgress ? copy.keepGoing : copy.noPlanProgress}
        </Text>
      </View>

      <Text style={styles.quickActionsTitle}>{copy.quickActions.toUpperCase()}</Text>
      <View style={styles.quickGrid}>
        <Pressable
          style={[styles.quickCard, styles.quickCardHighlights]}
          onPress={() => {
            setLibraryFilter('highlight');
            onTabChange('saved');
          }}>
          <View style={[styles.quickIconBadge, styles.quickIconBadgeHighlights]}>
            <MaterialCommunityIcons name="star-outline" size={20} color="#E6A01D" />
          </View>
          <Text style={styles.quickTitle}>{copy.highlights}</Text>
          <Text style={styles.quickSub}>{copy.quickHighlightsSub}</Text>
        </Pressable>
        <Pressable
          style={[styles.quickCard, styles.quickCardNotes]}
          onPress={() => {
            setLibraryFilter('note');
            onTabChange('saved');
          }}>
          <View style={[styles.quickIconBadge, styles.quickIconBadgeNotes]}>
            <MaterialCommunityIcons name="notebook-outline" size={20} color="#8C62D9" />
          </View>
          <Text style={styles.quickTitle}>{copy.notes}</Text>
          <Text style={styles.quickSub}>{copy.quickNotesSub}</Text>
        </Pressable>
        <Pressable
          style={[styles.quickCard, styles.quickCardSaved]}
          onPress={() => {
            setLibraryFilter('bookmark');
            onTabChange('saved');
          }}>
          <View style={[styles.quickIconBadge, styles.quickIconBadgeSaved]}>
            <MaterialCommunityIcons name="bookmark-outline" size={20} color="#D95D5D" />
          </View>
          <Text style={styles.quickTitle}>{copy.saved}</Text>
          <Text style={styles.quickSub}>{copy.quickSavedSub}</Text>
        </Pressable>
        <Pressable
          style={[styles.quickCard, styles.quickCardPlans]}
          onPress={() => onTabChange('plans')}>
          <View style={[styles.quickIconBadge, styles.quickIconBadgePlans]}>
            <MaterialCommunityIcons name="clipboard-check-outline" size={20} color="#3F83C9" />
          </View>
          <Text style={styles.quickTitle}>{copy.plans}</Text>
          <Text style={styles.quickSub}>{copy.quickPlansSub}</Text>
        </Pressable>
      </View>

      <View style={styles.recentHead}>
        <Text style={styles.sectionTitle}>{copy.recent.toUpperCase()}</Text>
        <Text style={styles.viewAll}>{copy.viewAll}</Text>
      </View>
      <View style={styles.recentCard}>
        {recentEntries.length ? (
          recentEntries.map(item => (
            <Pressable key={item.reference + item.updatedAt} style={styles.recentItem} onPress={() => onLibraryEntryPress(item)}>
              <Text style={styles.recentIcon}>{item.bookmark ? '🔖' : item.note ? '📝' : '⭐'}</Text>
              <View style={styles.recentTextWrap}>
                <Text style={styles.recentRef}>{formatRef(item.book, item.chapter, item.verse)}</Text>
                <Text style={styles.recentPreview} numberOfLines={1}>{item.note ?? item.text}</Text>
              </View>
              <Text style={styles.recentTime}>{isTamil ? 'சமீபத்தில்' : 'Recent'}</Text>
            </Pressable>
          ))
        ) : (
          <Text style={[styles.recentPreview, styles.recentPreviewEmpty]}>
            {isTamil ? 'இன்னும் செயல்பாடு இல்லை.' : 'No recent activity yet.'}
          </Text>
        )}
      </View>

      <View style={styles.homeShareWrap}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel={copy.shareApp}
          style={styles.homeShareButton}
          onPress={() => {
            void onShareApp();
          }}>
          <MaterialCommunityIcons name="share-variant" size={31} color="#FFFFFF" />
        </Pressable>
      </View>
    </ScrollView>
  );

  const renderBible = () => (
    <View style={styles.bibleWrap}>
      <View style={styles.readHeader}>
        <Pressable accessibilityRole="button" style={styles.headerIconBtn} onPress={() => onTabChange('home')}>
          <Text style={styles.headerIcon}>‹</Text>
        </Pressable>
        <Pressable
          accessibilityRole="button"
          style={styles.refPill}
          onPress={openNavigator}
          onLongPress={openNavigator}
          disabled={isMutating}
          hitSlop={10}
          pressRetentionOffset={16}>
          <Text style={styles.refPillText}>{focusVerse ? formatRef(focusVerse.book, focusVerse.chapter, focusVerse.verse) : formatRef(selectedBook, selectedChapter)}</Text>
        </Pressable>
        <View style={styles.headerActions}>
          <Pressable style={styles.fontSizeBtn} onPress={decreaseFontSize}><Text style={styles.fontSizeBtnText}>AA-</Text></Pressable>
          <Pressable style={styles.fontSizeBtn} onPress={increaseFontSize}><Text style={styles.fontSizeBtnText}>AA+</Text></Pressable>
          <Pressable style={styles.headerIconBtn}><Text style={styles.headerIcon}>🔊</Text></Pressable>
        </View>
      </View>

      <View style={styles.verseStripWrap}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.verseStripRow}>
          {chapterVerses.map(verse => {
            const isActive = focusReference === verse.reference;

            return (
              <Pressable
                key={verse.reference}
                onPress={() => onNavigateToVerse(verse.reference)}
                style={[styles.verseStripChip, isActive && styles.verseStripChipActive]}>
                <Text style={[styles.verseStripText, isActive && styles.verseStripTextActive]}>
                  {verse.verse}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>

      <FlatList
        data={visibleVerses}
        keyExtractor={item => item.reference}
        renderItem={renderVerseCard}
        contentContainerStyle={styles.verseList}
      />

      <View style={styles.chapterDockBar}>
        <View style={styles.chapterDockRow}>
          <Pressable
            style={[styles.chapterDockPill, !canGoPrevChapter && styles.chapterDockPillDisabled]}
            onPress={handlePrevChapter}
            disabled={!canGoPrevChapter}>
            <MaterialCommunityIcons name="chevron-left" size={16} color={canGoPrevChapter ? '#3B342D' : '#B6AEA3'} />
            <View>
              <Text style={[styles.chapterDockTitle, !canGoPrevChapter && styles.chapterDockTitleDisabled]}>
                {isTamil ? 'முந்தைய' : 'Previous'}
              </Text>
              {canGoPrevChapter ? (
                <Text style={styles.chapterDockSub}>{`${selectedBook} ${chapters[chapterIndex - 1]}`}</Text>
              ) : null}
            </View>
          </Pressable>

          <Pressable style={styles.chapterDockCenter} onPress={openNavigator}>
            <View style={styles.chapterDockCenterIcon}>
              <MaterialCommunityIcons name="book-open-page-variant-outline" size={18} color="#B37A2A" />
            </View>
            <Text style={styles.chapterDockCenterText}>{copy.goTo}</Text>
          </Pressable>

          <Pressable
            style={[styles.chapterDockPill, !canGoNextChapter && styles.chapterDockPillDisabled]}
            onPress={handleNextChapter}
            disabled={!canGoNextChapter}>
            <View>
              <Text style={[styles.chapterDockTitle, !canGoNextChapter && styles.chapterDockTitleDisabled]}>
                {isTamil ? 'அடுத்தது' : 'Next'}
              </Text>
              {canGoNextChapter ? (
                <Text style={styles.chapterDockSub}>{`${selectedBook} ${chapters[chapterIndex + 1]}`}</Text>
              ) : null}
            </View>
            <MaterialCommunityIcons name="chevron-right" size={16} color={canGoNextChapter ? '#3B342D' : '#B6AEA3'} />
          </Pressable>
        </View>
      </View>

      {selectionMode ? (
        <View style={styles.floatingTools}>
          <Pressable style={styles.toolBtn} onPress={onOpenBottomSheet}>
            <MaterialCommunityIcons name="star-outline" size={19} color="#B27A2B" />
            <Text style={styles.toolLabel}>{copy.highlights}</Text>
          </Pressable>
          <Pressable style={styles.toolBtn} onPress={onOpenBottomSheet}>
            <MaterialCommunityIcons name="notebook-outline" size={19} color="#6D63BF" />
            <Text style={styles.toolLabel}>{copy.notes}</Text>
          </Pressable>
          <Pressable style={styles.toolBtn} onPress={onBookmarkAction}>
            <MaterialCommunityIcons name="bookmark-outline" size={19} color="#C05757" />
            <Text style={styles.toolLabel}>{copy.saved}</Text>
          </Pressable>
          <Pressable style={styles.toolBtn} onPress={() => Alert.alert('Share', isTamil ? 'பகிர்வு UI மட்டும்' : 'Share UI only')}>
            <MaterialCommunityIcons name="share-variant-outline" size={19} color="#4F6D8F" />
            <Text style={styles.toolLabel}>Share</Text>
          </Pressable>
          <Pressable style={styles.toolBtn} onPress={onCopySelectedVerses}>
            <MaterialCommunityIcons name="content-copy" size={19} color="#6D63BF" />
            <Text style={styles.toolLabel}>{copy.copyAction}</Text>
          </Pressable>
          <Pressable style={styles.toolBtn} onPress={onAiExplain}>
            <MaterialCommunityIcons name="lightbulb-on-outline" size={19} color="#4E8A5F" />
            <Text style={styles.toolLabel}>{copy.aiExplain}</Text>
          </Pressable>
        </View>
      ) : null}

      {isBottomSheetMounted ? (
        <Animated.View style={[styles.bottomSheet, {transform: [{translateY: bottomSheetTranslateY}]}]}>
          <View style={styles.sheetHead}>
            <Text style={styles.sheetTitle}>{selectionMode ? `${selectedReferences.length} ${copy.selectVerse}` : copy.selectVerse}</Text>
            <Pressable onPress={onCloseBottomSheet} style={styles.sheetClose}><Text style={styles.sheetCloseTxt}>✕</Text></Pressable>
          </View>

          <Text style={styles.sheetLabel}>{copy.selectHighlight}</Text>
          <View style={styles.swatchRow}>
            {highlightOptions.map(color => (
              <Pressable key={color} style={[styles.swatch, {backgroundColor: color}]} onPress={() => onHighlightAction(color)} />
            ))}
          </View>

          <TextInput
            multiline
            style={styles.noteBox}
            value={noteDraft}
            onChangeText={onNoteChange}
            placeholder={copy.notePlaceholder}
            placeholderTextColor="#89786F"
          />

          <View style={styles.sheetActions}>
            <Pressable style={[styles.sheetActionBtn, styles.bookmarkAct]} onPress={onBookmarkAction} disabled={isMutating}><Text style={styles.sheetActionTxt}>{bookmarkActionLabel}</Text></Pressable>
            <Pressable style={[styles.sheetActionBtn, styles.saveAct]} onPress={onSaveNote} disabled={isMutating}><Text style={styles.sheetActionTxt}>{copy.saveNote}</Text></Pressable>
            <Pressable style={[styles.sheetActionBtn, styles.clearAct]} onPress={onClearHighlight} disabled={isMutating}><Text style={styles.sheetActionTxt}>{copy.clear}</Text></Pressable>
          </View>
        </Animated.View>
      ) : null}

      <Modal transparent visible={isNavigatorOpen} animationType="fade" onRequestClose={() => setIsNavigatorOpen(false)}>
        <View style={styles.sideNavigatorScrim}>
          <Pressable style={styles.sideNavigatorBackdrop} onPress={() => setIsNavigatorOpen(false)} />
          <View style={styles.sideNavigatorSheet}>
            <View style={styles.navigatorHead}>
              <Text style={styles.navigatorTitle}>{copy.goTo}</Text>
              <Pressable onPress={() => setIsNavigatorOpen(false)}><Text style={styles.navigatorClose}>✕</Text></Pressable>
            </View>

            <View style={styles.testamentRow}>
              <Pressable
                style={[styles.testamentBtn, selectedTestament === 'old' && styles.testamentBtnActive]}
                onPress={() => {
                  onTestamentChange('old');
                }}>
                <Text style={[styles.testamentTxt, selectedTestament === 'old' && styles.testamentTxtActive]}>{copy.old}</Text>
              </Pressable>
              <Pressable
                style={[styles.testamentBtn, selectedTestament === 'new' && styles.testamentBtnActive]}
                onPress={() => {
                  onTestamentChange('new');
                }}>
                <Text style={[styles.testamentTxt, selectedTestament === 'new' && styles.testamentTxtActive]}>{copy.new}</Text>
              </Pressable>
            </View>

            <View style={styles.categoryRow}>
              {(selectedTestament === 'old' ? OLD_CATEGORIES : NEW_CATEGORIES).map(cat => {
                const isActive = activeCats.includes(cat.key);
                return (
                  <Pressable
                    key={cat.key}
                    onPress={() => toggleCat(cat.key)}
                    style={[styles.categoryBtn, isActive ? styles.categoryBtnActive : styles.categoryBtnInactive]}>
                    <Text style={[styles.categoryIcon, isActive && styles.categoryIconActive]}>{cat.icon}</Text>
                    <Text style={[styles.categoryLabel, isActive && styles.categoryLabelActive]}>{cat.label}</Text>
                  </Pressable>
                );
              })}
            </View>

            <Text style={styles.navigatorSecTitle}>{copy.books}</Text>
            <ScrollView style={styles.gridBlock} contentContainerStyle={styles.bookGrid}>
              {categoryBooks.map(book => (
                <Pressable
                  key={book.name}
                  style={[styles.gridChip, selectedBook === book.name && styles.gridChipActive]}
                  onPress={() => { onBookPress(book.name); setIsNavigatorOpen(false); }}>
                  <Text style={[styles.gridChipText, selectedBook === book.name && styles.gridChipTextActive]} numberOfLines={1}>{getBookLabel(book.name)}</Text>
                </Pressable>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );

  const renderSaved = () => (
    <ScrollView style={styles.pageScroll} contentContainerStyle={styles.pageContent}>
      <Text style={styles.savedTitle}>{copy.saved}</Text>
      <View style={styles.metricsRow}>
        <Pressable style={[styles.metricCard, libraryFilter === 'bookmark' && styles.metricCardActive]} onPress={() => setLibraryFilter('bookmark')}>
          <Text style={[styles.metricNum, libraryFilter === 'bookmark' && styles.metricNumActive]}>{summary.bookmarkCount}</Text>
          <Text style={[styles.metricLbl, libraryFilter === 'bookmark' && styles.metricLblActive]}>{copy.saved}</Text>
        </Pressable>
        <Pressable style={[styles.metricCard, libraryFilter === 'highlight' && styles.metricCardActive]} onPress={() => setLibraryFilter('highlight')}>
          <Text style={[styles.metricNum, libraryFilter === 'highlight' && styles.metricNumActive]}>{summary.highlightCount}</Text>
          <Text style={[styles.metricLbl, libraryFilter === 'highlight' && styles.metricLblActive]}>{copy.highlights}</Text>
        </Pressable>
        <Pressable style={[styles.metricCard, libraryFilter === 'note' && styles.metricCardActive]} onPress={() => setLibraryFilter('note')}>
          <Text style={[styles.metricNum, libraryFilter === 'note' && styles.metricNumActive]}>{summary.noteCount}</Text>
          <Text style={[styles.metricLbl, libraryFilter === 'note' && styles.metricLblActive]}>{copy.notes}</Text>
        </Pressable>
      </View>

      <View style={styles.savedListCard}>
        {displayEntries.length ? (
          displayEntries.map(entry => (
            <View key={entry.reference + entry.updatedAt} style={styles.savedItemWrap}>
              <Pressable
                style={[
                  styles.savedItemCard,
                  libraryFilter === 'highlight' && entry.highlightColor
                    ? {backgroundColor: entry.highlightColor}
                    : null,
                ]}
                onPress={() => onLibraryEntryPress(entry)}>
                <Text style={styles.savedItemRef}>{formatRef(entry.book, entry.chapter, entry.verse)}</Text>
                <Text style={styles.savedItemText} numberOfLines={2}>
                  {libraryFilter === 'note' ? (entry.note ?? entry.text) : entry.text}
                </Text>
              </Pressable>
              <Pressable
                style={styles.savedDeleteBtn}
                onPress={() => {
                  if (libraryFilter === 'bookmark') onDeleteBookmark(entry.reference);
                  if (libraryFilter === 'highlight') onDeleteHighlight(entry.reference);
                  if (libraryFilter === 'note') onDeleteNote(entry.reference);
                }}>
                <Text style={styles.savedDeleteText}>🗑</Text>
              </Pressable>
            </View>
          ))
        ) : (
          <Text style={styles.savedEmpty}>{isTamil ? 'எந்த பதிவும் இல்லை.' : 'No entries yet.'}</Text>
        )}
      </View>
    </ScrollView>
  );

  const renderPlaceholder = (title: string, subtitle: string) => (
    <View style={styles.placeholderPage}>
      <Text style={styles.placeholderTitle}>{title}</Text>
      <Text style={styles.placeholderSub}>{subtitle}</Text>
      <View style={styles.placeholderCard}>
        <Text style={styles.placeholderCardTitle}>{isTamil ? 'UI தயாராக உள்ளது' : 'Design ready'}</Text>
        <Text style={styles.placeholderCardSub}>{isTamil ? 'இங்கே பின்னர் தரவு/இன்டிக்ரேஷன் சேர்க்கலாம்.' : 'We can integrate full functionality in next phase.'}</Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="dark-content" translucent={false} backgroundColor="#F7F4EE" />

      {errorMessage ? (
        <View style={styles.errorBanner}><Text style={styles.errorText}>{errorMessage}</Text></View>
      ) : null}

      <View style={styles.contentWrap}>
        {activeTab === 'home' ? renderHome() : null}
        {activeTab === 'bible' ? renderBible() : null}
        {activeTab === 'saved' ? renderSaved() : null}
        {activeTab === 'plans' ? (
          selectedPlan ? (
            <PlanDetails
              plan={selectedPlan}
              completedDays={planProgress[selectedPlan.id] ?? 0}
              selectedLanguage={selectedLanguage}
              onBackPress={handlePlanBackPress}
              onStartPlan={handleStartPlan}
              onMarkDayComplete={onMarkDayComplete}
              onResetPlan={onResetPlan}
            />
          ) : (
            <PlansList
              selectedLanguage={selectedLanguage}
              onBackPress={() => onTabChange('bible')}
              onPlanSelect={handlePlanSelect}
            />
          )
        ) : null}
      </View>

      <View style={styles.tabBar}>
        <Pressable
          style={styles.tabItem}
          onPress={() => {
            onTabChange('home');
          }}>
          <Text style={[styles.tabIcon, activeTab === 'home' && styles.tabIconActive]}>⌂</Text>
          <Text style={[styles.tabText, activeTab === 'home' && styles.tabTextActive]}>{copy.home}</Text>
        </Pressable>

        <Pressable
          style={styles.tabItem}
          onPress={() => {
            onTabChange('bible');
          }}>
          <Text style={[styles.tabIcon, activeTab === 'bible' && styles.tabIconActive]}>📖</Text>
          <Text style={[styles.tabText, activeTab === 'bible' && styles.tabTextActive]}>{copy.bible}</Text>
        </Pressable>

        <Pressable
          style={styles.tabItem}
          onPress={() => {
            onTabChange('plans');
          }}>
          <Text style={[styles.tabIcon, activeTab === 'plans' && styles.tabIconActive]}>☑</Text>
          <Text style={[styles.tabText, activeTab === 'plans' && styles.tabTextActive]}>{copy.plans}</Text>
        </Pressable>

        <Pressable
          style={styles.tabItem}
          onPress={() => {
            setLibraryFilter('bookmark');
            onTabChange('saved');
          }}>
          <Text style={[styles.tabIcon, activeTab === 'saved' && styles.tabIconActive]}>🔖</Text>
          <Text style={[styles.tabText, activeTab === 'saved' && styles.tabTextActive]}>{copy.savedTab}</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#F7F4EE',
    paddingTop: Platform.OS === 'android' ? (StatusBar.currentHeight ?? 0) : 0,
  },
  contentWrap: {flex: 1},
  errorBanner: {
    marginHorizontal: 16,
    marginTop: 8,
    borderRadius: 12,
    backgroundColor: '#FDE7E7',
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  errorText: {color: '#812626', fontWeight: '600'},

  pageScroll: {flex: 1},
  pageContent: {padding: 16, paddingBottom: 24, gap: 16},

  brandRow: {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'},
  brandLeft: {flexDirection: 'row', alignItems: 'center', gap: 10},
  brandLogo: {fontSize: 20, color: '#B88737'},
  brandTitle: {fontSize: 20, fontWeight: '800', color: '#18202A', fontFamily: 'Poppins_500Medium'},
  langBtn: {
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#E8DDD0',
    backgroundColor: '#FFFDF9',
    paddingHorizontal: 16,
    paddingVertical: 8,
  },
  langBtnText: {fontWeight: '700', color: '#30343A', fontFamily: 'Poppins_500Medium'},
  heroTitleRow: {flexDirection: 'row', alignItems: 'center', gap: 8},
  heroTitle: {fontSize: 22, fontWeight: '800', color: '#181A1F', fontFamily: 'Poppins_500Medium'},
  heroCrossIcon: {marginTop: 1, color: '#B88737', fontSize: 22, lineHeight: 22},
  heroSub: {fontSize: 14, color: '#666E7B', marginTop: -4, fontFamily: 'Inter_400Regular'},

  searchShell: {
    flexDirection: 'row',
    alignItems: 'center',
    minHeight: 40,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#E6DDD2',
    backgroundColor: '#FFFEFC',
    paddingHorizontal: 14,
    paddingVertical: 4,
  },
  searchMicButton: {
    width: 28,
    height: 28,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchMicButtonActive: {
    backgroundColor: '#FCE7E8',
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    paddingHorizontal: 10,
    paddingVertical: 0,
    color: '#1D222B',
    fontFamily: 'Poppins_500Medium',
  },

  continueCard: {
    borderRadius: 22,
    borderWidth: 1,
    borderColor: '#DDE9E0',
    backgroundColor: '#F4FBF6',
    padding: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  continueLeftIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#E6F1EA',
  },
  continueIconText: {fontSize: 28},
  continueMain: {flex: 1},
  sectionKicker: {fontSize: 11, fontWeight: '800', color: '#2D7A59', fontFamily: 'Inter_400Regular'},
  continueTitle: {fontSize: 17, fontWeight: '800', color: '#1F2732', fontFamily: 'Poppins_500Medium'},
  continueSub: {fontSize: 13, color: '#6A7079', fontFamily: 'Inter_400Regular'},
  progressTrack: {
    marginVertical: 6,
    borderRadius: 999,
    backgroundColor: '#D7E8DC',
    height: 7,
    overflow: 'hidden',
  },
  progressFill: {height: 7, backgroundColor: '#2E7E5F', borderRadius: 999},
  continueBtn: {
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 10,
    backgroundColor: '#2E7E5F',
  },
  continueBtnText: {color: '#FFFFFF', fontWeight: '700', fontSize: 12, fontFamily: 'Poppins_500Medium'},

  votdCard: {
    borderRadius: 24,
    borderWidth: 1,
    borderColor: '#E8D9C0',
    padding: 16,
    overflow: 'hidden',
  },
  votdBgImage: {
    borderRadius: 24,
    resizeMode: 'cover',
  },
  votdOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(248, 234, 203, 0.48)',
    borderRadius: 24,
  },
  votdGradientWrap: {
    ...StyleSheet.absoluteFillObject,
    flexDirection: 'row',
    borderRadius: 24,
    overflow: 'hidden',
  },
  votdGradientStop: {
    flex: 1,
  },
  votdKicker: {fontSize: 12, fontWeight: '700', color: '#B89433', marginBottom: 10, letterSpacing: 0.5, fontFamily: 'Inter_400Regular'},
  votdText: {
    fontSize: 14,
    lineHeight: 22,
    color: '#1A1510',
    fontWeight: '500',
    fontFamily: 'Merriweather_400Regular',
    width: '80%',
  },
  votdRef: {marginTop: 12, fontSize: 14, fontWeight: '700', color: '#B89433', fontFamily: 'Inter_400Regular'},
  votdBtn: {
    alignSelf: 'flex-start',
    marginTop: 12,
    minWidth: 132,
    borderRadius: 999,
    borderWidth: 0,
    backgroundColor: '#F5EDE5',
    paddingHorizontal: 15,
    paddingVertical: 6,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  votdBtnText: {
    fontSize: 11,
    fontWeight: '600',
    lineHeight: 16,
    marginTop: 1,
    color: '#1A1510',
    fontFamily: 'Poppins_500Medium',
    textAlign: 'center',
  },
  votdBtnArrow: {
    fontSize: 16,
    fontWeight: '700',
    lineHeight: 16,
    marginTop: -1,
    fontFamily: 'Poppins_500Medium',
  },

  streakCard: {
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#E4E3E0',
    backgroundColor: '#FFFEFC',
    padding: 14,
  },
  streakHeader: {flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12},
  streakTitle: {fontSize: 12, fontWeight: '800', color: '#2E3C58', fontFamily: 'Poppins_500Medium'},
  streakCount: {fontSize: 12, fontWeight: '800', color: '#B97A1D', fontFamily: 'Poppins_500Medium'},
  planProgressMeta: {
    fontSize: 12,
    color: '#5A606C',
    marginBottom: 10,
    fontFamily: 'Inter_400Regular',
  },
  streakDays: {flexDirection: 'row', justifyContent: 'space-between'},
  dayWrap: {alignItems: 'center', gap: 4},
  dayDot: {
    width: 32,
    height: 32,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#E4E1DC',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
  },
  dayDotDone: {backgroundColor: '#EAF4ED', borderColor: '#D4E6DA'},
  dayDotActive: {borderColor: '#B5873A', borderWidth: 1.5},
  dayTick: {color: '#2E7E5F', fontWeight: '800', fontFamily: 'Inter_400Regular'},
  dayLabel: {fontSize: 12, color: '#5A606C', fontFamily: 'Inter_400Regular'},
  streakNote: {textAlign: 'center', marginTop: 10, color: '#646A76', fontSize: 13, fontFamily: 'Inter_400Regular'},
  streakNoteEmpty: {fontSize: 11, color: '#8A8F99'},

  sectionTitle: {fontSize: 18, fontWeight: '800', color: '#223048', fontFamily: 'Poppins_500Medium'},
  quickActionsTitle: {
    fontSize: 14,
    fontWeight: '800',
    color: '#223048',
    fontFamily: 'Poppins_500Medium',
    letterSpacing: 0.4,
  },
  quickGrid: {flexDirection: 'row', gap: 8, justifyContent: 'space-between'},
  quickCard: {
    flex: 1,
    borderRadius: 15,
    borderWidth: 1,
    paddingVertical: 12,
    paddingHorizontal: 8,
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  quickCardHighlights: {
    borderColor: '#F0DFC2',
    backgroundColor: '#FFFBF3',
  },
  quickCardNotes: {
    borderColor: '#E7DEF4',
    backgroundColor: '#FBF8FF',
  },
  quickCardSaved: {
    borderColor: '#F0DCDB',
    backgroundColor: '#FFF8F8',
  },
  quickCardPlans: {
    borderColor: '#D8E7F5',
    backgroundColor: '#F5FAFF',
  },
  quickIconBadge: {
    width: 36,
    height: 36,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  quickIconBadgeHighlights: {backgroundColor: '#FFF1D7', borderColor: '#F2D6A1'},
  quickIconBadgeNotes: {backgroundColor: '#F2EAFE', borderColor: '#D8C5F7'},
  quickIconBadgeSaved: {backgroundColor: '#FFE8E8', borderColor: '#F2C7C7'},
  quickIconBadgePlans: {backgroundColor: '#E8F3FF', borderColor: '#BFDCF8'},
  quickTitle: {
    fontSize: 12,
    fontWeight: '700',
    color: '#1E2431',
    textAlign: 'center',
    fontFamily: 'Poppins_500Medium',
    lineHeight: 16,
  },
  quickSub: {
    fontSize: 10,
    color: '#6F7480',
    marginTop: 4,
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
    lineHeight: 13,
  },

  recentHead: {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'},
  viewAll: {fontSize: 14, fontWeight: '700', color: '#B7842E', fontFamily: 'Poppins_500Medium'},
  recentCard: {
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#E6E0D7',
    backgroundColor: '#FFFDF9',
    overflow: 'hidden',
  },
  recentItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F0E8DD',
  },
  recentIcon: {fontSize: 18},
  recentTextWrap: {flex: 1},
  recentRef: {fontSize: 14, fontWeight: '700', color: '#242A35', fontFamily: 'Poppins_500Medium'},
  recentPreview: {fontSize: 13, color: '#686F7B', fontFamily: 'Inter_400Regular'},
  recentPreviewEmpty: {
    paddingHorizontal: 12,
    paddingVertical: 14,
  },
  recentTime: {fontSize: 12, color: '#8A8F99', fontFamily: 'Inter_400Regular'},

  bibleWrap: {flex: 1},
  readHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#E9E1D6',
    backgroundColor: '#FFFCF7',
    zIndex: 2,
    elevation: 2,
  },
  verseStripWrap: {
    borderBottomWidth: 1,
    borderBottomColor: '#E9E1D6',
    backgroundColor: '#FFF9F1',
    paddingVertical: 8,
  },
  verseStripRow: {
    paddingHorizontal: 12,
    gap: 8,
  },
  verseStripChip: {
    minWidth: 36,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#E4D8C9',
    backgroundColor: '#FFFDF9',
    paddingHorizontal: 10,
    paddingVertical: 6,
    alignItems: 'center',
  },
  verseStripChipActive: {
    backgroundColor: '#F2E5D3',
    borderColor: '#C59443',
  },
  verseStripText: {
    fontSize: 12,
    color: '#2C2A27',
    fontWeight: '600',
    fontFamily: 'Inter_400Regular',
  },
  verseStripTextActive: {
    color: '#7A4C18',
    fontWeight: '700',
  },
  headerActions: {flexDirection: 'row', gap: 2},
  headerIconBtn: {
    width: 34,
    height: 34,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 999,
  },
  headerIcon: {fontSize: 16, color: '#22252C'},
  refPill: {
    flex: 1,
    marginHorizontal: 8,
    borderRadius: 999,
    backgroundColor: '#F2EADB',
    minHeight: 38,
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  refPillText: {textAlign: 'center', color: '#2A241E', fontWeight: '700', fontFamily: 'Poppins_500Medium'},

  verseList: {padding: 14, paddingBottom: 138, gap: 10},
  verseCard: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#ECE2D5',
    paddingHorizontal: 14,
    paddingVertical: 12,
    backgroundColor: '#FFFDF9',
  },
  verseCardSelected: {
    borderColor: '#1E3135',
    borderWidth: 2,
  },
  verseText: {fontSize: 16, lineHeight: 26, color: '#231A16', fontFamily: 'Merriweather_400Regular'},
  verseNo: {fontWeight: '800', color: '#B58536', fontFamily: 'Inter_400Regular'},
  fontSizeBtn: {
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#DDD3C5',
    backgroundColor: '#F5EDE2',
    paddingHorizontal: 8,
    paddingVertical: 5,
    marginHorizontal: 2,
  },
  fontSizeBtnText: {fontSize: 11, fontWeight: '700', color: '#3A2A1E', fontFamily: 'Poppins_500Medium'},
  verseMetaRow: {flexDirection: 'row', gap: 8, marginTop: 8},
  verseMetaChip: {
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#E6D7C8',
    backgroundColor: '#FBF2E8',
    paddingHorizontal: 10,
    paddingVertical: 4,
    fontSize: 11,
    fontWeight: '700',
    color: '#654E3B',
    fontFamily: 'Inter_400Regular',
  },
  verseColorHintWrap: {marginTop: 8, alignItems: 'flex-start'},
  verseColorHint: {
    width: 32,
    height: 6,
    borderRadius: 999,
  },

  floatingTools: {
    position: 'absolute',
    left: 10,
    right: 10,
    bottom: 84,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#E9DDCD',
    backgroundColor: '#FFF9F1',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 8,
    paddingVertical: 8,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowOffset: {width: 0, height: 4},
    shadowRadius: 10,
    elevation: 6,
  },
  toolBtn: {
    alignItems: 'center',
    justifyContent: 'center',
    gap: 3,
    width: '15.6%',
    borderRadius: 10,
    paddingVertical: 6,
  },
  toolLabel: {fontSize: 10, color: '#47372F', fontWeight: '600', textAlign: 'center', fontFamily: 'Inter_400Regular'},
  chapterDockBar: {
    position: 'absolute',
    left: 10,
    right: 10,
    bottom: 10,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#E9DDCD',
    backgroundColor: '#FFF9F1',
    paddingHorizontal: 8,
    paddingVertical: 8,
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowOffset: {width: 0, height: 4},
    shadowRadius: 10,
    elevation: 6,
  },
  chapterDockRow: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  chapterDockPill: {
    flex: 1,
    minHeight: 48,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#E0D5C7',
    backgroundColor: '#F8F2E8',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    paddingHorizontal: 10,
  },
  chapterDockPillDisabled: {
    backgroundColor: '#F3EEE6',
    borderColor: '#E7DFD3',
  },
  chapterDockTitle: {
    fontSize: 11,
    color: '#3A332D',
    fontFamily: 'Poppins_500Medium',
    textAlign: 'center',
  },
  chapterDockTitleDisabled: {
    color: '#AAA296',
  },
  chapterDockSub: {
    fontSize: 10,
    color: '#6A635B',
    fontFamily: 'Inter_400Regular',
    textAlign: 'center',
  },
  chapterDockCenter: {
    width: 86,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 3,
  },
  chapterDockCenterIcon: {
    width: 42,
    height: 42,
    borderRadius: 21,
    borderWidth: 1,
    borderColor: '#DFCDB7',
    backgroundColor: '#F7ECDD',
    alignItems: 'center',
    justifyContent: 'center',
  },
  chapterDockCenterText: {
    fontSize: 10,
    color: '#7A4C18',
    fontFamily: 'Poppins_500Medium',
    textAlign: 'center',
  },

  bottomSheet: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    minHeight: 300,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    backgroundColor: '#FFF8F0',
    borderWidth: 1,
    borderColor: '#E6D8CA',
    paddingHorizontal: 16,
    paddingTop: 14,
    paddingBottom: 20,
    gap: 10,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowOffset: {width: 0, height: -3},
    shadowRadius: 8,
    elevation: 8,
  },
  sheetHead: {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'},
  sheetTitle: {fontSize: 17, fontWeight: '800', color: '#2A1E19', fontFamily: 'Poppins_500Medium'},
  sheetClose: {
    width: 32,
    height: 32,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#EEE2D6',
  },
  sheetCloseTxt: {fontSize: 16, fontWeight: '700', color: '#3A2A24', fontFamily: 'Poppins_500Medium'},
  sheetLabel: {fontSize: 12, fontWeight: '700', color: '#675349', fontFamily: 'Inter_400Regular'},
  swatchRow: {flexDirection: 'row', gap: 10},
  swatch: {
    width: 32,
    height: 32,
    borderRadius: 999,
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  noteBox: {
    minHeight: 110,
    borderRadius: 16,
    backgroundColor: '#F4ECE1',
    padding: 12,
    fontSize: 14,
    color: '#251C16',
    fontFamily: 'Inter_400Regular',
  },
  sheetActions: {flexDirection: 'row', justifyContent: 'flex-end', gap: 8},
  sheetActionBtn: {
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  sheetActionTxt: {color: '#FFF8F0', fontWeight: '700', fontSize: 12, fontFamily: 'Poppins_500Medium'},
  bookmarkAct: {backgroundColor: '#5B7A8F'},
  saveAct: {backgroundColor: '#6B8E5F'},
  clearAct: {backgroundColor: '#8B5A5A'},

  sideNavigatorScrim: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.28)',
    flexDirection: 'row',
  },
  sideNavigatorBackdrop: {flex: 1},
  sideNavigatorSheet: {
    width: '78%',
    backgroundColor: '#FFFCF8',
    paddingHorizontal: 16,
    paddingTop: 14,
    paddingBottom: 20,
    borderTopLeftRadius: 24,
    borderBottomLeftRadius: 24,
  },
  navigatorHead: {flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'},
  navigatorTitle: {fontSize: 20, fontWeight: '800', color: '#241D17', fontFamily: 'Poppins_500Medium'},
  navigatorClose: {fontSize: 20, color: '#2A2D34', fontWeight: '700', fontFamily: 'Poppins_500Medium'},
  testamentRow: {flexDirection: 'row', gap: 8, marginTop: 12},
  testamentBtn: {
    flex: 1,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#D9C7B0',
    paddingVertical: 10,
    alignItems: 'center',
  },
  testamentBtnActive: {backgroundColor: '#B37A2A', borderColor: '#B37A2A'},
  testamentTxt: {fontSize: 14, fontWeight: '700', color: '#2E2D2A', fontFamily: 'Poppins_500Medium'},
  testamentTxtActive: {color: '#FFF8F0'},

  categoryRow: {flexDirection: 'row', justifyContent: 'space-between', marginTop: 12, marginBottom: 4},
  categoryBtn: {
    alignItems: 'center',
    width: '24%',
    gap: 4,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E6D8CA',
    backgroundColor: '#FFF9F1',
  },
  categoryBtnActive: {borderColor: '#B37A2A', borderWidth: 2},
  categoryBtnInactive: {},
  categoryIcon: {
    width: 36,
    height: 36,
    borderRadius: 999,
    textAlign: 'center',
    textAlignVertical: 'center',
    lineHeight: 36,
    fontSize: 18,
    backgroundColor: '#F4ECE1',
    overflow: 'hidden',
  },
  categoryIconActive: {},
  categoryLabel: {fontSize: 11, color: '#524B43', fontWeight: '600', fontFamily: 'Inter_400Regular'},
  categoryLabelActive: {color: '#B37A2A', fontWeight: '700'},
  navigatorSecTitle: {fontSize: 15, fontWeight: '800', color: '#23201B', marginTop: 12, marginBottom: 8, fontFamily: 'Poppins_500Medium'},
  gridBlock: {maxHeight: '82%'},
  bookGrid: {flexDirection: 'row', flexWrap: 'wrap', gap: 8, paddingBottom: 4},
  gridChip: {
    width: '31%',
    borderRadius: 9,
    borderWidth: 1,
    borderColor: '#E4D8C9',
    backgroundColor: '#FFF9F1',
    paddingVertical: 10,
    paddingHorizontal: 8,
  },
  gridChipActive: {backgroundColor: '#F2E5D3', borderColor: '#C59443'},
  gridChipText: {fontSize: 12, textAlign: 'center', color: '#2C2A27', fontWeight: '600', fontFamily: 'Inter_400Regular'},
  gridChipTextActive: {color: '#7A4C18', fontWeight: '700'},

  savedTitle: {fontSize: 22, fontWeight: '800', color: '#1F2027', fontFamily: 'Poppins_500Medium'},
  metricsRow: {flexDirection: 'row', gap: 10},
  metricCard: {
    flex: 1,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#E8DBCB',
    backgroundColor: '#FFFDF9',
    alignItems: 'center',
    paddingVertical: 14,
  },
  metricCardActive: {backgroundColor: '#1F3134', borderColor: '#1F3134'},
  metricNum: {fontSize: 22, fontWeight: '800', color: '#1F3134', fontFamily: 'Poppins_500Medium'},
  metricNumActive: {color: '#FFF8F0'},
  metricLbl: {fontSize: 12, fontWeight: '700', color: '#6C5E53', fontFamily: 'Inter_400Regular'},
  metricLblActive: {color: '#FFF8F0'},

  savedListCard: {
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#E8DFD2',
    backgroundColor: '#FFFDF9',
    padding: 12,
    gap: 10,
  },
  savedItemWrap: {flexDirection: 'row', alignItems: 'center', gap: 8},
  savedItemCard: {
    flex: 1,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E6D8CA',
    backgroundColor: '#F9F2E9',
    paddingHorizontal: 12,
    paddingVertical: 10,
    gap: 4,
  },
  savedItemRef: {fontSize: 12, fontWeight: '800', color: '#7C4B29', fontFamily: 'Inter_400Regular'},
  savedItemText: {fontSize: 14, lineHeight: 20, color: '#2A1D18', fontFamily: 'Inter_400Regular'},
  savedDeleteBtn: {
    width: 34,
    height: 34,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F0E6DC',
  },
  savedDeleteText: {fontSize: 16},
  savedEmpty: {fontSize: 14, color: '#605147', fontFamily: 'Inter_400Regular'},

  placeholderPage: {
    flex: 1,
    padding: 20,
    gap: 10,
    backgroundColor: '#F7F4EE',
  },
  placeholderTitle: {fontSize: 22, fontWeight: '800', color: '#1E2530', fontFamily: 'Poppins_500Medium'},
  placeholderSub: {fontSize: 16, color: '#646D7A', fontFamily: 'Inter_400Regular'},
  placeholderCard: {
    marginTop: 12,
    borderRadius: 18,
    borderWidth: 1,
    borderColor: '#E8DDCF',
    backgroundColor: '#FFFDF9',
    padding: 16,
    gap: 6,
  },
  placeholderCardTitle: {fontSize: 18, fontWeight: '800', color: '#3F301E', fontFamily: 'Poppins_500Medium'},
  placeholderCardSub: {fontSize: 14, color: '#716557', fontFamily: 'Inter_400Regular'},

  tabBar: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: '#E8DDCF',
    backgroundColor: '#FFFCF8',
    paddingBottom: 6,
  },
  tabItem: {flex: 1, alignItems: 'center', paddingTop: 8, paddingBottom: 4},
  homeShareWrap: {
    marginTop: 16,
    marginBottom: 8,
    alignItems: 'center',
  },
  homeShareButton: {
    width: 62,
    height: 62,
    borderRadius: 31,
    backgroundColor: '#2E8A5F',
    borderWidth: 3,
    borderColor: '#EAF5EF',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#1E6D4A',
    shadowOpacity: 0.24,
    shadowRadius: 8,
    shadowOffset: {width: 0, height: 3},
    elevation: 6,
  },
  tabIcon: {fontSize: 18, color: '#7D8390'},
  tabIconActive: {color: '#B37A2A'},
  tabText: {fontSize: 11, marginTop: 2, color: '#7D8390', fontWeight: '600', fontFamily: 'Inter_400Regular'},
  tabTextActive: {color: '#B37A2A', fontWeight: '700'},
});

export default ReaderPage;
