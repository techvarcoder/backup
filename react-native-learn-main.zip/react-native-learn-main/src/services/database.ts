import {open} from 'react-native-quick-sqlite';
import {tamilBibleSeed} from '../data/tamilBibleSeed';
import {englishBibleSeed} from '../data/englishBibleSeed';
import type {BookMeta, Verse} from '../types';

const DATABASE_NAME = 'bible_local.db';

let database = null as ReturnType<typeof open> | null;
let initializationPromise: Promise<void> | null = null;
let currentLanguage: 'en' | 'ta' = 'ta';

function normalizeBookName(book: string) {
  return book === 'undefined' ? 'Revelation' : book;
}

function normalizeReference(reference: string) {
  return reference.startsWith('undefined ')
    ? reference.replace(/^undefined\s+/, 'Revelation ')
    : reference;
}

function getBookAliases(book: string) {
  return book === 'Revelation' ? ['Revelation', 'undefined'] : [book];
}

function dedupeVersesByReference(verses: Verse[]) {
  const seen = new Set<string>();
  return verses.filter(verse => {
    if (seen.has(verse.reference)) {
      return false;
    }

    seen.add(verse.reference);
    return true;
  });
}

function getDatabase() {
  if (!database) {
    database = open({name: DATABASE_NAME});
  }

  return database;
}

function mapVerse(row: Record<string, unknown>): Verse {
  const rawBook = String(row.book);
  const rawReference = String(row.reference);

  return {
    book: normalizeBookName(rawBook),
    bookOrder: Number(row.book_order),
    chapter: Number(row.chapter),
    verse: Number(row.verse),
    reference: normalizeReference(rawReference),
    text: String(row.text),
  };
}

export async function initializeDatabase(language: 'en' | 'ta' = 'ta') {
  if (currentLanguage !== language) {
    initializationPromise = null;
    currentLanguage = language;
    await resetDatabase();
  }

  if (!initializationPromise) {
    initializationPromise = (async () => {
      const db = getDatabase();

      await db.executeAsync(`
        CREATE TABLE IF NOT EXISTS verses (
          reference TEXT PRIMARY KEY,
          book TEXT NOT NULL,
          book_order INTEGER NOT NULL,
          chapter INTEGER NOT NULL,
          verse INTEGER NOT NULL,
          text TEXT NOT NULL
        )
      `);

      await db.executeAsync(`
        CREATE TABLE IF NOT EXISTS user_content (
          id TEXT PRIMARY KEY,
          verse_ref TEXT NOT NULL,
          type TEXT NOT NULL,
          content TEXT,
          color TEXT,
          is_synced INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL,
          UNIQUE(verse_ref, type)
        )
      `);

      await db.executeAsync(
        'CREATE INDEX IF NOT EXISTS idx_verses_book_chapter ON verses(book, chapter, verse)',
      );
      await db.executeAsync(
        'CREATE INDEX IF NOT EXISTS idx_user_content_verse_ref ON user_content(verse_ref)',
      );

      const countResult = await db.executeAsync(
        'SELECT COUNT(*) AS count FROM verses',
      );
      const count = Number(countResult.rows?.item(0).count ?? 0);

      if (count === 0) {
        const seed = language === 'en' ? englishBibleSeed : tamilBibleSeed;
        await db.executeBatchAsync(
          seed.map(verse => [
            'INSERT INTO verses(reference, book, book_order, chapter, verse, text) VALUES (?, ?, ?, ?, ?, ?)',
            [
              verse.reference,
              verse.book,
              verse.bookOrder,
              verse.chapter,
              verse.verse,
              verse.text,
            ],
          ]),
        );
      }
    })();
  }

  return initializationPromise;
}

export async function resetDatabase() {
  if (database) {
    try {
      await database.executeAsync('DROP TABLE IF EXISTS verses');
      await database.executeAsync('DROP TABLE IF EXISTS user_content');
    } catch (error) {
      console.error('Error resetting database:', error);
    }
  }
}

export async function getBooks(): Promise<BookMeta[]> {
  const result = await getDatabase().executeAsync(`
    SELECT
      CASE WHEN book = 'undefined' THEN 'Revelation' ELSE book END AS book,
      MIN(book_order) AS book_order,
      COUNT(DISTINCT chapter) AS chapter_count
    FROM verses
    GROUP BY CASE WHEN book = 'undefined' THEN 'Revelation' ELSE book END
    ORDER BY book_order ASC
  `);

  return result.rows?._array.map(row => ({
    name: String(row.book),
    bookOrder: Number(row.book_order),
    chapterCount: Number(row.chapter_count),
  })) ?? [];
}

export async function getChaptersForBook(book: string): Promise<number[]> {
  const aliases = getBookAliases(book);
  const placeholders = aliases.map(() => '?').join(', ');
  const result = await getDatabase().executeAsync(
    `SELECT DISTINCT chapter FROM verses WHERE book IN (${placeholders}) ORDER BY chapter ASC`,
    aliases,
  );

  return result.rows?._array.map(row => Number(row.chapter)) ?? [];
}

export async function getChapterVerses(
  book: string,
  chapter: number,
): Promise<Verse[]> {
  const aliases = getBookAliases(book);
  const placeholders = aliases.map(() => '?').join(', ');
  const result = await getDatabase().executeAsync(
    `SELECT reference, book, book_order, chapter, verse, text
     FROM verses
     WHERE book IN (${placeholders}) AND chapter = ?
     ORDER BY verse ASC`,
    [...aliases, chapter],
  );

  const verses = result.rows?._array.map(row => mapVerse(row)) ?? [];
  return dedupeVersesByReference(verses);
}

export async function searchVerses(query: string): Promise<Verse[]> {
  const match = `%${query}%`;
  const result = await getDatabase().executeAsync(
    `SELECT reference, book, book_order, chapter, verse, text
     FROM verses
     WHERE reference LIKE ? OR text LIKE ?
     ORDER BY book_order ASC, chapter ASC, verse ASC
     LIMIT 50`,
    [match, match],
  );

  const verses = result.rows?._array.map(row => mapVerse(row)) ?? [];
  return dedupeVersesByReference(verses);
}
