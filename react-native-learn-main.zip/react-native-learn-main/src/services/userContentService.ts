import {open} from 'react-native-quick-sqlite';
import {initializeDatabase} from './database';
import type {
  ContentSummary,
  HighlightColor,
  LibraryEntry,
  UserContentType,
  VerseContentState,
} from '../types';

const DATABASE_NAME = 'bible_local.db';

let database = null as ReturnType<typeof open> | null;

function normalizeBookName(book: string) {
  return book === 'undefined' ? 'Revelation' : book;
}

function normalizeReference(reference: string) {
  return reference.startsWith('undefined ')
    ? reference.replace(/^undefined\s+/, 'Revelation ')
    : reference;
}

function getDatabase() {
  if (!database) {
    database = open({name: DATABASE_NAME});
  }

  return database;
}

function createId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

async function upsertContent(
  verseRef: string,
  type: UserContentType,
  content: string | null,
  color: string | null,
) {
  const timestamp = new Date().toISOString();
  await getDatabase().executeAsync(
    `
      INSERT INTO user_content(
        id,
        verse_ref,
        type,
        content,
        color,
        is_synced,
        created_at,
        updated_at
      )
      VALUES (?, ?, ?, ?, ?, 0, ?, ?)
      ON CONFLICT(verse_ref, type)
      DO UPDATE SET
        content = excluded.content,
        color = excluded.color,
        updated_at = excluded.updated_at,
        is_synced = 0
    `,
    [createId(), verseRef, type, content, color, timestamp, timestamp],
  );
}

async function deleteContent(verseRef: string, type: UserContentType) {
  await getDatabase().executeAsync(
    'DELETE FROM user_content WHERE verse_ref = ? AND type = ?',
    [verseRef, type],
  );
}

export async function getContentForReferences(
  references: string[],
): Promise<Record<string, VerseContentState>> {
  if (!references.length) {
    return {};
  }

  const placeholders = references.map(() => '?').join(', ');
  const result = await getDatabase().executeAsync(
    `
      SELECT verse_ref, type, content, color
      FROM user_content
      WHERE verse_ref IN (${placeholders})
    `,
    references,
  );

  return (result.rows?._array ?? []).reduce<Record<string, VerseContentState>>(
    (accumulator, row) => {
      const verseRef = String(row.verse_ref);
      const current = accumulator[verseRef] ?? {
        bookmark: false,
        highlightColor: null,
        note: null,
      };

      if (row.type === 'bookmark') {
        current.bookmark = true;
      }

      if (row.type === 'highlight') {
        current.highlightColor = row.color ? String(row.color) : null;
      }

      if (row.type === 'note') {
        current.note = row.content ? String(row.content) : null;
      }

      accumulator[verseRef] = current;
      return accumulator;
    },
    {},
  );
}

export async function setBookmarks(references: string[], shouldBookmark: boolean) {
  await getDatabase().transaction(async tx => {
    for (const reference of references) {
      if (shouldBookmark) {
        const timestamp = new Date().toISOString();
        await tx.executeAsync(
          `
            INSERT INTO user_content(
              id,
              verse_ref,
              type,
              content,
              color,
              is_synced,
              created_at,
              updated_at
            )
            VALUES (?, ?, 'bookmark', NULL, NULL, 0, ?, ?)
            ON CONFLICT(verse_ref, type)
            DO UPDATE SET
              updated_at = excluded.updated_at,
              is_synced = 0
          `,
          [createId(), reference, timestamp, timestamp],
        );
      } else {
        await tx.executeAsync(
          'DELETE FROM user_content WHERE verse_ref = ? AND type = ?',
          [reference, 'bookmark'],
        );
      }
    }
  });
}

export async function applyHighlight(
  references: string[],
  color: HighlightColor,
) {
  await getDatabase().transaction(async tx => {
    const timestamp = new Date().toISOString();

    for (const reference of references) {
      await tx.executeAsync(
        `
          INSERT INTO user_content(
            id,
            verse_ref,
            type,
            content,
            color,
            is_synced,
            created_at,
            updated_at
          )
          VALUES (?, ?, 'highlight', NULL, ?, 0, ?, ?)
          ON CONFLICT(verse_ref, type)
          DO UPDATE SET
            color = excluded.color,
            updated_at = excluded.updated_at,
            is_synced = 0
        `,
        [createId(), reference, color, timestamp, timestamp],
      );
    }
  });
}

export async function clearHighlight(references: string[]) {
  await getDatabase().transaction(async tx => {
    for (const reference of references) {
      await tx.executeAsync(
        'DELETE FROM user_content WHERE verse_ref = ? AND type = ?',
        [reference, 'highlight'],
      );
    }
  });
}

export async function saveNote(verseRef: string, content: string) {
  const nextContent = content.trim();
  if (!nextContent) {
    await deleteContent(verseRef, 'note');
    return;
  }

  await upsertContent(verseRef, 'note', nextContent, null);
}

export async function getContentSummary(): Promise<ContentSummary> {
  const result = await getDatabase().executeAsync(`
    SELECT
      SUM(CASE WHEN type = 'bookmark' THEN 1 ELSE 0 END) AS bookmark_count,
      SUM(CASE WHEN type = 'highlight' THEN 1 ELSE 0 END) AS highlight_count,
      SUM(CASE WHEN type = 'note' THEN 1 ELSE 0 END) AS note_count
    FROM user_content
  `);

  const row = result.rows?.item(0);

  return {
    bookmarkCount: Number(row?.bookmark_count ?? 0),
    highlightCount: Number(row?.highlight_count ?? 0),
    noteCount: Number(row?.note_count ?? 0),
  };
}

export async function getLibraryEntries(): Promise<LibraryEntry[]> {
  const result = await getDatabase().executeAsync(`
    SELECT
      v.reference,
      v.book,
      v.chapter,
      v.verse,
      v.text,
      MAX(CASE WHEN uc.type = 'bookmark' THEN 1 ELSE 0 END) AS bookmark,
      MAX(CASE WHEN uc.type = 'highlight' THEN uc.color ELSE NULL END) AS highlight_color,
      MAX(CASE WHEN uc.type = 'note' THEN uc.content ELSE NULL END) AS note,
      MAX(uc.updated_at) AS updated_at
    FROM user_content uc
    INNER JOIN verses v ON v.reference = uc.verse_ref
    GROUP BY v.reference, v.book, v.chapter, v.verse, v.text, v.book_order
    ORDER BY updated_at DESC, v.book_order ASC, v.chapter ASC, v.verse ASC
  `);

  return (result.rows?._array ?? []).map(row => ({
    reference: normalizeReference(String(row.reference)),
    book: normalizeBookName(String(row.book)),
    chapter: Number(row.chapter),
    verse: Number(row.verse),
    text: String(row.text),
    bookmark: Number(row.bookmark ?? 0) === 1,
    highlightColor: row.highlight_color ? String(row.highlight_color) : null,
    note: row.note ? String(row.note) : null,
    updatedAt: String(row.updated_at ?? ''),
  }));
}

export async function deleteBookmark(verseRef: string) {
  await deleteContent(verseRef, 'bookmark');
}

export async function deleteHighlight(verseRef: string) {
  await deleteContent(verseRef, 'highlight');
}

export async function deleteNote(verseRef: string) {
  await deleteContent(verseRef, 'note');
}
