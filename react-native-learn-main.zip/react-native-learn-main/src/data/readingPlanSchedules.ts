// Reading plan daily schedules for all 5 plans.
// 30-day plan: handcrafted highlighted passages.
// 60 / 90 / 180 / 365-day plans: algorithmically generated from book lists.

export type DayReading = {
  day: number;
  passages: string[];
  theme: string;
};

// ─── 30 rotating reflection themes ──────────────────────────────────────────
const THEMES: string[] = [
  'In the beginning, God created everything good.',
  'Sin entered, but God promised a Redeemer.',
  'God saves through water and covenant.',
  'God calls ordinary people to do extraordinary things.',
  'The God who provides on the mountain.',
  'God is at work even in our deepest suffering.',
  'God turns trials into triumphs for His glory.',
  'God hears and responds to the cries of His people.',
  'God delivers His people from impossible situations.',
  "God's law is a gift of love and guidance.",
  'The Lord is my shepherd — I shall not want.',
  'God is our refuge and fortress in every storm.',
  "Great is God's mercy toward those who fear Him.",
  'Trust in the Lord with all your heart.',
  'He was pierced for our transgressions.',
  'Come, all who are thirsty — God satisfies fully.',
  "God's plans are always for good and not disaster.",
  'Blessed are the pure in heart, for they shall see God.',
  'Jesus faced the cross with perfect trust in the Father.',
  'He is risen! Death has been defeated forever.',
  'With God, all things are truly possible.',
  'Let it be done to me according to Your word.',
  "Jesus overcame every temptation by God's Word.",
  'Heaven rejoices when even one lost person is found.',
  'The Spirit of God leads us into all truth.',
  'The Holy Spirit was poured out at Pentecost.',
  'The grace of God can transform any life.',
  'Nothing can separate us from the love of God.',
  'Love is patient, kind, and never fails.',
  'Behold, God makes all things new — forever with Him.',
];

// ─── 30-Day Plan (hand-curated highlights) ───────────────────────────────────
const PLAN_30: DayReading[] = [
  {day: 1,  passages: ['Gen 1-2', 'John 1:1-18'],          theme: THEMES[0]},
  {day: 2,  passages: ['Gen 3-5', 'John 1:19-51'],         theme: THEMES[1]},
  {day: 3,  passages: ['Gen 6-9', 'John 2'],               theme: THEMES[2]},
  {day: 4,  passages: ['Gen 12, 15', 'John 3:1-21'],       theme: THEMES[3]},
  {day: 5,  passages: ['Gen 22, 28', 'John 3:22-36'],      theme: THEMES[4]},
  {day: 6,  passages: ['Gen 37, 39', 'John 4:1-26'],       theme: THEMES[5]},
  {day: 7,  passages: ['Gen 41-42', 'John 4:27-54'],       theme: THEMES[6]},
  {day: 8,  passages: ['Ex 1-3', 'John 5:1-30'],           theme: THEMES[7]},
  {day: 9,  passages: ['Ex 12-14', 'John 5:31-47'],        theme: THEMES[8]},
  {day: 10, passages: ['Ex 19-20', 'John 6:1-21'],         theme: THEMES[9]},
  {day: 11, passages: ['Ps 1, 8, 23', 'John 6:22-59'],     theme: THEMES[10]},
  {day: 12, passages: ['Ps 51, 91', 'John 6:60-71'],       theme: THEMES[11]},
  {day: 13, passages: ['Ps 103, 119:1-32', 'John 7:1-31'],theme: THEMES[12]},
  {day: 14, passages: ['Prov 3-4', 'John 7:32-53'],        theme: THEMES[13]},
  {day: 15, passages: ['Isa 40, 53', 'John 8:1-30'],       theme: THEMES[14]},
  {day: 16, passages: ['Isa 55, 61', 'John 8:31-59'],      theme: THEMES[15]},
  {day: 17, passages: ['Jer 29:1-14', 'Dan 3', 'John 9'],  theme: THEMES[16]},
  {day: 18, passages: ['Matt 5-7', 'John 10:1-21'],        theme: THEMES[17]},
  {day: 19, passages: ['Matt 26:36-75', 'John 10:22-42'],  theme: THEMES[18]},
  {day: 20, passages: ['Matt 27-28', 'John 11:1-44'],      theme: THEMES[19]},
  {day: 21, passages: ['Mark 10:17-52', 'John 11:45-57'],  theme: THEMES[20]},
  {day: 22, passages: ['Luke 1:26-56', 'John 12:1-36'],    theme: THEMES[21]},
  {day: 23, passages: ['Luke 4:1-30', 'John 12:37-50'],    theme: THEMES[22]},
  {day: 24, passages: ['Luke 15', 'John 13'],              theme: THEMES[23]},
  {day: 25, passages: ['Luke 23-24', 'John 14'],           theme: THEMES[24]},
  {day: 26, passages: ['Acts 2', 'John 15'],               theme: THEMES[25]},
  {day: 27, passages: ['Acts 9:1-31', 'John 16'],          theme: THEMES[26]},
  {day: 28, passages: ['Rom 8', 'John 17'],                theme: THEMES[27]},
  {day: 29, passages: ['1 Cor 13', 'Phil 4', 'John 18'],   theme: THEMES[28]},
  {day: 30, passages: ['Rev 21-22', 'John 19-21'],         theme: THEMES[29]},
];

// ─── Generator for 60 / 90 / 180 / 365-day plans ────────────────────────────

type BookRange = {name: string; start: number; end: number};

function generateSchedule(books: BookRange[], totalDays: number): DayReading[] {
  // Flatten all chapters into an ordered list
  const allChapters: {book: string; ch: number}[] = [];
  for (const b of books) {
    for (let ch = b.start; ch <= b.end; ch++) {
      allChapters.push({book: b.name, ch});
    }
  }

  const total = allChapters.length;
  const schedule: DayReading[] = [];
  let idx = 0;

  for (let day = 1; day <= totalDays; day++) {
    // Spread chapters evenly across days using proportional slicing
    const nextIdx = Math.round((day / totalDays) * total);
    const dayChapters = allChapters.slice(idx, nextIdx);
    idx = nextIdx;

    // Merge consecutive chapters of the same book into ranges
    const passages: string[] = [];
    let i = 0;
    while (i < dayChapters.length) {
      const bookName = dayChapters[i].book;
      let j = i + 1;
      while (j < dayChapters.length && dayChapters[j].book === bookName) {
        j++;
      }
      const segment = dayChapters.slice(i, j);
      const first = segment[0].ch;
      const last = segment[segment.length - 1].ch;
      passages.push(first === last ? `${bookName} ${first}` : `${bookName} ${first}-${last}`);
      i = j;
    }

    schedule.push({
      day,
      passages: passages.length > 0 ? passages : ['Rest & Reflect'],
      theme: THEMES[(day - 1) % THEMES.length],
    });
  }

  return schedule;
}

// ─── Book lists ───────────────────────────────────────────────────────────────

// 60-Day: Key OT highlights + full NT
const BOOKS_60: BookRange[] = [
  {name: 'Gen',   start: 1, end: 50},
  {name: 'Ex',    start: 1, end: 20},
  {name: 'Ps',    start: 1, end: 50},
  {name: 'Prov',  start: 1, end: 15},
  {name: 'Isa',   start: 40, end: 66},
  {name: 'Dan',   start: 1, end: 12},
  {name: 'Matt',  start: 1, end: 28},
  {name: 'Mark',  start: 1, end: 16},
  {name: 'Luke',  start: 1, end: 24},
  {name: 'John',  start: 1, end: 21},
  {name: 'Acts',  start: 1, end: 28},
  {name: 'Rom',   start: 1, end: 16},
  {name: 'Rev',   start: 1, end: 22},
]; // ~329 chapters ÷ 60 ≈ 5.5/day

// 90-Day: Major OT books + full NT
const BOOKS_90: BookRange[] = [
  {name: 'Gen',    start: 1, end: 50},
  {name: 'Ex',     start: 1, end: 40},
  {name: 'Deut',   start: 1, end: 34},
  {name: 'Josh',   start: 1, end: 24},
  {name: '1 Sam',  start: 1, end: 31},
  {name: 'Ps',     start: 1, end: 100},
  {name: 'Prov',   start: 1, end: 31},
  {name: 'Isa',    start: 1, end: 66},
  {name: 'Dan',    start: 1, end: 12},
  {name: 'Matt',   start: 1, end: 28},
  {name: 'Mark',   start: 1, end: 16},
  {name: 'Luke',   start: 1, end: 24},
  {name: 'John',   start: 1, end: 21},
  {name: 'Acts',   start: 1, end: 28},
  {name: 'Rom',    start: 1, end: 16},
  {name: '1 Cor',  start: 1, end: 16},
  {name: 'Eph',    start: 1, end: 6},
  {name: 'Phil',   start: 1, end: 4},
  {name: 'Heb',    start: 1, end: 13},
  {name: 'Rev',    start: 1, end: 22},
]; // ~602 chapters ÷ 90 ≈ 6.7/day

// 180-Day: Near-complete Bible
const BOOKS_180: BookRange[] = [
  {name: 'Gen',   start: 1, end: 50},
  {name: 'Ex',    start: 1, end: 40},
  {name: 'Lev',   start: 1, end: 27},
  {name: 'Num',   start: 1, end: 36},
  {name: 'Deut',  start: 1, end: 34},
  {name: 'Josh',  start: 1, end: 24},
  {name: 'Judg',  start: 1, end: 21},
  {name: 'Ruth',  start: 1, end: 4},
  {name: '1 Sam', start: 1, end: 31},
  {name: '2 Sam', start: 1, end: 24},
  {name: '1 Kgs', start: 1, end: 22},
  {name: '2 Kgs', start: 1, end: 25},
  {name: 'Job',   start: 1, end: 42},
  {name: 'Ps',    start: 1, end: 150},
  {name: 'Prov',  start: 1, end: 31},
  {name: 'Eccl',  start: 1, end: 12},
  {name: 'Isa',   start: 1, end: 66},
  {name: 'Jer',   start: 1, end: 52},
  {name: 'Dan',   start: 1, end: 12},
  {name: 'Hos',   start: 1, end: 14},
  {name: 'Jonah', start: 1, end: 4},
  {name: 'Mal',   start: 1, end: 4},
  {name: 'Matt',  start: 1, end: 28},
  {name: 'Mark',  start: 1, end: 16},
  {name: 'Luke',  start: 1, end: 24},
  {name: 'John',  start: 1, end: 21},
  {name: 'Acts',  start: 1, end: 28},
  {name: 'Rom',   start: 1, end: 16},
  {name: '1 Cor', start: 1, end: 16},
  {name: '2 Cor', start: 1, end: 13},
  {name: 'Gal',   start: 1, end: 6},
  {name: 'Eph',   start: 1, end: 6},
  {name: 'Phil',  start: 1, end: 4},
  {name: 'Col',   start: 1, end: 4},
  {name: 'Heb',   start: 1, end: 13},
  {name: 'James', start: 1, end: 5},
  {name: '1 Pet', start: 1, end: 5},
  {name: '1 John',start: 1, end: 5},
  {name: 'Rev',   start: 1, end: 22},
]; // ~1000 chapters ÷ 180 ≈ 5.6/day

// 365-Day: Complete Bible (all 66 books, 1189 chapters)
const BOOKS_365: BookRange[] = [
  {name: 'Gen',    start: 1, end: 50},
  {name: 'Ex',     start: 1, end: 40},
  {name: 'Lev',    start: 1, end: 27},
  {name: 'Num',    start: 1, end: 36},
  {name: 'Deut',   start: 1, end: 34},
  {name: 'Josh',   start: 1, end: 24},
  {name: 'Judg',   start: 1, end: 21},
  {name: 'Ruth',   start: 1, end: 4},
  {name: '1 Sam',  start: 1, end: 31},
  {name: '2 Sam',  start: 1, end: 24},
  {name: '1 Kgs',  start: 1, end: 22},
  {name: '2 Kgs',  start: 1, end: 25},
  {name: '1 Chr',  start: 1, end: 29},
  {name: '2 Chr',  start: 1, end: 36},
  {name: 'Ezra',   start: 1, end: 10},
  {name: 'Neh',    start: 1, end: 13},
  {name: 'Esth',   start: 1, end: 10},
  {name: 'Job',    start: 1, end: 42},
  {name: 'Ps',     start: 1, end: 150},
  {name: 'Prov',   start: 1, end: 31},
  {name: 'Eccl',   start: 1, end: 12},
  {name: 'Song',   start: 1, end: 8},
  {name: 'Isa',    start: 1, end: 66},
  {name: 'Jer',    start: 1, end: 52},
  {name: 'Lam',    start: 1, end: 5},
  {name: 'Ezek',   start: 1, end: 48},
  {name: 'Dan',    start: 1, end: 12},
  {name: 'Hos',    start: 1, end: 14},
  {name: 'Joel',   start: 1, end: 3},
  {name: 'Amos',   start: 1, end: 9},
  {name: 'Obad',   start: 1, end: 1},
  {name: 'Jonah',  start: 1, end: 4},
  {name: 'Mic',    start: 1, end: 7},
  {name: 'Nah',    start: 1, end: 3},
  {name: 'Hab',    start: 1, end: 3},
  {name: 'Zeph',   start: 1, end: 3},
  {name: 'Hag',    start: 1, end: 2},
  {name: 'Zech',   start: 1, end: 14},
  {name: 'Mal',    start: 1, end: 4},
  {name: 'Matt',   start: 1, end: 28},
  {name: 'Mark',   start: 1, end: 16},
  {name: 'Luke',   start: 1, end: 24},
  {name: 'John',   start: 1, end: 21},
  {name: 'Acts',   start: 1, end: 28},
  {name: 'Rom',    start: 1, end: 16},
  {name: '1 Cor',  start: 1, end: 16},
  {name: '2 Cor',  start: 1, end: 13},
  {name: 'Gal',    start: 1, end: 6},
  {name: 'Eph',    start: 1, end: 6},
  {name: 'Phil',   start: 1, end: 4},
  {name: 'Col',    start: 1, end: 4},
  {name: '1 Thes', start: 1, end: 5},
  {name: '2 Thes', start: 1, end: 3},
  {name: '1 Tim',  start: 1, end: 6},
  {name: '2 Tim',  start: 1, end: 4},
  {name: 'Titus',  start: 1, end: 3},
  {name: 'Phlm',   start: 1, end: 1},
  {name: 'Heb',    start: 1, end: 13},
  {name: 'James',  start: 1, end: 5},
  {name: '1 Pet',  start: 1, end: 5},
  {name: '2 Pet',  start: 1, end: 3},
  {name: '1 John', start: 1, end: 5},
  {name: '2 John', start: 1, end: 1},
  {name: '3 John', start: 1, end: 1},
  {name: 'Jude',   start: 1, end: 1},
  {name: 'Rev',    start: 1, end: 22},
]; // 1189 chapters ÷ 365 ≈ 3.25/day

// ─── Exported schedules ───────────────────────────────────────────────────────
export const PLAN_SCHEDULES: Record<string, DayReading[]> = {
  'plan-30':      PLAN_30,
  'plan-60':      generateSchedule(BOOKS_60,  60),
  'plan-90':      generateSchedule(BOOKS_90,  90),
  'plan-6months': generateSchedule(BOOKS_180, 180),
  'plan-1year':   generateSchedule(BOOKS_365, 365),
};
