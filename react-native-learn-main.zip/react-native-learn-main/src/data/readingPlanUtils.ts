import type {DayReading} from './readingPlanSchedules';

const BOOK_ALIAS_MAP: Record<string, string> = {
  Gen: 'Genesis',
  Ex: 'Exodus',
  Lev: 'Leviticus',
  Num: 'Numbers',
  Deut: 'Deuteronomy',
  Josh: 'Joshua',
  Judg: 'Judges',
  Ruth: 'Ruth',
  '1 Sam': '1 Samuel',
  '2 Sam': '2 Samuel',
  '1 Kgs': '1 Kings',
  '2 Kgs': '2 Kings',
  '1 Chr': '1 Chronicles',
  '2 Chr': '2 Chronicles',
  Ezra: 'Ezra',
  Neh: 'Nehemiah',
  Esth: 'Esther',
  Job: 'Job',
  Ps: 'Psalm',
  Prov: 'Proverbs',
  Eccl: 'Ecclesiastes',
  Isa: 'Isaiah',
  Jer: 'Jeremiah',
  Lam: 'Lamentations',
  Ezek: 'Ezekiel',
  Dan: 'Daniel',
  Hos: 'Hosea',
  Joel: 'Joel',
  Amos: 'Amos',
  Obad: 'Obadiah',
  Jonah: 'Jonah',
  Mic: 'Micah',
  Nah: 'Nahum',
  Hab: 'Habakkuk',
  Zeph: 'Zephaniah',
  Hag: 'Haggai',
  Zech: 'Zechariah',
  Mal: 'Malachi',
  Matt: 'Matthew',
  Mark: 'Mark',
  Luke: 'Luke',
  John: 'John',
  Acts: 'Acts',
  Rom: 'Romans',
  '1 Cor': '1 Corinthians',
  '2 Cor': '2 Corinthians',
  Gal: 'Galatians',
  Eph: 'Ephesians',
  Phil: 'Philippians',
  Col: 'Colossians',
  '1 Thes': '1 Thessalonians',
  '2 Thes': '2 Thessalonians',
  '1 Tim': '1 Timothy',
  '2 Tim': '2 Timothy',
  Titus: 'Titus',
  Phlm: 'Philemon',
  Heb: 'Hebrews',
  James: 'James',
  '1 Pet': '1 Peter',
  '2 Pet': '2 Peter',
  '1 John': '1 John',
  '2 John': '2 John',
  '3 John': '3 John',
  Jude: 'Jude',
  Rev: 'Revelation',
};

const SORTED_ALIASES = Object.keys(BOOK_ALIAS_MAP).sort((left, right) => right.length - left.length);

export type ReadingTarget = {
  book: string;
  chapter: number;
};

export function getReadingTarget(dayReading: DayReading | undefined): ReadingTarget | null {
  if (!dayReading || dayReading.passages.length === 0) {
    return null;
  }

  const firstPassage = dayReading.passages[0]?.trim();
  if (!firstPassage) {
    return null;
  }

  const alias = SORTED_ALIASES.find(item => firstPassage === item || firstPassage.startsWith(`${item} `));
  if (!alias) {
    return null;
  }

  const remaining = firstPassage.slice(alias.length).trim();
  const chapterMatch = remaining.match(/^(\d+)/);
  if (!chapterMatch) {
    return null;
  }

  return {
    book: BOOK_ALIAS_MAP[alias],
    chapter: Number(chapterMatch[1]),
  };
}