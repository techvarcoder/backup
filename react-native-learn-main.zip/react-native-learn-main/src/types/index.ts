export interface Verse {
  book: string;
  bookOrder: number;
  chapter: number;
  verse: number;
  reference: string;
  text: string;
}

export interface BookMeta {
  name: string;
  bookOrder: number;
  chapterCount: number;
}

export type UserContentType = 'bookmark' | 'highlight' | 'note';

export type HighlightColor = '#F4D58D' | '#B8D8BA' | '#E7B8C8';

export interface UserContentRecord {
  id: string;
  verseRef: string;
  type: UserContentType;
  content: string | null;
  color: string | null;
  isSynced: 0 | 1;
  createdAt: string;
  updatedAt: string;
}

export interface VerseContentState {
  bookmark: boolean;
  highlightColor: string | null;
  note: string | null;
}

export interface ContentSummary {
  bookmarkCount: number;
  highlightCount: number;
  noteCount: number;
}

export interface LibraryEntry {
  reference: string;
  book: string;
  chapter: number;
  verse: number;
  text: string;
  bookmark: boolean;
  highlightColor: string | null;
  note: string | null;
  updatedAt: string;
}
