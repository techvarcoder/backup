# File Converter — Android App

A production-ready file conversion app for Android, built with React Native, TypeScript, and Material Design 3.

## Features

- **Document conversion** — PDF ↔ DOCX, DOC, RTF, TXT, HTML
- **Image conversion** — JPG, PNG, WEBP, HEIC, BMP, TIFF, SVG, ICO, AVIF
- **Spreadsheet conversion** — XLS, XLSX, CSV, ODS
- **Presentation conversion** — PPT, PPTX, ODP
- **Scanner** — Camera capture or gallery import → PDF
- **Offline conversions** — Image format changes, text/HTML/CSV → PDF run entirely on-device
- **Conversion history** — Browseable, filterable, with favorites
- **Dark mode** — Full light/dark/system theme support
- **Progress notifications** — Background conversion updates via Notifee

## Tech Stack

| Layer | Library |
|---|---|
| Framework | React Native 0.80, TypeScript (strict) |
| UI | React Native Paper (Material 3) |
| Navigation | React Navigation 6 |
| State | Zustand 5 |
| Storage | react-native-mmkv |
| HTTP | Axios |
| Lists | @shopify/flash-list |
| Animations | Reanimated 3 |
| Forms | React Hook Form |
| Queries | TanStack Query 5 |
| Notifications | @notifee/react-native |
| Permissions | react-native-permissions |

## Setup

### Prerequisites

- Node.js 18+
- Bun (`npm install -g bun`)
- Android Studio with SDK 33+
- Java 17

### Install

```bash
bun install
```

### Android

```bash
# Debug build
bun android

# Release build (requires signing keystore)
bun android:release
```

### Metro bundler

```bash
bun start

# Clear cache
bun start:reset
```

## Architecture

```
src/
├── api/              # Axios client + conversion API calls
├── components/
│   ├── common/       # AppButton, AppCard, AppBar, SearchBar, EmptyState, ...
│   └── converter/    # ConverterCard, CategoryCard, ConversionHistoryItem, ...
├── constants/        # Routes, converters list, format metadata, app constants
├── hooks/            # useTheme, useConversion, useFileSystem, useSearch, ...
├── navigation/       # AppNavigator (root stack), BottomTabNavigator
├── screens/          # Feature screens grouped by domain
├── services/
│   ├── conversion/   # ImageConverter (local), ConversionService (orchestrator)
│   ├── file/         # FileService (RNFS wrapper)
│   ├── notification/ # NotificationService (Notifee)
│   └── permission/   # PermissionService (react-native-permissions)
├── store/            # Zustand stores (app, settings, history, conversion)
├── theme/            # MD3 colors, typography, spacing tokens
├── types/            # Shared TypeScript types
└── utils/            # Formatters, validators, file helpers
```

### Conversion flow

1. User picks a file → `FilePickerScreen`
2. Chooses settings (format, quality, name) → `ConversionSettingsScreen`
3. `useConversion.startConversion()` navigates to `ConversionProgressScreen`
4. `ConversionService.convert()` routes to:
   - **Local engine** (`ImageConverter`) for image↔image, text/HTML/CSV→PDF
   - **Backend API** (`conversionApi`) for Office formats (DOCX↔PDF, XLSX, PPTX)
5. On success → `ConversionSuccessScreen`; on failure → `ConversionFailedScreen`
6. Result stored in `useHistoryStore`

### Offline vs Online

Each converter is tagged with `engine: 'local' | 'backend'`. The app shows an **Offline** or **Online** badge on every converter card so users know which conversions work without internet.

## Backend API

Complex format conversions require a backend. Configure the URL in **Settings → Backend API URL**. The API must accept:

```
POST /convert
Content-Type: multipart/form-data

file:         <binary>
outputFormat: "pdf"
```

Response: `{ jobId, downloadUrl }` or a direct binary stream.

## Environment

No `.env` file needed — the backend URL is configured at runtime through the in-app Settings and persisted in MMKV.

## Testing

```bash
# Run all tests
bun test

# With coverage
bun test:coverage
```

Tests live in `src/__tests__/` mirroring the `src/` tree:

| File | What it covers |
|---|---|
| `utils/formatters.test.ts` | File size, duration, date, filename formatting |
| `utils/validators.test.ts` | File size/name/type validation, sanitize |
| `store/useAppStore.test.ts` | Snackbar queue, favorite converter ids |
| `components/AppButton.test.tsx` | Render, press, disabled, loading states |

## Permissions (Android)

| Permission | Purpose |
|---|---|
| `READ_EXTERNAL_STORAGE` | Read files on API ≤ 32 |
| `READ_MEDIA_IMAGES` | Read image files on API 33+ |
| `WRITE_EXTERNAL_STORAGE` | Save to Downloads on API ≤ 29 |
| `CAMERA` | Scanner screen |
| `POST_NOTIFICATIONS` | Conversion progress & completion alerts |

## Code Quality

```bash
bun type-check   # TypeScript
bun lint         # ESLint
bun lint:fix     # ESLint auto-fix
bun prettier     # Prettier format
```

## Build Notes

- MMKV requires JVM min SDK ≥ 16 (satisfied by RN 0.80 defaults)
- @notifee requires `compileSdkVersion 33` — set in `android/build.gradle`
- react-native-permissions needs each permission declared in `AndroidManifest.xml` (already present)
- react-native-vision-camera requires `minSdkVersion 26` for the camera API
