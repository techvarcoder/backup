import React from 'react';
import { StyleSheet, View, Text, Platform } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import { MainTabParamList } from './types';
import { useTheme } from '../hooks/useTheme';
import { spacing, radius, iconSize } from '../theme/spacing';
import { fontSize, fontWeight } from '../theme/typography';
import { Routes } from '../constants/routes';

import HomeScreen from '../screens/home/HomeScreen';
import CategoriesScreen from '../screens/categories/CategoriesScreen';
import HistoryScreen from '../screens/history/HistoryScreen';
import FavoritesScreen from '../screens/favorites/FavoritesScreen';
import SettingsScreen from '../screens/settings/SettingsScreen';

const Tab = createBottomTabNavigator<MainTabParamList>();

interface TabIconProps {
  name: string;
  focused: boolean;
  color: string;
}

function TabIcon({ name, focused, color }: TabIconProps) {
  return (
    <View style={[styles.iconContainer, focused && styles.iconContainerActive]}>
      <Icon name={name} size={iconSize.lg} color={color} />
    </View>
  );
}

export function BottomTabNavigator() {
  const { colors } = useTheme();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: [styles.tabBar, { backgroundColor: colors.tabBar, borderTopColor: colors.tabBarBorder }],
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.tabBarInactive,
        tabBarLabelStyle: styles.tabLabel,
        tabBarIcon: ({ focused, color }) => {
          const icons: Record<string, { active: string; inactive: string }> = {
            [Routes.TAB_HOME]: { active: 'home', inactive: 'home-outline' },
            [Routes.TAB_CATEGORIES]: { active: 'view-grid', inactive: 'view-grid-outline' },
            [Routes.TAB_HISTORY]: { active: 'history', inactive: 'history' },
            [Routes.TAB_FAVORITES]: { active: 'star', inactive: 'star-outline' },
            [Routes.TAB_SETTINGS]: { active: 'cog', inactive: 'cog-outline' },
          };
          const icon = icons[route.name];
          const name = focused ? icon?.active ?? 'home' : icon?.inactive ?? 'home-outline';
          return <TabIcon name={name} focused={focused} color={color} />;
        },
      })}>
      <Tab.Screen name={Routes.TAB_HOME} component={HomeScreen} options={{ title: 'Home' }} />
      <Tab.Screen name={Routes.TAB_CATEGORIES} component={CategoriesScreen} options={{ title: 'Convert' }} />
      <Tab.Screen name={Routes.TAB_HISTORY} component={HistoryScreen} options={{ title: 'History' }} />
      <Tab.Screen name={Routes.TAB_FAVORITES} component={FavoritesScreen} options={{ title: 'Favorites' }} />
      <Tab.Screen name={Routes.TAB_SETTINGS} component={SettingsScreen} options={{ title: 'Settings' }} />
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    height: Platform.OS === 'android' ? 64 : 80,
    paddingBottom: Platform.OS === 'android' ? 8 : 20,
    paddingTop: 8,
    borderTopWidth: 1,
    elevation: 0,
    shadowOpacity: 0,
  },
  tabLabel: {
    fontSize: fontSize.xs,
    fontWeight: fontWeight.medium,
    marginTop: 2,
  },
  iconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: radius.md,
    width: 48,
    height: 32,
  },
  iconContainerActive: {
    backgroundColor: 'rgba(0,122,255,0.12)',
  },
});
