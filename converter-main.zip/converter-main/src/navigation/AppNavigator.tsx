import React, { useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { PaperProvider } from 'react-native-paper';
import { useColorScheme } from 'react-native';

import { RootStackParamList } from './types';
import { Routes } from '../constants/routes';
import { useTheme } from '../hooks/useTheme';
import { AppLightTheme, AppDarkTheme } from '../theme';
import { useSettingsStore } from '../store/useSettingsStore';
import { useAppStore } from '../store/useAppStore';
import { useHistoryStore } from '../store/useHistoryStore';
import storageService from '../services/storage/StorageService';
import notificationService from '../services/notification/NotificationService';
import { STORAGE_KEYS } from '../constants';

import { BottomTabNavigator } from './BottomTabNavigator';
import SplashScreen from '../screens/splash/SplashScreen';
import OnboardingScreen from '../screens/onboarding/OnboardingScreen';
import ConverterDetailScreen from '../screens/converter/ConverterDetailScreen';
import FilePickerScreen from '../screens/converter/FilePickerScreen';
import ConversionSettingsScreen from '../screens/converter/ConversionSettingsScreen';
import ConversionProgressScreen from '../screens/converter/ConversionProgressScreen';
import ConversionSuccessScreen from '../screens/converter/ConversionSuccessScreen';
import ConversionFailedScreen from '../screens/converter/ConversionFailedScreen';
import FilePreviewScreen from '../screens/preview/FilePreviewScreen';
import SearchResultsScreen from '../screens/search/SearchResultsScreen';
import ScannerScreen from '../screens/scanner/ScannerScreen';
import GlobalSnackbar from '../components/common/GlobalSnackbar';

const Stack = createNativeStackNavigator<RootStackParamList>();

function AppNavigatorInner() {
  const { theme, isDark } = useTheme();
  const { settings, loadSettings } = useSettingsStore();
  const { setInitialized, loadFavorites } = useAppStore();
  const { loadHistory } = useHistoryStore();

  useEffect(() => {
    async function initialize() {
      loadSettings();
      loadHistory();
      const favorites = storageService.getObject<string[]>(STORAGE_KEYS.FAVORITES, []);
      loadFavorites(favorites);
      await notificationService.initialize();
      setInitialized(true);
    }
    initialize();
  }, []);

  const navTheme = isDark ? AppDarkTheme : AppLightTheme;

  return (
    <PaperProvider theme={theme}>
      <NavigationContainer theme={navTheme as any}>
        <Stack.Navigator
          initialRouteName={Routes.SPLASH}
          screenOptions={{ headerShown: false, animation: 'fade' }}>
          <Stack.Screen name={Routes.SPLASH} component={SplashScreen} />
          <Stack.Screen name={Routes.ONBOARDING} component={OnboardingScreen} options={{ gestureEnabled: false }} />
          <Stack.Screen name={Routes.MAIN} component={BottomTabNavigator} options={{ gestureEnabled: false }} />
          <Stack.Screen
            name={Routes.CONVERTER_DETAIL}
            component={ConverterDetailScreen}
            options={{ animation: 'slide_from_right' }}
          />
          <Stack.Screen
            name={Routes.FILE_PICKER}
            component={FilePickerScreen}
            options={{ animation: 'slide_from_right' }}
          />
          <Stack.Screen
            name={Routes.CONVERSION_SETTINGS}
            component={ConversionSettingsScreen}
            options={{ animation: 'slide_from_right' }}
          />
          <Stack.Screen
            name={Routes.CONVERSION_PROGRESS}
            component={ConversionProgressScreen}
            options={{ animation: 'fade', gestureEnabled: false }}
          />
          <Stack.Screen
            name={Routes.CONVERSION_SUCCESS}
            component={ConversionSuccessScreen}
            options={{ animation: 'fade', gestureEnabled: false }}
          />
          <Stack.Screen
            name={Routes.CONVERSION_FAILED}
            component={ConversionFailedScreen}
            options={{ animation: 'fade', gestureEnabled: false }}
          />
          <Stack.Screen
            name={Routes.FILE_PREVIEW}
            component={FilePreviewScreen}
            options={{ animation: 'slide_from_bottom' }}
          />
          <Stack.Screen
            name={Routes.SEARCH_RESULTS}
            component={SearchResultsScreen}
            options={{ animation: 'fade' }}
          />
          <Stack.Screen
            name={Routes.SCANNER}
            component={ScannerScreen}
            options={{ animation: 'slide_from_bottom' }}
          />
        </Stack.Navigator>
        <GlobalSnackbar />
      </NavigationContainer>
    </PaperProvider>
  );
}

export function AppNavigator() {
  return <AppNavigatorInner />;
}
