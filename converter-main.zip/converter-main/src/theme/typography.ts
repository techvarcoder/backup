import { StyleSheet, TextStyle } from 'react-native';

export const fontFamily = {
  regular: 'System',
  medium: 'System',
  semiBold: 'System',
  bold: 'System',
  mono: 'monospace',
};

export const fontSize = {
  xs: 11,
  sm: 12,
  base: 14,
  md: 16,
  lg: 18,
  xl: 20,
  xxl: 24,
  xxxl: 28,
  display: 32,
  hero: 40,
};

export const fontWeight = {
  regular: '400' as TextStyle['fontWeight'],
  medium: '500' as TextStyle['fontWeight'],
  semiBold: '600' as TextStyle['fontWeight'],
  bold: '700' as TextStyle['fontWeight'],
  extraBold: '800' as TextStyle['fontWeight'],
};

export const lineHeight = {
  tight: 1.2,
  normal: 1.5,
  relaxed: 1.75,
};

export const letterSpacing = {
  tight: -0.5,
  normal: 0,
  wide: 0.5,
  wider: 1.0,
  widest: 1.5,
};

export const textVariants = StyleSheet.create({
  displayLarge: {
    fontSize: fontSize.hero,
    fontWeight: fontWeight.bold,
    letterSpacing: letterSpacing.tight,
  },
  displayMedium: {
    fontSize: fontSize.display,
    fontWeight: fontWeight.bold,
    letterSpacing: letterSpacing.tight,
  },
  displaySmall: {
    fontSize: fontSize.xxxl,
    fontWeight: fontWeight.bold,
  },
  headlineLarge: {
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.semiBold,
  },
  headlineMedium: {
    fontSize: fontSize.xl,
    fontWeight: fontWeight.semiBold,
  },
  headlineSmall: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semiBold,
  },
  titleLarge: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.medium,
  },
  titleMedium: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.medium,
    letterSpacing: letterSpacing.wide,
  },
  titleSmall: {
    fontSize: fontSize.base,
    fontWeight: fontWeight.medium,
    letterSpacing: letterSpacing.wide,
  },
  bodyLarge: {
    fontSize: fontSize.md,
    fontWeight: fontWeight.regular,
  },
  bodyMedium: {
    fontSize: fontSize.base,
    fontWeight: fontWeight.regular,
  },
  bodySmall: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.regular,
  },
  labelLarge: {
    fontSize: fontSize.base,
    fontWeight: fontWeight.medium,
    letterSpacing: letterSpacing.wide,
  },
  labelMedium: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.medium,
    letterSpacing: letterSpacing.wider,
  },
  labelSmall: {
    fontSize: fontSize.xs,
    fontWeight: fontWeight.medium,
    letterSpacing: letterSpacing.widest,
  },
});
