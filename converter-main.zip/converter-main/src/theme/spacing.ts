export const spacing = {
  px: 1,
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
  huge: 40,
  massive: 48,
  giant: 64,
};

export const radius = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  full: 9999,
};

export const iconSize = {
  xs: 14,
  sm: 16,
  md: 20,
  lg: 24,
  xl: 28,
  xxl: 32,
  xxxl: 40,
  huge: 48,
};

export const touchTarget = {
  min: 48,
  comfortable: 56,
  large: 64,
};

export const layout = {
  screenPadding: spacing.lg,
  cardPadding: spacing.lg,
  sectionSpacing: spacing.xxl,
  headerHeight: 56,
  tabBarHeight: 64,
  fabSize: 56,
};
