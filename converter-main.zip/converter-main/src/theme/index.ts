import { MD3DarkTheme, MD3LightTheme, adaptNavigationTheme } from 'react-native-paper';
import { DarkTheme as NavigationDarkTheme, DefaultTheme as NavigationDefaultTheme } from '@react-navigation/native';
import { lightColors, darkColors } from './colors';

export * from './colors';
export * from './typography';
export * from './spacing';

const { LightTheme: NavLightTheme, DarkTheme: NavDarkTheme } = adaptNavigationTheme({
  reactNavigationLight: NavigationDefaultTheme,
  reactNavigationDark: NavigationDarkTheme,
});

export const AppLightTheme = {
  ...MD3LightTheme,
  ...NavLightTheme,
  colors: {
    ...MD3LightTheme.colors,
    ...NavLightTheme.colors,
    primary: lightColors.primary,
    primaryContainer: lightColors.primaryContainer,
    secondary: lightColors.secondary,
    secondaryContainer: lightColors.secondaryContainer,
    tertiary: lightColors.tertiary,
    tertiaryContainer: lightColors.tertiaryContainer,
    surface: lightColors.surface,
    surfaceVariant: lightColors.surfaceVariant,
    background: lightColors.background,
    error: lightColors.error,
    errorContainer: lightColors.errorContainer,
    onPrimary: lightColors.onPrimary,
    onSecondary: lightColors.onSecondary,
    onSurface: lightColors.onSurface,
    onSurfaceVariant: lightColors.onSurfaceVariant,
    onBackground: lightColors.onBackground,
    outline: lightColors.outline,
    outlineVariant: lightColors.outlineVariant,
    card: lightColors.surface,
    text: lightColors.text,
    border: lightColors.outline,
    notification: lightColors.primary,
  },
  custom: lightColors,
};

export const AppDarkTheme = {
  ...MD3DarkTheme,
  ...NavDarkTheme,
  colors: {
    ...MD3DarkTheme.colors,
    ...NavDarkTheme.colors,
    primary: darkColors.primary,
    primaryContainer: darkColors.primaryContainer,
    secondary: darkColors.secondary,
    secondaryContainer: darkColors.secondaryContainer,
    tertiary: darkColors.tertiary,
    tertiaryContainer: darkColors.tertiaryContainer,
    surface: darkColors.surface,
    surfaceVariant: darkColors.surfaceVariant,
    background: darkColors.background,
    error: darkColors.error,
    errorContainer: darkColors.errorContainer,
    onPrimary: darkColors.onPrimary,
    onSecondary: darkColors.onSecondary,
    onSurface: darkColors.onSurface,
    onSurfaceVariant: darkColors.onSurfaceVariant,
    onBackground: darkColors.onBackground,
    outline: darkColors.outline,
    outlineVariant: darkColors.outlineVariant,
    card: darkColors.surface,
    text: darkColors.text,
    border: darkColors.outline,
    notification: darkColors.primary,
  },
  custom: darkColors,
};

export type AppTheme = typeof AppLightTheme;
