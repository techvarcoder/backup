export const palette = {
  blue50: '#EFF6FF',
  blue100: '#DBEAFE',
  blue200: '#BFDBFE',
  blue500: '#3B82F6',
  blue600: '#007AFF',
  blue700: '#1D4ED8',

  green50: '#F0FDF4',
  green100: '#DCFCE7',
  green500: '#22C55E',
  green600: '#16A34A',
  green700: '#15803D',

  red50: '#FEF2F2',
  red100: '#FEE2E2',
  red500: '#EF4444',
  red600: '#DC2626',

  orange50: '#FFF7ED',
  orange100: '#FFEDD5',
  orange500: '#F97316',
  orange600: '#EA580C',

  yellow50: '#FEFCE8',
  yellow500: '#EAB308',

  purple50: '#F5F3FF',
  purple500: '#8B5CF6',
  purple600: '#7C3AED',

  pink50: '#FDF2F8',
  pink500: '#EC4899',

  teal50: '#F0FDFA',
  teal500: '#14B8A6',
  teal600: '#0D9488',

  grey50: '#F9FAFB',
  grey100: '#F3F4F6',
  grey200: '#E5E7EB',
  grey300: '#D1D5DB',
  grey400: '#9CA3AF',
  grey500: '#6B7280',
  grey600: '#4B5563',
  grey700: '#374151',
  grey800: '#1F2937',
  grey900: '#111827',

  white: '#FFFFFF',
  black: '#000000',
  transparent: 'transparent',
};

export const lightColors = {
  primary: '#007AFF',
  primaryContainer: '#DBEAFE',
  onPrimary: '#FFFFFF',
  onPrimaryContainer: '#1D4ED8',

  secondary: '#22C55E',
  secondaryContainer: '#DCFCE7',
  onSecondary: '#FFFFFF',
  onSecondaryContainer: '#15803D',

  tertiary: '#8B5CF6',
  tertiaryContainer: '#F5F3FF',
  onTertiary: '#FFFFFF',
  onTertiaryContainer: '#6D28D9',

  error: '#EF4444',
  errorContainer: '#FEE2E2',
  onError: '#FFFFFF',
  onErrorContainer: '#DC2626',

  success: '#22C55E',
  successContainer: '#DCFCE7',
  warning: '#EAB308',
  warningContainer: '#FEFCE8',

  background: '#F8F9FA',
  onBackground: '#1A1A1A',
  surface: '#FFFFFF',
  surfaceVariant: '#F3F4F6',
  onSurface: '#1A1A1A',
  onSurfaceVariant: '#4B5563',
  surfaceTint: '#007AFF',
  inverseSurface: '#1F2937',
  inverseOnSurface: '#F9FAFB',
  inversePrimary: '#93C5FD',

  outline: '#E5E7EB',
  outlineVariant: '#D1D5DB',
  shadow: 'rgba(0,0,0,0.08)',
  scrim: 'rgba(0,0,0,0.5)',

  tabBar: '#FFFFFF',
  tabBarBorder: '#E5E7EB',
  tabBarActive: '#007AFF',
  tabBarInactive: '#9CA3AF',

  cardBackground: '#FFFFFF',
  cardBorder: '#E5E7EB',
  divider: '#F3F4F6',
  shimmer: '#E5E7EB',
  shimmerHighlight: '#F9FAFB',

  text: '#1A1A1A',
  textSecondary: '#4B5563',
  textTertiary: '#9CA3AF',
  textDisabled: '#D1D5DB',
  textInverse: '#FFFFFF',

  statusBarStyle: 'dark-content' as const,
};

export const darkColors: typeof lightColors = {
  primary: '#3B9EFF',
  primaryContainer: '#1D3A5F',
  onPrimary: '#FFFFFF',
  onPrimaryContainer: '#93C5FD',

  secondary: '#4ADE80',
  secondaryContainer: '#14532D',
  onSecondary: '#052E16',
  onSecondaryContainer: '#BBF7D0',

  tertiary: '#A78BFA',
  tertiaryContainer: '#3B2070',
  onTertiary: '#1C0B4C',
  onTertiaryContainer: '#DDD6FE',

  error: '#F87171',
  errorContainer: '#7F1D1D',
  onError: '#450A0A',
  onErrorContainer: '#FECACA',

  success: '#4ADE80',
  successContainer: '#14532D',
  warning: '#FDE047',
  warningContainer: '#713F12',

  background: '#0F0F11',
  onBackground: '#F9FAFB',
  surface: '#1A1A1E',
  surfaceVariant: '#242428',
  onSurface: '#F9FAFB',
  onSurfaceVariant: '#9CA3AF',
  surfaceTint: '#3B9EFF',
  inverseSurface: '#F9FAFB',
  inverseOnSurface: '#1A1A1E',
  inversePrimary: '#007AFF',

  outline: '#374151',
  outlineVariant: '#2D3748',
  shadow: 'rgba(0,0,0,0.4)',
  scrim: 'rgba(0,0,0,0.7)',

  tabBar: '#1A1A1E',
  tabBarBorder: '#374151',
  tabBarActive: '#3B9EFF',
  tabBarInactive: '#6B7280',

  cardBackground: '#1A1A1E',
  cardBorder: '#374151',
  divider: '#242428',
  shimmer: '#374151',
  shimmerHighlight: '#4B5563',

  text: '#F9FAFB',
  textSecondary: '#9CA3AF',
  textTertiary: '#6B7280',
  textDisabled: '#4B5563',
  textInverse: '#1A1A1A',

  statusBarStyle: 'light-content' as const,
};

export const categoryColors = {
  documents: { bg: '#EFF6FF', icon: '#007AFF', dark_bg: '#1D3A5F', dark_icon: '#3B9EFF' },
  images: { bg: '#F0FDF4', icon: '#22C55E', dark_bg: '#14532D', dark_icon: '#4ADE80' },
  spreadsheets: { bg: '#F0FDFA', icon: '#0D9488', dark_bg: '#134E4A', dark_icon: '#2DD4BF' },
  presentations: { bg: '#FFF7ED', icon: '#F97316', dark_bg: '#431407', dark_icon: '#FB923C' },
  scanner: { bg: '#F5F3FF', icon: '#8B5CF6', dark_bg: '#3B2070', dark_icon: '#A78BFA' },
  audio: { bg: '#FDF2F8', icon: '#EC4899', dark_bg: '#500724', dark_icon: '#F472B6' },
};

export const formatColors: Record<string, string> = {
  pdf: '#EF4444',
  doc: '#2563EB',
  docx: '#2563EB',
  xls: '#16A34A',
  xlsx: '#16A34A',
  ppt: '#EA580C',
  pptx: '#EA580C',
  jpg: '#8B5CF6',
  jpeg: '#8B5CF6',
  png: '#EC4899',
  gif: '#F59E0B',
  webp: '#14B8A6',
  mp4: '#DC2626',
  mp3: '#7C3AED',
  txt: '#6B7280',
  csv: '#16A34A',
  html: '#F97316',
  svg: '#F59E0B',
  default: '#9CA3AF',
};

export type Colors = typeof lightColors;
