import { FileItem, StoredConversion } from './file';
import { ConverterDefinition } from './converter';

export type RootStackParamList = {
  Splash: undefined;
  Onboarding: undefined;
  Main: { screen?: keyof MainTabParamList; params?: object } | undefined;
  ConverterDetail: { converter: ConverterDefinition };
  FilePicker: { converter: ConverterDefinition };
  ConversionSettings: { converter: ConverterDefinition; file: FileItem };
  ConversionProgress: { jobId: string; converter: ConverterDefinition; file: FileItem };
  ConversionSuccess: { conversion: StoredConversion };
  ConversionFailed: { error: string; converter: ConverterDefinition };
  FilePreview: { file: FileItem };
  SearchResults: { query?: string };
  Scanner: undefined;
};

export type MainTabParamList = {
  Home: undefined;
  Categories: undefined;
  History: undefined;
  Favorites: undefined;
  Settings: undefined;
};

export type RootScreenProps<T extends keyof RootStackParamList> = {
  route: { key: string; name: T; params: RootStackParamList[T] };
  navigation: {
    navigate: <K extends keyof RootStackParamList>(
      screen: K,
      params?: RootStackParamList[K],
    ) => void;
    goBack: () => void;
    replace: <K extends keyof RootStackParamList>(
      screen: K,
      params?: RootStackParamList[K],
    ) => void;
    reset: (state: { index: number; routes: Array<{ name: string }> }) => void;
  };
};
