import { FileFormat, FileCategory } from './file';

export type ConversionEngine = 'local' | 'backend' | 'hybrid';

export type ConverterCategoryId = 'documents' | 'images' | 'spreadsheets' | 'presentations' | 'scanner';

export interface ConversionRoute {
  id: string;
  inputFormat: FileFormat;
  outputFormat: FileFormat;
  label: string;
  engine: ConversionEngine;
  isPopular?: boolean;
}

export interface ConverterDefinition {
  id: string;
  name: string;
  description: string;
  inputFormat: FileFormat;
  outputFormat: FileFormat;
  inputFormats?: FileFormat[];
  categoryId: ConverterCategoryId;
  engine: ConversionEngine;
  isPopular: boolean;
  iconName: string;
  inputMimeTypes: string[];
}

export interface ConverterCategory {
  id: ConverterCategoryId;
  name: string;
  description: string;
  iconName: string;
  fileCategory: FileCategory;
  formats: FileFormat[];
  converters: ConverterDefinition[];
}

export interface ConversionOptions {
  outputFormat: FileFormat;
  outputFileName?: string;
  outputDirectory?: string;
  quality?: 'low' | 'medium' | 'high';
  keepFormatting?: boolean;
  pageRange?: { start: number; end: number };
  imageQuality?: number;
  passwordProtect?: boolean;
  password?: string;
  maintainAspectRatio?: boolean;
  resizeWidth?: number;
  resizeHeight?: number;
  // For scanner: all scanned pages to combine into a single PDF
  scanPages?: import('./file').FileItem[];
}

export interface ConversionProgress {
  jobId: string;
  stage: 'preparing' | 'uploading' | 'processing' | 'downloading' | 'saving' | 'done';
  percentage: number;
  message: string;
  estimatedSeconds?: number;
}
