import { FileFormat } from './file';

export type ThemeMode = 'light' | 'dark' | 'system';
export type Language = 'en' | 'es' | 'fr' | 'de' | 'pt' | 'ar' | 'zh' | 'ja' | 'ko';
export type ImageQuality = 'low' | 'medium' | 'high';
export type SaveLocation = 'internal' | 'downloads' | 'documents' | 'custom';

export interface AppSettings {
  themeMode: ThemeMode;
  language: Language;
  defaultOutputFormat: FileFormat;
  defaultImageQuality: ImageQuality;
  saveLocation: SaveLocation;
  customSavePath?: string;
  showConversionNotifications: boolean;
  hapticFeedback: boolean;
  autoCheckUpdates: boolean;
  backendApiUrl: string;
  backendApiKey: string;
  onboardingCompleted: boolean;
  analyticsEnabled: boolean;
}

export const defaultSettings: AppSettings = {
  themeMode: 'system',
  language: 'en',
  defaultOutputFormat: 'pdf',
  defaultImageQuality: 'high',
  saveLocation: 'downloads',
  showConversionNotifications: true,
  hapticFeedback: true,
  autoCheckUpdates: true,
  backendApiUrl: 'https://api.convertapi.com/convert',
  backendApiKey: '',
  onboardingCompleted: false,
  analyticsEnabled: false,
};
