export interface ApiResponse<T> {
  data: T;
  success: boolean;
  message?: string;
  error?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}

export type AsyncState<T> =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; data: T }
  | { status: 'error'; error: string };

export interface SnackbarConfig {
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
  duration?: number;
  action?: {
    label: string;
    onPress: () => void;
  };
}

export interface DialogConfig {
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  type?: 'info' | 'warning' | 'danger';
  onConfirm: () => void;
  onCancel?: () => void;
}

export type SortOrder = 'asc' | 'desc';
export type SortField = 'name' | 'date' | 'size' | 'format';

export interface FilterOptions {
  query?: string;
  format?: string;
  category?: string;
  dateRange?: { start: Date; end: Date };
  sortField: SortField;
  sortOrder: SortOrder;
}
