export type FileCategory = 'document' | 'image' | 'spreadsheet' | 'presentation' | 'audio' | 'video' | 'other';

export type FileFormat =
  | 'pdf' | 'doc' | 'docx' | 'txt' | 'rtf' | 'html' | 'odt' | 'epub'
  | 'jpg' | 'jpeg' | 'png' | 'webp' | 'heic' | 'bmp' | 'tiff' | 'svg' | 'ico' | 'avif' | 'gif'
  | 'xls' | 'xlsx' | 'csv' | 'ods'
  | 'ppt' | 'pptx' | 'odp' | 'key'
  | 'mp3' | 'aac' | 'wav' | 'ogg' | 'm4a' | 'flac'
  | 'mp4' | 'mov' | 'avi' | 'mkv' | 'webm'
  | 'zip' | 'rar' | '7z';

export interface FileItem {
  id: string;
  name: string;
  displayName: string;
  extension: FileFormat;
  mimeType: string;
  size: number;
  path: string;
  uri: string;
  category: FileCategory;
  lastModified: number;
  thumbnail?: string;
}

export interface ConversionResult {
  id: string;
  inputFile: FileItem;
  outputFile: FileItem;
  status: ConversionStatus;
  progress: number;
  error?: string;
  startedAt: number;
  completedAt?: number;
  conversionTime?: number;
  compressionRatio?: number;
}

export type ConversionStatus =
  | 'idle'
  | 'uploading'
  | 'converting'
  | 'finalizing'
  | 'completed'
  | 'failed'
  | 'cancelled';

export interface StoredConversion {
  id: string;
  converterId: string;
  converterName: string;
  inputFileName: string;
  inputFileSize: number;
  inputFormat: FileFormat;
  outputFileName: string;
  outputFileSize?: number;
  outputFilePath?: string;
  outputFormat: FileFormat;
  status: ConversionStatus;
  error?: string;
  createdAt: number;
  completedAt?: number;
  conversionTimeMs?: number;
  isFavorite: boolean;
}
