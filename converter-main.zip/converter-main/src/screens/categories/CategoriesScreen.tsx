import React, { useState, useCallback, useMemo } from 'react';
import { View, Text, StyleSheet, SectionList, TouchableOpacity, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import { useTheme } from '../../hooks/useTheme';
import { useAppStore } from '../../store/useAppStore';
import { SearchBar } from '../../components/common/SearchBar';
import { ConverterCard } from '../../components/converter/ConverterCard';
import { CategoryCard } from '../../components/converter/CategoryCard';
import { EmptyState } from '../../components/common/EmptyState';
import { CONVERTER_CATEGORIES, CONVERTERS } from '../../constants/converters';
import { Routes } from '../../constants/routes';
import { spacing, radius, iconSize, touchTarget } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { ConverterDefinition } from '../../types/converter';
import { categoryColors } from '../../theme/colors';

export default function CategoriesScreen() {
  const navigation = useNavigation<any>();
  const { colors, isDark } = useTheme();
  const { toggleFavoriteConverter, isFavoriteConverter } = useAppStore();

  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredConverters = useMemo(() => {
    let list = selectedCategoryId
      ? CONVERTERS.filter(c => c.categoryId === selectedCategoryId)
      : CONVERTERS;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        c =>
          c.name.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q) ||
          c.inputFormat.toLowerCase().includes(q) ||
          c.outputFormat.toLowerCase().includes(q),
      );
    }
    return list;
  }, [selectedCategoryId, searchQuery]);

  const handleConverterPress = useCallback(
    (converter: ConverterDefinition) => {
      navigation.navigate(Routes.CONVERTER_DETAIL, { converter });
    },
    [navigation],
  );

  const sections = useMemo(() => {
    if (searchQuery.trim() || selectedCategoryId) {
      return [{ title: selectedCategoryId ? CONVERTER_CATEGORIES.find(c => c.id === selectedCategoryId)?.name ?? 'Results' : 'Search Results', data: filteredConverters }];
    }
    return CONVERTER_CATEGORIES.map(cat => ({
      title: cat.name,
      data: cat.converters,
      category: cat,
    }));
  }, [filteredConverters, searchQuery, selectedCategoryId]);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />

      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.outline }]}>
        <Text style={[styles.title, { color: colors.text }]}>All Converters</Text>
        <SearchBar
          value={searchQuery}
          onChangeText={setSearchQuery}
          placeholder="Search by format or name..."
          style={styles.searchBar}
        />

        {/* Category Filter Chips */}
        <View style={styles.filterContainer}>
          <TouchableOpacity
            onPress={() => setSelectedCategoryId(null)}
            style={[
              styles.chip,
              {
                backgroundColor: !selectedCategoryId ? colors.primary : colors.surfaceVariant,
                borderColor: !selectedCategoryId ? colors.primary : colors.outline,
              },
            ]}>
            <Text style={[styles.chipLabel, { color: !selectedCategoryId ? '#FFF' : colors.textSecondary }]}>
              All
            </Text>
          </TouchableOpacity>
          {CONVERTER_CATEGORIES.map(cat => {
            const active = selectedCategoryId === cat.id;
            const catColor = categoryColors[cat.id as keyof typeof categoryColors];
            return (
              <TouchableOpacity
                key={cat.id}
                onPress={() => setSelectedCategoryId(active ? null : cat.id)}
                style={[
                  styles.chip,
                  {
                    backgroundColor: active ? (isDark ? catColor?.dark_bg : catColor?.bg) : colors.surfaceVariant,
                    borderColor: active ? (isDark ? catColor?.dark_icon : catColor?.icon) : colors.outline,
                  },
                ]}>
                <Icon
                  name={cat.iconName}
                  size={14}
                  color={active ? (isDark ? catColor?.dark_icon : catColor?.icon) : colors.textSecondary}
                />
                <Text
                  style={[
                    styles.chipLabel,
                    { color: active ? (isDark ? catColor?.dark_icon : catColor?.icon) : colors.textSecondary },
                  ]}>
                  {cat.name}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      <SectionList
        sections={sections}
        keyExtractor={item => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.list}
        stickySectionHeadersEnabled={false}
        renderSectionHeader={({ section }) => (
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>{section.title}</Text>
            <Text style={[styles.sectionCount, { color: colors.textSecondary }]}>
              {section.data.length} converter{section.data.length !== 1 ? 's' : ''}
            </Text>
          </View>
        )}
        renderItem={({ item }) => (
          <ConverterCard
            converter={item}
            onPress={handleConverterPress}
            onFavorite={toggleFavoriteConverter}
            isFavorite={isFavoriteConverter(item.id)}
            style={styles.converterItem}
          />
        )}
        ListEmptyComponent={
          <EmptyState
            iconName="magnify"
            title="No converters found"
            description="Try a different search term or category."
            style={styles.emptyState}
          />
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingBottom: spacing.md,
    borderBottomWidth: 1,
  },
  title: {
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.bold,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.sm,
  },
  searchBar: {
    marginHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  filterContainer: {
    flexDirection: 'row',
    paddingHorizontal: spacing.lg,
    gap: spacing.sm,
    flexWrap: 'wrap',
  },
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: radius.full,
    borderWidth: 1,
    gap: spacing.xs,
    height: 34,
  },
  chipLabel: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.medium,
  },
  list: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.huge,
    paddingTop: spacing.md,
    gap: spacing.sm,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.md,
    marginTop: spacing.sm,
  },
  sectionTitle: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semiBold,
  },
  sectionCount: {
    fontSize: fontSize.sm,
  },
  converterItem: { marginBottom: spacing.xs },
  emptyState: { paddingVertical: spacing.xxxl },
});
