import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Dimensions,
  TouchableOpacity,
  StatusBar,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  interpolate,
  useAnimatedScrollHandler,
  Extrapolation,
} from 'react-native-reanimated';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import LinearGradient from 'react-native-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useSettingsStore } from '../../store/useSettingsStore';
import { AppButton } from '../../components/common/AppButton';
import { Routes } from '../../constants/routes';
import { radius, spacing, iconSize } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import type { RootScreenProps } from '../../types/navigation';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

interface OnboardingPage {
  id: string;
  icon: string;
  gradient: [string, string];
  title: string;
  description: string;
}

const PAGES: OnboardingPage[] = [
  {
    id: '1',
    icon: 'file-swap',
    gradient: ['#007AFF', '#0056CC'],
    title: 'Convert Any File',
    description:
      'Transform documents, images, spreadsheets, and more. 60+ formats supported.',
  },
  {
    id: '2',
    icon: 'shield-check',
    gradient: ['#22C55E', '#15803D'],
    title: 'Fast & Secure',
    description:
      'Your files are processed securely. Image conversions work completely offline.',
  },
  {
    id: '3',
    icon: 'history',
    gradient: ['#8B5CF6', '#6D28D9'],
    title: 'Track Everything',
    description:
      'View your conversion history, save favorites, and re-convert files in one tap.',
  },
];

type Props = RootScreenProps<'Onboarding'>;

export default function OnboardingScreen({ navigation }: Props) {
  const insets = useSafeAreaInsets();
  const [activeIndex, setActiveIndex] = useState(0);
  const { setOnboardingCompleted } = useSettingsStore();
  const scrollX = useSharedValue(0);
  const flatListRef = useRef<FlatList>(null);

  const scrollHandler = useAnimatedScrollHandler(event => {
    scrollX.value = event.contentOffset.x;
  });

  const handleNext = () => {
    if (activeIndex < PAGES.length - 1) {
      flatListRef.current?.scrollToIndex({ index: activeIndex + 1, animated: true });
    } else {
      handleGetStarted();
    }
  };

  const handleSkip = () => handleGetStarted();

  const handleGetStarted = () => {
    setOnboardingCompleted();
    navigation.replace(Routes.MAIN);
  };

  const isLast = activeIndex === PAGES.length - 1;

  return (
    <View style={[styles.container, { paddingBottom: insets.bottom }]}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />

      <Animated.FlatList
        ref={flatListRef as any}
        data={PAGES}
        keyExtractor={item => item.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={scrollHandler}
        scrollEventThrottle={16}
        onMomentumScrollEnd={e => {
          setActiveIndex(Math.round(e.nativeEvent.contentOffset.x / SCREEN_WIDTH));
        }}
        renderItem={({ item, index }) => {
          return (
            <LinearGradient
              colors={item.gradient}
              style={[styles.page, { width: SCREEN_WIDTH }]}>
              <View style={[styles.pageContent, { paddingTop: insets.top + 60 }]}>
                <View style={styles.iconContainer}>
                  <Icon name={item.icon} size={80} color="rgba(255,255,255,0.95)" />
                </View>
                <Text style={styles.pageTitle}>{item.title}</Text>
                <Text style={styles.pageDescription}>{item.description}</Text>
              </View>
            </LinearGradient>
          );
        }}
      />

      <View style={styles.footer}>
        <View style={styles.dots}>
          {PAGES.map((_, i) => {
            const inputRange = [(i - 1) * SCREEN_WIDTH, i * SCREEN_WIDTH, (i + 1) * SCREEN_WIDTH];
            const dotWidth = interpolate(scrollX.value, inputRange, [8, 24, 8], Extrapolation.CLAMP);
            const dotOpacity = interpolate(scrollX.value, inputRange, [0.4, 1, 0.4], Extrapolation.CLAMP);

            return (
              <Animated.View
                key={i}
                style={[
                  styles.dot,
                  useAnimatedStyle(() => ({
                    width: dotWidth,
                    opacity: dotOpacity,
                  })),
                ]}
              />
            );
          })}
        </View>

        <View style={styles.buttons}>
          {!isLast && (
            <TouchableOpacity onPress={handleSkip} style={styles.skipButton}>
              <Text style={styles.skipText}>Skip</Text>
            </TouchableOpacity>
          )}
          <AppButton
            label={isLast ? 'Get Started' : 'Next'}
            onPress={handleNext}
            variant="filled"
            iconName={isLast ? 'check' : 'arrow-right'}
            iconRight
            style={[styles.nextButton, isLast && styles.fullButton]}
          />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#007AFF',
  },
  page: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  pageContent: {
    alignItems: 'center',
    paddingHorizontal: spacing.xxxl,
    gap: spacing.xl,
  },
  iconContainer: {
    width: 140,
    height: 140,
    borderRadius: 40,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.lg,
  },
  pageTitle: {
    fontSize: 28,
    fontWeight: fontWeight.bold,
    color: '#FFFFFF',
    textAlign: 'center',
    letterSpacing: -0.3,
  },
  pageDescription: {
    fontSize: fontSize.md,
    color: 'rgba(255,255,255,0.85)',
    textAlign: 'center',
    lineHeight: 26,
  },
  footer: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: spacing.xxl,
    paddingTop: spacing.xxl,
    paddingBottom: spacing.xl,
    borderTopLeftRadius: radius.xxl,
    borderTopRightRadius: radius.xxl,
    gap: spacing.xl,
    elevation: 16,
  },
  dots: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: spacing.xs,
  },
  dot: {
    height: 8,
    borderRadius: 4,
    backgroundColor: '#007AFF',
  },
  buttons: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: spacing.md,
  },
  skipButton: {
    padding: spacing.md,
  },
  skipText: {
    fontSize: fontSize.base,
    fontWeight: fontWeight.medium,
    color: '#9CA3AF',
  },
  nextButton: {
    flex: 1,
    maxWidth: 200,
  },
  fullButton: {
    flex: 1,
    maxWidth: undefined,
  },
});
