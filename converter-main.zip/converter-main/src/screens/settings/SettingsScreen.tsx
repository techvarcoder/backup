import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Linking,
  Share,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import { useTheme } from '../../hooks/useTheme';
import { useSettingsStore } from '../../store/useSettingsStore';
import { useHistoryStore } from '../../store/useHistoryStore';
import { useAppStore } from '../../store/useAppStore';
import { AppCard } from '../../components/common/AppCard';
import { AppDialog } from '../../components/common/AppDialog';
import { AppButton } from '../../components/common/AppButton';
import { APP_NAME, APP_VERSION, PLAY_STORE_URL, PRIVACY_POLICY_URL, TERMS_URL, SUPPORT_EMAIL } from '../../constants';
import { spacing, radius, iconSize, touchTarget } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { ThemeMode } from '../../types/settings';

function SettingsRow({
  icon,
  label,
  value,
  onPress,
  rightContent,
  colors,
  dangerous = false,
}: {
  icon: string;
  label: string;
  value?: string;
  onPress?: () => void;
  rightContent?: React.ReactNode;
  colors: any;
  dangerous?: boolean;
}) {
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[styles.row, { borderBottomColor: colors.divider }]}
      disabled={!onPress && !rightContent}>
      <View style={[styles.rowIcon, { backgroundColor: dangerous ? colors.errorContainer : colors.primaryContainer }]}>
        <Icon name={icon} size={18} color={dangerous ? colors.error : colors.primary} />
      </View>
      <View style={styles.rowContent}>
        <Text style={[styles.rowLabel, { color: dangerous ? colors.error : colors.text }]}>{label}</Text>
        {value ? (
          <Text style={[styles.rowValue, { color: colors.textSecondary }]}>{value}</Text>
        ) : null}
      </View>
      {rightContent ?? (onPress ? <Icon name="chevron-right" size={iconSize.md} color={colors.textTertiary} /> : null)}
    </TouchableOpacity>
  );
}

export default function SettingsScreen() {
  const { colors, isDark } = useTheme();
  const { settings, updateSettings, resetSettings } = useSettingsStore();
  const { clearHistory } = useHistoryStore();
  const showSnackbar = useAppStore(s => s.showSnackbar);

  const [clearHistoryDialogVisible, setClearHistoryDialogVisible] = useState(false);
  const [resetDialogVisible, setResetDialogVisible] = useState(false);

  const themeModes: { value: ThemeMode; label: string }[] = [
    { value: 'light', label: 'Light' },
    { value: 'dark', label: 'Dark' },
    { value: 'system', label: 'System' },
  ];

  const Section = ({ title }: { title: string }) => (
    <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>{title}</Text>
  );

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />

      <Text style={[styles.headerTitle, { color: colors.text }]}>Settings</Text>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>

        {/* Appearance */}
        <Section title="APPEARANCE" />
        <AppCard style={styles.card} padding={0}>
          <View style={[styles.row, { borderBottomColor: colors.divider }]}>
            <View style={[styles.rowIcon, { backgroundColor: colors.primaryContainer }]}>
              <Icon name="theme-light-dark" size={18} color={colors.primary} />
            </View>
            <View style={styles.rowContent}>
              <Text style={[styles.rowLabel, { color: colors.text }]}>Theme</Text>
            </View>
            <View style={styles.themeButtons}>
              {themeModes.map(m => (
                <TouchableOpacity
                  key={m.value}
                  onPress={() => updateSettings({ themeMode: m.value })}
                  style={[
                    styles.themeChip,
                    {
                      backgroundColor: settings.themeMode === m.value ? colors.primary : colors.surfaceVariant,
                      borderColor: settings.themeMode === m.value ? colors.primary : colors.outline,
                    },
                  ]}>
                  <Text style={[styles.themeChipLabel, { color: settings.themeMode === m.value ? '#FFF' : colors.textSecondary }]}>
                    {m.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </AppCard>

        {/* Preferences */}
        <Section title="PREFERENCES" />
        <AppCard style={styles.card} padding={0}>
          <SettingsRow
            icon="bell-outline"
            label="Conversion Notifications"
            colors={colors}
            rightContent={
              <Switch
                value={settings.showConversionNotifications}
                onValueChange={v => updateSettings({ showConversionNotifications: v })}
                trackColor={{ false: colors.outline, true: colors.primary }}
                thumbColor="#FFF"
              />
            }
          />
          <SettingsRow
            icon="vibrate"
            label="Haptic Feedback"
            colors={colors}
            rightContent={
              <Switch
                value={settings.hapticFeedback}
                onValueChange={v => updateSettings({ hapticFeedback: v })}
                trackColor={{ false: colors.outline, true: colors.primary }}
                thumbColor="#FFF"
              />
            }
          />
          <SettingsRow
            icon="update"
            label="Auto Check Updates"
            colors={colors}
            rightContent={
              <Switch
                value={settings.autoCheckUpdates}
                onValueChange={v => updateSettings({ autoCheckUpdates: v })}
                trackColor={{ false: colors.outline, true: colors.primary }}
                thumbColor="#FFF"
              />
            }
          />
        </AppCard>

        {/* Storage */}
        <Section title="STORAGE" />
        <AppCard style={styles.card} padding={0}>
          <View style={[styles.row, { borderBottomColor: colors.divider }]}>
            <View style={[styles.rowIcon, { backgroundColor: colors.primaryContainer }]}>
              <Icon name="folder-outline" size={18} color={colors.primary} />
            </View>
            <View style={styles.rowContent}>
              <Text style={[styles.rowLabel, { color: colors.text }]}>Default Save Location</Text>
            </View>
            <View style={styles.themeButtons}>
              {(['downloads', 'internal'] as const).map(loc => (
                <TouchableOpacity
                  key={loc}
                  onPress={() => updateSettings({ saveLocation: loc })}
                  style={[
                    styles.themeChip,
                    {
                      backgroundColor: settings.saveLocation === loc ? colors.primary : colors.surfaceVariant,
                      borderColor: settings.saveLocation === loc ? colors.primary : colors.outline,
                    },
                  ]}>
                  <Text style={[styles.themeChipLabel, { color: settings.saveLocation === loc ? '#FFF' : colors.textSecondary }]}>
                    {loc === 'downloads' ? 'Downloads' : 'Internal'}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
          <View style={[styles.row, { borderBottomColor: colors.divider }]}>
            <View style={[styles.rowIcon, { backgroundColor: colors.primaryContainer }]}>
              <Icon name="image-size-select-actual" size={18} color={colors.primary} />
            </View>
            <View style={styles.rowContent}>
              <Text style={[styles.rowLabel, { color: colors.text }]}>Default Image Quality</Text>
            </View>
            <View style={styles.themeButtons}>
              {(['low', 'medium', 'high'] as const).map(q => (
                <TouchableOpacity
                  key={q}
                  onPress={() => updateSettings({ defaultImageQuality: q })}
                  style={[
                    styles.themeChip,
                    {
                      backgroundColor: settings.defaultImageQuality === q ? colors.primary : colors.surfaceVariant,
                      borderColor: settings.defaultImageQuality === q ? colors.primary : colors.outline,
                    },
                  ]}>
                  <Text style={[styles.themeChipLabel, { color: settings.defaultImageQuality === q ? '#FFF' : colors.textSecondary }]}>
                    {q.charAt(0).toUpperCase() + q.slice(1)}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </AppCard>

        {/* Data */}
        <Section title="DATA" />
        <AppCard style={styles.card} padding={0}>
          <SettingsRow
            icon="history"
            label="Clear Conversion History"
            colors={colors}
            onPress={() => setClearHistoryDialogVisible(true)}
          />
          <SettingsRow
            icon="restore"
            label="Reset All Settings"
            colors={colors}
            onPress={() => setResetDialogVisible(true)}
          />
        </AppCard>

        {/* About */}
        <Section title="ABOUT" />
        <AppCard style={styles.card} padding={0}>
          <SettingsRow
            icon="star-outline"
            label="Rate App"
            colors={colors}
            onPress={() => Linking.openURL(PLAY_STORE_URL).catch(() => {})}
          />
          <SettingsRow
            icon="share-variant"
            label="Share App"
            colors={colors}
            onPress={() => {
              Share.share({
                message: `Try File Converter — convert any file, anywhere!\n${PLAY_STORE_URL}`,
              }).catch(() => {});
            }}
          />
          <SettingsRow
            icon="shield-outline"
            label="Privacy Policy"
            colors={colors}
            onPress={() => Linking.openURL(PRIVACY_POLICY_URL).catch(() => {})}
          />
          <SettingsRow
            icon="file-document-outline"
            label="Terms of Use"
            colors={colors}
            onPress={() => Linking.openURL(TERMS_URL).catch(() => {})}
          />
          <SettingsRow
            icon="email-outline"
            label="Contact Support"
            value={SUPPORT_EMAIL}
            colors={colors}
            onPress={() => Linking.openURL(`mailto:${SUPPORT_EMAIL}`).catch(() => {})}
          />
          <SettingsRow
            icon="information-outline"
            label="Version"
            value={`${APP_NAME} v${APP_VERSION}`}
            colors={colors}
          />
        </AppCard>
      </ScrollView>

      <AppDialog
        visible={clearHistoryDialogVisible}
        title="Clear History"
        message="This will permanently delete all conversion history."
        confirmLabel="Clear"
        cancelLabel="Cancel"
        type="danger"
        onConfirm={() => {
          clearHistory();
          setClearHistoryDialogVisible(false);
          showSnackbar({ message: 'History cleared.', type: 'success' });
        }}
        onCancel={() => setClearHistoryDialogVisible(false)}
      />

      <AppDialog
        visible={resetDialogVisible}
        title="Reset Settings"
        message="All settings will be reset to defaults. This cannot be undone."
        confirmLabel="Reset"
        cancelLabel="Cancel"
        type="danger"
        onConfirm={() => {
          resetSettings();
          setResetDialogVisible(false);
          showSnackbar({ message: 'Settings reset to defaults.', type: 'success' });
        }}
        onCancel={() => setResetDialogVisible(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerTitle: {
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.bold,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.sm,
  },
  scroll: { paddingHorizontal: spacing.lg, paddingBottom: spacing.huge, gap: spacing.xs },
  sectionTitle: {
    fontSize: fontSize.xs,
    fontWeight: fontWeight.semiBold,
    letterSpacing: 0.8,
    marginTop: spacing.lg,
    marginBottom: spacing.xs,
    paddingHorizontal: spacing.xs,
  },
  card: { overflow: 'hidden' },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    minHeight: touchTarget.comfortable,
    borderBottomWidth: StyleSheet.hairlineWidth,
    gap: spacing.md,
  },
  rowIcon: { width: 32, height: 32, borderRadius: radius.sm, alignItems: 'center', justifyContent: 'center' },
  rowContent: { flex: 1, gap: 2 },
  rowLabel: { fontSize: fontSize.base },
  rowValue: { fontSize: fontSize.sm },
  themeButtons: { flexDirection: 'row', gap: spacing.xs },
  themeChip: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 4,
    borderRadius: radius.full,
    borderWidth: 1,
  },
  themeChipLabel: { fontSize: fontSize.xs, fontWeight: fontWeight.medium },
});
