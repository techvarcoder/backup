import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  ScrollView,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import { useTheme } from '../../hooks/useTheme';
import { useFileSystem } from '../../hooks/useFileSystem';
import { useConversion } from '../../hooks/useConversion';
import { AppButton } from '../../components/common/AppButton';
import { AppBar } from '../../components/common/AppBar';
import permissionService from '../../services/permission/PermissionService';
import { findConverter } from '../../constants/converters';
import { spacing, radius, iconSize } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { FileItem } from '../../types';
import { ConversionOptions } from '../../types/converter';

export default function ScannerScreen() {
  const navigation = useNavigation<any>();
  const { colors, isDark } = useTheme();
  const { pickImage, pickMultipleImages } = useFileSystem();
  const { startConversion } = useConversion();

  const [scannedPages, setScannedPages] = useState<FileItem[]>([]);
  const [isConverting, setIsConverting] = useState(false);
  const [permissionDenied, setPermissionDenied] = useState(false);

  const handleAddFromGallery = useCallback(async () => {
    const files = await pickMultipleImages();
    if (files.length > 0) {
      setScannedPages(prev => [...prev, ...files]);
    }
  }, [pickMultipleImages]);

  const handleAddFromCamera = useCallback(async () => {
    const granted = await permissionService.ensureCameraPermission();
    if (!granted) { setPermissionDenied(true); return; }

    const file = await pickImage();
    if (file) {
      setScannedPages(prev => [...prev, file]);
    }
  }, [pickImage]);

  const handleRemovePage = useCallback((index: number) => {
    setScannedPages(prev => prev.filter((_, i) => i !== index));
  }, []);

  const handleConvertToPDF = useCallback(async () => {
    if (scannedPages.length === 0) return;
    setIsConverting(true);

    // Use the dedicated scan-to-pdf converter so ConversionService uses all pages
    const converter = findConverter('jpg', 'pdf', 'scan-to-pdf');
    if (!converter) { setIsConverting(false); return; }

    const options: ConversionOptions = {
      outputFormat: 'pdf',
      quality: 'high',
      outputFileName: `scan_${Date.now()}.pdf`,
      // Pass all pages; ConversionService.runLocalConversion handles scan-to-pdf
      scanPages: scannedPages,
    };

    await startConversion(converter, scannedPages[0], options);
    setIsConverting(false);
  }, [scannedPages, startConversion]);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />
      <AppBar title="Scanner" subtitle="Scan to PDF" onBack={() => navigation.goBack()} />

      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Permission Denied Banner */}
        {permissionDenied && (
          <View style={[styles.banner, { backgroundColor: colors.errorContainer }]}>
            <Icon name="camera-off" size={iconSize.md} color={colors.error} />
            <Text style={[styles.bannerText, { color: colors.error }]}>
              Camera permission denied. Enable it in Settings.
            </Text>
            <TouchableOpacity onPress={() => permissionService.openSettings()}>
              <Text style={[styles.bannerAction, { color: colors.error }]}>Open Settings</Text>
            </TouchableOpacity>
          </View>
        )}

        {/* Scanned Pages Grid */}
        {scannedPages.length > 0 ? (
          <View style={styles.pagesGrid}>
            {scannedPages.map((page, index) => (
              <View key={`${page.id}-${index}`} style={styles.pageWrapper}>
                <Image
                  source={{ uri: page.uri }}
                  style={[styles.pageImage, { borderColor: colors.outline }]}
                  resizeMode="cover"
                />
                <TouchableOpacity
                  onPress={() => handleRemovePage(index)}
                  style={[styles.removeButton, { backgroundColor: colors.error }]}>
                  <Icon name="close" size={12} color="#FFF" />
                </TouchableOpacity>
                <View style={[styles.pageNumber, { backgroundColor: colors.inverseSurface }]}>
                  <Text style={[styles.pageNumberText, { color: colors.inverseOnSurface }]}>
                    {index + 1}
                  </Text>
                </View>
              </View>
            ))}
            {/* Add more button */}
            <TouchableOpacity
              onPress={handleAddFromCamera}
              style={[
                styles.addPageButton,
                { borderColor: colors.primary, backgroundColor: colors.primaryContainer },
              ]}>
              <Icon name="plus" size={iconSize.xl} color={colors.primary} />
              <Text style={[styles.addPageText, { color: colors.primary }]}>Add Page</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.emptyState}>
            <View style={[styles.emptyIcon, { backgroundColor: colors.primaryContainer }]}>
              <Icon name="camera-plus-outline" size={64} color={colors.primary} />
            </View>
            <Text style={[styles.emptyTitle, { color: colors.text }]}>Scan Documents</Text>
            <Text style={[styles.emptyHint, { color: colors.textSecondary }]}>
              Take photos with your camera or pick images from gallery to create a PDF.
            </Text>
          </View>
        )}

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <AppButton
            label="Camera"
            onPress={handleAddFromCamera}
            variant="outlined"
            iconName="camera"
            style={styles.actionBtn}
          />
          <AppButton
            label="Gallery"
            onPress={handleAddFromGallery}
            variant="outlined"
            iconName="image-multiple"
            style={styles.actionBtn}
          />
        </View>

        {scannedPages.length > 0 && (
          <Text style={[styles.pageCount, { color: colors.textSecondary }]}>
            {scannedPages.length} page{scannedPages.length !== 1 ? 's' : ''} ready
          </Text>
        )}
      </ScrollView>

      {/* Convert Button */}
      {scannedPages.length > 0 && (
        <View style={[styles.footer, { backgroundColor: colors.surface, borderTopColor: colors.outline }]}>
          <AppButton
            label={`Create PDF (${scannedPages.length} pages)`}
            onPress={handleConvertToPDF}
            variant="filled"
            size="lg"
            loading={isConverting}
            iconName="file-pdf-box"
            fullWidth
          />
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { padding: spacing.lg, paddingBottom: spacing.xxxl, gap: spacing.lg, flexGrow: 1 },
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.md,
    borderRadius: radius.md,
    gap: spacing.sm,
  },
  bannerText: { flex: 1, fontSize: fontSize.sm },
  bannerAction: { fontSize: fontSize.sm, fontWeight: fontWeight.bold },
  pagesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.md,
  },
  pageWrapper: {
    width: '30%',
    aspectRatio: 0.707,
    position: 'relative',
  },
  pageImage: {
    width: '100%',
    height: '100%',
    borderRadius: radius.md,
    borderWidth: 1,
  },
  removeButton: {
    position: 'absolute',
    top: -6,
    right: -6,
    width: 20,
    height: 20,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pageNumber: {
    position: 'absolute',
    bottom: spacing.xs,
    left: spacing.xs,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: radius.sm,
  },
  pageNumberText: { fontSize: 10, fontWeight: fontWeight.bold },
  addPageButton: {
    width: '30%',
    aspectRatio: 0.707,
    borderRadius: radius.md,
    borderWidth: 2,
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xs,
  },
  addPageText: { fontSize: fontSize.xs, fontWeight: fontWeight.medium },
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.lg,
    paddingVertical: spacing.massive,
  },
  emptyIcon: {
    width: 120,
    height: 120,
    borderRadius: 60,
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyTitle: { fontSize: fontSize.xl, fontWeight: fontWeight.semiBold },
  emptyHint: { fontSize: fontSize.base, textAlign: 'center', lineHeight: 22 },
  actionButtons: { flexDirection: 'row', gap: spacing.md },
  actionBtn: { flex: 1 },
  pageCount: { textAlign: 'center', fontSize: fontSize.sm },
  footer: {
    padding: spacing.lg,
    paddingBottom: spacing.xl,
    borderTopWidth: 1,
  },
});
