import React, { useState, useMemo, useCallback } from 'react';
import { View, Text, StyleSheet, SectionList, TouchableOpacity, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import { useTheme } from '../../hooks/useTheme';
import { useHistoryStore } from '../../store/useHistoryStore';
import { useAppStore } from '../../store/useAppStore';
import { SearchBar } from '../../components/common/SearchBar';
import { ConversionHistoryItem } from '../../components/converter/ConversionHistoryItem';
import { EmptyState } from '../../components/common/EmptyState';
import { AppDialog } from '../../components/common/AppDialog';
import { spacing, radius } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { groupBy } from '../../utils/helpers';
import { getHistoryGroupLabel } from '../../utils/formatters';
import { useShareFile } from '../../hooks/useShareFile';
import { StoredConversion } from '../../types';
import { Routes } from '../../constants/routes';

const FILTER_OPTIONS = ['all', 'completed', 'failed'] as const;
type FilterOption = typeof FILTER_OPTIONS[number];

export default function HistoryScreen() {
  const { colors, isDark } = useTheme();
  const navigation = useNavigation<any>();
  const { conversions, removeConversion, toggleFavorite, clearHistory } = useHistoryStore();
  const showSnackbar = useAppStore(s => s.showSnackbar);
  const { shareFile } = useShareFile();

  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<FilterOption>('all');
  const [clearDialogVisible, setClearDialogVisible] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const filtered = useMemo(() => {
    let list = conversions;
    if (filter !== 'all') list = list.filter(c => c.status === filter);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        c =>
          c.outputFileName.toLowerCase().includes(q) ||
          c.inputFileName.toLowerCase().includes(q) ||
          c.converterName.toLowerCase().includes(q) ||
          c.inputFormat.toLowerCase().includes(q) ||
          c.outputFormat.toLowerCase().includes(q),
      );
    }
    return list;
  }, [conversions, filter, query]);

  const sections = useMemo(() => {
    const grouped = groupBy(filtered, c => getHistoryGroupLabel(c.createdAt));
    const order = ['Today', 'Yesterday', 'This Week', 'Older'];
    return order
      .filter(k => grouped[k])
      .map(k => ({ title: k, data: grouped[k] }));
  }, [filtered]);

  const handleDelete = useCallback((id: string) => setDeleteId(id), []);
  const confirmDelete = useCallback(() => {
    if (deleteId) {
      removeConversion(deleteId);
      showSnackbar({ message: 'Conversion removed.', type: 'info' });
      setDeleteId(null);
    }
  }, [deleteId, removeConversion, showSnackbar]);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />

      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.outline }]}>
        <View style={styles.titleRow}>
          <Text style={[styles.title, { color: colors.text }]}>History</Text>
          {conversions.length > 0 && (
            <TouchableOpacity
              onPress={() => setClearDialogVisible(true)}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Text style={[styles.clearText, { color: colors.error }]}>Clear All</Text>
            </TouchableOpacity>
          )}
        </View>
        <SearchBar
          value={query}
          onChangeText={setQuery}
          placeholder="Search history..."
          style={styles.search}
        />
        {/* Filters */}
        <View style={styles.filters}>
          {FILTER_OPTIONS.map(f => (
            <TouchableOpacity
              key={f}
              onPress={() => setFilter(f)}
              style={[
                styles.filterChip,
                {
                  backgroundColor: filter === f ? colors.primary : colors.surfaceVariant,
                  borderColor: filter === f ? colors.primary : colors.outline,
                },
              ]}>
              <Text
                style={[styles.filterLabel, { color: filter === f ? '#FFF' : colors.textSecondary }]}>
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <SectionList
        sections={sections}
        keyExtractor={item => item.id}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.list}
        stickySectionHeadersEnabled
        renderSectionHeader={({ section }) => (
          <View style={[styles.sectionHeader, { backgroundColor: colors.background }]}>
            <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>{section.title}</Text>
            <Text style={[styles.sectionCount, { color: colors.textTertiary }]}>
              {section.data.length}
            </Text>
          </View>
        )}
        renderItem={({ item }) => (
          <ConversionHistoryItem
            conversion={item}
            onShare={
              item.outputFilePath
                ? () => shareFile(item.outputFilePath!, item.outputFileName)
                : undefined
            }
            onDelete={() => handleDelete(item.id)}
            onFavorite={() => toggleFavorite(item.id)}
          />
        )}
        ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
        ListEmptyComponent={
          <EmptyState
            iconName="history"
            title={query ? 'No results found' : 'No conversions yet'}
            description={query ? 'Try a different search term.' : 'Your conversion history will appear here.'}
            actionLabel={query ? undefined : 'Start Converting'}
            onAction={query ? undefined : () => navigation.navigate(Routes.MAIN, { screen: Routes.TAB_CATEGORIES })}
            style={styles.emptyState}
          />
        }
      />

      <AppDialog
        visible={clearDialogVisible}
        title="Clear History"
        message="Are you sure you want to delete all conversion history? This cannot be undone."
        confirmLabel="Clear All"
        cancelLabel="Cancel"
        type="danger"
        onConfirm={() => { clearHistory(); setClearDialogVisible(false); }}
        onCancel={() => setClearDialogVisible(false)}
      />

      <AppDialog
        visible={!!deleteId}
        title="Delete Entry"
        message="Remove this conversion from history?"
        confirmLabel="Delete"
        cancelLabel="Cancel"
        type="danger"
        onConfirm={confirmDelete}
        onCancel={() => setDeleteId(null)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingBottom: spacing.md, borderBottomWidth: 1 },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.sm,
  },
  title: { fontSize: fontSize.xxl, fontWeight: fontWeight.bold },
  clearText: { fontSize: fontSize.base, fontWeight: fontWeight.medium },
  search: { marginHorizontal: spacing.lg, marginBottom: spacing.sm },
  filters: {
    flexDirection: 'row',
    paddingHorizontal: spacing.lg,
    gap: spacing.sm,
  },
  filterChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.full,
    borderWidth: 1,
  },
  filterLabel: { fontSize: fontSize.sm, fontWeight: fontWeight.medium },
  list: { padding: spacing.lg, paddingBottom: spacing.huge },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: spacing.sm,
    marginBottom: spacing.xs,
  },
  sectionTitle: { fontSize: fontSize.sm, fontWeight: fontWeight.semiBold, letterSpacing: 0.5 },
  sectionCount: { fontSize: fontSize.sm },
  emptyState: { paddingVertical: spacing.xxxl },
});
