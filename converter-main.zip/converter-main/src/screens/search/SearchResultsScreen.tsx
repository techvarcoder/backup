import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, FlatList, StatusBar, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';

import { useTheme } from '../../hooks/useTheme';
import { useSearch } from '../../hooks/useSearch';
import { useAppStore } from '../../store/useAppStore';
import { SearchBar } from '../../components/common/SearchBar';
import { ConverterCard } from '../../components/converter/ConverterCard';
import { EmptyState } from '../../components/common/EmptyState';
import { Routes } from '../../constants/routes';
import { spacing, radius } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { ConverterDefinition } from '../../types/converter';

export default function SearchResultsScreen() {
  const navigation = useNavigation<any>();
  const { colors, isDark } = useTheme();
  const { toggleFavoriteConverter, isFavoriteConverter } = useAppStore();
  const {
    query,
    setQueryImmediate,
    results,
    recentSearches,
    addRecentSearch,
    clearRecentSearches,
    clearQuery,
  } = useSearch();

  const handleConverterPress = (converter: ConverterDefinition) => {
    addRecentSearch(query);
    navigation.navigate(Routes.CONVERTER_DETAIL, { converter });
  };

  const handleRecentSearch = (term: string) => {
    setQueryImmediate(term);
  };

  const showRecent = !query && recentSearches.length > 0;
  const showEmpty = !!query && results.length === 0;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />

      {/* Search Header */}
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.outline }]}>
        <SearchBar
          value={query}
          onChangeText={setQueryImmediate}
          placeholder="Search converters, formats..."
          autoFocus
          style={styles.searchBar}
          onClear={clearQuery}
        />
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <Text style={[styles.cancelText, { color: colors.primary }]}>Cancel</Text>
        </TouchableOpacity>
      </View>

      {/* Recent Searches */}
      {showRecent && (
        <View style={styles.recentContainer}>
          <View style={styles.recentHeader}>
            <Text style={[styles.recentTitle, { color: colors.text }]}>Recent Searches</Text>
            <TouchableOpacity onPress={clearRecentSearches}>
              <Text style={[styles.clearText, { color: colors.textTertiary }]}>Clear</Text>
            </TouchableOpacity>
          </View>
          {recentSearches.map(term => (
            <TouchableOpacity
              key={term}
              onPress={() => handleRecentSearch(term)}
              style={styles.recentItem}>
              <Text style={[styles.recentText, { color: colors.textSecondary }]}>{term}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* Results */}
      {query.length > 0 && (
        <FlatList
          data={results}
          keyExtractor={item => item.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.results}
          renderItem={({ item }) => (
            <ConverterCard
              converter={item}
              onPress={handleConverterPress}
              onFavorite={toggleFavoriteConverter}
              isFavorite={isFavoriteConverter(item.id)}
            />
          )}
          ItemSeparatorComponent={() => <View style={{ height: spacing.sm }} />}
          ListHeaderComponent={
            results.length > 0 ? (
              <Text style={[styles.resultCount, { color: colors.textSecondary }]}>
                {results.length} result{results.length !== 1 ? 's' : ''} for "{query}"
              </Text>
            ) : null
          }
          ListEmptyComponent={
            showEmpty ? (
              <EmptyState
                iconName="magnify-close"
                title="No results"
                description={`No converters found for "${query}".`}
                style={styles.emptyState}
              />
            ) : null
          }
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    gap: spacing.md,
    borderBottomWidth: 1,
  },
  searchBar: { flex: 1 },
  cancelText: { fontSize: fontSize.base, fontWeight: fontWeight.medium },
  recentContainer: { paddingHorizontal: spacing.lg, paddingTop: spacing.lg },
  recentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  recentTitle: { fontSize: fontSize.base, fontWeight: fontWeight.semiBold },
  clearText: { fontSize: fontSize.sm },
  recentItem: {
    paddingVertical: spacing.md,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  recentText: { fontSize: fontSize.base },
  results: { padding: spacing.lg, paddingBottom: spacing.huge },
  resultCount: { fontSize: fontSize.sm, marginBottom: spacing.md },
  emptyState: { paddingVertical: spacing.xxxl },
});
