import React, { useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { FlashList } from '@shopify/flash-list';

import { useTheme } from '../../hooks/useTheme';
import { useHistoryStore } from '../../store/useHistoryStore';
import { useAppStore } from '../../store/useAppStore';
import { SearchBar } from '../../components/common/SearchBar';
import { SectionHeader } from '../../components/common/SectionHeader';
import { ConverterCard } from '../../components/converter/ConverterCard';
import { CategoryCard } from '../../components/converter/CategoryCard';
import { ConversionHistoryItem } from '../../components/converter/ConversionHistoryItem';
import { EmptyState } from '../../components/common/EmptyState';
import { POPULAR_CONVERTERS, CONVERTER_CATEGORIES } from '../../constants/converters';
import { Routes } from '../../constants/routes';
import { spacing, radius, iconSize } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { ConverterDefinition } from '../../types/converter';
import { ConverterCategory } from '../../types/converter';
import { useShareFile } from '../../hooks/useShareFile';

function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return 'Good Morning';
  if (h < 17) return 'Good Afternoon';
  return 'Good Evening';
}

export default function HomeScreen() {
  const navigation = useNavigation<any>();
  const { colors, isDark } = useTheme();
  const { conversions } = useHistoryStore();
  const { toggleFavoriteConverter, isFavoriteConverter } = useAppStore();
  const { shareFile } = useShareFile();

  const recentConversions = useMemo(() => conversions.slice(0, 5), [conversions]);
  const topCategories = useMemo(() => CONVERTER_CATEGORIES.slice(0, 4), []);

  const handleConverterPress = useCallback(
    (converter: ConverterDefinition) => {
      navigation.navigate(Routes.CONVERTER_DETAIL, { converter });
    },
    [navigation],
  );

  const handleCategoryPress = useCallback(
    (category: ConverterCategory) => {
      navigation.navigate(Routes.MAIN, { screen: Routes.TAB_CATEGORIES, params: { categoryId: category.id } });
    },
    [navigation],
  );

  const handleSearchPress = useCallback(() => {
    navigation.navigate(Routes.SEARCH_RESULTS);
  }, [navigation]);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <StatusBar
        barStyle={isDark ? 'light-content' : 'dark-content'}
        backgroundColor={colors.background}
      />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.scroll}>

        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={[styles.greeting, { color: colors.textSecondary }]}>{getGreeting()} 👋</Text>
            <Text style={[styles.headerTitle, { color: colors.text }]}>File Converter</Text>
          </View>
          <TouchableOpacity
            onPress={() => navigation.navigate(Routes.MAIN, { screen: Routes.TAB_SETTINGS })}
            style={[styles.avatarButton, { backgroundColor: colors.primaryContainer }]}>
            <Icon name="account-circle" size={28} color={colors.primary} />
          </TouchableOpacity>
        </View>

        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <SearchBar
            value=""
            onChangeText={() => {}}
            placeholder="Search converters..."
            onPress={handleSearchPress}
            style={{ marginHorizontal: spacing.lg }}
          />
        </View>

        {/* Feature Pills */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.pills}>
          {[
            { icon: 'lightning-bolt', label: '60+ Formats' },
            { icon: 'shield-check', label: 'Fast & Secure' },
            { icon: 'image-size-select-actual', label: 'High Quality' },
            { icon: 'wifi-off', label: 'Works Offline' },
          ].map(pill => (
            <View
              key={pill.label}
              style={[styles.pill, { backgroundColor: colors.primaryContainer }]}>
              <Icon name={pill.icon} size={14} color={colors.primary} />
              <Text style={[styles.pillLabel, { color: colors.primary }]}>{pill.label}</Text>
            </View>
          ))}
        </ScrollView>

        {/* Popular Converters */}
        <View style={styles.section}>
          <SectionHeader
            title="Popular Converters"
            actionLabel="See All"
            onAction={() => navigation.navigate(Routes.MAIN, { screen: Routes.TAB_CATEGORIES })}
          />
          <View style={styles.converterList}>
            {POPULAR_CONVERTERS.slice(0, 4).map(converter => (
              <ConverterCard
                key={converter.id}
                converter={converter}
                onPress={handleConverterPress}
                onFavorite={toggleFavoriteConverter}
                isFavorite={isFavoriteConverter(converter.id)}
                style={styles.converterItem}
              />
            ))}
          </View>
        </View>

        {/* Categories */}
        <View style={styles.section}>
          <SectionHeader
            title="Categories"
            actionLabel="All"
            onAction={() => navigation.navigate(Routes.MAIN, { screen: Routes.TAB_CATEGORIES })}
          />
          <View style={styles.categoryGrid}>
            {topCategories.map(cat => (
              <CategoryCard
                key={cat.id}
                category={cat}
                onPress={handleCategoryPress}
                style={styles.categoryItem}
              />
            ))}
          </View>
        </View>

        {/* Recent Conversions */}
        <View style={styles.section}>
          <SectionHeader
            title="Recent Conversions"
            actionLabel="History"
            onAction={() => navigation.navigate(Routes.MAIN, { screen: Routes.TAB_HISTORY })}
          />
          {recentConversions.length === 0 ? (
            <EmptyState
              iconName="history"
              title="No conversions yet"
              description="Your recent conversions will appear here."
              style={styles.emptyState}
            />
          ) : (
            <View style={styles.historyList}>
              {recentConversions.map(conv => (
                <ConversionHistoryItem
                  key={conv.id}
                  conversion={conv}
                  onShare={
                    conv.outputFilePath
                      ? () => shareFile(conv.outputFilePath!, conv.outputFileName)
                      : undefined
                  }
                />
              ))}
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { paddingBottom: spacing.huge },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.lg,
  },
  greeting: {
    fontSize: fontSize.base,
    marginBottom: 2,
  },
  headerTitle: {
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.bold,
    letterSpacing: -0.5,
  },
  avatarButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  searchContainer: { marginBottom: spacing.lg },
  pills: {
    paddingHorizontal: spacing.lg,
    paddingBottom: spacing.lg,
    gap: spacing.sm,
  },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: radius.full,
    gap: spacing.xs,
  },
  pillLabel: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.medium,
  },
  section: { marginBottom: spacing.xxl },
  converterList: {
    paddingHorizontal: spacing.lg,
    gap: spacing.sm,
  },
  converterItem: {},
  categoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: spacing.lg,
    gap: spacing.md,
  },
  categoryItem: {
    width: '47%',
  },
  historyList: {
    paddingHorizontal: spacing.lg,
    gap: spacing.sm,
  },
  emptyState: { paddingVertical: spacing.xl },
});
