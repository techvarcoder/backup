import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation } from '@react-navigation/native';

import { useTheme } from '../../hooks/useTheme';
import { useAppStore } from '../../store/useAppStore';
import { useHistoryStore } from '../../store/useHistoryStore';
import { ConverterCard } from '../../components/converter/ConverterCard';
import { ConversionHistoryItem } from '../../components/converter/ConversionHistoryItem';
import { SectionHeader } from '../../components/common/SectionHeader';
import { EmptyState } from '../../components/common/EmptyState';
import { CONVERTERS } from '../../constants/converters';
import { Routes } from '../../constants/routes';
import { spacing } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { useShareFile } from '../../hooks/useShareFile';
import { ConverterDefinition } from '../../types/converter';

export default function FavoritesScreen() {
  const navigation = useNavigation<any>();
  const { colors, isDark } = useTheme();
  const { favoriteConverterIds, toggleFavoriteConverter, isFavoriteConverter } = useAppStore();
  const { conversions } = useHistoryStore();
  const { shareFile } = useShareFile();

  const favoriteConverters = useMemo(
    () => CONVERTERS.filter(c => favoriteConverterIds.includes(c.id)),
    [favoriteConverterIds],
  );

  const favoriteConversions = useMemo(
    () => conversions.filter(c => c.isFavorite).slice(0, 10),
    [conversions],
  );

  const handleConverterPress = (converter: ConverterDefinition) => {
    navigation.navigate(Routes.CONVERTER_DETAIL, { converter });
  };

  if (favoriteConverters.length === 0 && favoriteConversions.length === 0) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
        <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />
        <Text style={[styles.headerTitle, { color: colors.text }]}>Favorites</Text>
        <EmptyState
          iconName="star-outline"
          title="No favorites yet"
          description="Star your favorite converters and conversions to find them quickly."
          actionLabel="Browse Converters"
          onAction={() => navigation.navigate(Routes.MAIN, { screen: Routes.TAB_CATEGORIES })}
        />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />

      <Text style={[styles.headerTitle, { color: colors.text }]}>Favorites</Text>

      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Favorite Converters */}
        {favoriteConverters.length > 0 && (
          <View style={styles.section}>
            <SectionHeader title="Pinned Converters" />
            <View style={styles.list}>
              {favoriteConverters.map(converter => (
                <ConverterCard
                  key={converter.id}
                  converter={converter}
                  onPress={handleConverterPress}
                  onFavorite={toggleFavoriteConverter}
                  isFavorite={true}
                />
              ))}
            </View>
          </View>
        )}

        {/* Favorite Conversions */}
        {favoriteConversions.length > 0 && (
          <View style={styles.section}>
            <SectionHeader
              title="Starred Files"
              actionLabel="All History"
              onAction={() => navigation.navigate(Routes.MAIN, { screen: Routes.TAB_HISTORY })}
            />
            <View style={styles.list}>
              {favoriteConversions.map(conv => (
                <ConversionHistoryItem
                  key={conv.id}
                  conversion={conv}
                  onShare={
                    conv.outputFilePath
                      ? () => shareFile(conv.outputFilePath!, conv.outputFileName)
                      : undefined
                  }
                />
              ))}
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerTitle: {
    fontSize: fontSize.xxl,
    fontWeight: fontWeight.bold,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.sm,
  },
  scroll: { paddingBottom: spacing.huge },
  section: { marginBottom: spacing.xxl },
  list: { paddingHorizontal: spacing.lg, gap: spacing.sm },
});
