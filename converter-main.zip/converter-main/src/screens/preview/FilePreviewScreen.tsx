import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  StatusBar,
  ScrollView,
  Image,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import type { RouteProp } from '@react-navigation/native';

import { useTheme } from '../../hooks/useTheme';
import { AppBar } from '../../components/common/AppBar';
import { AppButton } from '../../components/common/AppButton';
import { LoadingSpinner } from '../../components/common/LoadingSpinner';
import { useShareFile } from '../../hooks/useShareFile';
import { spacing, radius, iconSize } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { formatFileSize } from '../../utils/formatters';
import { isImageFile } from '../../utils/fileUtils';
import { RootStackParamList } from '../../types/navigation';

type RouteProps = RouteProp<RootStackParamList, 'FilePreview'>;

export default function FilePreviewScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<RouteProps>();
  const { file } = route.params;
  const { colors, isDark } = useTheme();
  const { shareFile } = useShareFile();
  const [loading, setLoading] = useState(false);

  const isImage = isImageFile(file.extension);
  const isPDF = file.extension === 'pdf';
  const isText = ['txt', 'html', 'csv'].includes(file.extension);

  const handleShare = () => {
    shareFile(file.uri.replace('file://', ''), file.name, file.mimeType);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />
      <AppBar
        title={file.displayName}
        subtitle={formatFileSize(file.size)}
        onBack={() => navigation.goBack()}
        rightActions={
          <TouchableOpacity
            onPress={handleShare}
            style={styles.shareButton}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <Icon name="share-variant" size={iconSize.lg} color={colors.text} />
          </TouchableOpacity>
        }
      />

      <View style={styles.content}>
        {loading && <LoadingSpinner message="Loading preview..." />}

        {isImage && !loading && (
          <ScrollView
            maximumZoomScale={4}
            minimumZoomScale={1}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.imageContainer}>
            <Image
              source={{ uri: file.uri }}
              style={styles.image}
              resizeMode="contain"
              onLoadStart={() => setLoading(true)}
              onLoad={() => setLoading(false)}
              onError={() => setLoading(false)}
            />
          </ScrollView>
        )}

        {isPDF && !loading && (
          <View style={styles.unsupportedContainer}>
            <View style={[styles.iconContainer, { backgroundColor: colors.errorContainer }]}>
              <Icon name="file-pdf-box" size={64} color={colors.error} />
            </View>
            <Text style={[styles.unsupportedTitle, { color: colors.text }]}>
              PDF Preview
            </Text>
            <Text style={[styles.unsupportedHint, { color: colors.textSecondary }]}>
              Use the Open With button to view this PDF in an external app like Adobe Acrobat or Google Drive.
            </Text>
            <AppButton
              label="Open With"
              onPress={handleShare}
              variant="filled"
              iconName="open-in-app"
              style={styles.openButton}
            />
          </View>
        )}

        {!isImage && !isPDF && (
          <View style={styles.unsupportedContainer}>
            <View style={[styles.iconContainer, { backgroundColor: colors.primaryContainer }]}>
              <Icon name="file-outline" size={64} color={colors.primary} />
            </View>
            <Text style={[styles.unsupportedTitle, { color: colors.text }]}>
              Preview Not Available
            </Text>
            <Text style={[styles.unsupportedHint, { color: colors.textSecondary }]}>
              Preview is available for images and PDFs. Share the file to open it in a compatible app.
            </Text>
            <AppButton
              label="Open With"
              onPress={handleShare}
              variant="filled"
              iconName="open-in-app"
              style={styles.openButton}
            />
          </View>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1 },
  imageContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  image: { width: '100%', height: 400 },
  shareButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  unsupportedContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xxxl,
    gap: spacing.lg,
  },
  iconContainer: {
    width: 110,
    height: 110,
    borderRadius: 55,
    alignItems: 'center',
    justifyContent: 'center',
  },
  unsupportedTitle: { fontSize: fontSize.xl, fontWeight: fontWeight.semiBold, textAlign: 'center' },
  unsupportedHint: { fontSize: fontSize.base, textAlign: 'center', lineHeight: 22 },
  openButton: {},
});
