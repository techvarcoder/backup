import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, TextInput, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import type { RouteProp } from '@react-navigation/native';

import { useTheme } from '../../hooks/useTheme';
import { useConversion } from '../../hooks/useConversion';
import { useSettingsStore } from '../../store/useSettingsStore';
import { AppBar } from '../../components/common/AppBar';
import { AppButton } from '../../components/common/AppButton';
import { AppCard } from '../../components/common/AppCard';
import { Dropdown } from '../../components/common/Dropdown';
import { FileCard } from '../../components/file/FileCard';
import { Routes } from '../../constants/routes';
import { spacing, radius } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { ConversionOptions } from '../../types/converter';
import { RootStackParamList } from '../../types/navigation';
import { buildOutputFileName } from '../../utils/formatters';
import type { FileFormat } from '../../types/file';

type RouteProps = RouteProp<RootStackParamList, 'ConversionSettings'>;

const QUALITY_OPTIONS = [
  { value: 'low', label: 'Low', description: 'Smaller file size, reduced quality' },
  { value: 'medium', label: 'Medium', description: 'Balanced quality and size' },
  { value: 'high', label: 'High', description: 'Best quality (recommended)' },
];

const OUTPUT_FORMAT_DESCRIPTIONS: Record<string, string> = {
  pdf: 'Portable Document Format',
  docx: 'Word Document',
  doc: 'Word 97-2003 Document',
  jpg: 'JPEG Image',
  png: 'PNG Image (lossless)',
  webp: 'WebP Image (modern)',
  txt: 'Plain Text',
  xlsx: 'Excel Spreadsheet',
  csv: 'Comma-Separated Values',
  pptx: 'PowerPoint Presentation',
};

export default function ConversionSettingsScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<RouteProps>();
  const { converter, file } = route.params;
  const { colors, isDark } = useTheme();
  const { startConversion } = useConversion();
  const { settings } = useSettingsStore();

  const [outputFormat, setOutputFormat] = useState<FileFormat>(converter.outputFormat);
  const [quality, setQuality] = useState<'low' | 'medium' | 'high'>(settings.defaultImageQuality);
  const [keepFormatting, setKeepFormatting] = useState(true);
  const [outputFileName, setOutputFileName] = useState(
    buildOutputFileName(file.name, converter.outputFormat),
  );
  const [isConverting, setIsConverting] = useState(false);

  const outputFormatOptions = [
    {
      value: converter.outputFormat,
      label: converter.outputFormat.toUpperCase(),
      description: OUTPUT_FORMAT_DESCRIPTIONS[converter.outputFormat] ?? converter.outputFormat,
    },
  ];

  const handleConvert = useCallback(async () => {
    setIsConverting(true);
    const options: ConversionOptions = {
      outputFormat,
      quality,
      keepFormatting,
      outputFileName: outputFileName.trim() || buildOutputFileName(file.name, outputFormat),
    };
    await startConversion(converter, file, options);
    setIsConverting(false);
  }, [startConversion, converter, file, outputFormat, quality, keepFormatting, outputFileName]);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />
      <AppBar title="Conversion Settings" onBack={() => navigation.goBack()} />

      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Selected File */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>SELECTED FILE</Text>
          <FileCard file={file} />
        </View>

        {/* Output Format */}
        <AppCard style={styles.settingsCard}>
          <Dropdown
            label="Output Format"
            options={outputFormatOptions}
            value={outputFormat}
            onChange={v => {
              setOutputFormat(v as FileFormat);
              setOutputFileName(buildOutputFileName(file.name, v));
            }}
          />
        </AppCard>

        {/* Quality */}
        <AppCard style={styles.settingsCard}>
          <Dropdown
            label="Quality"
            options={QUALITY_OPTIONS}
            value={quality}
            onChange={v => setQuality(v as 'low' | 'medium' | 'high')}
          />
        </AppCard>

        {/* Output Filename */}
        <AppCard style={styles.settingsCard}>
          <Text style={[styles.fieldLabel, { color: colors.textSecondary }]}>Output Filename</Text>
          <TextInput
            value={outputFileName}
            onChangeText={setOutputFileName}
            style={[
              styles.textInput,
              {
                backgroundColor: colors.surfaceVariant,
                color: colors.text,
                borderColor: colors.outline,
              },
            ]}
            autoCapitalize="none"
            autoCorrect={false}
          />
        </AppCard>

        {/* Keep Formatting Toggle */}
        <AppCard style={styles.settingsCard}>
          <View style={styles.toggleRow}>
            <View style={styles.toggleInfo}>
              <Text style={[styles.toggleLabel, { color: colors.text }]}>Keep Original Layout</Text>
              <Text style={[styles.toggleDesc, { color: colors.textSecondary }]}>
                Preserve fonts, spacing and formatting
              </Text>
            </View>
            <Switch
              value={keepFormatting}
              onValueChange={setKeepFormatting}
              trackColor={{ false: colors.outline, true: colors.primary }}
              thumbColor="#FFFFFF"
            />
          </View>
        </AppCard>
      </ScrollView>

      {/* Convert Button */}
      <View style={[styles.footer, { backgroundColor: colors.surface, borderTopColor: colors.outline }]}>
        <AppButton
          label="Convert Now"
          onPress={handleConvert}
          variant="filled"
          size="lg"
          loading={isConverting}
          iconName="transfer"
          iconRight
          fullWidth
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { padding: spacing.lg, gap: spacing.md, paddingBottom: spacing.xxxl },
  section: { gap: spacing.sm },
  sectionTitle: {
    fontSize: fontSize.xs,
    fontWeight: fontWeight.semiBold,
    letterSpacing: 0.8,
    marginLeft: spacing.xs,
    marginBottom: spacing.xs,
  },
  settingsCard: { padding: spacing.lg, gap: spacing.md },
  fieldLabel: { fontSize: fontSize.sm, fontWeight: fontWeight.medium, marginBottom: spacing.xs },
  textInput: {
    borderWidth: 1,
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    height: 48,
    fontSize: fontSize.base,
  },
  toggleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  toggleInfo: { flex: 1, marginRight: spacing.lg },
  toggleLabel: { fontSize: fontSize.base, fontWeight: fontWeight.medium },
  toggleDesc: { fontSize: fontSize.sm, marginTop: 2 },
  footer: { padding: spacing.lg, paddingBottom: spacing.xl, borderTopWidth: 1 },
});
