import React, { useState, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import type { RouteProp } from '@react-navigation/native';

import { useTheme } from '../../hooks/useTheme';
import { useFileSystem } from '../../hooks/useFileSystem';
import { useHistoryStore } from '../../store/useHistoryStore';
import { AppBar } from '../../components/common/AppBar';
import { AppButton } from '../../components/common/AppButton';
import { AppCard } from '../../components/common/AppCard';
import { FileCard } from '../../components/file/FileCard';
import { ConversionHistoryItem } from '../../components/converter/ConversionHistoryItem';
import { EmptyState } from '../../components/common/EmptyState';
import { Routes } from '../../constants/routes';
import { spacing, radius, iconSize } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { FileItem } from '../../types';
import { RootStackParamList } from '../../types/navigation';
import { formatFileSize } from '../../utils/formatters';

type RouteProps = RouteProp<RootStackParamList, 'FilePicker'>;

export default function FilePickerScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<RouteProps>();
  const { converter } = route.params;
  const { colors, isDark } = useTheme();
  const { pickDocument, pickImage } = useFileSystem();
  const { conversions } = useHistoryStore();

  const [selectedFile, setSelectedFile] = useState<FileItem | null>(null);

  const isImageConverter = ['jpg', 'jpeg', 'png', 'webp', 'heic', 'bmp', 'tiff', 'svg', 'gif'].includes(
    converter.inputFormat,
  );

  const handlePickFile = useCallback(async () => {
    const file = await pickDocument(converter);
    if (file) setSelectedFile(file);
  }, [pickDocument, converter]);

  const handlePickImage = useCallback(async () => {
    const file = await pickImage();
    if (file) setSelectedFile(file);
  }, [pickImage]);

  const handleContinue = useCallback(() => {
    if (!selectedFile) return;
    navigation.navigate(Routes.CONVERSION_SETTINGS, {
      converter,
      file: selectedFile,
    });
  }, [selectedFile, converter, navigation]);

  const recentForThisConverter = conversions
    .filter(c => c.converterId === converter.id && c.status === 'completed')
    .slice(0, 3);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />
      <AppBar title={converter.name} subtitle="Select File" onBack={() => navigation.goBack()} />

      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Upload Area */}
        <AppCard
          style={[
            styles.uploadCard,
            {
              borderColor: selectedFile ? colors.primary : colors.outline,
              borderStyle: selectedFile ? 'solid' : 'dashed',
              borderWidth: selectedFile ? 1.5 : 1.5,
            },
          ]}>
          {selectedFile ? (
            <View style={styles.selectedFileContent}>
              <FileCard
                file={selectedFile}
                onRemove={() => setSelectedFile(null)}
                style={styles.fileCard}
              />
              <Text style={[styles.selectedHint, { color: colors.textSecondary }]}>
                Supported: {(converter.inputFormats ?? [converter.inputFormat])
                  .map(f => f.toUpperCase())
                  .join(', ')}
              </Text>
            </View>
          ) : (
            <View style={styles.emptyUploadContent}>
              <View style={[styles.uploadIcon, { backgroundColor: colors.primaryContainer }]}>
                <Icon name="cloud-upload-outline" size={48} color={colors.primary} />
              </View>
              <Text style={[styles.uploadTitle, { color: colors.text }]}>Upload File</Text>
              <Text style={[styles.uploadHint, { color: colors.textSecondary }]}>
                Drag & drop your file here, or
              </Text>
              <AppButton
                label="Browse Files"
                onPress={handlePickFile}
                variant="outlined"
                iconName="folder-open-outline"
                style={styles.browseButton}
              />
              {isImageConverter && (
                <AppButton
                  label="Pick from Gallery"
                  onPress={handlePickImage}
                  variant="text"
                  iconName="image-outline"
                  style={styles.galleryButton}
                />
              )}
              <Text style={[styles.supportedFormats, { color: colors.textTertiary }]}>
                Supported: {(converter.inputFormats ?? [converter.inputFormat])
                  .map(f => f.toUpperCase())
                  .join(', ')}
              </Text>
            </View>
          )}
        </AppCard>

        {/* Recent files for this converter */}
        {recentForThisConverter.length > 0 && (
          <View style={styles.recentSection}>
            <Text style={[styles.recentTitle, { color: colors.text }]}>Recent</Text>
            {recentForThisConverter.map(conv => (
              <ConversionHistoryItem key={conv.id} conversion={conv} />
            ))}
          </View>
        )}
      </ScrollView>

      {/* Bottom CTA */}
      <View style={[styles.footer, { backgroundColor: colors.surface, borderTopColor: colors.outline }]}>
        <AppButton
          label="Next"
          onPress={handleContinue}
          variant="filled"
          size="lg"
          disabled={!selectedFile}
          iconName="arrow-right"
          iconRight
          fullWidth
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { padding: spacing.lg, paddingBottom: spacing.xxxl, gap: spacing.lg },
  uploadCard: { padding: spacing.xl, borderRadius: radius.xl },
  emptyUploadContent: { alignItems: 'center', gap: spacing.md, paddingVertical: spacing.xl },
  uploadIcon: { width: 88, height: 88, borderRadius: 44, alignItems: 'center', justifyContent: 'center' },
  uploadTitle: { fontSize: fontSize.xl, fontWeight: fontWeight.semiBold },
  uploadHint: { fontSize: fontSize.base },
  browseButton: { marginTop: spacing.sm },
  galleryButton: {},
  supportedFormats: { fontSize: fontSize.xs, textAlign: 'center', marginTop: spacing.xs },
  selectedFileContent: { gap: spacing.sm },
  fileCard: {},
  selectedHint: { fontSize: fontSize.xs, textAlign: 'center' },
  recentSection: { gap: spacing.sm },
  recentTitle: { fontSize: fontSize.base, fontWeight: fontWeight.semiBold, paddingLeft: spacing.xs },
  footer: {
    padding: spacing.lg,
    paddingBottom: spacing.xl,
    borderTopWidth: 1,
  },
});
