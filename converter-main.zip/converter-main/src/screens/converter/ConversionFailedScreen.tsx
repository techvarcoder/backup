import React from 'react';
import { View, Text, StyleSheet, StatusBar, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import type { RouteProp } from '@react-navigation/native';

import { useTheme } from '../../hooks/useTheme';
import { AppButton } from '../../components/common/AppButton';
import { AppCard } from '../../components/common/AppCard';
import { Routes } from '../../constants/routes';
import { spacing, radius, iconSize } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { RootStackParamList } from '../../types/navigation';

type RouteProps = RouteProp<RootStackParamList, 'ConversionFailed'>;

const COMMON_ERRORS: Record<string, { title: string; hint: string }> = {
  'permission denied': {
    title: 'Permission Denied',
    hint: 'Grant storage access in Settings > App Permissions.',
  },
  'storage permission': {
    title: 'Storage Permission Required',
    hint: 'Allow storage access to save converted files.',
  },
  'network': {
    title: 'Network Error',
    hint: 'This conversion requires internet. Check your connection and try again.',
  },
  'api key': {
    title: 'API Key Required',
    hint: 'Add your backend API key in Settings to convert this format.',
  },
  'unsupported': {
    title: 'Unsupported Format',
    hint: 'This format combination is not currently supported.',
  },
  'cancelled': {
    title: 'Conversion Cancelled',
    hint: 'You cancelled the conversion.',
  },
  'file too large': {
    title: 'File Too Large',
    hint: 'Maximum file size is 100MB. Try compressing the file first.',
  },
  'corrupted': {
    title: 'File Appears Corrupted',
    hint: 'The file could not be read. Try with a different file.',
  },
};

function getErrorInfo(error: string): { title: string; hint: string } {
  const lower = error.toLowerCase();
  for (const [key, info] of Object.entries(COMMON_ERRORS)) {
    if (lower.includes(key)) return info;
  }
  return { title: 'Conversion Failed', hint: 'An unexpected error occurred. Please try again.' };
}

export default function ConversionFailedScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<RouteProps>();
  const { error, converter } = route.params;
  const { colors, isDark } = useTheme();
  const errorInfo = getErrorInfo(error);

  const handleRetry = () => {
    navigation.navigate(Routes.FILE_PICKER, { converter });
  };

  const handleChooseAnother = () => {
    // Navigate to Main and direct the tab navigator to show Categories
    navigation.reset({
      index: 0,
      routes: [{ name: Routes.MAIN, params: { screen: Routes.TAB_CATEGORIES } }],
    });
  };

  const handleHome = () => {
    navigation.reset({ index: 0, routes: [{ name: Routes.MAIN }] });
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top', 'bottom']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />

      <ScrollView contentContainerStyle={styles.content}>
        {/* Error Icon */}
        <View style={[styles.errorCircle, { backgroundColor: colors.errorContainer }]}>
          <Icon name="close-octagon" size={60} color={colors.error} />
        </View>

        <Text style={[styles.title, { color: colors.text }]}>{errorInfo.title}</Text>
        <Text style={[styles.hint, { color: colors.textSecondary }]}>{errorInfo.hint}</Text>

        {/* Error Details */}
        <AppCard style={[styles.errorCard, { borderColor: colors.errorContainer }]}>
          <View style={styles.errorHeader}>
            <Icon name="information-outline" size={iconSize.sm} color={colors.error} />
            <Text style={[styles.errorLabel, { color: colors.error }]}>Error Details</Text>
          </View>
          <Text style={[styles.errorText, { color: colors.textSecondary }]}>{error}</Text>
        </AppCard>

        {/* Actions */}
        <View style={styles.actions}>
          <AppButton
            label="Try Again"
            onPress={handleRetry}
            variant="filled"
            iconName="refresh"
            fullWidth
            size="lg"
          />
          <AppButton
            label="Choose Another File"
            onPress={handleChooseAnother}
            variant="outlined"
            iconName="folder-open"
            fullWidth
          />
          <AppButton
            label="Go Home"
            onPress={handleHome}
            variant="text"
            iconName="home"
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xxl,
    gap: spacing.lg,
  },
  errorCircle: {
    width: 110,
    height: 110,
    borderRadius: 55,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
  },
  title: { fontSize: fontSize.xxl, fontWeight: fontWeight.bold, textAlign: 'center' },
  hint: { fontSize: fontSize.base, textAlign: 'center', lineHeight: 22 },
  errorCard: {
    width: '100%',
    padding: spacing.lg,
    gap: spacing.sm,
    borderWidth: 1,
  },
  errorHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  errorLabel: { fontSize: fontSize.sm, fontWeight: fontWeight.semiBold },
  errorText: { fontSize: fontSize.sm, lineHeight: 18 },
  actions: { width: '100%', gap: spacing.sm, marginTop: spacing.md },
});
