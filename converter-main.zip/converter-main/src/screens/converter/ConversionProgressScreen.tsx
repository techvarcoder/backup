import React, { useEffect } from 'react';
import { View, Text, StyleSheet, StatusBar, BackHandler } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  Easing,
  interpolate,
  withSpring,
} from 'react-native-reanimated';
import Svg, { Circle } from 'react-native-svg';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import type { RouteProp } from '@react-navigation/native';

import { useTheme } from '../../hooks/useTheme';
import { useConversionStore } from '../../store/useConversionStore';
import { useConversion } from '../../hooks/useConversion';
import { AppButton } from '../../components/common/AppButton';
import { AppDialog } from '../../components/common/AppDialog';
import { FileCard } from '../../components/file/FileCard';
import { spacing, radius } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { formatEstimatedTime, formatPercentage } from '../../utils/formatters';
import { RootStackParamList } from '../../types/navigation';
import { useState } from 'react';

type RouteProps = RouteProp<RootStackParamList, 'ConversionProgress'>;

const CIRCLE_SIZE = 180;
const STROKE_WIDTH = 10;
const RADIUS = (CIRCLE_SIZE - STROKE_WIDTH) / 2;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

export default function ConversionProgressScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<RouteProps>();
  const { converter, file } = route.params;
  const { colors, isDark } = useTheme();
  const { progress, status } = useConversionStore();
  const { cancelConversion } = useConversion();
  const [showCancelDialog, setShowCancelDialog] = useState(false);

  const rotationAnim = useSharedValue(0);
  const progressAnim = useSharedValue(0);
  const scaleAnim = useSharedValue(0.8);

  useEffect(() => {
    rotationAnim.value = withRepeat(
      withTiming(360, { duration: 3000, easing: Easing.linear }),
      -1,
      false,
    );
    scaleAnim.value = withSpring(1, { damping: 12 });
  }, []);

  useEffect(() => {
    if (progress) {
      progressAnim.value = withSpring(progress.percentage / 100, { damping: 20 });
    }
  }, [progress?.percentage]);

  useEffect(() => {
    const handler = BackHandler.addEventListener('hardwareBackPress', () => {
      setShowCancelDialog(true);
      return true;
    });
    return () => handler.remove();
  }, []);

  const rotateStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${rotationAnim.value}deg` }],
  }));

  const containerStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scaleAnim.value }],
  }));

  const percentage = progress?.percentage ?? 0;
  const strokeDashoffset = CIRCUMFERENCE * (1 - percentage / 100);
  const stageLabelMap: Record<string, string> = {
    preparing: 'Preparing...',
    uploading: 'Uploading file...',
    processing: 'Converting...',
    downloading: 'Downloading result...',
    saving: 'Saving file...',
    done: 'Complete!',
  };
  const stageLabel = progress ? stageLabelMap[progress.stage] ?? progress.message : 'Processing...';

  const handleCancel = () => {
    cancelConversion();
    navigation.goBack();
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top', 'bottom']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />

      <Animated.View style={[styles.content, containerStyle]}>
        {/* File Info */}
        <View style={styles.fileInfo}>
          <Text style={[styles.title, { color: colors.text }]}>Converting</Text>
          <FileCard file={file} compact style={styles.fileCard} />
        </View>

        {/* Circular Progress */}
        <View style={styles.progressWrapper}>
          <Animated.View style={rotateStyle}>
            <Svg width={CIRCLE_SIZE} height={CIRCLE_SIZE}>
              {/* Background ring */}
              <Circle
                cx={CIRCLE_SIZE / 2}
                cy={CIRCLE_SIZE / 2}
                r={RADIUS}
                stroke={colors.outline}
                strokeWidth={STROKE_WIDTH}
                fill="none"
              />
            </Svg>
          </Animated.View>
          <Svg
            width={CIRCLE_SIZE}
            height={CIRCLE_SIZE}
            style={StyleSheet.absoluteFill}>
            <Circle
              cx={CIRCLE_SIZE / 2}
              cy={CIRCLE_SIZE / 2}
              r={RADIUS}
              stroke={colors.primary}
              strokeWidth={STROKE_WIDTH}
              fill="none"
              strokeDasharray={`${CIRCUMFERENCE}`}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
              transform={`rotate(-90, ${CIRCLE_SIZE / 2}, ${CIRCLE_SIZE / 2})`}
            />
          </Svg>
          <View style={StyleSheet.absoluteFill as any}>
            <View style={styles.progressCenter}>
              <Text style={[styles.percentText, { color: colors.text }]}>
                {formatPercentage(percentage)}
              </Text>
              <Text style={[styles.stageText, { color: colors.textSecondary }]}>{stageLabel}</Text>
            </View>
          </View>
        </View>

        {/* Status */}
        <View style={styles.statusContainer}>
          <View style={styles.statusSteps}>
            {['Uploading', 'Converting', 'Finalizing'].map((step, i) => {
              const stageIndex = { uploading: 0, processing: 1, saving: 2, done: 3 };
              const currentIdx = stageIndex[(progress?.stage ?? 'preparing') as keyof typeof stageIndex] ?? -1;
              const done = currentIdx > i;
              const active = currentIdx === i;
              return (
                <View key={step} style={styles.statusStep}>
                  <View
                    style={[
                      styles.stepDot,
                      {
                        backgroundColor: done ? colors.success : active ? colors.primary : colors.outline,
                      },
                    ]}>
                    {done && <Icon name="check" size={12} color="#FFF" />}
                  </View>
                  <Text style={[styles.stepLabel, { color: done || active ? colors.text : colors.textTertiary }]}>
                    {step}
                  </Text>
                  {done && <Text style={[styles.stepStatus, { color: colors.success }]}>Completed</Text>}
                  {active && <Text style={[styles.stepStatus, { color: colors.primary }]}>In Progress</Text>}
                  {!done && !active && <Text style={[styles.stepStatus, { color: colors.textTertiary }]}>Pending</Text>}
                </View>
              );
            })}
          </View>
        </View>

        <Text style={[styles.hint, { color: colors.textTertiary }]}>
          Please don't close the app.
        </Text>

        <AppButton
          label="Cancel"
          onPress={() => setShowCancelDialog(true)}
          variant="text"
          style={styles.cancelButton}
        />
      </Animated.View>

      <AppDialog
        visible={showCancelDialog}
        title="Cancel Conversion"
        message="Are you sure you want to cancel this conversion? Progress will be lost."
        confirmLabel="Yes, Cancel"
        cancelLabel="Continue"
        type="warning"
        onConfirm={handleCancel}
        onCancel={() => setShowCancelDialog(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xxl, gap: spacing.xxl },
  fileInfo: { width: '100%', alignItems: 'center', gap: spacing.sm },
  title: { fontSize: fontSize.xl, fontWeight: fontWeight.bold },
  fileCard: { width: '100%' },
  progressWrapper: { width: CIRCLE_SIZE, height: CIRCLE_SIZE, alignItems: 'center', justifyContent: 'center' },
  progressCenter: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  percentText: { fontSize: 36, fontWeight: fontWeight.bold, letterSpacing: -1 },
  stageText: { fontSize: fontSize.sm, marginTop: spacing.xs, textAlign: 'center' },
  statusContainer: { width: '100%' },
  statusSteps: { gap: spacing.md },
  statusStep: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  stepDot: { width: 24, height: 24, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  stepLabel: { flex: 1, fontSize: fontSize.base, fontWeight: fontWeight.medium },
  stepStatus: { fontSize: fontSize.sm },
  hint: { fontSize: fontSize.sm, textAlign: 'center' },
  cancelButton: { marginTop: spacing.sm },
});
