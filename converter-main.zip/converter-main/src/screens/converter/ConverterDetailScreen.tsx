import React, { useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

import { useTheme } from '../../hooks/useTheme';
import { useAppStore } from '../../store/useAppStore';
import { AppBar } from '../../components/common/AppBar';
import { AppButton } from '../../components/common/AppButton';
import { AppCard } from '../../components/common/AppCard';
import { Badge, OfflineBadge, OnlineBadge } from '../../components/common/Badge';
import { Routes } from '../../constants/routes';
import { getFormatInfo } from '../../constants/formats';
import { spacing, radius, iconSize } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { RootStackParamList } from '../../types/navigation';
import type { RouteProp } from '@react-navigation/native';

type RouteProps = RouteProp<RootStackParamList, 'ConverterDetail'>;

export default function ConverterDetailScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<RouteProps>();
  const { converter } = route.params;
  const { colors, isDark } = useTheme();
  const { toggleFavoriteConverter, isFavoriteConverter } = useAppStore();

  const isFav = isFavoriteConverter(converter.id);
  const isOffline = converter.engine === 'local';

  const inputInfo = getFormatInfo(converter.inputFormat);
  const outputInfo = getFormatInfo(converter.outputFormat);

  const handleStart = useCallback(() => {
    navigation.navigate(Routes.FILE_PICKER, { converter });
  }, [navigation, converter]);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />
      <AppBar
        title={converter.name}
        onBack={() => navigation.goBack()}
        rightActions={
          <AppButton
            label={isFav ? 'Saved' : 'Save'}
            onPress={() => toggleFavoriteConverter(converter.id)}
            variant="text"
            iconName={isFav ? 'star' : 'star-outline'}
            size="sm"
          />
        }
      />

      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Format Conversion Visual */}
        <AppCard style={styles.conversionCard}>
          <View style={styles.conversionVisual}>
            <View style={styles.formatBlock}>
              <View style={[styles.formatIcon, { backgroundColor: `${inputInfo?.color ?? '#9CA3AF'}18` }]}>
                <Icon name={inputInfo?.iconName ?? 'file'} size={36} color={inputInfo?.color ?? '#9CA3AF'} />
              </View>
              <Text style={[styles.formatLabel, { color: colors.text }]}>
                {converter.inputFormat.toUpperCase()}
              </Text>
              <Text style={[styles.formatDesc, { color: colors.textSecondary }]}>Input</Text>
            </View>

            <View style={styles.arrowContainer}>
              <Icon name="arrow-right-bold" size={32} color={colors.primary} />
            </View>

            <View style={styles.formatBlock}>
              <View style={[styles.formatIcon, { backgroundColor: `${outputInfo?.color ?? '#9CA3AF'}18` }]}>
                <Icon name={outputInfo?.iconName ?? 'file'} size={36} color={outputInfo?.color ?? '#9CA3AF'} />
              </View>
              <Text style={[styles.formatLabel, { color: colors.text }]}>
                {converter.outputFormat.toUpperCase()}
              </Text>
              <Text style={[styles.formatDesc, { color: colors.textSecondary }]}>Output</Text>
            </View>
          </View>
        </AppCard>

        {/* Description */}
        <AppCard style={styles.infoCard}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>About</Text>
          <Text style={[styles.description, { color: colors.textSecondary }]}>
            {converter.description}
          </Text>
        </AppCard>

        {/* Details */}
        <AppCard style={styles.infoCard}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>Details</Text>
          <View style={styles.detailRows}>
            <DetailRow
              icon="wifi"
              label="Processing"
              value={isOffline ? 'Offline — works without internet' : 'Requires internet connection'}
              colors={colors}
            />
            <DetailRow
              icon="cog"
              label="Engine"
              value={isOffline ? 'Local (on-device)' : 'Cloud conversion'}
              colors={colors}
            />
            {converter.inputFormats && converter.inputFormats.length > 1 && (
              <DetailRow
                icon="file-multiple"
                label="Accepted Input"
                value={converter.inputFormats.map(f => f.toUpperCase()).join(', ')}
                colors={colors}
              />
            )}
          </View>
          <View style={styles.badgeRow}>
            {isOffline ? <OfflineBadge /> : <OnlineBadge />}
            {converter.isPopular && (
              <Badge label="Popular" backgroundColor={colors.warningContainer} color={colors.warning} />
            )}
          </View>
        </AppCard>

        {/* Start Button */}
        <AppButton
          label="Select File to Convert"
          onPress={handleStart}
          variant="filled"
          size="lg"
          iconName="folder-open"
          fullWidth
          style={styles.startButton}
        />
      </ScrollView>
    </SafeAreaView>
  );
}

function DetailRow({
  icon,
  label,
  value,
  colors,
}: {
  icon: string;
  label: string;
  value: string;
  colors: any;
}) {
  return (
    <View style={detailStyles.row}>
      <View style={[detailStyles.iconContainer, { backgroundColor: colors.primaryContainer }]}>
        <Icon name={icon} size={16} color={colors.primary} />
      </View>
      <View style={detailStyles.texts}>
        <Text style={[detailStyles.label, { color: colors.textSecondary }]}>{label}</Text>
        <Text style={[detailStyles.value, { color: colors.text }]}>{value}</Text>
      </View>
    </View>
  );
}

const detailStyles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, paddingVertical: spacing.sm },
  iconContainer: { width: 32, height: 32, borderRadius: radius.sm, alignItems: 'center', justifyContent: 'center' },
  texts: { flex: 1 },
  label: { fontSize: fontSize.xs, fontWeight: fontWeight.medium },
  value: { fontSize: fontSize.base, marginTop: 2 },
});

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { padding: spacing.lg, gap: spacing.md },
  conversionCard: { padding: spacing.xxl },
  conversionVisual: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.xl,
  },
  formatBlock: { alignItems: 'center', gap: spacing.sm },
  formatIcon: {
    width: 72,
    height: 72,
    borderRadius: radius.xl,
    alignItems: 'center',
    justifyContent: 'center',
  },
  formatLabel: { fontSize: fontSize.lg, fontWeight: fontWeight.bold },
  formatDesc: { fontSize: fontSize.sm },
  arrowContainer: { alignItems: 'center', justifyContent: 'center' },
  infoCard: { padding: spacing.lg, gap: spacing.md },
  sectionTitle: { fontSize: fontSize.base, fontWeight: fontWeight.semiBold },
  description: { fontSize: fontSize.base, lineHeight: 22 },
  detailRows: { gap: spacing.xs },
  badgeRow: { flexDirection: 'row', gap: spacing.sm, marginTop: spacing.sm },
  startButton: { marginTop: spacing.md },
});
