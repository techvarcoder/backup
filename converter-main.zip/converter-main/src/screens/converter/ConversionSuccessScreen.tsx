import React, { useEffect } from 'react';
import { View, Text, StyleSheet, StatusBar } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useNavigation, useRoute } from '@react-navigation/native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withDelay,
  withTiming,
  withSequence,
} from 'react-native-reanimated';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import type { RouteProp } from '@react-navigation/native';

import { useTheme } from '../../hooks/useTheme';
import { AppButton } from '../../components/common/AppButton';
import { AppCard } from '../../components/common/AppCard';
import { FileIcon } from '../../components/file/FileIcon';
import { Routes } from '../../constants/routes';
import { spacing, radius, iconSize } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { formatFileSize, formatDuration, formatCompressionRatio } from '../../utils/formatters';
import { useShareFile } from '../../hooks/useShareFile';
import fileService from '../../services/file/FileService';
import { useAppStore } from '../../store/useAppStore';
import { RootStackParamList } from '../../types/navigation';

type RouteProps = RouteProp<RootStackParamList, 'ConversionSuccess'>;

export default function ConversionSuccessScreen() {
  const navigation = useNavigation<any>();
  const route = useRoute<RouteProps>();
  const { conversion } = route.params;
  const { colors, isDark } = useTheme();
  const { shareFile } = useShareFile();
  const showSnackbar = useAppStore(s => s.showSnackbar);

  const checkScale = useSharedValue(0);
  const contentOpacity = useSharedValue(0);
  const contentY = useSharedValue(30);

  useEffect(() => {
    checkScale.value = withSequence(
      withSpring(1.2, { damping: 8 }),
      withSpring(1, { damping: 12 }),
    );
    contentOpacity.value = withDelay(400, withTiming(1, { duration: 500 }));
    contentY.value = withDelay(400, withSpring(0, { damping: 16 }));
  }, []);

  const checkStyle = useAnimatedStyle(() => ({
    transform: [{ scale: checkScale.value }],
  }));

  const contentStyle = useAnimatedStyle(() => ({
    opacity: contentOpacity.value,
    transform: [{ translateY: contentY.value }],
  }));

  const handleSave = async () => {
    if (!conversion.outputFilePath) return;
    try {
      await fileService.saveToDownloads(conversion.outputFilePath, conversion.outputFileName);
      showSnackbar({ message: `Saved to Downloads: ${conversion.outputFileName}`, type: 'success' });
    } catch (e: any) {
      showSnackbar({ message: e.message ?? 'Failed to save file.', type: 'error' });
    }
  };

  const handleShare = () => {
    if (conversion.outputFilePath) {
      shareFile(conversion.outputFilePath, conversion.outputFileName);
    }
  };

  const handleConvertAnother = () => {
    navigation.reset({ index: 0, routes: [{ name: Routes.MAIN }] });
  };

  const compressionInfo =
    conversion.outputFileSize && conversion.inputFileSize
      ? formatCompressionRatio(conversion.inputFileSize, conversion.outputFileSize)
      : null;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]} edges={['top', 'bottom']}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={colors.background} />

      <View style={styles.content}>
        {/* Success Icon */}
        <Animated.View style={[styles.checkContainer, checkStyle]}>
          <View style={[styles.checkCircle, { backgroundColor: colors.successContainer }]}>
            <Icon name="check-bold" size={52} color={colors.success} />
          </View>
        </Animated.View>

        <Animated.View style={[styles.body, contentStyle]}>
          <Text style={[styles.title, { color: colors.text }]}>Conversion Complete!</Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
            Your file has been converted successfully.
          </Text>

          {/* File Result Card */}
          <AppCard style={styles.resultCard}>
            <View style={styles.fileRow}>
              <FileIcon extension={conversion.inputFormat} size={40} />
              <Icon name="arrow-right" size={iconSize.md} color={colors.textTertiary} />
              <FileIcon extension={conversion.outputFormat} size={40} />
            </View>
            <Text style={[styles.fileName, { color: colors.text }]} numberOfLines={1} ellipsizeMode="middle">
              {conversion.outputFileName}
            </Text>

            <View style={styles.stats}>
              {[
                {
                  label: 'Original Size',
                  value: formatFileSize(conversion.inputFileSize),
                  icon: 'file',
                },
                {
                  label: 'Converted Size',
                  value: conversion.outputFileSize ? formatFileSize(conversion.outputFileSize) : '--',
                  icon: 'file-check',
                },
                {
                  label: 'Time',
                  value: conversion.conversionTimeMs ? formatDuration(conversion.conversionTimeMs) : '--',
                  icon: 'timer',
                },
                compressionInfo && {
                  label: 'Size Change',
                  value: compressionInfo,
                  icon: 'chart-line',
                },
              ]
                .filter(Boolean)
                .map((stat: any) => (
                  <View key={stat.label} style={[styles.stat, { borderColor: colors.outline }]}>
                    <Icon name={stat.icon} size={14} color={colors.textSecondary} />
                    <Text style={[styles.statValue, { color: colors.text }]}>{stat.value}</Text>
                    <Text style={[styles.statLabel, { color: colors.textSecondary }]}>{stat.label}</Text>
                  </View>
                ))}
            </View>
          </AppCard>

          {/* Actions */}
          <View style={styles.actions}>
            <AppButton
              label="Save to Device"
              onPress={handleSave}
              variant="filled"
              iconName="download"
              fullWidth
              size="lg"
            />
            <AppButton
              label="Share File"
              onPress={handleShare}
              variant="outlined"
              iconName="share-variant"
              fullWidth
            />
            <AppButton
              label="Convert Another File"
              onPress={handleConvertAnother}
              variant="text"
              iconName="refresh"
            />
          </View>
        </Animated.View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xxl },
  checkContainer: { marginBottom: spacing.xxl },
  checkCircle: {
    width: 100,
    height: 100,
    borderRadius: 50,
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: { width: '100%', alignItems: 'center', gap: spacing.md },
  title: { fontSize: fontSize.xxl, fontWeight: fontWeight.bold, textAlign: 'center' },
  subtitle: { fontSize: fontSize.base, textAlign: 'center', lineHeight: 22 },
  resultCard: { width: '100%', padding: spacing.lg, gap: spacing.md, alignItems: 'center' },
  fileRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  fileName: { fontSize: fontSize.base, fontWeight: fontWeight.medium, width: '100%', textAlign: 'center' },
  stats: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm, justifyContent: 'center', width: '100%' },
  stat: {
    alignItems: 'center',
    gap: 3,
    borderWidth: 1,
    borderRadius: radius.md,
    padding: spacing.sm,
    minWidth: 80,
  },
  statValue: { fontSize: fontSize.base, fontWeight: fontWeight.semiBold },
  statLabel: { fontSize: fontSize.xs, textAlign: 'center' },
  actions: { width: '100%', gap: spacing.sm },
});
