import React, { useEffect } from 'react';
import { View, Text, StyleSheet, StatusBar } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
  withDelay,
  withSequence,
  runOnJS,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import LinearGradient from 'react-native-linear-gradient';
import { useSettingsStore } from '../../store/useSettingsStore';
import { Routes } from '../../constants/routes';
import { APP_NAME } from '../../constants';
import { fontSize, fontWeight } from '../../theme/typography';
import { spacing } from '../../theme/spacing';
import type { RootScreenProps } from '../../types/navigation';

type Props = RootScreenProps<'Splash'>;

export default function SplashScreen({ navigation }: Props) {
  const { settings } = useSettingsStore();

  const iconScale = useSharedValue(0);
  const iconOpacity = useSharedValue(0);
  const titleOpacity = useSharedValue(0);
  const subtitleOpacity = useSharedValue(0);
  const dotsOpacity = useSharedValue(0);

  const iconStyle = useAnimatedStyle(() => ({
    transform: [{ scale: iconScale.value }],
    opacity: iconOpacity.value,
  }));
  const titleStyle = useAnimatedStyle(() => ({ opacity: titleOpacity.value }));
  const subtitleStyle = useAnimatedStyle(() => ({ opacity: subtitleOpacity.value }));
  const dotsStyle = useAnimatedStyle(() => ({ opacity: dotsOpacity.value }));

  function navigateNext() {
    if (!settings.onboardingCompleted) {
      navigation.replace(Routes.ONBOARDING);
    } else {
      navigation.replace(Routes.MAIN);
    }
  }

  useEffect(() => {
    iconScale.value = withSpring(1, { damping: 12, stiffness: 150 });
    iconOpacity.value = withTiming(1, { duration: 500 });
    titleOpacity.value = withDelay(400, withTiming(1, { duration: 400 }));
    subtitleOpacity.value = withDelay(700, withTiming(1, { duration: 400 }));
    dotsOpacity.value = withDelay(900, withTiming(1, { duration: 300 }));

    const timer = setTimeout(() => runOnJS(navigateNext)(), 2200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <LinearGradient colors={['#007AFF', '#0056CC']} style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />

      <View style={styles.content}>
        <Animated.View style={[styles.iconWrapper, iconStyle]}>
          <View style={styles.iconBackground}>
            <Icon name="file-swap" size={52} color="#007AFF" />
          </View>
        </Animated.View>

        <Animated.Text style={[styles.title, titleStyle]}>{APP_NAME}</Animated.Text>
        <Animated.Text style={[styles.subtitle, subtitleStyle]}>
          Convert Any File, Anywhere
        </Animated.Text>
      </View>

      <Animated.View style={[styles.footer, dotsStyle]}>
        <Text style={styles.footerText}>60+ Formats · Fast · Secure</Text>
      </Animated.View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    alignItems: 'center',
    gap: spacing.lg,
  },
  iconWrapper: {
    marginBottom: spacing.md,
  },
  iconBackground: {
    width: 100,
    height: 100,
    borderRadius: 28,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 8,
    shadowColor: 'rgba(0,0,0,0.3)',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
  },
  title: {
    fontSize: fontSize.display,
    fontWeight: fontWeight.bold,
    color: '#FFFFFF',
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: fontSize.md,
    color: 'rgba(255,255,255,0.8)',
    letterSpacing: 0.3,
  },
  footer: {
    position: 'absolute',
    bottom: 40,
  },
  footerText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: fontSize.sm,
    letterSpacing: 0.5,
  },
});
