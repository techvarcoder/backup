import { useColorScheme } from 'react-native';
import { useSettingsStore } from '../store/useSettingsStore';
import { AppLightTheme, AppDarkTheme, lightColors, darkColors } from '../theme';
import type { Colors } from '../theme/colors';

export function useTheme() {
  const systemScheme = useColorScheme();
  const { settings } = useSettingsStore();

  const isDark =
    settings.themeMode === 'dark'
      ? true
      : settings.themeMode === 'light'
      ? false
      : systemScheme === 'dark';

  const theme = isDark ? AppDarkTheme : AppLightTheme;
  const colors: Colors = isDark ? darkColors : lightColors;

  return { theme, colors, isDark };
}
