import { useState, useCallback, useMemo } from 'react';
import { CONVERTERS } from '../constants/converters';
import { ConverterDefinition } from '../types/converter';
import { debounce } from '../utils/helpers';

export function useSearch() {
  const [query, setQuery] = useState('');
  const [recentSearches, setRecentSearches] = useState<string[]>([]);

  const setQueryDebounced = useMemo(
    () => debounce((q: string) => setQuery(q), 200),
    [],
  );

  const results = useMemo<ConverterDefinition[]>(() => {
    if (!query.trim()) return [];
    const lower = query.toLowerCase();
    return CONVERTERS.filter(
      c =>
        c.name.toLowerCase().includes(lower) ||
        c.description.toLowerCase().includes(lower) ||
        c.inputFormat.toLowerCase().includes(lower) ||
        c.outputFormat.toLowerCase().includes(lower) ||
        c.inputFormats?.some(f => f.toLowerCase().includes(lower)) ||
        c.categoryId.toLowerCase().includes(lower),
    );
  }, [query]);

  const addRecentSearch = useCallback((term: string) => {
    if (!term.trim()) return;
    setRecentSearches(prev => {
      const filtered = prev.filter(s => s !== term);
      return [term, ...filtered].slice(0, 10);
    });
  }, []);

  const clearRecentSearches = useCallback(() => setRecentSearches([]), []);

  const clearQuery = useCallback(() => {
    setQuery('');
  }, []);

  return {
    query,
    setQuery: setQueryDebounced,
    setQueryImmediate: setQuery,
    results,
    recentSearches,
    addRecentSearch,
    clearRecentSearches,
    clearQuery,
    hasResults: results.length > 0,
  };
}
