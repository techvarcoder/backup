import { useCallback, useRef } from 'react';
import { useNavigation } from '@react-navigation/native';
import { FileItem } from '../types';
import { ConverterDefinition, ConversionOptions } from '../types/converter';
import { useConversionStore } from '../store/useConversionStore';
import { useHistoryStore } from '../store/useHistoryStore';
import { useAppStore } from '../store/useAppStore';
import conversionService, { ConversionError } from '../services/conversion/ConversionService';
import notificationService from '../services/notification/NotificationService';
import { useSettingsStore } from '../store/useSettingsStore';
import { Routes } from '../constants/routes';

export function useConversion() {
  const navigation = useNavigation<any>();
  const conversionStore = useConversionStore();
  const historyStore = useHistoryStore();
  const appStore = useAppStore();
  const { settings } = useSettingsStore();
  const jobIdRef = useRef<string | null>(null);

  const startConversion = useCallback(
    async (
      converter: ConverterDefinition,
      file: FileItem,
      options: ConversionOptions,
    ) => {
      const jobId = `job-${Date.now()}`;
      jobIdRef.current = jobId;
      conversionStore.startConversion(jobId);

      navigation.navigate(Routes.CONVERSION_PROGRESS, {
        jobId,
        converter,
        file,
      });

      try {
        // Pass jobId so ConversionService registers the abort controller under the
        // same key that cancelConversion() will look up.
        const result = await conversionService.convert(
          converter,
          file,
          options,
          progress => {
            conversionStore.updateProgress(progress);
            if (settings.showConversionNotifications) {
              notificationService
                .showProgress(jobId, `Converting ${file.name}`, progress.percentage)
                .catch(() => {});
            }
          },
          jobId,
        );

        historyStore.addConversion(result);
        conversionStore.completeConversion(result);

        if (settings.showConversionNotifications) {
          notificationService
            .showSuccess(jobId, result.outputFileName, result.outputFilePath ?? '')
            .catch(() => {});
        }

        navigation.replace(Routes.CONVERSION_SUCCESS, { conversion: result });
      } catch (err: unknown) {
        const message = err instanceof Error ? err.message : 'Conversion failed.';
        conversionStore.failConversion(message);

        if (err instanceof ConversionError) historyStore.addConversion(err.stored);
        if (settings.showConversionNotifications) {
          notificationService.showError(jobId, file.name, message).catch(() => {});
        }

        navigation.replace(Routes.CONVERSION_FAILED, {
          error: message,
          converter,
        });
      }
    },
    [conversionStore, historyStore, settings, navigation],
  );

  const cancelConversion = useCallback(() => {
    if (jobIdRef.current) {
      conversionService.cancelJob(jobIdRef.current);
      notificationService.cancelNotification(jobIdRef.current).catch(() => {});
    }
    conversionStore.cancelConversion();
  }, [conversionStore]);

  return { startConversion, cancelConversion };
}
