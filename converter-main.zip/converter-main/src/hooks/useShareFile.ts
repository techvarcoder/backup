import { useCallback } from 'react';
import Share from 'react-native-share';
import { useAppStore } from '../store/useAppStore';

export function useShareFile() {
  const showSnackbar = useAppStore(s => s.showSnackbar);

  const shareFile = useCallback(
    async (filePath: string, fileName: string, mimeType = 'application/octet-stream') => {
      try {
        await Share.open({
          url: `file://${filePath}`,
          filename: fileName,
          type: mimeType,
          failOnCancel: false,
        });
      } catch (error: any) {
        if (error?.message?.includes('cancelled')) return;
        showSnackbar({ message: 'Failed to share file.', type: 'error' });
      }
    },
    [showSnackbar],
  );

  const shareText = useCallback(
    async (text: string, title?: string) => {
      try {
        await Share.open({ message: text, title, failOnCancel: false });
      } catch {
        // User cancelled
      }
    },
    [],
  );

  return { shareFile, shareText };
}
