import { useCallback, useState } from 'react';
import DocumentPicker from 'react-native-document-picker';
import { launchImageLibrary } from 'react-native-image-picker';
import { FileItem } from '../types';
import { buildFileItem } from '../utils/fileUtils';
import { useAppStore } from '../store/useAppStore';
import permissionService from '../services/permission/PermissionService';
import { ConverterDefinition } from '../types/converter';

export function useFileSystem() {
  const [isPickerOpen, setPickerOpen] = useState(false);
  const showSnackbar = useAppStore(s => s.showSnackbar);

  const pickDocument = useCallback(
    async (converter?: ConverterDefinition): Promise<FileItem | null> => {
      if (isPickerOpen) return null;
      setPickerOpen(true);
      try {
        const mimeTypes = converter?.inputMimeTypes ?? ['*/*'];

        const [result] = await DocumentPicker.pick({
          type: mimeTypes,
          allowMultiSelection: false,
          copyTo: 'cachesDirectory',
        });

        if (!result) return null;

        const uri = result.fileCopyUri ?? result.uri;
        const name = result.name ?? 'unknown';
        const size = result.size ?? 0;
        const mimeType = result.type ?? undefined;

        return buildFileItem({ uri, name, size, mimeType: mimeType ?? undefined });
      } catch (error: any) {
        if (DocumentPicker.isCancel(error)) return null;
        showSnackbar({ message: 'Failed to pick file.', type: 'error' });
        return null;
      } finally {
        setPickerOpen(false);
      }
    },
    [isPickerOpen, showSnackbar],
  );

  const pickImage = useCallback(async (): Promise<FileItem | null> => {
    const granted = await permissionService.ensureStoragePermission();
    if (!granted) {
      showSnackbar({ message: 'Storage permission required.', type: 'error' });
      return null;
    }

    return new Promise(resolve => {
      launchImageLibrary(
        {
          mediaType: 'photo',
          quality: 1,
          selectionLimit: 1,
          includeBase64: false,
        },
        response => {
          if (response.didCancel || !response.assets?.length) {
            resolve(null);
            return;
          }
          const asset = response.assets[0];
          if (!asset.uri) { resolve(null); return; }

          const file = buildFileItem({
            uri: asset.uri,
            name: asset.fileName ?? `image_${Date.now()}.jpg`,
            size: asset.fileSize ?? 0,
            mimeType: asset.type ?? 'image/jpeg',
          });
          resolve(file);
        },
      );
    });
  }, [showSnackbar]);

  const pickMultipleImages = useCallback(async (): Promise<FileItem[]> => {
    const granted = await permissionService.ensureStoragePermission();
    if (!granted) {
      showSnackbar({ message: 'Storage permission required.', type: 'error' });
      return [];
    }

    return new Promise(resolve => {
      launchImageLibrary(
        { mediaType: 'photo', quality: 1, selectionLimit: 10 },
        response => {
          if (response.didCancel || !response.assets?.length) {
            resolve([]);
            return;
          }
          const files = response.assets
            .filter(a => !!a.uri)
            .map(a =>
              buildFileItem({
                uri: a.uri!,
                name: a.fileName ?? `image_${Date.now()}.jpg`,
                size: a.fileSize ?? 0,
                mimeType: a.type ?? 'image/jpeg',
              }),
            );
          resolve(files);
        },
      );
    });
  }, [showSnackbar]);

  return { pickDocument, pickImage, pickMultipleImages, isPickerOpen };
}
