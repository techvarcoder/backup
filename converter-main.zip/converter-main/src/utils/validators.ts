import { MAX_FILE_SIZE_BYTES, SUPPORTED_MIME_TYPES } from '../constants';
import { FileItem } from '../types';

export interface ValidationResult {
  valid: boolean;
  error?: string;
}

export function validateFileSize(sizeBytes: number): ValidationResult {
  if (sizeBytes <= 0) return { valid: false, error: 'File appears to be empty.' };
  if (sizeBytes > MAX_FILE_SIZE_BYTES) {
    return {
      valid: false,
      error: `File is too large. Maximum size is ${MAX_FILE_SIZE_BYTES / 1024 / 1024}MB.`,
    };
  }
  return { valid: true };
}

export function validateMimeType(mimeType: string): ValidationResult {
  if (!mimeType) return { valid: false, error: 'Could not detect file type.' };
  const isSupported = SUPPORTED_MIME_TYPES.some(m => mimeType.startsWith(m.split('/')[0]) || mimeType === m);
  if (!isSupported) {
    return { valid: false, error: `File type "${mimeType}" is not supported.` };
  }
  return { valid: true };
}

export function validateFile(file: FileItem): ValidationResult {
  const sizeCheck = validateFileSize(file.size);
  if (!sizeCheck.valid) return sizeCheck;
  if (!file.uri) return { valid: false, error: 'Invalid file URI.' };
  if (!file.name) return { valid: false, error: 'File has no name.' };
  return { valid: true };
}

export function validateOutputFileName(name: string): ValidationResult {
  if (!name || name.trim().length === 0) {
    return { valid: false, error: 'Output file name cannot be empty.' };
  }
  const invalidChars = /[<>:"/\\|?*\x00-\x1F]/;
  if (invalidChars.test(name)) {
    return { valid: false, error: 'File name contains invalid characters.' };
  }
  if (name.length > 255) {
    return { valid: false, error: 'File name is too long (max 255 characters).' };
  }
  return { valid: true };
}

export function validateApiKey(key: string): ValidationResult {
  if (!key || key.trim().length === 0) {
    return { valid: false, error: 'API key is required for this conversion.' };
  }
  return { valid: true };
}

export function sanitizeFileName(name: string): string {
  return name
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, '_')
    .replace(/\s+/g, '_')
    .replace(/_{2,}/g, '_')
    .replace(/^_+|_+$/, '')
    .slice(0, 200);
}
