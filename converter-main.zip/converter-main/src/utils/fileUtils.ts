import { Platform } from 'react-native';
import { FileItem, FileCategory, FileFormat } from '../types';
import { getFormatInfo, getFileCategory } from '../constants/formats';
import { getFileExtension, getFileNameWithoutExtension } from './formatters';

export function buildFileItem(params: {
  uri: string;
  name: string;
  size: number;
  mimeType?: string;
}): FileItem {
  const { uri, name, size, mimeType } = params;
  const extension = getFileExtension(name) as FileFormat;
  const formatInfo = getFormatInfo(extension);
  const category: FileCategory = formatInfo?.category ?? getFileCategory(extension);

  return {
    id: generateFileId(uri, name),
    name,
    displayName: name,
    extension,
    mimeType: mimeType ?? formatInfo?.mimeType ?? 'application/octet-stream',
    size,
    path: uriToPath(uri),
    uri,
    category,
    lastModified: Date.now(),
  };
}

export function generateFileId(uri: string, name: string): string {
  return `${name}-${uri.slice(-20)}-${Date.now()}`;
}

export function uriToPath(uri: string): string {
  if (Platform.OS === 'android') {
    if (uri.startsWith('file://')) return uri.replace('file://', '');
    return uri;
  }
  return uri;
}

export function pathToUri(path: string): string {
  if (path.startsWith('file://') || path.startsWith('content://')) return path;
  return `file://${path}`;
}

export function getDownloadsPath(): string {
  return Platform.OS === 'android'
    ? '/storage/emulated/0/Download'
    : '';
}

export function getDocumentsPath(): string {
  return Platform.OS === 'android'
    ? '/storage/emulated/0/Documents'
    : '';
}

export function getOutputPath(
  directory: string,
  outputFileName: string,
): string {
  const separator = directory.endsWith('/') ? '' : '/';
  return `${directory}${separator}${outputFileName}`;
}

export function isImageFile(extension: string): boolean {
  const imageFormats = ['jpg', 'jpeg', 'png', 'webp', 'heic', 'bmp', 'tiff', 'svg', 'gif', 'avif', 'ico'];
  return imageFormats.includes(extension.toLowerCase().replace('.', ''));
}

export function isDocumentFile(extension: string): boolean {
  const documentFormats = ['pdf', 'doc', 'docx', 'txt', 'rtf', 'html', 'odt', 'epub'];
  return documentFormats.includes(extension.toLowerCase().replace('.', ''));
}

export function isPreviewable(extension: string): boolean {
  return isImageFile(extension) || ['pdf', 'txt', 'html'].includes(extension.toLowerCase());
}

export function getOutputFileName(inputName: string, outputFormat: string): string {
  const base = getFileNameWithoutExtension(inputName);
  return `${base}_converted.${outputFormat}`;
}

export function getMimeTypeForFormat(format: string): string {
  return getFormatInfo(format)?.mimeType ?? 'application/octet-stream';
}
