import { format, formatDistanceToNow, isToday, isYesterday, isThisWeek } from 'date-fns';

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return '0 B';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

export function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  const seconds = Math.floor(ms / 1000);
  if (seconds < 60) return `${seconds}s`;
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  if (minutes < 60) return `${minutes}m ${remainingSeconds}s`;
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  return `${hours}h ${remainingMinutes}m`;
}

export function formatDate(timestamp: number): string {
  const date = new Date(timestamp);
  if (isToday(date)) return `Today ${format(date, 'h:mm a')}`;
  if (isYesterday(date)) return `Yesterday ${format(date, 'h:mm a')}`;
  if (isThisWeek(date)) return format(date, 'EEEE h:mm a');
  return format(date, 'MMM d, yyyy h:mm a');
}

export function formatDateShort(timestamp: number): string {
  return format(new Date(timestamp), 'MMM d');
}

export function formatRelativeTime(timestamp: number): string {
  return formatDistanceToNow(new Date(timestamp), { addSuffix: true });
}

export function getHistoryGroupLabel(timestamp: number): string {
  const date = new Date(timestamp);
  if (isToday(date)) return 'Today';
  if (isYesterday(date)) return 'Yesterday';
  if (isThisWeek(date)) return 'This Week';
  return 'Older';
}

export function formatPercentage(value: number): string {
  return `${Math.round(Math.min(100, Math.max(0, value)))}%`;
}

export function formatCompressionRatio(inputBytes: number, outputBytes: number): string {
  if (inputBytes === 0) return '0%';
  const ratio = ((inputBytes - outputBytes) / inputBytes) * 100;
  if (ratio > 0) return `-${ratio.toFixed(1)}%`;
  if (ratio < 0) return `+${Math.abs(ratio).toFixed(1)}%`;
  return '0%';
}

export function truncateFileName(name: string, maxLength = 32): string {
  if (name.length <= maxLength) return name;
  const ext = name.includes('.') ? `.${name.split('.').pop()}` : '';
  const base = name.slice(0, name.lastIndexOf('.')) || name;
  const truncated = base.slice(0, maxLength - ext.length - 3);
  return `${truncated}...${ext}`;
}

export function getFileExtension(fileName: string): string {
  const parts = fileName.split('.');
  if (parts.length < 2) return '';
  return parts[parts.length - 1].toLowerCase();
}

export function getFileNameWithoutExtension(fileName: string): string {
  const lastDot = fileName.lastIndexOf('.');
  if (lastDot === -1) return fileName;
  return fileName.slice(0, lastDot);
}

export function buildOutputFileName(
  inputFileName: string,
  outputFormat: string,
  suffix?: string,
): string {
  const base = getFileNameWithoutExtension(inputFileName);
  const suffixStr = suffix ? `_${suffix}` : '';
  return `${base}${suffixStr}.${outputFormat}`;
}

export function formatEstimatedTime(seconds: number): string {
  if (seconds <= 0) return 'Almost done...';
  if (seconds < 60) return `About ${seconds}s remaining`;
  const minutes = Math.ceil(seconds / 60);
  return `About ${minutes}min remaining`;
}
