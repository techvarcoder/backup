import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import storageService from '../services/storage/StorageService';
import { STORAGE_KEYS } from '../constants';
import { defaultSettings } from '../types/settings';

let _apiInstance: AxiosInstance | null = null;

function getApiInstance(): AxiosInstance {
  const settings = storageService.getObject(STORAGE_KEYS.SETTINGS, defaultSettings);
  const baseURL = settings.backendApiUrl || defaultSettings.backendApiUrl;

  if (_apiInstance) return _apiInstance;

  _apiInstance = axios.create({
    baseURL,
    timeout: 120_000,
    headers: {
      'Content-Type': 'multipart/form-data',
      Accept: 'application/json',
    },
  });

  _apiInstance.interceptors.request.use(config => {
    const fresh = storageService.getObject(STORAGE_KEYS.SETTINGS, defaultSettings);
    if (fresh.backendApiKey) {
      config.headers.Authorization = `Bearer ${fresh.backendApiKey}`;
    }
    return config;
  });

  _apiInstance.interceptors.response.use(
    response => response,
    error => {
      const message =
        error.response?.data?.message ||
        error.message ||
        'An unknown network error occurred.';
      return Promise.reject(new Error(message));
    },
  );

  return _apiInstance;
}

export function invalidateApiInstance(): void {
  _apiInstance = null;
}

export async function postFormData<T>(
  endpoint: string,
  formData: FormData,
  onUploadProgress?: (progress: number) => void,
): Promise<T> {
  const instance = getApiInstance();
  const config: AxiosRequestConfig = {
    onUploadProgress: event => {
      if (event.total && onUploadProgress) {
        onUploadProgress(event.loaded / event.total);
      }
    },
  };
  const response = await instance.post<T>(endpoint, formData, config);
  return response.data;
}

export async function getRequest<T>(endpoint: string): Promise<T> {
  const instance = getApiInstance();
  const response = await instance.get<T>(endpoint);
  return response.data;
}

export default getApiInstance;
