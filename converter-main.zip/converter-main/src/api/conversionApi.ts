import RNFS from 'react-native-fs';
import { postFormData } from './client';
import { FileItem } from '../types';
import { ConversionOptions } from '../types/converter';

export interface BackendConversionResponse {
  url?: string;
  filePath?: string;
  fileSize?: number;
  outputFormat?: string;
  success: boolean;
  error?: string;
  jobId?: string;
}

class ConversionApi {
  private static instance: ConversionApi;

  static getInstance(): ConversionApi {
    if (!ConversionApi.instance) {
      ConversionApi.instance = new ConversionApi();
    }
    return ConversionApi.instance;
  }

  async convert(
    inputFile: FileItem,
    outputFormat: string,
    _options: ConversionOptions,
    onProgress?: (p: number) => void,
  ): Promise<{ downloadUrl: string; fileSize?: number }> {
    const formData = new FormData();

    formData.append('file', {
      uri: inputFile.uri,
      name: inputFile.name,
      type: inputFile.mimeType,
    } as any);
    formData.append('outputFormat', outputFormat);
    formData.append('quality', _options.quality ?? 'high');

    onProgress?.(0.1);

    const response = await postFormData<BackendConversionResponse>(
      `/${inputFile.extension}/${outputFormat}`,
      formData,
      p => onProgress?.(0.1 + p * 0.6),
    );

    if (!response.success || !response.url) {
      throw new Error(response.error ?? 'Conversion failed on server.');
    }

    return { downloadUrl: response.url, fileSize: response.fileSize };
  }

  async downloadResult(
    downloadUrl: string,
    outputPath: string,
    onProgress?: (p: number) => void,
  ): Promise<number> {
    return new Promise((resolve, reject) => {
      RNFS.downloadFile({
        fromUrl: downloadUrl,
        toFile: outputPath,
        progress: res => {
          if (res.contentLength > 0) {
            onProgress?.(res.bytesWritten / res.contentLength);
          }
        },
      }).promise.then(async result => {
        if (result.statusCode >= 200 && result.statusCode < 300) {
          const stat = await RNFS.stat(outputPath);
          resolve(Number(stat.size));
        } else {
          reject(new Error(`Download failed: HTTP ${result.statusCode}`));
        }
      }).catch(reject);
    });
  }
}

export const conversionApi = ConversionApi.getInstance();
export default conversionApi;
