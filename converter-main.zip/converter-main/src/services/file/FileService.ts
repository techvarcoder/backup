import RNFS from 'react-native-fs';
import { buildFileItem, getOutputPath, getDownloadsPath } from '../../utils/fileUtils';
import { FileItem } from '../../types';
import permissionService from '../permission/PermissionService';

class FileService {
  private static instance: FileService;

  static getInstance(): FileService {
    if (!FileService.instance) {
      FileService.instance = new FileService();
    }
    return FileService.instance;
  }

  async readTextFile(path: string): Promise<string> {
    return RNFS.readFile(path, 'utf8');
  }

  async writeFile(path: string, content: string, encoding: 'utf8' | 'base64' = 'utf8'): Promise<void> {
    await RNFS.writeFile(path, content, encoding);
  }

  async copyFile(sourcePath: string, destPath: string): Promise<void> {
    await RNFS.copyFile(sourcePath, destPath);
  }

  async moveFile(sourcePath: string, destPath: string): Promise<void> {
    await RNFS.moveFile(sourcePath, destPath);
  }

  async deleteFile(path: string): Promise<void> {
    const exists = await RNFS.exists(path);
    if (exists) await RNFS.unlink(path);
  }

  async fileExists(path: string): Promise<boolean> {
    return RNFS.exists(path);
  }

  async getFileSize(path: string): Promise<number> {
    const stat = await RNFS.stat(path);
    return Number(stat.size);
  }

  async ensureDirectory(dir: string): Promise<void> {
    const exists = await RNFS.exists(dir);
    if (!exists) await RNFS.mkdir(dir);
  }

  async saveToDownloads(sourcePath: string, fileName: string): Promise<string> {
    const hasPermission = await permissionService.ensureStoragePermission();
    if (!hasPermission) throw new Error('Storage permission denied.');

    const downloadsDir = getDownloadsPath();
    await this.ensureDirectory(downloadsDir);

    const destPath = getOutputPath(downloadsDir, fileName);
    const exists = await this.fileExists(destPath);

    if (exists) {
      const ts = Date.now();
      const ext = fileName.includes('.') ? `.${fileName.split('.').pop()}` : '';
      const base = fileName.slice(0, fileName.lastIndexOf('.'));
      const newFileName = `${base}_${ts}${ext}`;
      const newDestPath = getOutputPath(downloadsDir, newFileName);
      await this.copyFile(sourcePath, newDestPath);
      return newDestPath;
    }

    await this.copyFile(sourcePath, destPath);
    return destPath;
  }

  async getTempDirectory(): Promise<string> {
    const tmpDir = `${RNFS.CachesDirectoryPath}/fileconverter_tmp`;
    await this.ensureDirectory(tmpDir);
    return tmpDir;
  }

  async getOutputDirectory(): Promise<string> {
    const outDir = `${RNFS.CachesDirectoryPath}/fileconverter_out`;
    await this.ensureDirectory(outDir);
    return outDir;
  }

  async cleanTempFiles(): Promise<void> {
    try {
      const tmpDir = `${RNFS.CachesDirectoryPath}/fileconverter_tmp`;
      const exists = await RNFS.exists(tmpDir);
      if (exists) {
        await RNFS.unlink(tmpDir);
      }
    } catch {
      // Best effort cleanup
    }
  }

  async readFileAsBase64(path: string): Promise<string> {
    return RNFS.readFile(path, 'base64');
  }

  async writeBase64ToFile(base64: string, destPath: string): Promise<void> {
    await RNFS.writeFile(destPath, base64, 'base64');
  }

  async buildFileItemFromPath(path: string, fileName?: string): Promise<FileItem> {
    const stat = await RNFS.stat(path);
    const name = fileName ?? path.split('/').pop() ?? 'unknown';
    const uri = `file://${path}`;
    return buildFileItem({
      uri,
      name,
      size: Number(stat.size),
    });
  }

  async downloadFile(
    url: string,
    destPath: string,
    onProgress?: (progress: number) => void,
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      RNFS.downloadFile({
        fromUrl: url,
        toFile: destPath,
        progress: res => {
          const progress = res.bytesWritten / res.contentLength;
          onProgress?.(progress);
        },
      }).promise.then(result => {
        if (result.statusCode >= 200 && result.statusCode < 300) {
          resolve();
        } else {
          reject(new Error(`Download failed with status: ${result.statusCode}`));
        }
      }).catch(reject);
    });
  }
}

export const fileService = FileService.getInstance();
export default fileService;
