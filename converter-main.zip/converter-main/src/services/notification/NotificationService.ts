import notifee, { AndroidImportance, AndroidStyle } from '@notifee/react-native';

class NotificationService {
  private static instance: NotificationService;
  private channelId = 'fileconverter-conversions';
  private channelCreated = false;

  static getInstance(): NotificationService {
    if (!NotificationService.instance) {
      NotificationService.instance = new NotificationService();
    }
    return NotificationService.instance;
  }

  async initialize(): Promise<void> {
    try {
      await this.createChannel();
    } catch {
      // Non-critical — app works without notifications
    }
  }

  private async createChannel(): Promise<void> {
    if (this.channelCreated) return;
    await notifee.createChannel({
      id: this.channelId,
      name: 'File Conversions',
      lights: false,
      vibration: true,
      importance: AndroidImportance.HIGH,
    });
    this.channelCreated = true;
  }

  async showProgress(
    id: string,
    title: string,
    progress: number,
  ): Promise<void> {
    try {
      await notifee.displayNotification({
        id,
        title,
        body: `Converting... ${Math.round(progress)}%`,
        android: {
          channelId: this.channelId,
          progress: {
            max: 100,
            current: Math.round(progress),
            indeterminate: progress <= 0,
          },
          ongoing: true,
          onlyAlertOnce: true,
          smallIcon: 'ic_notification',
          importance: AndroidImportance.LOW,
        },
      });
    } catch {
      // Silently ignore notification errors
    }
  }

  async showSuccess(
    id: string,
    fileName: string,
    outputPath: string,
  ): Promise<void> {
    try {
      await notifee.displayNotification({
        id,
        title: 'Conversion Complete',
        body: `${fileName} has been converted successfully.`,
        android: {
          channelId: this.channelId,
          smallIcon: 'ic_notification',
          importance: AndroidImportance.HIGH,
          style: {
            type: AndroidStyle.BIGTEXT,
            text: `${fileName} converted successfully.\nTap to view the file.`,
          },
          pressAction: {
            id: 'open-file',
            launchActivity: 'default',
          },
        },
        data: { outputPath, action: 'open' },
      });
    } catch {
      // Silently ignore
    }
  }

  async showError(id: string, fileName: string, error: string): Promise<void> {
    try {
      await notifee.displayNotification({
        id,
        title: 'Conversion Failed',
        body: `Failed to convert ${fileName}: ${error}`,
        android: {
          channelId: this.channelId,
          smallIcon: 'ic_notification',
          importance: AndroidImportance.DEFAULT,
        },
      });
    } catch {
      // Silently ignore
    }
  }

  async cancelNotification(id: string): Promise<void> {
    try {
      await notifee.cancelNotification(id);
    } catch {
      // Silently ignore
    }
  }

  async requestPermission(): Promise<boolean> {
    try {
      const settings = await notifee.requestPermission();
      return settings.authorizationStatus >= 1;
    } catch {
      return false;
    }
  }
}

export const notificationService = NotificationService.getInstance();
export default notificationService;
