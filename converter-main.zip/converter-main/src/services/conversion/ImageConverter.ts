import ImageManipulator, { SaveFormat } from 'react-native-image-manipulator';
import RNHTMLtoPDF from 'react-native-html-to-pdf';
import RNFS from 'react-native-fs';
import { FileItem } from '../../types';
import { ConversionOptions } from '../../types/converter';
import { buildFileItem } from '../../utils/fileUtils';

export interface ImageConversionResult {
  outputPath: string;
  outputSize: number;
}

class ImageConverter {
  private static instance: ImageConverter;

  static getInstance(): ImageConverter {
    if (!ImageConverter.instance) {
      ImageConverter.instance = new ImageConverter();
    }
    return ImageConverter.instance;
  }

  private qualityToNumber(quality: ConversionOptions['quality'] = 'high'): number {
    switch (quality) {
      case 'low': return 0.4;
      case 'medium': return 0.7;
      case 'high': return 0.95;
      default: return 0.9;
    }
  }

  private formatToSaveFormat(format: string): SaveFormat {
    switch (format.toLowerCase()) {
      case 'jpg':
      case 'jpeg': return SaveFormat.JPEG;
      case 'png': return SaveFormat.PNG;
      case 'webp': return SaveFormat.WEBP;
      default: return SaveFormat.JPEG;
    }
  }

  async convertImage(
    inputFile: FileItem,
    outputFormat: string,
    options: ConversionOptions,
    onProgress?: (p: number) => void,
  ): Promise<ImageConversionResult> {
    onProgress?.(0.1);

    const saveFormat = this.formatToSaveFormat(outputFormat);
    const quality = this.qualityToNumber(options.quality);

    const actions: any[] = [];

    if (options.resizeWidth || options.resizeHeight) {
      actions.push({
        resize: {
          width: options.resizeWidth,
          height: options.resizeHeight,
        },
      });
    }

    onProgress?.(0.3);

    const result = await ImageManipulator.manipulate(
      inputFile.uri,
      actions,
      {
        compress: quality,
        format: saveFormat,
        base64: false,
      },
    ).renderAsync();
    const savedResult = await result.saveAsync({
      compress: quality,
      format: saveFormat,
    });

    onProgress?.(0.9);

    const outputSize = await RNFS.stat(savedResult.uri.replace('file://', '')).then(
      s => Number(s.size),
    ).catch(() => 0);

    onProgress?.(1.0);

    return {
      outputPath: savedResult.uri.replace('file://', ''),
      outputSize,
    };
  }

  async convertImagesToPDF(
    inputFiles: FileItem[],
    outputPath: string,
    options: ConversionOptions,
    onProgress?: (p: number) => void,
  ): Promise<ImageConversionResult> {
    const total = inputFiles.length;
    const imagesHtml = await Promise.all(
      inputFiles.map(async (file, idx) => {
        onProgress?.((idx / total) * 0.7);
        const base64 = await RNFS.readFile(
          file.uri.replace('file://', ''),
          'base64',
        );
        const ext = file.extension === 'png' ? 'png' : 'jpeg';
        return `
          <div style="page-break-after: always; width:100%; text-align:center; margin:0; padding:0;">
            <img src="data:image/${ext};base64,${base64}"
                 style="max-width:100%; max-height:100vh; object-fit:contain;" />
          </div>`;
      }),
    );

    onProgress?.(0.8);

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="UTF-8" />
          <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { background: white; }
            @page { margin: 0; }
          </style>
        </head>
        <body>${imagesHtml.join('')}</body>
      </html>`;

    const pdfResult = await RNHTMLtoPDF.convert({
      html,
      fileName: outputPath.split('/').pop()?.replace('.pdf', '') ?? 'output',
      directory: outputPath.substring(0, outputPath.lastIndexOf('/')),
      width: 595,
      height: 842,
      paddingTop: 0,
      paddingLeft: 0,
      paddingRight: 0,
      paddingBottom: 0,
    });

    if (!pdfResult.filePath) throw new Error('PDF generation failed.');

    onProgress?.(1.0);

    const outputSize = await RNFS.stat(pdfResult.filePath).then(s => Number(s.size)).catch(() => 0);

    if (pdfResult.filePath !== outputPath) {
      await RNFS.copyFile(pdfResult.filePath, outputPath);
      await RNFS.unlink(pdfResult.filePath).catch(() => {});
    }

    return { outputPath, outputSize };
  }

  async convertTextToPDF(
    textContent: string,
    outputPath: string,
    onProgress?: (p: number) => void,
  ): Promise<ImageConversionResult> {
    onProgress?.(0.2);

    const escaped = textContent
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\n/g, '<br/>');

    const html = `
      <!DOCTYPE html><html>
      <head><meta charset="UTF-8"/>
      <style>body{font-family:Arial,sans-serif;font-size:12pt;line-height:1.6;
        padding:40px;color:#222;white-space:pre-wrap;word-wrap:break-word;}
      </style></head>
      <body>${escaped}</body></html>`;

    onProgress?.(0.5);

    const result = await RNHTMLtoPDF.convert({
      html,
      fileName: 'output',
      directory: outputPath.substring(0, outputPath.lastIndexOf('/')),
      width: 595,
      height: 842,
    });

    onProgress?.(0.9);

    if (!result.filePath) throw new Error('PDF generation failed.');

    if (result.filePath !== outputPath) {
      await RNFS.copyFile(result.filePath, outputPath);
      await RNFS.unlink(result.filePath).catch(() => {});
    }

    const outputSize = await RNFS.stat(outputPath).then(s => Number(s.size)).catch(() => 0);
    onProgress?.(1.0);
    return { outputPath, outputSize };
  }

  async convertHTMLToPDF(
    htmlContent: string,
    outputPath: string,
    onProgress?: (p: number) => void,
  ): Promise<ImageConversionResult> {
    onProgress?.(0.3);
    const result = await RNHTMLtoPDF.convert({
      html: htmlContent,
      fileName: 'output',
      directory: outputPath.substring(0, outputPath.lastIndexOf('/')),
      width: 595,
      height: 842,
    });

    if (!result.filePath) throw new Error('PDF generation failed.');

    if (result.filePath !== outputPath) {
      await RNFS.copyFile(result.filePath, outputPath);
      await RNFS.unlink(result.filePath).catch(() => {});
    }

    const outputSize = await RNFS.stat(outputPath).then(s => Number(s.size)).catch(() => 0);
    onProgress?.(1.0);
    return { outputPath, outputSize };
  }

  async convertCSVToPDF(
    csvContent: string,
    outputPath: string,
    onProgress?: (p: number) => void,
  ): Promise<ImageConversionResult> {
    onProgress?.(0.2);
    const rows = csvContent.split('\n').map(r => r.split(','));
    const tableRows = rows
      .map((cols, i) => {
        const tag = i === 0 ? 'th' : 'td';
        const cells = cols.map(c => `<${tag}>${c.replace(/"/g, '')}</${tag}>`).join('');
        return `<tr>${cells}</tr>`;
      })
      .join('');

    const html = `
      <!DOCTYPE html><html><head><meta charset="UTF-8"/>
      <style>
        table{width:100%;border-collapse:collapse;font-family:Arial,sans-serif;font-size:10pt;}
        th{background:#007AFF;color:white;padding:8px;border:1px solid #ccc;text-align:left;}
        td{padding:6px 8px;border:1px solid #ddd;}
        tr:nth-child(even){background:#f8f9fa;}
      </style></head>
      <body style="padding:20px;"><table>${tableRows}</table></body></html>`;

    return this.convertHTMLToPDF(html, outputPath, p => onProgress?.(0.2 + p * 0.8));
  }
}

export const imageConverter = ImageConverter.getInstance();
export default imageConverter;
