import RNFS from 'react-native-fs';
import mammoth from 'mammoth';
import { FileItem } from '../../types';
import { ConversionOptions } from '../../types/converter';
import imageConverter, { ImageConversionResult } from './ImageConverter';

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
}

class DocumentConverter {
  private static instance: DocumentConverter;

  static getInstance(): DocumentConverter {
    if (!DocumentConverter.instance) {
      DocumentConverter.instance = new DocumentConverter();
    }
    return DocumentConverter.instance;
  }

  async convertDocxToPDF(
    inputFile: FileItem,
    outputPath: string,
    options: ConversionOptions,
    onProgress?: (p: number, msg: string) => void,
  ): Promise<ImageConversionResult> {
    onProgress?.(0.1, 'Reading document...');

    const base64 = await RNFS.readFile(
      inputFile.uri.replace('file://', ''),
      'base64',
    );

    const arrayBuffer = base64ToArrayBuffer(base64);

    onProgress?.(0.3, 'Converting DOCX to HTML...');

    const result = await mammoth.convertToHtml({ arrayBuffer });

    onProgress?.(0.6, 'Generating PDF...');

    const html = `<!DOCTYPE html><html>
<head><meta charset="UTF-8"/>
<style>
  body{font-family:Arial,sans-serif;font-size:11pt;line-height:1.6;
    padding:40px 50px;color:#111;max-width:720px;margin:0 auto;}
  h1,h2,h3,h4{color:#1a1a1a;margin-top:20px;}
  p{margin:0 0 10px;}
  table{border-collapse:collapse;width:100%;margin:10px 0;}
  td,th{border:1px solid #ccc;padding:6px 10px;}
  img{max-width:100%;}
  ul,ol{margin:8px 0;padding-left:24px;}
</style></head>
<body>${result.value}</body></html>`;

    return imageConverter.convertHTMLToPDF(
      html,
      outputPath,
      p => onProgress?.(0.6 + p * 0.4, 'Creating PDF...'),
    );
  }

  async convertRTFToPDF(
    inputFile: FileItem,
    outputPath: string,
    onProgress?: (p: number, msg: string) => void,
  ): Promise<ImageConversionResult> {
    onProgress?.(0.1, 'Reading RTF file...');
    const rtf = await RNFS.readFile(inputFile.uri.replace('file://', ''), 'utf8');

    onProgress?.(0.3, 'Converting RTF to text...');
    // Strip RTF control words to extract readable plain text
    const plainText = rtf
      .replace(/\{[^{}]*\}/g, '')
      .replace(/\\[a-z]+\d* ?/g, ' ')
      .replace(/[{}\\]/g, '')
      .replace(/\s{2,}/g, '\n')
      .trim();

    onProgress?.(0.5, 'Generating PDF...');
    const escaped = plainText
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    const html = `<!DOCTYPE html><html>
<head><meta charset="UTF-8"/>
<style>body{font-family:Arial,sans-serif;font-size:11pt;line-height:1.6;
  padding:40px;color:#222;white-space:pre-wrap;word-wrap:break-word;}</style>
</head><body>${escaped}</body></html>`;

    return imageConverter.convertHTMLToPDF(
      html,
      outputPath,
      p => onProgress?.(0.5 + p * 0.5, 'Creating PDF...'),
    );
  }
}

export const documentConverter = DocumentConverter.getInstance();
export default documentConverter;
