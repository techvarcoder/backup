import RNFS from 'react-native-fs';
import * as XLSX from 'xlsx';
import { FileItem } from '../../types';
import { ConversionOptions } from '../../types/converter';
import imageConverter, { ImageConversionResult } from './ImageConverter';

class SpreadsheetConverter {
  private static instance: SpreadsheetConverter;

  static getInstance(): SpreadsheetConverter {
    if (!SpreadsheetConverter.instance) {
      SpreadsheetConverter.instance = new SpreadsheetConverter();
    }
    return SpreadsheetConverter.instance;
  }

  private async readWorkbook(inputFile: FileItem): Promise<XLSX.WorkBook> {
    const base64 = await RNFS.readFile(
      inputFile.uri.replace('file://', ''),
      'base64',
    );
    return XLSX.read(base64, { type: 'base64' });
  }

  async convertExcelToCSV(
    inputFile: FileItem,
    outputPath: string,
    onProgress?: (p: number, msg: string) => void,
  ): Promise<ImageConversionResult> {
    onProgress?.(0.1, 'Reading spreadsheet...');
    const wb = await this.readWorkbook(inputFile);
    onProgress?.(0.4, 'Converting to CSV...');

    const sheetName = wb.SheetNames[0];
    const ws = wb.Sheets[sheetName];
    const csv = XLSX.utils.sheet_to_csv(ws);

    onProgress?.(0.8, 'Saving file...');
    await RNFS.writeFile(outputPath, csv, 'utf8');
    const stat = await RNFS.stat(outputPath);
    onProgress?.(1.0, 'Done.');
    return { outputPath, outputSize: Number(stat.size) };
  }

  async convertCSVToExcel(
    inputFile: FileItem,
    outputPath: string,
    onProgress?: (p: number, msg: string) => void,
  ): Promise<ImageConversionResult> {
    onProgress?.(0.1, 'Reading CSV...');
    const csv = await RNFS.readFile(inputFile.uri.replace('file://', ''), 'utf8');
    onProgress?.(0.4, 'Converting to Excel...');

    const ws = XLSX.utils.aoa_to_sheet(
      csv.split('\n').map(row => row.split(',')),
    );
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    onProgress?.(0.7, 'Writing Excel file...');
    const xlsxData = XLSX.write(wb, { type: 'base64', bookType: 'xlsx' });
    await RNFS.writeFile(outputPath, xlsxData, 'base64');
    const stat = await RNFS.stat(outputPath);
    onProgress?.(1.0, 'Done.');
    return { outputPath, outputSize: Number(stat.size) };
  }

  async convertExcelToPDF(
    inputFile: FileItem,
    outputPath: string,
    options: ConversionOptions,
    onProgress?: (p: number, msg: string) => void,
  ): Promise<ImageConversionResult> {
    onProgress?.(0.1, 'Reading spreadsheet...');
    const wb = await this.readWorkbook(inputFile);
    onProgress?.(0.3, 'Generating HTML table...');

    const sheetName = wb.SheetNames[0];
    const ws = wb.Sheets[sheetName];
    const html = XLSX.utils.sheet_to_html(ws);

    const styledHtml = `<!DOCTYPE html><html>
<head><meta charset="UTF-8"/>
<style>
  body{font-family:Arial,sans-serif;font-size:9pt;padding:16px;}
  table{border-collapse:collapse;width:100%;font-size:9pt;}
  th{background:#1a73e8;color:#fff;padding:6px 8px;border:1px solid #aaa;text-align:left;}
  td{padding:5px 8px;border:1px solid #ccc;}
  tr:nth-child(even) td{background:#f5f5f5;}
</style></head>
<body>${html}</body></html>`;

    onProgress?.(0.6, 'Converting to PDF...');
    return imageConverter.convertHTMLToPDF(
      styledHtml,
      outputPath,
      p => onProgress?.(0.6 + p * 0.4, 'Creating PDF...'),
    );
  }
}

export const spreadsheetConverter = SpreadsheetConverter.getInstance();
export default spreadsheetConverter;
