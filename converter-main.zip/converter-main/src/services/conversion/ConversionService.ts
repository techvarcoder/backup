import RNFS from 'react-native-fs';
import { FileItem, ConversionStatus, StoredConversion } from '../../types';
import { ConversionOptions, ConversionProgress } from '../../types/converter';
import { ConverterDefinition } from '../../types/converter';
import { generateId, buildOutputFileName } from '../../utils';
import { buildFileItem } from '../../utils/fileUtils';
import imageConverter from './ImageConverter';
import spreadsheetConverter from './SpreadsheetConverter';
import documentConverter from './DocumentConverter';
import conversionApi from '../../api/conversionApi';
import fileService from '../file/FileService';

async function isNetworkAvailable(): Promise<boolean> {
  try {
    await fetch('https://connectivitycheck.gstatic.com/generate_204', {
      method: 'HEAD',
      cache: 'no-cache',
    });
    return true;
  } catch {
    return false;
  }
}

export class ConversionError extends Error {
  constructor(message: string, public readonly stored: StoredConversion) {
    super(message);
    this.name = 'ConversionError';
  }
}

export type ProgressCallback = (progress: ConversionProgress) => void;

const LOCAL_CONVERSIONS = new Set([
  'jpg-to-png', 'png-to-jpg', 'image-to-pdf', 'jpg-to-webp',
  'png-to-webp', 'webp-to-jpg', 'txt-to-pdf', 'html-to-pdf',
  'csv-to-pdf', 'scan-to-pdf',
  'word-to-pdf', 'rtf-to-pdf',
  'excel-to-csv', 'csv-to-excel', 'excel-to-pdf',
]);

class ConversionService {
  private static instance: ConversionService;
  private activeJobs = new Map<string, AbortController>();

  static getInstance(): ConversionService {
    if (!ConversionService.instance) {
      ConversionService.instance = new ConversionService();
    }
    return ConversionService.instance;
  }

  isOfflineCapable(converter: ConverterDefinition): boolean {
    return converter.engine === 'local' || LOCAL_CONVERSIONS.has(converter.id);
  }

  cancelJob(jobId: string): void {
    this.activeJobs.get(jobId)?.abort();
    this.activeJobs.delete(jobId);
  }

  async convert(
    converter: ConverterDefinition,
    inputFile: FileItem,
    options: ConversionOptions,
    onProgress: ProgressCallback,
    externalJobId?: string,
  ): Promise<StoredConversion> {
    const jobId = externalJobId ?? generateId();
    const abortController = new AbortController();
    this.activeJobs.set(jobId, abortController);

    const emit = (stage: ConversionProgress['stage'], percentage: number, message: string) => {
      if (abortController.signal.aborted) throw new Error('Conversion cancelled.');
      onProgress({ jobId, stage, percentage, message });
    };

    try {
      emit('preparing', 0, 'Preparing conversion...');

      const outputFormat = options.outputFormat;
      const outputFileName = options.outputFileName
        ?? buildOutputFileName(inputFile.name, outputFormat);
      const outDir = await fileService.getOutputDirectory();
      const outputPath = `${outDir}/${outputFileName}`;

      const startedAt = Date.now();
      let outputSize = 0;

      if (this.isOfflineCapable(converter)) {
        outputSize = await this.runLocalConversion(
          converter, inputFile, outputPath, options,
          (p, msg) => emit('processing', Math.round(p * 100), msg),
        );
      } else {
        const online = await isNetworkAvailable();
        if (!online) {
          throw new Error(
            'This conversion requires an internet connection. Please check your network and try again.',
          );
        }
        outputSize = await this.runBackendConversion(
          converter, inputFile, outputPath, options,
          emit, abortController.signal,
        );
      }

      const completedAt = Date.now();
      const outputFile = await fileService.buildFileItemFromPath(outputPath, outputFileName);

      emit('done', 100, 'Conversion complete!');

      const stored: StoredConversion = {
        id: jobId,
        converterId: converter.id,
        converterName: converter.name,
        inputFileName: inputFile.name,
        inputFileSize: inputFile.size,
        inputFormat: inputFile.extension,
        outputFileName,
        outputFileSize: outputSize,
        outputFilePath: outputPath,
        outputFormat,
        status: 'completed',
        createdAt: startedAt,
        completedAt,
        conversionTimeMs: completedAt - startedAt,
        isFavorite: false,
      };

      this.activeJobs.delete(jobId);
      return stored;
    } catch (error) {
      this.activeJobs.delete(jobId);
      const message = error instanceof Error ? error.message : 'Unknown error';
      const isCancelled = message.includes('cancelled') || abortController.signal.aborted;

      const stored: StoredConversion = {
        id: jobId,
        converterId: converter.id,
        converterName: converter.name,
        inputFileName: inputFile.name,
        inputFileSize: inputFile.size,
        inputFormat: inputFile.extension,
        outputFileName: options.outputFileName ?? '',
        outputFormat: options.outputFormat,
        status: isCancelled ? 'cancelled' : 'failed',
        error: message,
        createdAt: Date.now(),
        isFavorite: false,
      };

      throw new ConversionError(message, stored);
    }
  }

  private async runLocalConversion(
    converter: ConverterDefinition,
    inputFile: FileItem,
    outputPath: string,
    options: ConversionOptions,
    onProgress: (p: number, msg: string) => void,
  ): Promise<number> {
    const { outputFormat } = options;
    const id = converter.id;

    const imageFormats = ['jpg', 'jpeg', 'png', 'webp'];
    const isImageToImage =
      imageFormats.includes(inputFile.extension) &&
      imageFormats.includes(outputFormat);

    if (isImageToImage) {
      onProgress(0.1, 'Converting image...');
      const result = await imageConverter.convertImage(
        inputFile,
        outputFormat,
        options,
        p => onProgress(p, 'Converting image...'),
      );
      if (result.outputPath !== outputPath) {
        await RNFS.copyFile(result.outputPath, outputPath);
        await RNFS.unlink(result.outputPath).catch(() => {});
      }
      return result.outputSize;
    }

    if (id === 'scan-to-pdf') {
      const pages = options.scanPages && options.scanPages.length > 0
        ? options.scanPages
        : [inputFile];
      onProgress(0.1, `Creating PDF from ${pages.length} page${pages.length !== 1 ? 's' : ''}...`);
      const result = await imageConverter.convertImagesToPDF(
        pages, outputPath, options,
        p => onProgress(p, 'Creating PDF...'),
      );
      return result.outputSize;
    }

    if (id === 'image-to-pdf' || (imageFormats.includes(inputFile.extension) && outputFormat === 'pdf')) {
      onProgress(0.1, 'Creating PDF from image...');
      const result = await imageConverter.convertImagesToPDF(
        [inputFile], outputPath, options,
        p => onProgress(p, 'Creating PDF...'),
      );
      return result.outputSize;
    }

    if (id === 'txt-to-pdf') {
      onProgress(0.2, 'Reading text file...');
      const text = await fileService.readTextFile(inputFile.uri.replace('file://', ''));
      const result = await imageConverter.convertTextToPDF(
        text, outputPath,
        p => onProgress(p, 'Creating PDF...'),
      );
      return result.outputSize;
    }

    if (id === 'html-to-pdf') {
      onProgress(0.2, 'Reading HTML file...');
      const html = await fileService.readTextFile(inputFile.uri.replace('file://', ''));
      const result = await imageConverter.convertHTMLToPDF(
        html, outputPath,
        p => onProgress(p, 'Rendering PDF...'),
      );
      return result.outputSize;
    }

    if (id === 'csv-to-pdf') {
      onProgress(0.2, 'Reading CSV file...');
      const csv = await fileService.readTextFile(inputFile.uri.replace('file://', ''));
      const result = await imageConverter.convertCSVToPDF(
        csv, outputPath,
        p => onProgress(p, 'Creating PDF...'),
      );
      return result.outputSize;
    }

    if (id === 'word-to-pdf') {
      const result = await documentConverter.convertDocxToPDF(
        inputFile, outputPath, options,
        (p, msg) => onProgress(p, msg),
      );
      return result.outputSize;
    }

    if (id === 'rtf-to-pdf') {
      const result = await documentConverter.convertRTFToPDF(
        inputFile, outputPath,
        (p, msg) => onProgress(p, msg),
      );
      return result.outputSize;
    }

    if (id === 'excel-to-csv') {
      const result = await spreadsheetConverter.convertExcelToCSV(
        inputFile, outputPath,
        (p, msg) => onProgress(p, msg),
      );
      return result.outputSize;
    }

    if (id === 'csv-to-excel') {
      const result = await spreadsheetConverter.convertCSVToExcel(
        inputFile, outputPath,
        (p, msg) => onProgress(p, msg),
      );
      return result.outputSize;
    }

    if (id === 'excel-to-pdf') {
      const result = await spreadsheetConverter.convertExcelToPDF(
        inputFile, outputPath, options,
        (p, msg) => onProgress(p, msg),
      );
      return result.outputSize;
    }

    throw new Error(`Local conversion not implemented for ${converter.id}`);
  }

  private async runBackendConversion(
    converter: ConverterDefinition,
    inputFile: FileItem,
    outputPath: string,
    options: ConversionOptions,
    emit: (stage: ConversionProgress['stage'], pct: number, msg: string) => void,
    _signal: AbortSignal,
  ): Promise<number> {
    emit('uploading', 5, 'Uploading file...');

    const { downloadUrl, fileSize } = await conversionApi.convert(
      inputFile,
      options.outputFormat,
      options,
      p => emit('uploading', 5 + Math.round(p * 50), 'Uploading...'),
    );

    emit('downloading', 60, 'Downloading converted file...');

    const size = await conversionApi.downloadResult(
      downloadUrl,
      outputPath,
      p => emit('downloading', 60 + Math.round(p * 35), 'Downloading...'),
    );

    emit('saving', 98, 'Saving file...');
    return size || fileSize || 0;
  }
}

export const conversionService = ConversionService.getInstance();
export default conversionService;
