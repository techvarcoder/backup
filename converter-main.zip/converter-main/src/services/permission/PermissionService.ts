import { Platform } from 'react-native';
import {
  check,
  request,
  PERMISSIONS,
  RESULTS,
  PermissionStatus,
  openSettings,
} from 'react-native-permissions';

export type AppPermission = 'camera' | 'storage' | 'notifications' | 'microphone';

export interface PermissionResult {
  granted: boolean;
  status: PermissionStatus;
  blocked: boolean;
}

class PermissionService {
  private static instance: PermissionService;

  static getInstance(): PermissionService {
    if (!PermissionService.instance) {
      PermissionService.instance = new PermissionService();
    }
    return PermissionService.instance;
  }

  private getAndroidPermission(type: AppPermission): string | null {
    const apiLevel = Platform.Version as number;
    switch (type) {
      case 'camera':
        return PERMISSIONS.ANDROID.CAMERA;
      case 'storage':
        if (apiLevel >= 33) return PERMISSIONS.ANDROID.READ_MEDIA_IMAGES;
        return PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE;
      case 'microphone':
        return PERMISSIONS.ANDROID.RECORD_AUDIO;
      case 'notifications':
        if (apiLevel >= 33) return PERMISSIONS.ANDROID.POST_NOTIFICATIONS;
        return null;
      default:
        return null;
    }
  }

  async check(permission: AppPermission): Promise<PermissionResult> {
    try {
      const androidPerm = this.getAndroidPermission(permission);
      if (!androidPerm) {
        return { granted: true, status: RESULTS.GRANTED, blocked: false };
      }
      const status = await check(androidPerm as any);
      return {
        granted: status === RESULTS.GRANTED,
        status,
        blocked: status === RESULTS.BLOCKED,
      };
    } catch (error) {
      return { granted: false, status: RESULTS.DENIED, blocked: false };
    }
  }

  async request(permission: AppPermission): Promise<PermissionResult> {
    try {
      const androidPerm = this.getAndroidPermission(permission);
      if (!androidPerm) {
        return { granted: true, status: RESULTS.GRANTED, blocked: false };
      }
      const status = await request(androidPerm as any);
      return {
        granted: status === RESULTS.GRANTED,
        status,
        blocked: status === RESULTS.BLOCKED,
      };
    } catch (error) {
      return { granted: false, status: RESULTS.DENIED, blocked: false };
    }
  }

  async requestStorage(): Promise<PermissionResult> {
    const apiLevel = Platform.Version as number;
    if (apiLevel >= 33) {
      const images = await this.request('storage');
      return images;
    }
    return this.request('storage');
  }

  async requestCamera(): Promise<PermissionResult> {
    return this.request('camera');
  }

  async requestNotifications(): Promise<PermissionResult> {
    return this.request('notifications');
  }

  async ensureStoragePermission(): Promise<boolean> {
    const checked = await this.check('storage');
    if (checked.granted) return true;
    if (checked.blocked) {
      await openSettings().catch(() => {});
      return false;
    }
    const result = await this.requestStorage();
    return result.granted;
  }

  async ensureCameraPermission(): Promise<boolean> {
    const checked = await this.check('camera');
    if (checked.granted) return true;
    if (checked.blocked) {
      await openSettings().catch(() => {});
      return false;
    }
    const result = await this.requestCamera();
    return result.granted;
  }

  openSettings = openSettings;
}

export const permissionService = PermissionService.getInstance();
export default permissionService;
