import { MMKV } from 'react-native-mmkv';
import { safeParseJSON } from '../../utils/helpers';

const storage = new MMKV({ id: 'fileconverter-storage' });

class StorageService {
  private static instance: StorageService;

  static getInstance(): StorageService {
    if (!StorageService.instance) {
      StorageService.instance = new StorageService();
    }
    return StorageService.instance;
  }

  setString(key: string, value: string): void {
    storage.set(key, value);
  }

  getString(key: string): string | undefined {
    return storage.getString(key);
  }

  setObject<T>(key: string, value: T): void {
    storage.set(key, JSON.stringify(value));
  }

  getObject<T>(key: string, fallback: T): T {
    const raw = storage.getString(key);
    if (!raw) return fallback;
    return safeParseJSON<T>(raw, fallback);
  }

  setBoolean(key: string, value: boolean): void {
    storage.set(key, value);
  }

  getBoolean(key: string, fallback = false): boolean {
    const val = storage.getBoolean(key);
    return val !== undefined ? val : fallback;
  }

  setNumber(key: string, value: number): void {
    storage.set(key, value);
  }

  getNumber(key: string, fallback = 0): number {
    const val = storage.getNumber(key);
    return val !== undefined ? val : fallback;
  }

  delete(key: string): void {
    storage.delete(key);
  }

  clearAll(): void {
    storage.clearAll();
  }

  contains(key: string): boolean {
    return storage.contains(key);
  }

  getAllKeys(): string[] {
    return storage.getAllKeys();
  }
}

export const storageService = StorageService.getInstance();
export default storageService;
