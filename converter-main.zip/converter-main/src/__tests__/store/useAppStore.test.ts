import { act, renderHook } from '@testing-library/react-native';

// Mock storage dependency used in toggleFavoriteConverter
jest.mock('../../services/storage/StorageService', () => ({
  default: {
    setObject: jest.fn(),
    getObject: jest.fn(() => null),
  },
}));

jest.mock('../../constants', () => ({
  STORAGE_KEYS: { FAVORITES: 'favorites' },
}));

import { useAppStore } from '../../store/useAppStore';

// Reset store state between tests
beforeEach(() => {
  useAppStore.setState({
    isInitialized: false,
    isLoading: false,
    snackbar: null,
    favoriteConverterIds: [],
  });
});

describe('useAppStore - initialization', () => {
  it('has correct default state', () => {
    const { result } = renderHook(() => useAppStore());
    expect(result.current.isInitialized).toBe(false);
    expect(result.current.isLoading).toBe(false);
    expect(result.current.snackbar).toBeNull();
    expect(result.current.favoriteConverterIds).toEqual([]);
  });

  it('setInitialized updates flag', () => {
    const { result } = renderHook(() => useAppStore());
    act(() => result.current.setInitialized(true));
    expect(result.current.isInitialized).toBe(true);
  });

  it('setLoading updates flag', () => {
    const { result } = renderHook(() => useAppStore());
    act(() => result.current.setLoading(true));
    expect(result.current.isLoading).toBe(true);
  });
});

describe('useAppStore - snackbar', () => {
  it('showSnackbar sets the snackbar config', () => {
    const { result } = renderHook(() => useAppStore());
    act(() => result.current.showSnackbar({ message: 'Done!', type: 'success' }));
    expect(result.current.snackbar).toEqual({ message: 'Done!', type: 'success' });
  });

  it('hideSnackbar clears the snackbar', () => {
    const { result } = renderHook(() => useAppStore());
    act(() => result.current.showSnackbar({ message: 'Test', type: 'info' }));
    act(() => result.current.hideSnackbar());
    expect(result.current.snackbar).toBeNull();
  });
});

describe('useAppStore - favorite converters', () => {
  it('loadFavorites sets ids', () => {
    const { result } = renderHook(() => useAppStore());
    act(() => result.current.loadFavorites(['pdf-to-docx', 'jpg-to-png']));
    expect(result.current.favoriteConverterIds).toEqual(['pdf-to-docx', 'jpg-to-png']);
  });

  it('toggleFavoriteConverter adds a new id', () => {
    const { result } = renderHook(() => useAppStore());
    act(() => result.current.toggleFavoriteConverter('jpg-to-png'));
    expect(result.current.favoriteConverterIds).toContain('jpg-to-png');
  });

  it('toggleFavoriteConverter removes an existing id', () => {
    const { result } = renderHook(() => useAppStore());
    act(() => result.current.loadFavorites(['jpg-to-png']));
    act(() => result.current.toggleFavoriteConverter('jpg-to-png'));
    expect(result.current.favoriteConverterIds).not.toContain('jpg-to-png');
  });

  it('isFavoriteConverter returns true when favorited', () => {
    const { result } = renderHook(() => useAppStore());
    act(() => result.current.loadFavorites(['pdf-to-word']));
    expect(result.current.isFavoriteConverter('pdf-to-word')).toBe(true);
  });

  it('isFavoriteConverter returns false when not favorited', () => {
    const { result } = renderHook(() => useAppStore());
    expect(result.current.isFavoriteConverter('pdf-to-word')).toBe(false);
  });
});
