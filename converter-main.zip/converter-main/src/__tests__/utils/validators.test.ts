import {
  validateFileSize,
  validateOutputFileName,
  sanitizeFileName,
  validateFile,
} from '../../utils/validators';
import { MAX_FILE_SIZE_BYTES } from '../../constants';
import type { FileItem } from '../../types';

describe('validateFileSize', () => {
  it('rejects empty files', () => {
    const result = validateFileSize(0);
    expect(result.valid).toBe(false);
    expect(result.error).toMatch(/empty/i);
  });

  it('rejects files over the limit', () => {
    const result = validateFileSize(MAX_FILE_SIZE_BYTES + 1);
    expect(result.valid).toBe(false);
    expect(result.error).toMatch(/too large/i);
  });

  it('accepts files within the limit', () => {
    const result = validateFileSize(1024 * 1024);
    expect(result.valid).toBe(true);
    expect(result.error).toBeUndefined();
  });

  it('accepts files exactly at the limit', () => {
    const result = validateFileSize(MAX_FILE_SIZE_BYTES);
    expect(result.valid).toBe(true);
  });
});

describe('validateOutputFileName', () => {
  it('rejects empty names', () => {
    expect(validateOutputFileName('').valid).toBe(false);
    expect(validateOutputFileName('   ').valid).toBe(false);
  });

  it('rejects names with invalid characters', () => {
    expect(validateOutputFileName('file<name>.pdf').valid).toBe(false);
    expect(validateOutputFileName('file/name').valid).toBe(false);
    expect(validateOutputFileName('file:name').valid).toBe(false);
  });

  it('rejects names over 255 chars', () => {
    const longName = 'a'.repeat(256);
    expect(validateOutputFileName(longName).valid).toBe(false);
  });

  it('accepts valid names', () => {
    expect(validateOutputFileName('my_output_file.pdf').valid).toBe(true);
    expect(validateOutputFileName('report-2024.docx').valid).toBe(true);
  });
});

describe('sanitizeFileName', () => {
  it('replaces invalid characters with underscores', () => {
    expect(sanitizeFileName('file<name>.pdf')).toBe('file_name_.pdf');
  });

  it('collapses multiple spaces to single underscores', () => {
    expect(sanitizeFileName('my  file  name')).toBe('my_file_name');
  });

  it('trims leading/trailing underscores', () => {
    const result = sanitizeFileName('  file  ');
    expect(result.startsWith('_')).toBe(false);
    expect(result.endsWith('_')).toBe(false);
  });

  it('truncates to 200 characters', () => {
    const long = 'a'.repeat(250);
    expect(sanitizeFileName(long).length).toBe(200);
  });
});

describe('validateFile', () => {
  const validFile: FileItem = {
    id: '1',
    uri: 'file:///test/file.pdf',
    name: 'file.pdf',
    displayName: 'file',
    extension: 'pdf',
    mimeType: 'application/pdf',
    size: 1024,
    category: 'document',
    lastModified: Date.now(),
  };

  it('accepts a valid file', () => {
    expect(validateFile(validFile).valid).toBe(true);
  });

  it('rejects a file with no URI', () => {
    const result = validateFile({ ...validFile, uri: '' });
    expect(result.valid).toBe(false);
  });

  it('rejects a file with no name', () => {
    const result = validateFile({ ...validFile, name: '' });
    expect(result.valid).toBe(false);
  });

  it('rejects an empty file', () => {
    const result = validateFile({ ...validFile, size: 0 });
    expect(result.valid).toBe(false);
  });
});
