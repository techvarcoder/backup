import {
  formatFileSize,
  formatDuration,
  formatPercentage,
  formatCompressionRatio,
  truncateFileName,
  getFileExtension,
  getFileNameWithoutExtension,
  buildOutputFileName,
  formatEstimatedTime,
} from '../../utils/formatters';

describe('formatFileSize', () => {
  it('returns "0 B" for zero bytes', () => {
    expect(formatFileSize(0)).toBe('0 B');
  });

  it('formats bytes', () => {
    expect(formatFileSize(512)).toBe('512 B');
  });

  it('formats kilobytes', () => {
    expect(formatFileSize(1536)).toBe('1.5 KB');
  });

  it('formats megabytes', () => {
    expect(formatFileSize(2.5 * 1024 * 1024)).toBe('2.5 MB');
  });

  it('formats gigabytes', () => {
    expect(formatFileSize(1.5 * 1024 * 1024 * 1024)).toBe('1.50 GB');
  });
});

describe('formatDuration', () => {
  it('formats milliseconds', () => {
    expect(formatDuration(500)).toBe('500ms');
  });

  it('formats seconds', () => {
    expect(formatDuration(3000)).toBe('3s');
  });

  it('formats minutes and seconds', () => {
    expect(formatDuration(90000)).toBe('1m 30s');
  });

  it('formats hours and minutes', () => {
    expect(formatDuration(3660000)).toBe('1h 1m');
  });
});

describe('formatPercentage', () => {
  it('rounds to nearest integer', () => {
    expect(formatPercentage(66.6)).toBe('67%');
  });

  it('clamps below 0 to 0%', () => {
    expect(formatPercentage(-10)).toBe('0%');
  });

  it('clamps above 100 to 100%', () => {
    expect(formatPercentage(110)).toBe('100%');
  });

  it('handles exact boundaries', () => {
    expect(formatPercentage(0)).toBe('0%');
    expect(formatPercentage(100)).toBe('100%');
  });
});

describe('formatCompressionRatio', () => {
  it('returns 0% when input is zero', () => {
    expect(formatCompressionRatio(0, 500)).toBe('0%');
  });

  it('shows negative ratio when output is smaller', () => {
    expect(formatCompressionRatio(1000, 500)).toBe('-50.0%');
  });

  it('shows positive ratio when output is larger', () => {
    expect(formatCompressionRatio(500, 1000)).toBe('+100.0%');
  });

  it('returns 0% when sizes are equal', () => {
    expect(formatCompressionRatio(1000, 1000)).toBe('0%');
  });
});

describe('truncateFileName', () => {
  it('returns original if within limit', () => {
    expect(truncateFileName('short.pdf')).toBe('short.pdf');
  });

  it('truncates with extension preserved', () => {
    const result = truncateFileName('a_very_long_filename_that_exceeds_limit.pdf', 20);
    expect(result.endsWith('.pdf')).toBe(true);
    expect(result.length).toBeLessThanOrEqual(20);
  });

  it('handles files without extension', () => {
    const result = truncateFileName('this_is_a_very_long_file_name_without_extension', 20);
    expect(result.length).toBeLessThanOrEqual(20);
  });
});

describe('getFileExtension', () => {
  it('returns extension in lowercase', () => {
    expect(getFileExtension('Document.PDF')).toBe('pdf');
  });

  it('returns empty string for no extension', () => {
    expect(getFileExtension('noextension')).toBe('');
  });

  it('handles dotfiles', () => {
    expect(getFileExtension('.gitignore')).toBe('gitignore');
  });

  it('returns last extension for multiple dots', () => {
    expect(getFileExtension('archive.tar.gz')).toBe('gz');
  });
});

describe('getFileNameWithoutExtension', () => {
  it('removes extension', () => {
    expect(getFileNameWithoutExtension('report.pdf')).toBe('report');
  });

  it('returns full name if no extension', () => {
    expect(getFileNameWithoutExtension('noextension')).toBe('noextension');
  });

  it('handles multiple dots', () => {
    expect(getFileNameWithoutExtension('archive.tar.gz')).toBe('archive.tar');
  });
});

describe('buildOutputFileName', () => {
  it('replaces extension', () => {
    expect(buildOutputFileName('document.docx', 'pdf')).toBe('document.pdf');
  });

  it('appends suffix when provided', () => {
    expect(buildOutputFileName('photo.jpg', 'png', 'converted')).toBe('photo_converted.png');
  });
});

describe('formatEstimatedTime', () => {
  it('returns "Almost done..." for zero or negative seconds', () => {
    expect(formatEstimatedTime(0)).toBe('Almost done...');
    expect(formatEstimatedTime(-5)).toBe('Almost done...');
  });

  it('formats seconds remaining', () => {
    expect(formatEstimatedTime(30)).toBe('About 30s remaining');
  });

  it('formats minutes remaining', () => {
    expect(formatEstimatedTime(90)).toBe('About 2min remaining');
  });
});
