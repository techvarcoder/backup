import React from 'react';
import { render, fireEvent } from '@testing-library/react-native';
import { AppButton } from '../../components/common/AppButton';

// Mock Reanimated
jest.mock('react-native-reanimated', () => {
  const Reanimated = require('react-native-reanimated/mock');
  Reanimated.default.call = () => {};
  return Reanimated;
});

// Mock vector icons
jest.mock('react-native-vector-icons/MaterialCommunityIcons', () => 'Icon');

// Mock theme hook
jest.mock('../../hooks/useTheme', () => ({
  useTheme: () => ({
    colors: {
      primary: '#007AFF',
      onPrimary: '#FFFFFF',
      outline: '#E5E7EB',
      primaryContainer: '#EBF3FF',
      onPrimaryContainer: '#004499',
      surfaceVariant: '#F1F3F5',
      textDisabled: '#9CA3AF',
    },
    isDark: false,
  }),
}));

describe('AppButton', () => {
  it('renders label text', () => {
    const { getByText } = render(
      <AppButton label="Convert" onPress={() => {}} />,
    );
    expect(getByText('Convert')).toBeTruthy();
  });

  it('calls onPress when tapped', () => {
    const onPress = jest.fn();
    const { getByRole } = render(
      <AppButton label="Go" onPress={onPress} />,
    );
    fireEvent.press(getByRole('button'));
    expect(onPress).toHaveBeenCalledTimes(1);
  });

  it('does not call onPress when disabled', () => {
    const onPress = jest.fn();
    const { getByRole } = render(
      <AppButton label="Go" onPress={onPress} disabled />,
    );
    fireEvent.press(getByRole('button'));
    expect(onPress).not.toHaveBeenCalled();
  });

  it('does not call onPress when loading', () => {
    const onPress = jest.fn();
    const { getByRole } = render(
      <AppButton label="Go" onPress={onPress} loading />,
    );
    fireEvent.press(getByRole('button'));
    expect(onPress).not.toHaveBeenCalled();
  });

  it('shows ActivityIndicator when loading', () => {
    const { queryByText, getByTestId } = render(
      <AppButton label="Go" onPress={() => {}} loading />,
    );
    // Label is hidden during loading
    expect(queryByText('Go')).toBeNull();
  });

  it('uses accessibilityLabel when provided', () => {
    const { getByLabelText } = render(
      <AppButton label="Go" onPress={() => {}} accessibilityLabel="Navigate to converter" />,
    );
    expect(getByLabelText('Navigate to converter')).toBeTruthy();
  });

  it('defaults accessibilityLabel to label text', () => {
    const { getByLabelText } = render(
      <AppButton label="Convert Now" onPress={() => {}} />,
    );
    expect(getByLabelText('Convert Now')).toBeTruthy();
  });
});
