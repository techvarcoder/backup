import { FileFormat, FileCategory } from '../types/file';

export interface FormatInfo {
  extension: FileFormat;
  label: string;
  mimeType: string;
  category: FileCategory;
  iconName: string;
  color: string;
}

export const FORMAT_INFO: Record<string, FormatInfo> = {
  pdf: {
    extension: 'pdf',
    label: 'PDF',
    mimeType: 'application/pdf',
    category: 'document',
    iconName: 'file-pdf-box',
    color: '#EF4444',
  },
  doc: {
    extension: 'doc',
    label: 'DOC',
    mimeType: 'application/msword',
    category: 'document',
    iconName: 'file-word',
    color: '#2563EB',
  },
  docx: {
    extension: 'docx',
    label: 'DOCX',
    mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    category: 'document',
    iconName: 'file-word',
    color: '#2563EB',
  },
  txt: {
    extension: 'txt',
    label: 'TXT',
    mimeType: 'text/plain',
    category: 'document',
    iconName: 'file-document-outline',
    color: '#6B7280',
  },
  rtf: {
    extension: 'rtf',
    label: 'RTF',
    mimeType: 'application/rtf',
    category: 'document',
    iconName: 'file-document',
    color: '#4B5563',
  },
  html: {
    extension: 'html',
    label: 'HTML',
    mimeType: 'text/html',
    category: 'document',
    iconName: 'language-html5',
    color: '#F97316',
  },
  odt: {
    extension: 'odt',
    label: 'ODT',
    mimeType: 'application/vnd.oasis.opendocument.text',
    category: 'document',
    iconName: 'file-document',
    color: '#0EA5E9',
  },
  jpg: {
    extension: 'jpg',
    label: 'JPG',
    mimeType: 'image/jpeg',
    category: 'image',
    iconName: 'image',
    color: '#8B5CF6',
  },
  jpeg: {
    extension: 'jpeg',
    label: 'JPEG',
    mimeType: 'image/jpeg',
    category: 'image',
    iconName: 'image',
    color: '#8B5CF6',
  },
  png: {
    extension: 'png',
    label: 'PNG',
    mimeType: 'image/png',
    category: 'image',
    iconName: 'image-outline',
    color: '#EC4899',
  },
  webp: {
    extension: 'webp',
    label: 'WebP',
    mimeType: 'image/webp',
    category: 'image',
    iconName: 'web',
    color: '#14B8A6',
  },
  heic: {
    extension: 'heic',
    label: 'HEIC',
    mimeType: 'image/heic',
    category: 'image',
    iconName: 'apple',
    color: '#64748B',
  },
  bmp: {
    extension: 'bmp',
    label: 'BMP',
    mimeType: 'image/bmp',
    category: 'image',
    iconName: 'image',
    color: '#D97706',
  },
  tiff: {
    extension: 'tiff',
    label: 'TIFF',
    mimeType: 'image/tiff',
    category: 'image',
    iconName: 'image',
    color: '#7C3AED',
  },
  svg: {
    extension: 'svg',
    label: 'SVG',
    mimeType: 'image/svg+xml',
    category: 'image',
    iconName: 'vector-square',
    color: '#F59E0B',
  },
  gif: {
    extension: 'gif',
    label: 'GIF',
    mimeType: 'image/gif',
    category: 'image',
    iconName: 'gif',
    color: '#10B981',
  },
  avif: {
    extension: 'avif',
    label: 'AVIF',
    mimeType: 'image/avif',
    category: 'image',
    iconName: 'image',
    color: '#6366F1',
  },
  xls: {
    extension: 'xls',
    label: 'XLS',
    mimeType: 'application/vnd.ms-excel',
    category: 'spreadsheet',
    iconName: 'microsoft-excel',
    color: '#16A34A',
  },
  xlsx: {
    extension: 'xlsx',
    label: 'XLSX',
    mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    category: 'spreadsheet',
    iconName: 'microsoft-excel',
    color: '#16A34A',
  },
  csv: {
    extension: 'csv',
    label: 'CSV',
    mimeType: 'text/csv',
    category: 'spreadsheet',
    iconName: 'file-delimited',
    color: '#0D9488',
  },
  ods: {
    extension: 'ods',
    label: 'ODS',
    mimeType: 'application/vnd.oasis.opendocument.spreadsheet',
    category: 'spreadsheet',
    iconName: 'table',
    color: '#0284C7',
  },
  ppt: {
    extension: 'ppt',
    label: 'PPT',
    mimeType: 'application/vnd.ms-powerpoint',
    category: 'presentation',
    iconName: 'microsoft-powerpoint',
    color: '#EA580C',
  },
  pptx: {
    extension: 'pptx',
    label: 'PPTX',
    mimeType: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    category: 'presentation',
    iconName: 'microsoft-powerpoint',
    color: '#EA580C',
  },
  odp: {
    extension: 'odp',
    label: 'ODP',
    mimeType: 'application/vnd.oasis.opendocument.presentation',
    category: 'presentation',
    iconName: 'presentation',
    color: '#B45309',
  },
};

export function getFormatInfo(ext: string): FormatInfo | undefined {
  return FORMAT_INFO[ext.toLowerCase().replace('.', '')];
}

export function getMimeType(ext: string): string {
  return getFormatInfo(ext)?.mimeType ?? 'application/octet-stream';
}

export function getFormatColor(ext: string): string {
  return getFormatInfo(ext)?.color ?? '#9CA3AF';
}

export function getFileCategory(ext: string): FileCategory {
  return getFormatInfo(ext)?.category ?? 'other';
}
