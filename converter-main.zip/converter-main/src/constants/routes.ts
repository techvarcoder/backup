export const Routes = {
  // Root Stack
  SPLASH: 'Splash' as const,
  ONBOARDING: 'Onboarding' as const,
  MAIN: 'Main' as const,
  CONVERTER_DETAIL: 'ConverterDetail' as const,
  FILE_PICKER: 'FilePicker' as const,
  CONVERSION_SETTINGS: 'ConversionSettings' as const,
  CONVERSION_PROGRESS: 'ConversionProgress' as const,
  CONVERSION_SUCCESS: 'ConversionSuccess' as const,
  CONVERSION_FAILED: 'ConversionFailed' as const,
  FILE_PREVIEW: 'FilePreview' as const,
  SEARCH_RESULTS: 'SearchResults' as const,
  SCANNER: 'Scanner' as const,

  // Main Tabs
  TAB_HOME: 'Home' as const,
  TAB_CATEGORIES: 'Categories' as const,
  TAB_HISTORY: 'History' as const,
  TAB_FAVORITES: 'Favorites' as const,
  TAB_SETTINGS: 'Settings' as const,
};
