export * from './converters';
export * from './formats';
export * from './routes';

export const APP_NAME = 'File Converter';
export const APP_VERSION = '1.0.0';
export const APP_BUILD = '1';

export const STORAGE_KEYS = {
  SETTINGS: '@fileconverter/settings',
  HISTORY: '@fileconverter/history',
  FAVORITES: '@fileconverter/favorites',
  ONBOARDING: '@fileconverter/onboarding',
  THEME: '@fileconverter/theme',
};

export const QUERY_KEYS = {
  HISTORY: 'history',
  FAVORITES: 'favorites',
  SETTINGS: 'settings',
  CONVERSION: 'conversion',
};

export const MAX_FILE_SIZE_MB = 100;
export const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024;

export const CONVERSION_TIMEOUT_MS = 5 * 60 * 1000;
export const PROGRESS_POLL_INTERVAL_MS = 1000;

export const SUPPORTED_MIME_TYPES = [
  'application/pdf',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-powerpoint',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'text/plain',
  'text/html',
  'text/csv',
  'image/jpeg',
  'image/png',
  'image/webp',
  'image/heic',
  'image/heif',
  'image/bmp',
  'image/tiff',
  'image/svg+xml',
  'image/gif',
];

export const PLAY_STORE_URL = 'https://play.google.com/store/apps/details?id=com.fileconverter';
export const PRIVACY_POLICY_URL = 'https://fileconverter.app/privacy';
export const TERMS_URL = 'https://fileconverter.app/terms';
export const SUPPORT_EMAIL = 'support@fileconverter.app';
