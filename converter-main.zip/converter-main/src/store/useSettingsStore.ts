import { create } from 'zustand';
import { AppSettings, defaultSettings, ThemeMode } from '../types/settings';
import storageService from '../services/storage/StorageService';
import { STORAGE_KEYS } from '../constants';
import { invalidateApiInstance } from '../api/client';

interface SettingsState {
  settings: AppSettings;
  isDarkMode: boolean;
  loadSettings: () => void;
  updateSettings: (patch: Partial<AppSettings>) => void;
  resetSettings: () => void;
  setThemeMode: (mode: ThemeMode) => void;
  setOnboardingCompleted: () => void;
}

function resolveIsDark(mode: ThemeMode): boolean {
  if (mode === 'dark') return true;
  if (mode === 'light') return false;
  const { Appearance } = require('react-native');
  return Appearance.getColorScheme() === 'dark';
}

export const useSettingsStore = create<SettingsState>((set, get) => ({
  settings: storageService.getObject<AppSettings>(STORAGE_KEYS.SETTINGS, defaultSettings),
  isDarkMode: resolveIsDark(
    storageService.getObject<AppSettings>(STORAGE_KEYS.SETTINGS, defaultSettings).themeMode,
  ),

  loadSettings: () => {
    const settings = storageService.getObject<AppSettings>(STORAGE_KEYS.SETTINGS, defaultSettings);
    set({ settings, isDarkMode: resolveIsDark(settings.themeMode) });
  },

  updateSettings: (patch: Partial<AppSettings>) => {
    const current = get().settings;
    const updated = { ...current, ...patch };
    storageService.setObject(STORAGE_KEYS.SETTINGS, updated);
    const needsApiReset = patch.backendApiUrl !== undefined || patch.backendApiKey !== undefined;
    if (needsApiReset) invalidateApiInstance();
    set({ settings: updated, isDarkMode: resolveIsDark(updated.themeMode) });
  },

  resetSettings: () => {
    storageService.setObject(STORAGE_KEYS.SETTINGS, defaultSettings);
    set({ settings: defaultSettings, isDarkMode: resolveIsDark(defaultSettings.themeMode) });
  },

  setThemeMode: (mode: ThemeMode) => {
    get().updateSettings({ themeMode: mode });
  },

  setOnboardingCompleted: () => {
    get().updateSettings({ onboardingCompleted: true });
  },
}));
