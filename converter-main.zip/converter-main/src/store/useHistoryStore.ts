import { create } from 'zustand';
import { StoredConversion } from '../types';
import storageService from '../services/storage/StorageService';
import { STORAGE_KEYS } from '../constants';
import { generateId } from '../utils/helpers';

interface HistoryState {
  conversions: StoredConversion[];
  loadHistory: () => void;
  addConversion: (conversion: StoredConversion) => void;
  removeConversion: (id: string) => void;
  toggleFavorite: (id: string) => void;
  clearHistory: () => void;
  getConversionById: (id: string) => StoredConversion | undefined;
}

const MAX_HISTORY = 200;

export const useHistoryStore = create<HistoryState>((set, get) => ({
  conversions: storageService.getObject<StoredConversion[]>(STORAGE_KEYS.HISTORY, []),

  loadHistory: () => {
    const conversions = storageService.getObject<StoredConversion[]>(STORAGE_KEYS.HISTORY, []);
    set({ conversions });
  },

  addConversion: (conversion: StoredConversion) => {
    const current = get().conversions;
    const updated = [conversion, ...current].slice(0, MAX_HISTORY);
    storageService.setObject(STORAGE_KEYS.HISTORY, updated);
    set({ conversions: updated });
  },

  removeConversion: (id: string) => {
    const updated = get().conversions.filter(c => c.id !== id);
    storageService.setObject(STORAGE_KEYS.HISTORY, updated);
    set({ conversions: updated });
  },

  toggleFavorite: (id: string) => {
    const updated = get().conversions.map(c =>
      c.id === id ? { ...c, isFavorite: !c.isFavorite } : c,
    );
    storageService.setObject(STORAGE_KEYS.HISTORY, updated);
    set({ conversions: updated });
  },

  clearHistory: () => {
    storageService.setObject(STORAGE_KEYS.HISTORY, []);
    set({ conversions: [] });
  },

  getConversionById: (id: string) => get().conversions.find(c => c.id === id),
}));
