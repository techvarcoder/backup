import { create } from 'zustand';
import { FileItem } from '../types';
import { ConverterDefinition, ConversionOptions, ConversionProgress } from '../types/converter';
import { ConversionStatus, StoredConversion } from '../types/file';

interface ConversionState {
  activeConverter: ConverterDefinition | null;
  selectedFile: FileItem | null;
  conversionOptions: Partial<ConversionOptions>;
  activeJobId: string | null;
  progress: ConversionProgress | null;
  status: ConversionStatus;
  currentConversion: StoredConversion | null;
  error: string | null;

  setConverter: (converter: ConverterDefinition) => void;
  setSelectedFile: (file: FileItem | null) => void;
  setConversionOptions: (options: Partial<ConversionOptions>) => void;
  startConversion: (jobId: string) => void;
  updateProgress: (progress: ConversionProgress) => void;
  completeConversion: (conversion: StoredConversion) => void;
  failConversion: (error: string) => void;
  cancelConversion: () => void;
  reset: () => void;
}

const initialState = {
  activeConverter: null,
  selectedFile: null,
  conversionOptions: {},
  activeJobId: null,
  progress: null,
  status: 'idle' as ConversionStatus,
  currentConversion: null,
  error: null,
};

export const useConversionStore = create<ConversionState>(set => ({
  ...initialState,

  setConverter: (converter: ConverterDefinition) =>
    set({ activeConverter: converter }),

  setSelectedFile: (file: FileItem | null) =>
    set({ selectedFile: file }),

  setConversionOptions: (options: Partial<ConversionOptions>) =>
    set(state => ({ conversionOptions: { ...state.conversionOptions, ...options } })),

  startConversion: (jobId: string) =>
    set({
      activeJobId: jobId,
      status: 'converting',
      error: null,
      currentConversion: null,
    }),

  updateProgress: (progress: ConversionProgress) => {
    const statusMap: Record<ConversionProgress['stage'], ConversionStatus> = {
      preparing: 'converting',
      uploading: 'uploading',
      processing: 'converting',
      downloading: 'converting',
      saving: 'finalizing',
      done: 'completed',
    };
    set({ progress, status: statusMap[progress.stage] ?? 'converting' });
  },

  completeConversion: (conversion: StoredConversion) =>
    set({ currentConversion: conversion, status: 'completed', activeJobId: null }),

  failConversion: (error: string) =>
    set({ error, status: 'failed', activeJobId: null }),

  cancelConversion: () =>
    set({ ...initialState }),

  reset: () => set({ ...initialState }),
}));
