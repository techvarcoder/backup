import { create } from 'zustand';
import { SnackbarConfig } from '../types/common';

interface AppState {
  isInitialized: boolean;
  isLoading: boolean;
  snackbar: SnackbarConfig | null;
  favoriteConverterIds: string[];

  setInitialized: (initialized: boolean) => void;
  setLoading: (loading: boolean) => void;
  showSnackbar: (config: SnackbarConfig) => void;
  hideSnackbar: () => void;
  toggleFavoriteConverter: (converterId: string) => void;
  isFavoriteConverter: (converterId: string) => boolean;
  loadFavorites: (ids: string[]) => void;
}

export const useAppStore = create<AppState>((set, get) => ({
  isInitialized: false,
  isLoading: false,
  snackbar: null,
  favoriteConverterIds: [],

  setInitialized: (initialized: boolean) => set({ isInitialized: initialized }),
  setLoading: (loading: boolean) => set({ isLoading: loading }),

  showSnackbar: (config: SnackbarConfig) => set({ snackbar: config }),
  hideSnackbar: () => set({ snackbar: null }),

  toggleFavoriteConverter: (converterId: string) => {
    const current = get().favoriteConverterIds;
    const updated = current.includes(converterId)
      ? current.filter(id => id !== converterId)
      : [...current, converterId];
    set({ favoriteConverterIds: updated });

    const storageService = require('../services/storage/StorageService').default;
    const { STORAGE_KEYS } = require('../constants');
    storageService.setObject(STORAGE_KEYS.FAVORITES, updated);
  },

  isFavoriteConverter: (converterId: string) =>
    get().favoriteConverterIds.includes(converterId),

  loadFavorites: (ids: string[]) => set({ favoriteConverterIds: ids }),
}));
