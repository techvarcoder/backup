import React, { useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
  runOnJS,
} from 'react-native-reanimated';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAppStore } from '../../store/useAppStore';
import { useTheme } from '../../hooks/useTheme';
import { spacing, radius, iconSize } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';

const TYPE_CONFIG = {
  success: { icon: 'check-circle', color: '#22C55E' },
  error: { icon: 'alert-circle', color: '#EF4444' },
  warning: { icon: 'alert', color: '#EAB308' },
  info: { icon: 'information', color: '#007AFF' },
};

export default function GlobalSnackbar() {
  const { snackbar, hideSnackbar } = useAppStore();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const translateY = useSharedValue(200);
  const opacity = useSharedValue(0);

  useEffect(() => {
    if (snackbar) {
      translateY.value = withSpring(0, { damping: 20 });
      opacity.value = withTiming(1, { duration: 200 });
      const duration = snackbar.duration ?? 3000;
      const timer = setTimeout(() => {
        translateY.value = withTiming(200, { duration: 300 });
        opacity.value = withTiming(0, { duration: 300 }, finished => {
          if (finished) runOnJS(hideSnackbar)();
        });
      }, duration);
      return () => clearTimeout(timer);
    }
  }, [snackbar]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
    opacity: opacity.value,
  }));

  if (!snackbar) return null;

  const config = TYPE_CONFIG[snackbar.type];

  return (
    <Animated.View
      style={[
        styles.container,
        {
          backgroundColor: colors.inverseSurface,
          bottom: insets.bottom + spacing.md,
        },
        animatedStyle,
      ]}>
      <Icon name={config.icon} size={iconSize.md} color={config.color} />
      <Text
        style={[styles.message, { color: colors.inverseOnSurface }]}
        numberOfLines={2}>
        {snackbar.message}
      </Text>
      {snackbar.action ? (
        <TouchableOpacity
          onPress={() => {
            snackbar.action!.onPress();
            hideSnackbar();
          }}>
          <Text style={[styles.action, { color: colors.inversePrimary }]}>
            {snackbar.action.label}
          </Text>
        </TouchableOpacity>
      ) : null}
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: spacing.lg,
    right: spacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    borderRadius: radius.lg,
    gap: spacing.sm,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    zIndex: 9999,
  },
  message: {
    flex: 1,
    fontSize: fontSize.base,
    fontWeight: fontWeight.medium,
  },
  action: {
    fontSize: fontSize.base,
    fontWeight: fontWeight.bold,
    marginLeft: spacing.sm,
  },
});
