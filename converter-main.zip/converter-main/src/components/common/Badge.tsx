import React, { memo } from 'react';
import { View, Text, StyleSheet, ViewStyle } from 'react-native';
import { useTheme } from '../../hooks/useTheme';
import { radius, spacing } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';

interface BadgeProps {
  label: string;
  color?: string;
  backgroundColor?: string;
  style?: ViewStyle;
  small?: boolean;
}

export const Badge = memo(function Badge({
  label,
  color,
  backgroundColor,
  style,
  small = false,
}: BadgeProps) {
  const { colors } = useTheme();

  return (
    <View
      style={[
        styles.badge,
        small && styles.small,
        {
          backgroundColor: backgroundColor ?? colors.primaryContainer,
        },
        style,
      ]}>
      <Text
        style={[
          styles.label,
          small && styles.smallLabel,
          { color: color ?? colors.primary },
        ]}>
        {label}
      </Text>
    </View>
  );
});

export const OfflineBadge = memo(function OfflineBadge() {
  const { colors } = useTheme();
  return (
    <Badge
      label="Offline"
      backgroundColor={colors.successContainer}
      color={colors.success}
      small
    />
  );
});

export const OnlineBadge = memo(function OnlineBadge() {
  const { colors } = useTheme();
  return (
    <Badge
      label="Online"
      backgroundColor={colors.tertiaryContainer}
      color={colors.tertiary}
      small
    />
  );
});

const styles = StyleSheet.create({
  badge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
    borderRadius: radius.full,
  },
  label: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.semiBold,
  },
  small: {
    paddingHorizontal: spacing.xs,
  },
  smallLabel: {
    fontSize: fontSize.xs,
  },
});
