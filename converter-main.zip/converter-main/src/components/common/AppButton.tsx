import React, { memo } from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ActivityIndicator,
  ViewStyle,
  TextStyle,
  View,
} from 'react-native';
import Animated, { useSharedValue, useAnimatedStyle, withSpring } from 'react-native-reanimated';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useTheme } from '../../hooks/useTheme';
import { radius, spacing, touchTarget } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';

export type ButtonVariant = 'filled' | 'outlined' | 'text' | 'tonal';
export type ButtonSize = 'sm' | 'md' | 'lg';

interface AppButtonProps {
  onPress: () => void;
  label: string;
  variant?: ButtonVariant;
  size?: ButtonSize;
  disabled?: boolean;
  loading?: boolean;
  iconName?: string;
  iconRight?: boolean;
  style?: ViewStyle;
  labelStyle?: TextStyle;
  fullWidth?: boolean;
  accessibilityLabel?: string;
}

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export const AppButton = memo(function AppButton({
  onPress,
  label,
  variant = 'filled',
  size = 'md',
  disabled = false,
  loading = false,
  iconName,
  iconRight = false,
  style,
  labelStyle,
  fullWidth = false,
  accessibilityLabel,
}: AppButtonProps) {
  const { colors } = useTheme();
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const handlePressIn = () => { scale.value = withSpring(0.97, { damping: 20 }); };
  const handlePressOut = () => { scale.value = withSpring(1, { damping: 20 }); };

  const sizeStyles = {
    sm: { height: 36, paddingHorizontal: spacing.md, iconSize: 16 },
    md: { height: 48, paddingHorizontal: spacing.xl, iconSize: 20 },
    lg: { height: 56, paddingHorizontal: spacing.xxl, iconSize: 22 },
  }[size];

  const labelSizes = {
    sm: fontSize.sm,
    md: fontSize.base,
    lg: fontSize.md,
  }[size];

  const variantStyles: Record<ButtonVariant, { container: ViewStyle; label: TextStyle }> = {
    filled: {
      container: {
        backgroundColor: disabled ? colors.outline : colors.primary,
        borderWidth: 0,
      },
      label: { color: colors.onPrimary },
    },
    outlined: {
      container: {
        backgroundColor: 'transparent',
        borderWidth: 1.5,
        borderColor: disabled ? colors.outline : colors.primary,
      },
      label: { color: disabled ? colors.textDisabled : colors.primary },
    },
    text: {
      container: {
        backgroundColor: 'transparent',
        borderWidth: 0,
      },
      label: { color: disabled ? colors.textDisabled : colors.primary },
    },
    tonal: {
      container: {
        backgroundColor: disabled ? colors.surfaceVariant : colors.primaryContainer,
        borderWidth: 0,
      },
      label: { color: disabled ? colors.textDisabled : colors.onPrimaryContainer },
    },
  };

  const vs = variantStyles[variant];

  return (
    <AnimatedTouchable
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      disabled={disabled || loading}
      style={[
        styles.base,
        vs.container,
        { height: sizeStyles.height, paddingHorizontal: sizeStyles.paddingHorizontal },
        fullWidth && styles.fullWidth,
        animatedStyle,
        style,
      ]}
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel ?? label}
      accessibilityState={{ disabled: disabled || loading }}>
      {loading ? (
        <ActivityIndicator
          size="small"
          color={variant === 'filled' ? colors.onPrimary : colors.primary}
        />
      ) : (
        <View style={styles.content}>
          {iconName && !iconRight && (
            <Icon
              name={iconName}
              size={sizeStyles.iconSize}
              color={vs.label.color as string}
              style={styles.iconLeft}
            />
          )}
          <Text
            style={[
              styles.label,
              vs.label,
              { fontSize: labelSizes },
              labelStyle,
            ]}>
            {label}
          </Text>
          {iconName && iconRight && (
            <Icon
              name={iconName}
              size={sizeStyles.iconSize}
              color={vs.label.color as string}
              style={styles.iconRight}
            />
          )}
        </View>
      )}
    </AnimatedTouchable>
  );
});

const styles = StyleSheet.create({
  base: {
    borderRadius: radius.xl,
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 80,
    minHeight: touchTarget.min,
  },
  fullWidth: {
    alignSelf: 'stretch',
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  label: {
    fontWeight: fontWeight.semiBold,
    letterSpacing: 0.3,
  },
  iconLeft: {
    marginRight: spacing.xs,
  },
  iconRight: {
    marginLeft: spacing.xs,
  },
});
