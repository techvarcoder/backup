import React, { memo, ReactNode } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ViewStyle,
  Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useTheme } from '../../hooks/useTheme';
import { spacing, iconSize, layout, touchTarget } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';

interface AppBarProps {
  title?: string;
  subtitle?: string;
  onBack?: () => void;
  rightActions?: ReactNode;
  transparent?: boolean;
  style?: ViewStyle;
  titleLeft?: boolean;
}

export const AppBar = memo(function AppBar({
  title,
  subtitle,
  onBack,
  rightActions,
  transparent = false,
  style,
  titleLeft = false,
}: AppBarProps) {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: transparent ? 'transparent' : colors.surface,
          paddingTop: insets.top + spacing.sm,
          borderBottomColor: transparent ? 'transparent' : colors.outline,
        },
        style,
      ]}>
      <View style={styles.content}>
        {onBack ? (
          <TouchableOpacity
            onPress={onBack}
            style={styles.backButton}
            hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            accessibilityRole="button"
            accessibilityLabel="Go back">
            <Icon name="arrow-left" size={iconSize.lg} color={colors.text} />
          </TouchableOpacity>
        ) : (
          <View style={styles.placeholder} />
        )}

        <View style={[styles.titleContainer, titleLeft && styles.titleLeft]}>
          {title ? (
            <Text
              style={[styles.title, { color: colors.text }]}
              numberOfLines={1}
              ellipsizeMode="tail">
              {title}
            </Text>
          ) : null}
          {subtitle ? (
            <Text
              style={[styles.subtitle, { color: colors.textSecondary }]}
              numberOfLines={1}>
              {subtitle}
            </Text>
          ) : null}
        </View>

        <View style={styles.actions}>
          {rightActions ?? <View style={styles.placeholder} />}
        </View>
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    borderBottomWidth: 1,
    paddingBottom: spacing.sm,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.sm,
    minHeight: layout.headerHeight,
  },
  backButton: {
    width: touchTarget.min,
    height: touchTarget.min,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: touchTarget.min / 2,
  },
  placeholder: {
    width: touchTarget.min,
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: spacing.xs,
  },
  titleLeft: {
    alignItems: 'flex-start',
    paddingLeft: spacing.xs,
  },
  title: {
    fontSize: fontSize.lg,
    fontWeight: fontWeight.semiBold,
  },
  subtitle: {
    fontSize: fontSize.sm,
    marginTop: 1,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
    width: 'auto',
    minWidth: touchTarget.min,
    justifyContent: 'flex-end',
  },
});
