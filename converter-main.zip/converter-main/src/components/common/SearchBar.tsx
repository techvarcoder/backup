import React, { memo, useRef } from 'react';
import {
  View,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  ViewStyle,
  Platform,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useTheme } from '../../hooks/useTheme';
import { radius, spacing, iconSize, touchTarget } from '../../theme/spacing';
import { fontSize } from '../../theme/typography';

interface SearchBarProps {
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  onFocus?: () => void;
  onBlur?: () => void;
  onClear?: () => void;
  onSubmit?: () => void;
  style?: ViewStyle;
  autoFocus?: boolean;
  editable?: boolean;
  onPress?: () => void;
}

export const SearchBar = memo(function SearchBar({
  value,
  onChangeText,
  placeholder = 'Search converters...',
  onFocus,
  onBlur,
  onClear,
  onSubmit,
  style,
  autoFocus = false,
  editable = true,
  onPress,
}: SearchBarProps) {
  const { colors } = useTheme();
  const inputRef = useRef<TextInput>(null);

  const handleClear = () => {
    onChangeText('');
    onClear?.();
    inputRef.current?.focus();
  };

  if (onPress) {
    return (
      <TouchableOpacity
        onPress={onPress}
        style={[
          styles.container,
          {
            backgroundColor: colors.surfaceVariant,
            borderColor: colors.outline,
          },
          style,
        ]}
        accessibilityRole="search">
        <Icon name="magnify" size={iconSize.lg} color={colors.textTertiary} />
        <View style={[styles.placeholder]}>
          <Icon name="magnify" size={0} />
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: colors.surfaceVariant,
          borderColor: colors.outline,
        },
        style,
      ]}>
      <Icon
        name="magnify"
        size={iconSize.lg}
        color={colors.textTertiary}
        style={styles.searchIcon}
      />
      <TextInput
        ref={inputRef}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.textTertiary}
        style={[styles.input, { color: colors.text }]}
        onFocus={onFocus}
        onBlur={onBlur}
        onSubmitEditing={onSubmit}
        returnKeyType="search"
        autoFocus={autoFocus}
        editable={editable}
        autoCapitalize="none"
        autoCorrect={false}
        clearButtonMode="never"
      />
      {value.length > 0 && (
        <TouchableOpacity
          onPress={handleClear}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
          accessibilityRole="button"
          accessibilityLabel="Clear search">
          <Icon name="close-circle" size={iconSize.md} color={colors.textTertiary} />
        </TouchableOpacity>
      )}
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.xl,
    paddingHorizontal: spacing.md,
    height: touchTarget.comfortable,
    borderWidth: 1,
  },
  searchIcon: {
    marginRight: spacing.sm,
  },
  input: {
    flex: 1,
    fontSize: fontSize.base,
    paddingVertical: 0,
    paddingHorizontal: 0,
    includeFontPadding: false,
  },
  placeholder: {
    flex: 1,
  },
});
