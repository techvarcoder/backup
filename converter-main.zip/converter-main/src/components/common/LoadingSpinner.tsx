import React, { memo } from 'react';
import { View, ActivityIndicator, Text, StyleSheet, ViewStyle } from 'react-native';
import { useTheme } from '../../hooks/useTheme';
import { spacing } from '../../theme/spacing';
import { fontSize } from '../../theme/typography';

interface LoadingSpinnerProps {
  message?: string;
  size?: 'small' | 'large';
  style?: ViewStyle;
  overlay?: boolean;
}

export const LoadingSpinner = memo(function LoadingSpinner({
  message,
  size = 'large',
  style,
  overlay = false,
}: LoadingSpinnerProps) {
  const { colors } = useTheme();

  return (
    <View
      style={[
        styles.container,
        overlay && [styles.overlay, { backgroundColor: colors.scrim }],
        style,
      ]}>
      <ActivityIndicator size={size} color={colors.primary} />
      {message ? (
        <Text style={[styles.message, { color: overlay ? colors.white : colors.textSecondary }]}>
          {message}
        </Text>
      ) : null}
    </View>
  );
});

export const FullScreenLoader = memo(function FullScreenLoader({ message }: { message?: string }) {
  const { colors } = useTheme();
  return (
    <View style={[styles.fullScreen, { backgroundColor: colors.background }]}>
      <ActivityIndicator size="large" color={colors.primary} />
      {message ? (
        <Text style={[styles.message, { color: colors.textSecondary, marginTop: spacing.md }]}>
          {message}
        </Text>
      ) : null}
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 999,
  },
  fullScreen: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  message: {
    marginTop: spacing.md,
    fontSize: fontSize.base,
    textAlign: 'center',
  },
});
