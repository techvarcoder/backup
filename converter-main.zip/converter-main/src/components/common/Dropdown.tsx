import React, { memo, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  FlatList,
  ViewStyle,
} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useTheme } from '../../hooks/useTheme';
import { radius, spacing, iconSize, touchTarget } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';

export interface DropdownOption {
  value: string;
  label: string;
  description?: string;
  iconName?: string;
}

interface DropdownProps {
  options: DropdownOption[];
  value: string;
  onChange: (value: string) => void;
  label?: string;
  placeholder?: string;
  style?: ViewStyle;
}

export const Dropdown = memo(function Dropdown({
  options,
  value,
  onChange,
  label,
  placeholder = 'Select...',
  style,
}: DropdownProps) {
  const { colors } = useTheme();
  const [visible, setVisible] = useState(false);

  const selected = options.find(o => o.value === value);

  const handleSelect = useCallback(
    (option: DropdownOption) => {
      onChange(option.value);
      setVisible(false);
    },
    [onChange],
  );

  return (
    <View style={style}>
      {label ? (
        <Text style={[styles.label, { color: colors.textSecondary }]}>{label}</Text>
      ) : null}
      <TouchableOpacity
        onPress={() => setVisible(true)}
        style={[
          styles.trigger,
          {
            backgroundColor: colors.surfaceVariant,
            borderColor: colors.outline,
          },
        ]}
        accessibilityRole="button">
        <Text
          style={[
            styles.triggerText,
            { color: selected ? colors.text : colors.textTertiary },
          ]}>
          {selected?.label ?? placeholder}
        </Text>
        <Icon name={visible ? 'chevron-up' : 'chevron-down'} size={iconSize.md} color={colors.textSecondary} />
      </TouchableOpacity>

      <Modal
        visible={visible}
        transparent
        animationType="fade"
        onRequestClose={() => setVisible(false)}>
        <TouchableOpacity
          style={styles.backdrop}
          activeOpacity={1}
          onPress={() => setVisible(false)}>
          <View
            style={[
              styles.menu,
              {
                backgroundColor: colors.surface,
                borderColor: colors.outline,
              },
            ]}>
            <FlatList
              data={options}
              keyExtractor={item => item.value}
              renderItem={({ item }) => (
                <TouchableOpacity
                  onPress={() => handleSelect(item)}
                  style={[
                    styles.option,
                    item.value === value && { backgroundColor: colors.primaryContainer },
                  ]}>
                  {item.iconName && (
                    <Icon
                      name={item.iconName}
                      size={iconSize.md}
                      color={item.value === value ? colors.primary : colors.textSecondary}
                      style={styles.optionIcon}
                    />
                  )}
                  <View style={styles.optionTexts}>
                    <Text
                      style={[
                        styles.optionLabel,
                        {
                          color: item.value === value ? colors.primary : colors.text,
                          fontWeight: item.value === value ? fontWeight.semiBold : fontWeight.regular,
                        },
                      ]}>
                      {item.label}
                    </Text>
                    {item.description ? (
                      <Text style={[styles.optionDescription, { color: colors.textSecondary }]}>
                        {item.description}
                      </Text>
                    ) : null}
                  </View>
                  {item.value === value && (
                    <Icon name="check" size={iconSize.md} color={colors.primary} />
                  )}
                </TouchableOpacity>
              )}
            />
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
  );
});

const styles = StyleSheet.create({
  label: {
    fontSize: fontSize.sm,
    fontWeight: fontWeight.medium,
    marginBottom: spacing.xs,
    marginLeft: spacing.xs,
  },
  trigger: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: radius.md,
    paddingHorizontal: spacing.md,
    height: touchTarget.comfortable,
    borderWidth: 1,
  },
  triggerText: {
    flex: 1,
    fontSize: fontSize.base,
  },
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.xxl,
  },
  menu: {
    width: '100%',
    maxHeight: 300,
    borderRadius: radius.lg,
    borderWidth: 1,
    overflow: 'hidden',
    elevation: 16,
  },
  option: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
    minHeight: touchTarget.min,
  },
  optionIcon: {
    marginRight: spacing.md,
  },
  optionTexts: {
    flex: 1,
  },
  optionLabel: {
    fontSize: fontSize.base,
  },
  optionDescription: {
    fontSize: fontSize.sm,
    marginTop: 2,
  },
});
