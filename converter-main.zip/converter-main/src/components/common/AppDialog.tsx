import React, { memo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  TouchableWithoutFeedback,
} from 'react-native';
import { useTheme } from '../../hooks/useTheme';
import { AppButton } from './AppButton';
import { radius, spacing } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';

interface AppDialogProps {
  visible: boolean;
  title: string;
  message: string;
  confirmLabel?: string;
  cancelLabel?: string;
  type?: 'info' | 'warning' | 'danger';
  onConfirm: () => void;
  onCancel?: () => void;
  onDismiss?: () => void;
}

export const AppDialog = memo(function AppDialog({
  visible,
  title,
  message,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  type = 'info',
  onConfirm,
  onCancel,
  onDismiss,
}: AppDialogProps) {
  const { colors } = useTheme();

  const confirmVariant = type === 'danger' ? 'filled' : 'filled';
  const confirmColors = {
    info: colors.primary,
    warning: colors.warning,
    danger: colors.error,
  }[type];

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onDismiss ?? onCancel}>
      <TouchableWithoutFeedback onPress={onDismiss ?? onCancel}>
        <View style={styles.backdrop}>
          <TouchableWithoutFeedback>
            <View
              style={[
                styles.dialog,
                {
                  backgroundColor: colors.surface,
                  borderColor: colors.outline,
                },
              ]}>
              <Text style={[styles.title, { color: colors.text }]}>{title}</Text>
              <Text style={[styles.message, { color: colors.textSecondary }]}>{message}</Text>
              <View style={styles.actions}>
                {onCancel ? (
                  <AppButton
                    label={cancelLabel}
                    onPress={onCancel}
                    variant="text"
                    style={styles.actionButton}
                  />
                ) : null}
                <AppButton
                  label={confirmLabel}
                  onPress={onConfirm}
                  variant={type === 'danger' ? 'filled' : 'filled'}
                  style={[
                    styles.actionButton,
                    type === 'danger' && { backgroundColor: colors.error },
                  ]}
                />
              </View>
            </View>
          </TouchableWithoutFeedback>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
});

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.xxl,
  },
  dialog: {
    width: '100%',
    borderRadius: radius.xl,
    padding: spacing.xxl,
    borderWidth: 1,
    elevation: 24,
  },
  title: {
    fontSize: fontSize.xl,
    fontWeight: fontWeight.semiBold,
    marginBottom: spacing.md,
  },
  message: {
    fontSize: fontSize.base,
    lineHeight: 22,
    marginBottom: spacing.xxl,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: spacing.sm,
  },
  actionButton: {
    minWidth: 88,
  },
});
