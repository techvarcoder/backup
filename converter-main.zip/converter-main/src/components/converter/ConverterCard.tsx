import React, { memo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Animated, { useSharedValue, useAnimatedStyle, withSpring } from 'react-native-reanimated';
import { ConverterDefinition } from '../../types/converter';
import { useTheme } from '../../hooks/useTheme';
import { OfflineBadge, OnlineBadge } from '../common/Badge';
import { radius, spacing, iconSize } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { getFormatColor } from '../../constants/formats';

interface ConverterCardProps {
  converter: ConverterDefinition;
  onPress: (converter: ConverterDefinition) => void;
  onFavorite?: (converter: ConverterDefinition) => void;
  isFavorite?: boolean;
  style?: ViewStyle;
  compact?: boolean;
}

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export const ConverterCard = memo(function ConverterCard({
  converter,
  onPress,
  onFavorite,
  isFavorite = false,
  style,
  compact = false,
}: ConverterCardProps) {
  const { colors } = useTheme();
  const scale = useSharedValue(1);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const inputColor = getFormatColor(converter.inputFormat);
  const outputColor = getFormatColor(converter.outputFormat);

  const isOffline = converter.engine === 'local';

  return (
    <AnimatedTouchable
      onPress={() => onPress(converter)}
      onPressIn={() => { scale.value = withSpring(0.97, { damping: 20 }); }}
      onPressOut={() => { scale.value = withSpring(1, { damping: 20 }); }}
      style={[
        styles.container,
        {
          backgroundColor: colors.cardBackground,
          borderColor: colors.cardBorder,
        },
        compact && styles.compact,
        animStyle,
        style,
      ]}
      accessibilityRole="button"
      accessibilityLabel={`Convert ${converter.name}`}>
      <View style={styles.header}>
        <View style={styles.formatBadges}>
          <View style={[styles.formatBadge, { backgroundColor: `${inputColor}18` }]}>
            <Text style={[styles.formatText, { color: inputColor }]}>
              {converter.inputFormat.toUpperCase()}
            </Text>
          </View>
          <Icon name="arrow-right" size={iconSize.sm} color={colors.textTertiary} />
          <View style={[styles.formatBadge, { backgroundColor: `${outputColor}18` }]}>
            <Text style={[styles.formatText, { color: outputColor }]}>
              {converter.outputFormat.toUpperCase()}
            </Text>
          </View>
        </View>
        <View style={styles.rightActions}>
          {isOffline ? <OfflineBadge /> : <OnlineBadge />}
          {onFavorite && (
            <TouchableOpacity
              onPress={() => onFavorite(converter)}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              style={styles.favoriteButton}
              accessibilityRole="button"
              accessibilityLabel={isFavorite ? 'Remove from favorites' : 'Add to favorites'}>
              <Icon
                name={isFavorite ? 'star' : 'star-outline'}
                size={iconSize.md}
                color={isFavorite ? '#EAB308' : colors.textTertiary}
              />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {!compact && (
        <>
          <Text style={[styles.name, { color: colors.text }]}>{converter.name}</Text>
          <Text style={[styles.description, { color: colors.textSecondary }]}>
            {converter.description}
          </Text>
        </>
      )}

      {compact && (
        <Text style={[styles.name, { color: colors.text }]} numberOfLines={1}>
          {converter.name}
        </Text>
      )}

      <Icon
        name="chevron-right"
        size={iconSize.md}
        color={colors.textTertiary}
        style={styles.chevron}
      />
    </AnimatedTouchable>
  );
});

const styles = StyleSheet.create({
  container: {
    borderRadius: radius.lg,
    padding: spacing.lg,
    borderWidth: 1,
  },
  compact: {
    padding: spacing.md,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: spacing.sm,
  },
  formatBadges: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  formatBadge: {
    paddingHorizontal: spacing.sm,
    paddingVertical: 3,
    borderRadius: radius.sm,
  },
  formatText: {
    fontSize: fontSize.xs,
    fontWeight: fontWeight.bold,
    letterSpacing: 0.5,
  },
  rightActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  favoriteButton: {
    padding: 2,
  },
  name: {
    fontSize: fontSize.base,
    fontWeight: fontWeight.semiBold,
    marginBottom: 2,
  },
  description: {
    fontSize: fontSize.sm,
    lineHeight: 18,
  },
  chevron: {
    position: 'absolute',
    right: spacing.md,
    bottom: spacing.lg,
  },
});
