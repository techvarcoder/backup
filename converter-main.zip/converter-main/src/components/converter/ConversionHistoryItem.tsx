import React, { memo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { StoredConversion } from '../../types';
import { FileIcon } from '../file/FileIcon';
import { useTheme } from '../../hooks/useTheme';
import { radius, spacing, iconSize } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { formatRelativeTime, formatFileSize } from '../../utils/formatters';

interface ConversionHistoryItemProps {
  conversion: StoredConversion;
  onPress?: () => void;
  onShare?: () => void;
  onDelete?: () => void;
  onFavorite?: () => void;
}

const STATUS_CONFIG = {
  completed: { icon: 'check-circle', color: '#22C55E', label: 'Success' },
  failed: { icon: 'close-circle', color: '#EF4444', label: 'Failed' },
  cancelled: { icon: 'minus-circle', color: '#EAB308', label: 'Cancelled' },
  converting: { icon: 'loading', color: '#007AFF', label: 'Converting' },
  uploading: { icon: 'upload', color: '#007AFF', label: 'Uploading' },
  finalizing: { icon: 'cog', color: '#007AFF', label: 'Saving' },
  idle: { icon: 'clock-outline', color: '#9CA3AF', label: 'Idle' },
};

export const ConversionHistoryItem = memo(function ConversionHistoryItem({
  conversion,
  onPress,
  onShare,
  onDelete,
  onFavorite,
}: ConversionHistoryItemProps) {
  const { colors } = useTheme();
  const status = STATUS_CONFIG[conversion.status] ?? STATUS_CONFIG.idle;

  return (
    <TouchableOpacity
      onPress={onPress}
      style={[
        styles.container,
        {
          backgroundColor: colors.cardBackground,
          borderColor: colors.cardBorder,
        },
      ]}>
      <View style={styles.iconRow}>
        <FileIcon extension={conversion.inputFormat} size={40} />
        <Icon name="arrow-right" size={iconSize.sm} color={colors.textTertiary} />
        <FileIcon extension={conversion.outputFormat} size={40} />
      </View>

      <View style={styles.info}>
        <Text style={[styles.name, { color: colors.text }]} numberOfLines={1} ellipsizeMode="middle">
          {conversion.outputFileName || conversion.inputFileName}
        </Text>
        <View style={styles.meta}>
          <Icon name={status.icon} size={12} color={status.color} />
          <Text style={[styles.statusLabel, { color: status.color }]}>{status.label}</Text>
          <Text style={[styles.dot, { color: colors.textTertiary }]}>·</Text>
          <Text style={[styles.time, { color: colors.textSecondary }]}>
            {formatRelativeTime(conversion.createdAt)}
          </Text>
          {conversion.outputFileSize ? (
            <>
              <Text style={[styles.dot, { color: colors.textTertiary }]}>·</Text>
              <Text style={[styles.size, { color: colors.textSecondary }]}>
                {formatFileSize(conversion.outputFileSize)}
              </Text>
            </>
          ) : null}
        </View>
      </View>

      <View style={styles.actions}>
        {onFavorite && (
          <TouchableOpacity
            onPress={onFavorite}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <Icon
              name={conversion.isFavorite ? 'star' : 'star-outline'}
              size={iconSize.md}
              color={conversion.isFavorite ? '#EAB308' : colors.textTertiary}
            />
          </TouchableOpacity>
        )}
        {onShare && (
          <TouchableOpacity
            onPress={onShare}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <Icon name="share-variant" size={iconSize.md} color={colors.textTertiary} />
          </TouchableOpacity>
        )}
        {onDelete && (
          <TouchableOpacity
            onPress={onDelete}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <Icon name="delete-outline" size={iconSize.md} color={colors.textTertiary} />
          </TouchableOpacity>
        )}
      </View>
    </TouchableOpacity>
  );
});

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.md,
    borderRadius: radius.lg,
    borderWidth: 1,
    gap: spacing.md,
  },
  iconRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  info: {
    flex: 1,
    gap: 3,
  },
  name: {
    fontSize: fontSize.base,
    fontWeight: fontWeight.medium,
  },
  meta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
    flexWrap: 'wrap',
  },
  statusLabel: {
    fontSize: fontSize.xs,
    fontWeight: fontWeight.medium,
  },
  dot: {
    fontSize: fontSize.sm,
  },
  time: {
    fontSize: fontSize.xs,
  },
  size: {
    fontSize: fontSize.xs,
  },
  actions: {
    flexDirection: 'row',
    gap: spacing.sm,
  },
});
