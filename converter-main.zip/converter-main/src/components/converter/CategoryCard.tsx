import React, { memo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import Animated, { useSharedValue, useAnimatedStyle, withSpring } from 'react-native-reanimated';
import { ConverterCategory } from '../../types/converter';
import { useTheme } from '../../hooks/useTheme';
import { categoryColors } from '../../theme/colors';
import { radius, spacing, iconSize } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';

interface CategoryCardProps {
  category: ConverterCategory;
  onPress: (category: ConverterCategory) => void;
  style?: ViewStyle;
  horizontal?: boolean;
}

const AnimatedTouchable = Animated.createAnimatedComponent(TouchableOpacity);

export const CategoryCard = memo(function CategoryCard({
  category,
  onPress,
  style,
  horizontal = false,
}: CategoryCardProps) {
  const { colors, isDark } = useTheme();
  const scale = useSharedValue(1);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const catColors = categoryColors[category.id as keyof typeof categoryColors];
  const bgColor = isDark ? catColors?.dark_bg : catColors?.bg;
  const iconColor = isDark ? catColors?.dark_icon : catColors?.icon;

  const converterCount = category.converters.length;

  if (horizontal) {
    return (
      <AnimatedTouchable
        onPress={() => onPress(category)}
        onPressIn={() => { scale.value = withSpring(0.96, { damping: 20 }); }}
        onPressOut={() => { scale.value = withSpring(1, { damping: 20 }); }}
        style={[
          styles.horizontal,
          {
            backgroundColor: colors.cardBackground,
            borderColor: colors.cardBorder,
          },
          animStyle,
          style,
        ]}
        accessibilityRole="button">
        <View style={[styles.iconBadge, { backgroundColor: bgColor }]}>
          <Icon name={category.iconName} size={iconSize.xl} color={iconColor} />
        </View>
        <View style={styles.horizontalInfo}>
          <Text style={[styles.name, { color: colors.text }]}>{category.name}</Text>
          <Text style={[styles.count, { color: colors.textSecondary }]}>
            {converterCount} converter{converterCount !== 1 ? 's' : ''}
          </Text>
        </View>
        <Icon name="chevron-right" size={iconSize.md} color={colors.textTertiary} />
      </AnimatedTouchable>
    );
  }

  return (
    <AnimatedTouchable
      onPress={() => onPress(category)}
      onPressIn={() => { scale.value = withSpring(0.96, { damping: 20 }); }}
      onPressOut={() => { scale.value = withSpring(1, { damping: 20 }); }}
      style={[
        styles.container,
        { backgroundColor: bgColor ?? colors.primaryContainer },
        animStyle,
        style,
      ]}
      accessibilityRole="button">
      <Icon name={category.iconName} size={iconSize.xxxl} color={iconColor} />
      <Text style={[styles.name, { color: colors.text }]} numberOfLines={1}>
        {category.name}
      </Text>
      <Text style={[styles.description, { color: colors.textSecondary }]} numberOfLines={2}>
        {category.description}
      </Text>
    </AnimatedTouchable>
  );
});

const styles = StyleSheet.create({
  container: {
    borderRadius: radius.xl,
    padding: spacing.lg,
    gap: spacing.sm,
    minHeight: 120,
    flex: 1,
  },
  horizontal: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.lg,
    padding: spacing.lg,
    borderWidth: 1,
    gap: spacing.md,
  },
  iconBadge: {
    width: 48,
    height: 48,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  horizontalInfo: {
    flex: 1,
  },
  name: {
    fontSize: fontSize.base,
    fontWeight: fontWeight.semiBold,
  },
  description: {
    fontSize: fontSize.sm,
    lineHeight: 18,
  },
  count: {
    fontSize: fontSize.sm,
    marginTop: 2,
  },
});
