import React, { memo } from 'react';
import { View, Text, StyleSheet, ViewStyle } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { getFormatInfo } from '../../constants/formats';
import { radius, iconSize } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';

interface FileIconProps {
  extension: string;
  size?: number;
  style?: ViewStyle;
  showLabel?: boolean;
}

const FORMAT_ICON_MAP: Record<string, string> = {
  pdf: 'file-pdf-box',
  doc: 'file-word',
  docx: 'file-word',
  xls: 'microsoft-excel',
  xlsx: 'microsoft-excel',
  ppt: 'microsoft-powerpoint',
  pptx: 'microsoft-powerpoint',
  txt: 'file-document-outline',
  rtf: 'file-document',
  html: 'language-html5',
  odt: 'file-document',
  csv: 'file-delimited',
  jpg: 'file-image',
  jpeg: 'file-image',
  png: 'file-image',
  webp: 'file-image',
  heic: 'file-image',
  bmp: 'file-image',
  tiff: 'file-image',
  svg: 'vector-square',
  gif: 'file-gif-box',
  mp4: 'file-video',
  mp3: 'file-music',
  zip: 'zip-box',
};

const FORMAT_COLOR_MAP: Record<string, { bg: string; text: string; icon: string }> = {
  pdf: { bg: '#FEE2E2', text: '#EF4444', icon: '#EF4444' },
  doc: { bg: '#DBEAFE', text: '#2563EB', icon: '#2563EB' },
  docx: { bg: '#DBEAFE', text: '#2563EB', icon: '#2563EB' },
  xls: { bg: '#DCFCE7', text: '#16A34A', icon: '#16A34A' },
  xlsx: { bg: '#DCFCE7', text: '#16A34A', icon: '#16A34A' },
  ppt: { bg: '#FFEDD5', text: '#EA580C', icon: '#EA580C' },
  pptx: { bg: '#FFEDD5', text: '#EA580C', icon: '#EA580C' },
  csv: { bg: '#CCFBF1', text: '#0D9488', icon: '#0D9488' },
  txt: { bg: '#F3F4F6', text: '#6B7280', icon: '#6B7280' },
  html: { bg: '#FFEDD5', text: '#F97316', icon: '#F97316' },
  jpg: { bg: '#EDE9FE', text: '#7C3AED', icon: '#7C3AED' },
  jpeg: { bg: '#EDE9FE', text: '#7C3AED', icon: '#7C3AED' },
  png: { bg: '#FCE7F3', text: '#EC4899', icon: '#EC4899' },
  webp: { bg: '#CCFBF1', text: '#0D9488', icon: '#0D9488' },
  svg: { bg: '#FEF3C7', text: '#D97706', icon: '#D97706' },
  gif: { bg: '#D1FAE5', text: '#059669', icon: '#059669' },
  default: { bg: '#F3F4F6', text: '#6B7280', icon: '#9CA3AF' },
};

export const FileIcon = memo(function FileIcon({
  extension,
  size = 48,
  style,
  showLabel = false,
}: FileIconProps) {
  const ext = extension.toLowerCase().replace('.', '');
  const colors = FORMAT_COLOR_MAP[ext] ?? FORMAT_COLOR_MAP.default;
  const iconName = FORMAT_ICON_MAP[ext] ?? 'file';
  const iconSz = size * 0.54;
  const borderRad = size * 0.2;

  return (
    <View
      style={[
        styles.container,
        {
          width: size,
          height: size,
          borderRadius: borderRad,
          backgroundColor: colors.bg,
        },
        style,
      ]}>
      <Icon name={iconName} size={iconSz} color={colors.icon} />
      {showLabel && (
        <Text style={[styles.label, { color: colors.text, fontSize: size * 0.18 }]}>
          {ext.toUpperCase()}
        </Text>
      )}
    </View>
  );
});

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  label: {
    fontWeight: fontWeight.bold,
    marginTop: 1,
    letterSpacing: 0.5,
  },
});
