import React, { memo } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { FileItem } from '../../types';
import { FileIcon } from './FileIcon';
import { useTheme } from '../../hooks/useTheme';
import { radius, spacing, iconSize, touchTarget } from '../../theme/spacing';
import { fontSize, fontWeight } from '../../theme/typography';
import { formatFileSize, truncateFileName } from '../../utils/formatters';

interface FileCardProps {
  file: FileItem;
  onPress?: () => void;
  onRemove?: () => void;
  selected?: boolean;
  style?: ViewStyle;
  compact?: boolean;
}

export const FileCard = memo(function FileCard({
  file,
  onPress,
  onRemove,
  selected = false,
  style,
  compact = false,
}: FileCardProps) {
  const { colors } = useTheme();

  const content = (
    <View
      style={[
        styles.container,
        {
          backgroundColor: selected ? colors.primaryContainer : colors.surfaceVariant,
          borderColor: selected ? colors.primary : colors.outline,
        },
        compact && styles.compact,
        style,
      ]}>
      <FileIcon extension={file.extension} size={compact ? 40 : 48} />
      <View style={styles.info}>
        <Text
          style={[styles.name, { color: colors.text }]}
          numberOfLines={1}
          ellipsizeMode="middle">
          {truncateFileName(file.displayName, compact ? 24 : 28)}
        </Text>
        <View style={styles.meta}>
          <Text style={[styles.ext, { color: colors.primary }]}>
            {file.extension.toUpperCase()}
          </Text>
          <Text style={[styles.dot, { color: colors.textTertiary }]}>·</Text>
          <Text style={[styles.size, { color: colors.textSecondary }]}>
            {formatFileSize(file.size)}
          </Text>
        </View>
      </View>
      {onRemove && (
        <TouchableOpacity
          onPress={onRemove}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
          style={styles.removeButton}
          accessibilityRole="button"
          accessibilityLabel="Remove file">
          <Icon name="close-circle" size={iconSize.md} color={colors.textTertiary} />
        </TouchableOpacity>
      )}
      {selected && !onRemove && (
        <Icon name="check-circle" size={iconSize.lg} color={colors.primary} />
      )}
    </View>
  );

  if (onPress) {
    return (
      <TouchableOpacity onPress={onPress} accessibilityRole="button">
        {content}
      </TouchableOpacity>
    );
  }

  return content;
});

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.md,
    borderRadius: radius.lg,
    borderWidth: 1,
    gap: spacing.md,
  },
  compact: {
    padding: spacing.sm,
  },
  info: {
    flex: 1,
    gap: 2,
  },
  name: {
    fontSize: fontSize.base,
    fontWeight: fontWeight.medium,
  },
  meta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.xs,
  },
  ext: {
    fontSize: fontSize.xs,
    fontWeight: fontWeight.bold,
    letterSpacing: 0.5,
  },
  dot: {
    fontSize: fontSize.sm,
  },
  size: {
    fontSize: fontSize.sm,
  },
  removeButton: {
    padding: spacing.xs,
  },
});
