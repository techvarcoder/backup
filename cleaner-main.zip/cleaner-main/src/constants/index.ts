export const APP_NAME = 'AuroCleaner';

export const STORAGE_KEYS = {
  THEME: '@aurocleaner/theme',
  USER: '@aurocleaner/user',
};
