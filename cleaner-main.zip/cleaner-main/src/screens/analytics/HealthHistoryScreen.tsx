import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

function dayLabel(ts: number): string {
  const d = new Date(ts);
  const now = new Date();
  const diff = Math.floor((now.getTime() - d.getTime()) / 86400000);
  if (diff === 0) return 'Today';
  if (diff === 1) return 'Yesterday';
  return d.toLocaleDateString('en-US',{month:'short',day:'numeric'});
}

export default function HealthHistoryScreen() {
  const navigation = useNavigation();
  const { cleanHistory, totalCleaned, deviceStats, refreshDeviceStats } = useAppStore();
  const healthScore = deviceStats.healthScore;

  useFocusEffect(React.useCallback(() => { refreshDeviceStats(); }, []));

  // Build history from real cleanHistory + current score
  const history = useMemo(() => {
    const entries = cleanHistory.slice(0, 14).map((h) => ({
      label: dayLabel(new Date(h.date).getTime()),
      score: h.score,
    }));
    if (entries.length === 0 || entries[0]?.label !== 'Today') {
      entries.unshift({ label: 'Today', score: healthScore });
    }
    return entries;
  }, [cleanHistory, healthScore]);

  const avg    = history.length > 0 ? Math.round(history.reduce((s,h)=>s+h.score,0)/history.length) : healthScore;
  const best   = history.length > 0 ? Math.max(...history.map(h=>h.score)) : healthScore;
  const cleanedGB = (totalCleaned/1073741824).toFixed(2);

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={styles.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={styles.backBtn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={styles.title}>Health History</Text>
        <View style={{width:40}}/>
      </View>
      <ScrollView contentContainerStyle={styles.body}>
        <View style={styles.summaryRow}>
          {[
            { label:'Current',  value: String(healthScore) },
            { label:'Avg Score',value: String(avg)         },
            { label:'Best',     value: String(best)        },
            { label:'Cleanups', value: String(cleanHistory.length) },
          ].map(s => (
            <View key={s.label} style={styles.summaryBox}>
              <Text style={styles.summaryVal}>{s.value}</Text>
              <Text style={styles.summaryLbl}>{s.label}</Text>
            </View>
          ))}
        </View>

        <Text style={styles.sectionTitle}>Score History</Text>
        {history.length === 0
          ? <View style={styles.emptyWrap}>
              <Icon name="history" size={40} color={C.textMuted}/>
              <Text style={styles.emptyText}>Run cleanups to build history</Text>
            </View>
          : history.map((h,i) => (
            <View key={i} style={styles.histRow}>
              <Text style={styles.histDate}>{h.label}</Text>
              <View style={styles.histBar}>
                <View style={[styles.histFill,{width:`${h.score}%`,backgroundColor:h.score>=85?C.success:h.score>=70?C.warning:C.danger}]}/>
              </View>
              <Text style={[styles.histScore,{color:h.score>=85?C.success:h.score>=70?C.warning:C.danger}]}>{h.score}</Text>
            </View>
          ))
        }

        {cleanHistory.length > 0 && (
          <>
            <Text style={[styles.sectionTitle,{marginTop:24}]}>Recent Cleanups</Text>
            {cleanHistory.slice(0,5).map((h,i) => (
              <View key={i} style={styles.cleanRow}>
                <View style={styles.cleanIcon}><Icon name="broom" size={18} color={C.success}/></View>
                <View style={{flex:1,marginLeft:12}}>
                  <Text style={styles.cleanLabel}>Cleanup #{cleanHistory.length - i}</Text>
                  <Text style={styles.cleanMeta}>{h.date} · freed {h.freedGB.toFixed(2)} GB</Text>
                </View>
              </View>
            ))}
          </>
        )}
        <View style={{height:40}}/>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20},
  backBtn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  body:{paddingHorizontal:20,paddingTop:20},
  summaryRow:{flexDirection:'row',backgroundColor:C.card,borderRadius:radius.card,padding:20,marginBottom:24,borderWidth:1,borderColor:C.border},
  summaryBox:{flex:1,alignItems:'center'}, summaryVal:{fontSize:24,fontWeight:'900',color:C.textPrimary}, summaryLbl:{fontSize:11,color:C.textMuted,marginTop:4},
  sectionTitle:{fontSize:16,fontWeight:'700',color:C.textPrimary,marginBottom:12},
  emptyWrap:{alignItems:'center',paddingVertical:32,gap:12}, emptyText:{fontSize:14,color:C.textMuted},
  histRow:{flexDirection:'row',alignItems:'center',paddingVertical:10,gap:12},
  histDate:{width:80,fontSize:12,color:C.textMuted}, histBar:{flex:1,height:10,backgroundColor:C.border,borderRadius:5,overflow:'hidden'},
  histFill:{height:10,borderRadius:5}, histScore:{width:28,fontSize:14,fontWeight:'800',textAlign:'right'},
  cleanRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:8,borderWidth:1,borderColor:C.border},
  cleanIcon:{width:38,height:38,borderRadius:radius.md,backgroundColor:'#22C55E22',justifyContent:'center',alignItems:'center'},
  cleanLabel:{fontSize:13,fontWeight:'700',color:C.textPrimary}, cleanMeta:{fontSize:11,color:C.textMuted,marginTop:2},
});
