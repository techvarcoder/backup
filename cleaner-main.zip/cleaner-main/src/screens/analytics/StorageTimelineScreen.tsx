import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

interface StorageCategory { label: string; sizeGB: number; color: string; icon: string; }

export default function StorageTimelineScreen() {
  const navigation = useNavigation();
  const { deviceStats, refreshDeviceStats } = useAppStore();
  const [categories, setCategories] = useState<StorageCategory[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const RNFS = require('react-native-fs').default ?? require('react-native-fs');
      const base = RNFS.ExternalStorageDirectoryPath ?? '';
      const scanMap: Array<{ label:string; dirs:string[]; color:string; icon:string }> = [
        { label:'DCIM / Photos',  dirs:[base+'/DCIM', base+'/Pictures'],              color:'#3B82F6', icon:'image-multiple' },
        { label:'Videos',         dirs:[base+'/Movies', base+'/Video', base+'/DCIM/Camera'], color:'#22C55E', icon:'video-box' },
        { label:'Downloads',      dirs:[RNFS.DownloadDirectoryPath ?? base+'/Download'], color:'#F59E0B', icon:'download' },
        { label:'Audio / Music',  dirs:[base+'/Music', base+'/Ringtones'],            color:'#06B6D4', icon:'music-note-multiple' },
        { label:'Documents',      dirs:[base+'/Documents', base+'/Download'],          color:'#8B5CF6', icon:'file-document-multiple' },
      ];

      const results: StorageCategory[] = [];
      for (const cat of scanMap) {
        let bytes = 0;
        for (const dir of cat.dirs) {
          try {
            const items = await RNFS.readDir(dir).catch(() => []);
            for (const item of items) {
              if (item.isFile()) bytes += item.size ?? 0;
            }
          } catch {}
        }
        if (bytes > 0) results.push({ label: cat.label, sizeGB: parseFloat((bytes/1073741824).toFixed(2)), color: cat.color, icon: cat.icon });
      }
      // Other storage = total used minus scanned
      const scannedGB = results.reduce((t,c)=>t+c.sizeGB,0);
      const otherGB   = Math.max(0, parseFloat((deviceStats.storageUsed - scannedGB).toFixed(2)));
      if (otherGB > 0) results.push({ label:'Apps & Other', sizeGB: otherGB, color:'#EF4444', icon:'apps' });

      setCategories(results.sort((a,b)=>b.sizeGB-a.sizeGB));
    } catch { setCategories([]); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { refreshDeviceStats(); load(); }, []));

  const usedPct = Math.round((deviceStats.storageUsed/deviceStats.storageTotal)*100);

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={styles.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={styles.backBtn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={styles.title}>Storage Timeline</Text>
        <TouchableOpacity onPress={load} style={styles.backBtn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>
      <ScrollView contentContainerStyle={styles.body}>
        <View style={styles.totalCard}>
          <View style={styles.totalHeader}>
            <Text style={styles.totalVal}>{deviceStats.storageUsed} GB</Text>
            <Text style={styles.totalSub}>/ {deviceStats.storageTotal} GB Used · {usedPct}%</Text>
          </View>
          <View style={styles.totalBar}>
            <ProgressBar progress={usedPct} color={usedPct>85?C.danger:usedPct>60?C.warning:C.primary} height={10}/>
          </View>
        </View>

        <Text style={styles.sectionTitle}>By Category</Text>
        {loading
          ? <ActivityIndicator color={C.primary} style={{marginTop:20}}/>
          : categories.length === 0
            ? <View style={styles.emptyWrap}><Icon name="harddisk" size={40} color={C.textMuted}/><Text style={styles.emptyText}>No external storage found</Text></View>
            : categories.map(d => (
              <View key={d.label} style={styles.catRow}>
                <View style={[styles.catDot,{backgroundColor:d.color}]}/>
                <View style={[styles.catIcon,{backgroundColor:d.color+'22'}]}>
                  <Icon name={d.icon} size={18} color={d.color}/>
                </View>
                <Text style={styles.catLabel}>{d.label}</Text>
                <ProgressBar progress={Math.round((d.sizeGB/deviceStats.storageUsed)*100)} color={d.color} height={6} style={{flex:1,marginHorizontal:10}}/>
                <Text style={[styles.catSize,{color:d.color}]}>{d.sizeGB} GB</Text>
              </View>
            ))
        }
        <View style={{height:40}}/>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20},
  backBtn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  body:{paddingHorizontal:20,paddingTop:20},
  totalCard:{backgroundColor:C.card,borderRadius:radius.card,padding:24,marginBottom:20,borderWidth:1,borderColor:C.border},
  totalHeader:{flexDirection:'row',alignItems:'baseline',gap:8,marginBottom:12},
  totalVal:{fontSize:32,fontWeight:'900',color:C.textPrimary}, totalSub:{fontSize:13,color:C.textMuted},
  totalBar:{width:'100%'},
  sectionTitle:{fontSize:16,fontWeight:'700',color:C.textPrimary,marginBottom:12},
  emptyWrap:{alignItems:'center',paddingVertical:32,gap:12}, emptyText:{fontSize:14,color:C.textMuted},
  catRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:8,gap:8,borderWidth:1,borderColor:C.border},
  catDot:{width:8,height:8,borderRadius:4,flexShrink:0},
  catIcon:{width:36,height:36,borderRadius:radius.md,justifyContent:'center',alignItems:'center',flexShrink:0},
  catLabel:{width:110,fontSize:12,color:C.textPrimary,fontWeight:'600'},
  catSize:{fontSize:13,fontWeight:'800',width:54,textAlign:'right'},
});
