import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, StatusBar, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';

interface AppEntry { id: string; name: string; pkg: string; color: string; sizeMB: number; }

const COLORS = ['#3B82F6','#8B5CF6','#EC4899','#F59E0B','#10B981','#EF4444','#06B6D4','#F97316'];
function pkgColor(pkg: string) { let h=0; for(let i=0;i<pkg.length;i++) h=pkg.charCodeAt(i)+((h<<5)-h); return COLORS[Math.abs(h)%COLORS.length]; }
const SYS = ['com.android.','android.','com.google.android.','com.samsung.','com.qualcomm.','com.miui.','com.sec.','com.bikedex'];

export default function AppUsageScreen() {
  const navigation = useNavigation();
  const [apps, setApps]     = useState<AppEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab]       = useState(0);

  const load = async () => {
    setLoading(true);
    try {
      const DI   = require('react-native-device-info').default ?? require('react-native-device-info');
      const RNFS = require('react-native-fs').default ?? require('react-native-fs');
      const all: Array<{appName:string;packageName:string;firstInstallTime:number}> =
        await DI.getInstalledApplications().catch(() => []);

      // Scan /sdcard/Android/data once → build a map of pkg → external data size
      const extBase = `${RNFS.ExternalStorageDirectoryPath ?? ''}/Android/data`;
      const extMap: Record<string, number> = {};
      try {
        const pkgDirs = await RNFS.readDir(extBase).catch(() => []);
        for (const d of pkgDirs) {
          if (!d.isDirectory()) continue;
          let bytes = 0;
          try {
            const files = await RNFS.readDir(d.path).catch(() => []);
            for (const f of files) { if (f.isFile()) bytes += f.size ?? 0; }
          } catch {}
          extMap[d.name] = bytes;
        }
      } catch {}

      let id = 0;
      const items: AppEntry[] = all
        .filter(a => !SYS.some(p => (a.packageName||'').startsWith(p)))
        .map(a => {
          const externalBytes = extMap[a.packageName ?? ''] ?? 0;
          const sizeMB = Math.round(externalBytes / 1048576);
          return { id: String(id++), name: a.appName||a.packageName, pkg: a.packageName||'', color: pkgColor(a.packageName||''), sizeMB };
        })
        .sort((a,b) => b.sizeMB - a.sizeMB);
      setApps(items);
    } catch { setApps([]); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { load(); }, []));

  const TABS = ['All','Largest','Newest'];
  const sorted = tab === 1 ? [...apps].sort((a,b)=>b.sizeMB-a.sizeMB) : tab === 2 ? [...apps].slice(-20).reverse() : apps;
  const totalMB = apps.reduce((t,a)=>t+a.sizeMB,0);

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>App Analytics</Text>
        <TouchableOpacity onPress={load} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>

      <View style={s.summaryRow}>
        {[
          { label:'Total Apps',  val:String(apps.length),           icon:'apps',      c:C.primary },
          { label:'Total Size',  val:`${(totalMB/1024).toFixed(1)} GB`, icon:'harddisk', c:C.warning },
        ].map(st => (
          <View key={st.label} style={s.sumCard}>
            <Icon name={st.icon} size={20} color={st.c}/>
            <Text style={[s.sumVal,{color:st.c}]}>{st.val}</Text>
            <Text style={s.sumLabel}>{st.label}</Text>
          </View>
        ))}
      </View>

      <View style={s.tabs}>
        {TABS.map((t,i) => (
          <TouchableOpacity key={t} style={[s.tab,tab===i&&s.tabActive]} onPress={()=>setTab(i)}>
            <Text style={[s.tabText,tab===i&&s.tabTextActive]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading
        ? <ActivityIndicator color={C.primary} style={{marginTop:40}}/>
        : <FlatList
            data={sorted}
            keyExtractor={a=>a.id}
            contentContainerStyle={{paddingHorizontal:20,paddingBottom:40}}
            renderItem={({item:a}) => {
              const barPct = Math.min(100, Math.round((a.sizeMB / (sorted[0]?.sizeMB||1)) * 100));
              return (
                <View style={s.appRow}>
                  <View style={[s.appIcon,{backgroundColor:a.color+'22'}]}>
                    <Icon name="apps" size={22} color={a.color}/>
                  </View>
                  <View style={{flex:1,marginLeft:14}}>
                    <Text style={s.appName} numberOfLines={1}>{a.name}</Text>
                    <View style={s.barTrack}>
                      <View style={[s.barFill,{width:`${barPct}%` as any,backgroundColor:a.color}]}/>
                    </View>
                  </View>
                  <Text style={[s.appSize,{color:a.color}]}>{a.sizeMB > 0 ? `${a.sizeMB} MB` : '—'}</Text>
                </View>
              );
            }}
          />
      }
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:12},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  summaryRow:{flexDirection:'row',marginHorizontal:20,gap:12,marginBottom:12},
  sumCard:{flex:1,backgroundColor:C.card,borderRadius:radius.xl,padding:14,alignItems:'center',gap:6,borderWidth:1,borderColor:C.border},
  sumVal:{fontSize:18,fontWeight:'800'}, sumLabel:{fontSize:11,color:C.textMuted},
  tabs:{flexDirection:'row',marginHorizontal:20,backgroundColor:C.card,borderRadius:radius.pill,padding:4,marginBottom:12},
  tab:{flex:1,paddingVertical:8,alignItems:'center',borderRadius:radius.pill},
  tabActive:{backgroundColor:C.primary}, tabText:{fontSize:12,color:C.textMuted,fontWeight:'600'}, tabTextActive:{color:'#fff'},
  appRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:8,borderWidth:1,borderColor:C.border},
  appIcon:{width:44,height:44,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  appName:{fontSize:13,fontWeight:'700',color:C.textPrimary,marginBottom:6},
  barTrack:{height:4,backgroundColor:C.border,borderRadius:2,overflow:'hidden'},
  barFill:{height:4,borderRadius:2},
  appSize:{fontSize:12,fontWeight:'800',marginLeft:8,flexShrink:0},
});
