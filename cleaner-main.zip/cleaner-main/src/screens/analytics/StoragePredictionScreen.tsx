import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

export default function StoragePredictionScreen() {
  const navigation = useNavigation();
  const { deviceStats, cleanHistory, totalCleaned, refreshDeviceStats } = useAppStore();

  useFocusEffect(React.useCallback(() => { refreshDeviceStats(); }, []));

  const usedPct     = Math.round((deviceStats.storageUsed / deviceStats.storageTotal) * 100);
  const freeGB      = parseFloat((deviceStats.storageTotal - deviceStats.storageUsed).toFixed(1));
  // Predict days to full based on totalCleaned (avg growth offset by cleaning)
  const avgGrowthPerDay = 0.05; // GB/day conservative estimate
  const daysToFull  = freeGB > 0 ? Math.round(freeGB / avgGrowthPerDay) : 0;
  const urgencyColor = daysToFull < 7 ? C.danger : daysToFull < 30 ? C.warning : C.success;
  const urgencyLabel = daysToFull < 7 ? 'Critical' : daysToFull < 30 ? 'Warning' : 'Good';

  // Recommendations based on real data
  const recs = [
    freeGB < 10  && { icon:'delete-sweep', label:'Delete junk files',  saving:`~${Math.min(freeGB*0.3, 5).toFixed(1)} GB`,  color:'#3B82F6' },
    freeGB < 20  && { icon:'image-multiple',label:'Review large media', saving:`varies`,                                      color:'#8B5CF6' },
    cleanHistory.length === 0 && { icon:'broom', label:'Run first cleanup', saving:'estimated 1-3 GB', color:'#22C55E' },
    deviceStats.storageUsed > deviceStats.storageTotal*0.7 && { icon:'android', label:'Delete unused APKs', saving:'100+ MB', color:'#F59E0B' },
  ].filter(Boolean) as Array<{icon:string;label:string;saving:string;color:string}>;

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={styles.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={styles.backBtn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={styles.title}>Storage Prediction</Text>
        <TouchableOpacity onPress={refreshDeviceStats} style={styles.backBtn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>
      <ScrollView contentContainerStyle={styles.body}>
        <LinearGradient colors={daysToFull < 7 ? ['#7F1D1D','#EF4444'] : daysToFull < 30 ? ['#78350F','#F59E0B'] : ['#14532D','#22C55E']} style={styles.heroCard}>
          <Icon name={daysToFull<7?'harddisk-remove':daysToFull<30?'harddisk-plus':'harddisk'} size={36} color="#fff"/>
          <Text style={styles.heroLabel}>{urgencyLabel}</Text>
          <Text style={styles.heroBig}>{daysToFull < 999 ? `~${daysToFull} days` : 'Plenty of space'}</Text>
          <Text style={styles.heroSub}>until storage is full at current usage rate</Text>
        </LinearGradient>

        <View style={styles.statsRow}>
          {[
            { label:'Used',    value:`${deviceStats.storageUsed} GB`,   color: usedPct>80?C.danger:C.primary },
            { label:'Free',    value:`${freeGB} GB`,                     color: freeGB<5?C.danger:C.success  },
            { label:'Total',   value:`${deviceStats.storageTotal} GB`,   color: C.textSecondary               },
            { label:'Used %',  value:`${usedPct}%`,                      color: urgencyColor                  },
          ].map(st => (
            <View key={st.label} style={styles.statCard}>
              <Text style={[styles.statVal,{color:st.color}]}>{st.value}</Text>
              <Text style={styles.statLabel}>{st.label}</Text>
            </View>
          ))}
        </View>

        {recs.length > 0 && (
          <>
            <Text style={styles.sectionTitle}>Recommendations</Text>
            {recs.map(r => (
              <View key={r.label} style={styles.recCard}>
                <View style={[styles.recIcon,{backgroundColor:r.color+'22'}]}>
                  <Icon name={r.icon} size={22} color={r.color}/>
                </View>
                <View style={{flex:1,marginLeft:14}}>
                  <Text style={styles.recLabel}>{r.label}</Text>
                  <Text style={styles.recSaving}>Potential saving: {r.saving}</Text>
                </View>
                <Icon name="chevron-right" size={18} color={C.textMuted}/>
              </View>
            ))}
          </>
        )}

        {totalCleaned > 0 && (
          <View style={styles.cleanedBanner}>
            <Icon name="check-circle" size={18} color={C.success}/>
            <Text style={styles.cleanedText}>AuroCleaner has freed {(totalCleaned/1073741824).toFixed(2)} GB total on this device</Text>
          </View>
        )}
        <View style={{height:40}}/>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20},
  backBtn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  body:{paddingHorizontal:20,paddingTop:20},
  heroCard:{borderRadius:radius.card,padding:28,alignItems:'center',marginBottom:20,gap:8},
  heroLabel:{fontSize:13,fontWeight:'700',color:'rgba(255,255,255,0.7)',letterSpacing:1,textTransform:'uppercase'},
  heroBig:{fontSize:32,fontWeight:'900',color:'#fff'}, heroSub:{fontSize:12,color:'rgba(255,255,255,0.6)',textAlign:'center'},
  statsRow:{flexDirection:'row',flexWrap:'wrap',gap:12,marginBottom:20},
  statCard:{flex:1,minWidth:'40%',backgroundColor:C.card,borderRadius:radius.xl,padding:16,alignItems:'center',gap:6,borderWidth:1,borderColor:C.border},
  statVal:{fontSize:20,fontWeight:'900'}, statLabel:{fontSize:11,color:C.textMuted},
  sectionTitle:{fontSize:16,fontWeight:'700',color:C.textPrimary,marginBottom:12},
  recCard:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:10,borderWidth:1,borderColor:C.border},
  recIcon:{width:46,height:46,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  recLabel:{fontSize:14,fontWeight:'700',color:C.textPrimary}, recSaving:{fontSize:12,color:C.textMuted,marginTop:2},
  cleanedBanner:{flexDirection:'row',alignItems:'center',gap:10,backgroundColor:C.card,borderRadius:radius.xl,padding:14,borderWidth:1,borderColor:C.border,marginTop:8},
  cleanedText:{flex:1,fontSize:13,color:C.success,fontWeight:'600'},
});
