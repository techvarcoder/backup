import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

interface Insight { icon: string; title: string; desc: string; color: string; action: string; }

export default function AIInsightsScreen() {
  const navigation = useNavigation();
  const { deviceStats, totalCleaned, cleanHistory, refreshDeviceStats } = useAppStore();
  const healthScore = deviceStats.healthScore;
  const [loading, setLoading] = useState(true);
  const [insights, setInsights] = useState<Insight[]>([]);

  const buildInsights = () => {
    setLoading(true);
    const items: Insight[] = [];
    const storagePct = Math.round((deviceStats.storageUsed / deviceStats.storageTotal) * 100);
    const daysToFull = storagePct > 0
      ? Math.round(((deviceStats.storageTotal - deviceStats.storageUsed) / deviceStats.storageUsed) * 30)
      : 999;

    if (storagePct > 85) {
      items.push({ icon:'harddisk-remove', title:'Storage Critical', desc:`${storagePct}% used — only ${(deviceStats.storageTotal-deviceStats.storageUsed).toFixed(1)} GB remaining`, color:'#EF4444', action:'Clean Now' });
    } else if (storagePct > 60) {
      items.push({ icon:'chart-line', title:'Storage Filling Up', desc:`${storagePct}% used · at this rate, full in ~${daysToFull} days`, color:'#F59E0B', action:'Review' });
    }

    if (deviceStats.batteryLevel < 30 && !deviceStats.isCharging) {
      items.push({ icon:'battery-alert', title:'Battery Low', desc:`Battery at ${deviceStats.batteryLevel}% — plug in to avoid shutdown`, color:'#EF4444', action:'View' });
    } else if (deviceStats.batteryHealth > 0 && deviceStats.batteryHealth < 70) {
      items.push({ icon:'battery-heart-outline', title:'Battery Health Declining', desc:`Health at ${deviceStats.batteryHealth}% — consider replacement`, color:'#F59E0B', action:'View' });
    }

    const ramPct = Math.round((deviceStats.ramUsed / deviceStats.ramTotal) * 100);
    if (ramPct > 80) {
      items.push({ icon:'memory', title:'RAM Under Pressure', desc:`${deviceStats.ramUsed} GB of ${deviceStats.ramTotal} GB in use — performance may be affected`, color:'#8B5CF6', action:'Boost' });
    }

    if (deviceStats.temperature > 42) {
      items.push({ icon:'thermometer-alert', title:'Device Running Hot', desc:`Temperature at ${deviceStats.temperature}°C — close background apps`, color:'#EF4444', action:'Cool Down' });
    }

    if (cleanHistory.length > 0) {
      const lastClean = cleanHistory[0];
      const lastDate = new Date(lastClean.date); const daysSince = Math.floor((Date.now() - lastDate.getTime()) / 86400000);
      if (daysSince >= 7) {
        items.push({ icon:'broom', title:'Cleanup Overdue', desc:`Last cleaned ${daysSince} day${daysSince!==1?'s':''} ago — junk is accumulating`, color:'#3B82F6', action:'Clean' });
      } else {
        items.push({ icon:'check-circle', title:'Recently Cleaned', desc:`Last cleanup freed ${lastClean.freedGB.toFixed(2)} GB, ${daysSince} day${daysSince!==1?'s':''} ago`, color:'#22C55E', action:'View' });
      }
    } else {
      items.push({ icon:'broom', title:'Run Your First Cleanup', desc:'No cleanups yet — start scanning to free up space', color:'#3B82F6', action:'Scan' });
    }

    if (healthScore < 50) {
      items.push({ icon:'shield-alert', title:'Device Health Poor', desc:`Health score: ${healthScore}% — multiple issues need attention`, color:'#EF4444', action:'Fix' });
    } else if (healthScore >= 80) {
      items.push({ icon:'shield-check', title:'Device in Great Shape', desc:`Health score: ${healthScore}% — keep it up!`, color:'#22C55E', action:'View' });
    }

    setInsights(items.length > 0 ? items : [{ icon:'check-circle', title:'All Good!', desc:'No issues detected on your device right now', color:'#22C55E', action:'View' }]);
    setLoading(false);
  };

  useFocusEffect(React.useCallback(() => { refreshDeviceStats(); buildInsights(); }, [deviceStats.storageUsed, deviceStats.batteryLevel, healthScore]));

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={styles.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={styles.backBtn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={styles.title}>AI Insights</Text>
        <TouchableOpacity onPress={buildInsights} style={styles.backBtn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>
      <ScrollView contentContainerStyle={styles.body}>
        <LinearGradient colors={['#1E1B4B','#2563EB']} style={styles.heroCard}>
          <Icon name="robot-outline" size={36} color="#fff"/>
          <Text style={styles.heroTitle}>AI Analysis Complete</Text>
          <Text style={styles.heroSub}>{insights.length} insight{insights.length!==1?'s':''} based on your real device data</Text>
        </LinearGradient>

        {loading
          ? <ActivityIndicator color={C.primary} style={{marginTop:20}}/>
          : insights.map((ins, i) => (
            <View key={i} style={styles.insightCard}>
              <View style={[styles.insIcon,{backgroundColor:ins.color+'22'}]}>
                <Icon name={ins.icon} size={22} color={ins.color}/>
              </View>
              <View style={{flex:1,marginLeft:12}}>
                <Text style={styles.insTitle}>{ins.title}</Text>
                <Text style={styles.insSub}>{ins.desc}</Text>
              </View>
              <TouchableOpacity style={[styles.insAction,{borderColor:ins.color}]}>
                <Text style={[styles.insActionText,{color:ins.color}]}>{ins.action}</Text>
              </TouchableOpacity>
            </View>
          ))
        }
        <View style={{height:40}}/>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20},
  backBtn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  body:{paddingHorizontal:20,paddingTop:20},
  heroCard:{borderRadius:radius.card,padding:28,alignItems:'center',marginBottom:20},
  heroTitle:{fontSize:20,fontWeight:'800',color:'#fff',marginTop:12}, heroSub:{fontSize:13,color:'rgba(255,255,255,0.7)',marginTop:4,textAlign:'center'},
  insightCard:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:16,marginBottom:10,borderWidth:1,borderColor:C.border},
  insIcon:{width:48,height:48,borderRadius:radius.xl,justifyContent:'center',alignItems:'center'},
  insTitle:{fontSize:14,fontWeight:'700',color:C.textPrimary}, insSub:{fontSize:12,color:C.textMuted,marginTop:2,lineHeight:17},
  insAction:{borderWidth:1.5,borderRadius:radius.pill,paddingHorizontal:12,paddingVertical:6},
  insActionText:{fontSize:12,fontWeight:'700'},
});
