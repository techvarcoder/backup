
import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Animated, Dimensions, StatusBar, RefreshControl,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../navigation/types';
import { CircularProgress } from '../../components/ui/CircularProgress';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { SectionHeader } from '../../components/ui/SectionHeader';
import { darkColors as C, radius, spacing } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

const { width } = Dimensions.get('window');
type Nav = NativeStackNavigationProp<RootStackParamList>;

function timeAgo(iso: string): string {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (diff < 60) return 'Just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

const QUICK_ACTIONS = [
  { icon:'delete-sweep', label:'Junk Clean', color:['#2563EB','#1D4ED8'] as string[], nav:'SmartScan' as keyof RootStackParamList },
  { icon:'battery-80',   label:'Battery',    color:['#22C55E','#16A34A'] as string[], nav:'BatteryMonitor' as keyof RootStackParamList },
  { icon:'cpu-64-bit',   label:'CPU',         color:['#F59E0B','#D97706'] as string[], nav:'CPUMonitor' as keyof RootStackParamList },
  { icon:'memory',       label:'RAM Boost',  color:['#8B5CF6','#6D28D9'] as string[], nav:'RAMMonitor' as keyof RootStackParamList },
];

export default function HomeScreen() {
  const navigation = useNavigation<Nav>();
  const { deviceStats, recentActivity, isLoadingStats, refreshDeviceStats } = useAppStore();
  const scrollY = useRef(new Animated.Value(0)).current;
  const headerOpacity = scrollY.interpolate({ inputRange:[0,80], outputRange:[0,1], extrapolate:'clamp' });
  const storageUsedPct = Math.round((deviceStats.storageUsed / deviceStats.storageTotal) * 100);
  const ramUsedPct     = Math.round((deviceStats.ramUsed / deviceStats.ramTotal) * 100);

  useFocusEffect(
    React.useCallback(() => { refreshDeviceStats(); }, [])
  );

  const suggestions = [
    deviceStats.junkSize > 0 && {
      icon:'delete-sweep', color:'#3B82F6',
      title:`Free up ${deviceStats.junkSize.toFixed(2)} GB`,
      sub:'Clean Junk files', action:'SmartScan' as keyof RootStackParamList,
    },
    ramUsedPct > 70 && {
      icon:'speedometer', color:'#22C55E',
      title:`${deviceStats.ramUsed.toFixed(1)} GB RAM used`,
      sub:'Boost performance now', action:'RAMMonitor' as keyof RootStackParamList,
    },
    deviceStats.batteryLevel < 30 && {
      icon:'battery-alert', color:'#EF4444',
      title:`Battery at ${deviceStats.batteryLevel}%`,
      sub:'Battery saver mode', action:'BatteryMonitor' as keyof RootStackParamList,
    },
    storageUsedPct > 75 && {
      icon:'harddisk', color:'#F59E0B',
      title:`Storage ${storageUsedPct}% full`,
      sub:'Find large files', action:'LargeFileFinder' as keyof RootStackParamList,
    },
  ].filter(Boolean) as Array<{icon:string;color:string;title:string;sub:string;action:keyof RootStackParamList}>;

  if (suggestions.length === 0) {
    suggestions.push({ icon:'check-circle', color:'#22C55E', title:'Your device is healthy', sub:'Nothing to clean right now', action:'SmartScan' });
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <Animated.View style={[styles.stickyHeader, { opacity: headerOpacity }]}>
        <Text style={styles.stickyTitle}>AuroCleaner</Text>
      </Animated.View>

      <Animated.ScrollView
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        refreshControl={
          <RefreshControl refreshing={isLoadingStats} onRefresh={refreshDeviceStats} tintColor={C.primary} />
        }
      >
        {/* Header */}
        <LinearGradient colors={['#0A1628','#0F172A']} style={styles.headerSection}>
          <View style={styles.topRow}>
            <View>
              <Text style={styles.greeting}>Good morning</Text>
              <Text style={styles.brand}>AuroCleaner</Text>
            </View>
            <View style={styles.topActions}>
              <TouchableOpacity style={styles.iconBtn} onPress={() => navigation.navigate('SmartAlerts')}>
                <Icon name="bell-outline" size={22} color={C.textSecondary} />
                <View style={styles.badge} />
              </TouchableOpacity>
              <TouchableOpacity style={styles.iconBtn} onPress={() => navigation.navigate('Settings')}>
                <Icon name="cog-outline" size={22} color={C.textSecondary} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Health score ring */}
          <View style={styles.healthRow}>
            <View style={styles.healthLeft}>
              <CircularProgress size={120} progress={deviceStats.healthScore} strokeWidth={10} color={C.success}>
                <Text style={styles.scoreNum}>{deviceStats.healthScore}</Text>
                <Text style={styles.scoreLabel}>Score</Text>
              </CircularProgress>
            </View>
            <View style={styles.healthRight}>
              <StatRow icon="harddisk"     label="Storage" value={`${storageUsedPct}% used`}            color="#3B82F6" />
              <StatRow icon="memory"        label="RAM"     value={`${deviceStats.ramUsed}/${deviceStats.ramTotal} GB`} color="#8B5CF6" />
              <StatRow icon="battery-heart" label="Battery" value={`${deviceStats.batteryLevel}%${deviceStats.isCharging?' ⚡':''}`}  color="#22C55E" />
              <StatRow icon="thermometer"   label="Temp"    value={deviceStats.temperature > 0 ? `${deviceStats.temperature}°C` : '—'}      color="#F59E0B" />
            </View>
          </View>
        </LinearGradient>

        {/* Scan CTA */}
        <TouchableOpacity
          style={styles.scanCTA}
          onPress={() => navigation.navigate('SmartScan')}
        >
          <LinearGradient colors={C.gradientPrimary} style={styles.scanGradient}>
            <Icon name="radar" size={28} color="#fff" />
            <View style={{ flex:1 }}>
              <Text style={styles.scanTitle}>Smart Scan</Text>
              <Text style={styles.scanSub}>
                {deviceStats.junkSize > 0
                  ? `${deviceStats.junkSize.toFixed(2)} GB found last scan`
                  : 'Tap to scan your device'}
              </Text>
            </View>
            <Icon name="chevron-right" size={24} color="rgba(255,255,255,0.7)" />
          </LinearGradient>
        </TouchableOpacity>

        {/* Storage bar */}
        <View style={styles.section}>
          <SectionHeader title="Storage" action="Details" onAction={() => navigation.navigate('StorageTimeline')} />
          <View style={styles.storageCard}>
            <View style={styles.storageTopRow}>
              <Text style={styles.storageUsed}>{deviceStats.storageUsed} GB used</Text>
              <Text style={styles.storageTotal}>{deviceStats.storageTotal} GB total</Text>
            </View>
            <ProgressBar
              progress={storageUsedPct}
              color={storageUsedPct > 85 ? C.danger : storageUsedPct > 65 ? C.warning : C.primary}
              height={8}
              style={styles.storageProg}
            />
            <View style={styles.segRow}>
              {[
                { label:'Apps',  pct:22, color:'#F59E0B' },
                { label:'Media', pct:35, color:'#3B82F6' },
                { label:'System',pct:15, color:'#8B5CF6' },
                { label:'Other', pct:storageUsedPct-72 > 0 ? storageUsedPct-72 : 3, color:'#22C55E' },
              ].map(s => (
                <View key={s.label} style={styles.segItem}>
                  <View style={[styles.segDot, { backgroundColor:s.color }]} />
                  <Text style={styles.segLabel}>{s.label}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>

        {/* Quick actions */}
        <View style={styles.section}>
          <SectionHeader title="Quick Actions" />
          <View style={styles.qaRow}>
            {QUICK_ACTIONS.map(qa => (
              <TouchableOpacity key={qa.nav} style={styles.qaItem} onPress={() => (navigation as any).navigate(qa.nav)}>
                <LinearGradient colors={qa.color} style={styles.qaIcon}>
                  <Icon name={qa.icon} size={22} color="#fff" />
                </LinearGradient>
                <Text style={styles.qaLabel}>{qa.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* AI Suggestions */}
        {suggestions.length > 0 && (
          <View style={styles.section}>
            <SectionHeader title="Suggestions" action="View All" onAction={() => navigation.navigate('AIInsights')} />
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap:12, paddingHorizontal:0 }}>
              {suggestions.map((s, i) => (
                <TouchableOpacity key={i} onPress={() => (navigation as any).navigate(s.action)}>
                  <LinearGradient colors={['#1E293B','#162032']} style={styles.suggCard}>
                    <View style={[styles.suggIcon, { backgroundColor: s.color+'22' }]}>
                      <Icon name={s.icon} size={22} color={s.color} />
                    </View>
                    <Text style={styles.suggTitle}>{s.title}</Text>
                    <Text style={styles.suggSub}>{s.sub}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

        {/* Recent Activity */}
        {recentActivity.length > 0 && (
          <View style={styles.section}>
            <SectionHeader title="Recent Activity" action="History" onAction={() => navigation.navigate('HealthHistory')} />
            <View style={styles.actCard}>
              {recentActivity.slice(0,4).map(a => (
                <View key={a.id} style={styles.actRow}>
                  <View style={[styles.actIcon, { backgroundColor:a.color+'22' }]}>
                    <Icon name={a.icon} size={18} color={a.color} />
                  </View>
                  <View style={{ flex:1 }}>
                    <Text style={styles.actTitle}>{a.title}</Text>
                    <Text style={styles.actSub}>{a.subtitle}</Text>
                  </View>
                  <Text style={styles.actTime}>{timeAgo(a.time)}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        <View style={{ height:100 }} />
      </Animated.ScrollView>
    </View>
  );
}

const StatRow = ({ icon, label, value, color }: { icon:string; label:string; value:string; color:string }) => (
  <View style={styles.statRow}>
    <Icon name={icon} size={16} color={color} />
    <Text style={styles.statLabel}>{label}</Text>
    <Text style={styles.statValue}>{value}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: { flex:1, backgroundColor:'#0A0F1E' },
  stickyHeader: { position:'absolute', top:0, left:0, right:0, zIndex:99, paddingTop:52, paddingHorizontal:20, paddingBottom:12, backgroundColor:'#0A0F1E' },
  stickyTitle: { fontSize:18, fontWeight:'800', color:'#fff', textAlign:'center' },
  headerSection: { paddingTop:56, paddingHorizontal:20, paddingBottom:20 },
  topRow: { flexDirection:'row', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20 },
  greeting: { fontSize:13, color:C.textMuted },
  brand: { fontSize:24, fontWeight:'900', color:C.textPrimary, marginTop:2 },
  topActions: { flexDirection:'row', gap:8 },
  iconBtn: { width:40, height:40, backgroundColor:C.card, borderRadius:radius.xl, justifyContent:'center', alignItems:'center' },
  badge: { position:'absolute', top:8, right:8, width:8, height:8, borderRadius:4, backgroundColor:C.danger, borderWidth:2, borderColor:'#0A1628' },
  healthRow: { flexDirection:'row', alignItems:'center', gap:20 },
  healthLeft: {},
  healthRight: { flex:1, gap:8 },
  scoreNum: { fontSize:26, fontWeight:'900', color:C.textPrimary, textAlign:'center' },
  scoreLabel: { fontSize:11, color:C.textMuted, textAlign:'center' },
  statRow: { flexDirection:'row', alignItems:'center', gap:8 },
  statLabel: { flex:1, fontSize:12, color:C.textMuted },
  statValue: { fontSize:12, color:C.textSecondary, fontWeight:'700' },
  scanCTA: { marginHorizontal:20, marginTop:16, borderRadius:radius.card, overflow:'hidden' },
  scanGradient: { flexDirection:'row', alignItems:'center', padding:18, gap:16 },
  scanTitle: { fontSize:16, fontWeight:'800', color:'#fff' },
  scanSub: { fontSize:12, color:'rgba(255,255,255,0.7)', marginTop:2 },
  section: { marginTop:20, paddingHorizontal:20 },
  storageCard: { backgroundColor:C.card, borderRadius:radius.xl, padding:16, borderWidth:1, borderColor:C.border },
  storageTopRow: { flexDirection:'row', justifyContent:'space-between', marginBottom:10 },
  storageUsed: { fontSize:14, fontWeight:'700', color:C.textPrimary },
  storageTotal: { fontSize:13, color:C.textMuted },
  storageProg: { marginBottom:12 },
  segRow: { flexDirection:'row', gap:16 },
  segItem: { flexDirection:'row', alignItems:'center', gap:6 },
  segDot: { width:8, height:8, borderRadius:4 },
  segLabel: { fontSize:11, color:C.textMuted },
  qaRow: { flexDirection:'row', justifyContent:'space-between', gap:12 },
  qaItem: { flex:1, alignItems:'center', gap:8 },
  qaIcon: { width:52, height:52, borderRadius:radius.lg, justifyContent:'center', alignItems:'center' },
  qaLabel: { fontSize:11, color:C.textMuted, textAlign:'center', fontWeight:'600' },
  suggCard: { width:160, borderRadius:radius.xl, padding:16, borderWidth:1, borderColor:C.border, gap:10 },
  suggIcon: { width:40, height:40, borderRadius:radius.md, justifyContent:'center', alignItems:'center' },
  suggTitle: { fontSize:13, fontWeight:'700', color:C.textPrimary },
  suggSub: { fontSize:11, color:C.textMuted },
  actCard: { backgroundColor:C.card, borderRadius:radius.xl, overflow:'hidden', borderWidth:1, borderColor:C.border },
  actRow: { flexDirection:'row', alignItems:'center', padding:14, gap:12, borderBottomWidth:1, borderBottomColor:C.border },
  actIcon: { width:36, height:36, borderRadius:radius.md, justifyContent:'center', alignItems:'center' },
  actTitle: { fontSize:13, fontWeight:'700', color:C.textPrimary },
  actSub: { fontSize:11, color:C.textMuted, marginTop:2 },
  actTime: { fontSize:11, color:C.textMuted },
});
