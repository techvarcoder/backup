import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, Switch } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { darkColors as C, radius, spacing } from '../../theme';

const SCHEDULES = [
  { label: 'Daily Cleanup',       sub: 'Every day at 02:00 AM',     enabled: true,  color: C.primary },
  { label: 'Weekly Cleanup',      sub: 'Every Sunday at 11:00 PM',  enabled: true,  color: C.success },
  { label: 'Charging Cleanup',    sub: 'When phone is charging',    enabled: false, color: C.warning },
  { label: 'Low Storage Cleanup', sub: 'When storage below 15%',   enabled: true,  color: C.danger },
];

function computeNextCleanup(enabled: boolean[]): string {
  const now = new Date();
  function fmt(d: Date, timeStr: string): string {
    const todayStr  = now.toDateString();
    const tomorrowStr = new Date(now.getTime() + 86400000).toDateString();
    if (d.toDateString() === todayStr)     return `Today at ${timeStr}`;
    if (d.toDateString() === tomorrowStr)  return `Tomorrow at ${timeStr}`;
    return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }) + ` at ${timeStr}`;
  }
  if (enabled[0]) {                        // Daily at 02:00 AM
    const next = new Date(now); next.setHours(2, 0, 0, 0);
    if (next <= now) next.setDate(next.getDate() + 1);
    return fmt(next, '02:00 AM');
  }
  if (enabled[1]) {                        // Weekly — next Sunday 11 PM
    const daysToSun = now.getDay() === 0 && now.getHours() < 23 ? 0 : (7 - now.getDay()) % 7 || 7;
    const next = new Date(now); next.setDate(now.getDate() + daysToSun); next.setHours(23, 0, 0, 0);
    return fmt(next, '11:00 PM');
  }
  if (enabled[2]) return 'When charging';
  if (enabled[3]) return 'When storage < 15%';
  return 'No schedule active';
}

export default function ScheduleCleanupScreen() {
  const navigation = useNavigation();
  const [schedules, setSchedules] = React.useState(SCHEDULES.map(s => s.enabled));

  const nextCleanup = useMemo(() => computeNextCleanup(schedules), [schedules]);

  const toggle = (i: number) => setSchedules(prev => prev.map((v, idx) => idx === i ? !v : v));

  return (
    <LinearGradient colors={['#0A0F1E', '#0F172A']} style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Icon name="arrow-left" size={22} color={C.textSecondary} />
        </TouchableOpacity>
        <Text style={styles.title}>Scheduled Cleanup</Text>
        <View style={{ width: 40 }} />
      </View>
      <ScrollView contentContainerStyle={styles.body}>
        <View style={styles.nextCard}>
          <Icon name="clock-outline" size={28} color={C.primary} />
          <View style={{ marginLeft: 14, flex: 1 }}>
            <Text style={styles.nextLabel}>Next Cleanup</Text>
            <Text style={styles.nextTime}>{nextCleanup}</Text>
          </View>
        </View>
        {SCHEDULES.map((s, i) => (
          <View key={s.label} style={styles.scheduleCard}>
            <View style={[styles.dot, { backgroundColor: s.color }]} />
            <View style={{ flex: 1 }}>
              <Text style={styles.schedLabel}>{s.label}</Text>
              <Text style={styles.schedSub}>{s.sub}</Text>
            </View>
            <Switch
              value={schedules[i]}
              onValueChange={() => toggle(i)}
              trackColor={{ true: C.primary, false: C.border }}
              thumbColor="#fff"
            />
          </View>
        ))}
        <TouchableOpacity style={styles.addBtn}>
          <Icon name="plus" size={20} color={C.primary} />
          <Text style={styles.addText}>Add Custom Schedule</Text>
        </TouchableOpacity>
        <View style={{ height: 40 }} />
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 56, paddingHorizontal: 20 },
  backBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 18, fontWeight: '700', color: C.textPrimary },
  body: { paddingHorizontal: 20, paddingTop: 20 },
  nextCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: radius.card, padding: 20, marginBottom: 20, borderWidth: 1, borderColor: C.border },
  nextLabel: { fontSize: 12, color: C.textMuted },
  nextTime: { fontSize: 18, fontWeight: '700', color: C.textPrimary },
  scheduleCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: radius.xl, padding: 16, marginBottom: 10, gap: 12 },
  dot: { width: 10, height: 10, borderRadius: 5 },
  schedLabel: { fontSize: 14, fontWeight: '600', color: C.textPrimary },
  schedSub: { fontSize: 12, color: C.textMuted, marginTop: 2 },
  addBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 16, paddingVertical: 14, borderWidth: 1.5, borderColor: C.primary, borderRadius: radius.button, borderStyle: 'dashed' },
  addText: { fontSize: 14, color: C.primary, fontWeight: '600' },
});
