import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  PermissionsAndroid, Platform, Linking, Alert,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { useFocusEffect } from '@react-navigation/native';
import { RootStackParamList } from '../../navigation/types';
import { PrimaryButton } from '../../components/ui/PrimaryButton';
import { darkColors as C, radius, spacing } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

type Props = { navigation: NativeStackNavigationProp<RootStackParamList, 'Permissions'> };

// Android API level
const API = Platform.OS === 'android' ? (Platform.Version as number) : 0;

// ─── permission definitions ────────────────────────────────────────────────
// 'runtime'  → PermissionsAndroid.request()
// 'settings' → open a specific Settings screen via Linking
const PERMISSIONS = [
  {
    id: 'storage',
    icon: 'folder-outline',
    title: 'Storage Access',
    desc: 'Required to scan, clean junk files and manage your storage.',
    iconColors: ['#3B82F6', '#2563EB'] as string[],
    type: 'runtime' as const,
  },
  {
    id: 'notification',
    icon: 'bell-outline',
    title: 'Notification Access',
    desc: 'Lets AuroCleaner send cleanup reminders and important alerts.',
    iconColors: ['#F59E0B', '#D97706'] as string[],
    type: 'runtime' as const,
  },
  {
    id: 'usage',
    icon: 'chart-pie',
    title: 'Usage Stats Access',
    desc: 'Allows app usage analysis. Opens Usage Access settings — toggle AuroCleaner on.',
    iconColors: ['#8B5CF6', '#6D28D9'] as string[],
    type: 'settings' as const,
    settingsUrl: 'android.settings.USAGE_ACCESS_SETTINGS',
  },
  {
    id: 'battery',
    icon: 'battery-80',
    title: 'Battery Optimization',
    desc: 'Exclude AuroCleaner from battery restrictions. Opens Battery Optimization settings.',
    iconColors: ['#22C55E', '#16A34A'] as string[],
    type: 'settings' as const,
    settingsUrl: 'android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS',
  },
  {
    id: 'media',
    icon: 'image-multiple-outline',
    title: 'Media Access',
    desc: 'Find and remove duplicate photos, videos and large media files.',
    iconColors: ['#06B6D4', '#0891B2'] as string[],
    type: 'runtime' as const,
  },
];

// Returns the Android permission strings to request for a given permission ID
function getAndroidPermissions(id: string): string[] {
  switch (id) {
    case 'storage':
      if (API >= 33) {
        // Android 13+: granular media permissions — shows native dialog
        return [
          'android.permission.READ_MEDIA_IMAGES',
          'android.permission.READ_MEDIA_VIDEO',
          'android.permission.READ_MEDIA_AUDIO',
        ];
      }
      if (API >= 29) {
        return [PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE];
      }
      return [
        PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
      ];
    case 'notification':
      // POST_NOTIFICATIONS is only a runtime permission on Android 13+ (API 33+)
      if (API >= 33) {
        return ['android.permission.POST_NOTIFICATIONS'];
      }
      return []; // pre-13 notifications don't require runtime grant
    case 'media':
      if (API >= 33) {
        return [
          'android.permission.READ_MEDIA_IMAGES',
          'android.permission.READ_MEDIA_VIDEO',
          'android.permission.READ_MEDIA_AUDIO',
        ];
      }
      return [PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE];
    default:
      return [];
  }
}

// Check if a permission ID is already granted
async function checkGranted(id: string): Promise<boolean> {
  if (Platform.OS !== 'android') return true;
  switch (id) {
    case 'storage': {
      if (API >= 33) {
        return PermissionsAndroid.check('android.permission.READ_MEDIA_IMAGES' as any);
      }
      return PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE);
    }
    case 'notification': {
      if (API >= 33) {
        return PermissionsAndroid.check('android.permission.POST_NOTIFICATIONS' as any);
      }
      return true; // pre-13: always "granted"
    }
    case 'media': {
      if (API >= 33) {
        return PermissionsAndroid.check('android.permission.READ_MEDIA_IMAGES' as any);
      }
      return PermissionsAndroid.check(PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE);
    }
    // usage & battery can't be checked via PermissionsAndroid
    default:
      return false;
  }
}

export default function PermissionsScreen({ navigation }: Props) {
  const [granted, setGranted] = useState<Set<string>>(new Set());
  // Tracks settings-type permissions the user has visited but we can't verify programmatically
  const [visitedSettings, setVisitedSettings] = useState<Set<string>>(new Set());
  const { setPermissionsGranted } = useAppStore();

  // Re-check actual OS grant status every time screen is focused
  // (user may have come back from Settings)
  useFocusEffect(useCallback(() => {
    (async () => {
      const grantedIds = new Set<string>();
      for (const p of PERMISSIONS) {
        const isGranted = await checkGranted(p.id);
        if (isGranted) grantedIds.add(p.id);
      }
      setGranted(grantedIds);
    })();
  }, []));

  const handleAllow = async (id: string, type: 'runtime' | 'settings', settingsUrl?: string) => {
    if (Platform.OS !== 'android') {
      setGranted(prev => new Set([...prev, id]));
      return;
    }

    if (type === 'settings') {
      // Special permissions need an Android Intent action — NOT a URL.
      // Linking.sendIntent() is the correct RN API for this.
      const action = settingsUrl ?? 'android.settings.APPLICATION_DETAILS_SETTINGS';
      try {
        await Linking.sendIntent(action);
      } catch {
        // sendIntent failed (older device / action not found) — fallback
        try {
          await Linking.openURL(`android-app://com.android.settings/android.settings.${action.split('.').pop()}`);
        } catch {
          await Linking.openSettings();
        }
      }
      // Mark as visited — when user returns, show "Mark as Done" button
      setVisitedSettings(prev => new Set([...prev, id]));
      // useFocusEffect re-checks grant status when user returns from Settings
      return;
    }

    const perms = getAndroidPermissions(id);
    if (perms.length === 0) {
      // e.g. notifications on Android < 13 — no runtime grant needed
      setGranted(prev => new Set([...prev, id]));
      return;
    }

    try {
      const results = await PermissionsAndroid.requestMultiple(perms as any[]);
      const allGranted = Object.values(results).every(
        r => r === PermissionsAndroid.RESULTS.GRANTED
      );
      if (allGranted) {
        setGranted(prev => new Set([...prev, id]));
      } else {
        const permanentlyDenied = Object.values(results).some(
          r => r === PermissionsAndroid.RESULTS.NEVER_ASK_AGAIN
        );
        if (permanentlyDenied) {
          Alert.alert(
            'Permission Blocked',
            'This permission was permanently denied. Please enable it in App Settings.',
            [
              { text: 'Cancel', style: 'cancel' },
              { text: 'Open Settings', onPress: () => Linking.openSettings() },
            ]
          );
        }
      }
    } catch {
      // Ignore — fallback gracefully
    }
  };

  const handleContinue = () => {
    setPermissionsGranted();
    navigation.replace('Main');
  };

  return (
    <LinearGradient colors={['#0A0F1E', '#0F172A']} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.stepText}>02. PERMISSION FLOW</Text>
        <Text style={styles.title}>Allow Permissions</Text>
        <Text style={styles.subtitle}>These permissions help AuroCleaner\nwork at its best.</Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.list}>
        {PERMISSIONS.map((p) => {
          const isGranted = granted.has(p.id);
          const wasVisited = visitedSettings.has(p.id);
          return (
            <View key={p.id} style={styles.card}>
              <LinearGradient colors={p.iconColors} style={styles.iconBox}>
                <Icon name={p.icon} size={24} color="#fff" />
              </LinearGradient>
              <View style={styles.info}>
                <Text style={styles.permTitle}>{p.title}</Text>
                <Text style={styles.permDesc}>{p.desc}</Text>
              </View>
              <View style={styles.actions}>
                {isGranted ? (
                  <View style={styles.grantedBadge}>
                    <Icon name="check" size={14} color={C.success} />
                    <Text style={styles.grantedText}>Allowed</Text>
                  </View>
                ) : wasVisited ? (
                  // User visited settings but we can't verify programmatically — let them confirm
                  <View style={styles.btnRow}>
                    <TouchableOpacity onPress={handleContinue}>
                      <Text style={styles.skipTxt}>Skip</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={styles.doneBtn}
                      onPress={() => setGranted(prev => new Set([...prev, p.id]))}>
                      <Icon name="check" size={14} color="#fff" />
                      <Text style={styles.allowText}>Done</Text>
                    </TouchableOpacity>
                  </View>
                ) : (
                  <View style={styles.btnRow}>
                    <TouchableOpacity onPress={handleContinue}>
                      <Text style={styles.skipTxt}>Skip</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={[styles.allowBtn, p.type === 'settings' && styles.allowBtnSettings]}
                      onPress={() => handleAllow(p.id, p.type, (p as any).settingsUrl)}>
                      <Text style={styles.allowText}>
                        {p.type === 'settings' ? 'Open Settings' : 'Allow'}
                      </Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            </View>
          );
        })}
      </ScrollView>

      <View style={styles.cta}>
        <PrimaryButton title="Continue" onPress={handleContinue} style={styles.btn} />
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingTop: 60, paddingHorizontal: 24, paddingBottom: 20 },
  stepText: { fontSize: 11, color: C.primary, fontWeight: '700', letterSpacing: 1.5, marginBottom: 8 },
  title: { fontSize: 28, fontWeight: '800', color: C.textPrimary, marginBottom: 8 },
  subtitle: { fontSize: 14, color: C.textMuted, lineHeight: 22 },
  list: { paddingHorizontal: 24, paddingBottom: 20 },
  card: {
    backgroundColor: C.card,
    borderRadius: radius.card,
    padding: spacing.lg,
    marginBottom: spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: C.border,
  },
  iconBox: {
    width: 48,
    height: 48,
    borderRadius: radius.xl,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
    flexShrink: 0,
  },
  info: { flex: 1, marginRight: 8 },
  permTitle: { fontSize: 14, fontWeight: '700', color: C.textPrimary, marginBottom: 4 },
  permDesc: { fontSize: 12, color: C.textMuted, lineHeight: 18 },
  actions: { alignItems: 'flex-end' },
  btnRow: { alignItems: 'flex-end', gap: 8 },
  allowBtn: {
    backgroundColor: C.primary,
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: radius.pill,
  },
  allowBtnSettings: {
    backgroundColor: C.warning,
  },
  doneBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: C.success,
    paddingHorizontal: 14,
    paddingVertical: 7,
    borderRadius: radius.pill,
  },
  allowText: { fontSize: 12, color: '#fff', fontWeight: '700' },
  skipTxt: { fontSize: 12, color: C.textMuted },
  grantedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: C.success + '22',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: radius.pill,
    gap: 4,
  },
  grantedText: { fontSize: 12, color: C.success, fontWeight: '600' },
  cta: { paddingHorizontal: 24, paddingBottom: 36 },
  btn: { width: '100%' },
});
