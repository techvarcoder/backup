
import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { CircularProgress } from '../../components/ui/CircularProgress';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

// Deterministic color from package name
function pkgColor(pkg: string): string {
  const palette = ['#3B82F6','#8B5CF6','#EC4899','#F59E0B','#10B981','#EF4444','#06B6D4','#F97316'];
  let hash = 0;
  for (let i = 0; i < pkg.length; i++) { hash = pkg.charCodeAt(i) + ((hash << 5) - hash); }
  return palette[Math.abs(hash) % palette.length];
}

// System package prefixes to filter out
const SYSTEM_PREFIXES = [
  'com.android.', 'android.', 'com.google.android.', 'com.samsung.android.',
  'com.miui.', 'com.sec.android.', 'com.qualcomm.', 'com.mediatek.', 'com.bikedex',
];
function isSystemApp(pkg: string): boolean {
  return SYSTEM_PREFIXES.some(p => pkg.startsWith(p));
}

interface AppEntry { name: string; pkg: string; ramMB: number; color: string; }

export default function RAMMonitorScreen() {
  const navigation = useNavigation();
  const { deviceStats, refreshDeviceStats, updateDeviceStats, addActivity } = useAppStore();
  const [boosting, setBoosting]   = useState(false);
  const [boosted, setBoosted]     = useState(false);
  const [apps, setApps]           = useState<AppEntry[]>([]);
  const [loadingApps, setLoadingApps] = useState(false);

  const loadRealApps = async (ramUsedGB: number) => {
    setLoadingApps(true);
    try {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const DI = require('react-native-device-info').default ?? require('react-native-device-info');
      const installed: Array<{ appName: string; packageName: string }> = await DI.getInstalledApplications();
      const userApps = installed
        .filter(a => a.packageName && !isSystemApp(a.packageName))
        .sort((a, b) => (a.appName || '').localeCompare(b.appName || ''))
        .slice(0, 8);

      // Distribute real ramUsed proportionally across top apps (Android API restricts per-app RAM access)
      const ramUsedMB = Math.round(ramUsedGB * 1024);
      const weights   = [0.22, 0.17, 0.14, 0.12, 0.10, 0.09, 0.08, 0.08];
      const entries: AppEntry[] = userApps.map((a, i) => ({
        name:  a.appName || a.packageName,
        pkg:   a.packageName,
        ramMB: Math.round(ramUsedMB * (weights[i] ?? 0.05)),
        color: pkgColor(a.packageName),
      }));
      setApps(entries);
    } catch {
      setApps([]);
    } finally {
      setLoadingApps(false);
    }
  };

  useFocusEffect(
    React.useCallback(() => {
      refreshDeviceStats();
      loadRealApps(deviceStats.ramUsed);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])
  );

  const ramPct   = Math.round((deviceStats.ramUsed / deviceStats.ramTotal) * 100);
  const ramColor = ramPct > 75 ? C.danger : ramPct > 50 ? C.warning : C.success;

  const handleBoost = async () => {
    setBoosting(true);
    try {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      const DI = require('react-native-device-info').default ?? require('react-native-device-info');
      const memBefore: number = await DI.getUsedMemory();   // bytes used before GC
      // Trigger JS garbage collection (best-effort on Android)
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const g = (globalThis as any);
      if (typeof g.gc === 'function') { g.gc(); }
      await new Promise<void>(r => setTimeout(r, 1500));
      const memAfter: number = await DI.getUsedMemory();    // bytes used after GC
      const freedBytes = Math.max(0, memBefore - memAfter);
      const freedGB    = parseFloat((freedBytes / 1073741824).toFixed(2));
      const newUsed    = parseFloat((deviceStats.ramUsed - freedGB).toFixed(2));
      updateDeviceStats({ ramUsed: Math.max(0.1, newUsed) });
      const label = freedGB > 0 ? `${freedGB} GB freed` : 'Cache cleared';
      addActivity({ title: 'RAM Boosted', subtitle: label, time: new Date().toISOString(), icon: 'memory', color: '#22C55E' });
    } catch {
      // If DI unavailable, at least refresh real stats
      await refreshDeviceStats();
    } finally {
      setBoosting(false);
      setBoosted(true);
      setTimeout(() => setBoosted(false), 3000);
    }
  };

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}>
          <Icon name="arrow-left" size={22} color={C.textSecondary} />
        </TouchableOpacity>
        <Text style={s.title}>RAM Monitor</Text>
        <TouchableOpacity onPress={() => { refreshDeviceStats(); loadRealApps(deviceStats.ramUsed); }} style={s.back}>
          <Icon name="refresh" size={20} color={C.primary} />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom:40 }}>
        <View style={s.gaugeSection}>
          <CircularProgress size={160} progress={ramPct} strokeWidth={14} color={ramColor}>
            <Icon name="memory" size={28} color={ramColor} />
            <Text style={[s.gaugeNum, { color: ramColor }]}>{deviceStats.ramUsed} GB</Text>
            <Text style={s.gaugeSub}>of {deviceStats.ramTotal} GB</Text>
          </CircularProgress>
        </View>

        <View style={s.statsGrid}>
          {[
            { label:'Used',  value:`${deviceStats.ramUsed} GB`,                                                      color:'#EF4444' },
            { label:'Free',  value:`${parseFloat((deviceStats.ramTotal - deviceStats.ramUsed).toFixed(1))} GB`,       color:'#22C55E' },
            { label:'Total', value:`${deviceStats.ramTotal} GB`,                                                      color:'#3B82F6' },
            { label:'Usage', value:`${ramPct}%`,                                                                      color:'#F59E0B' },
          ].map(st => (
            <View key={st.label} style={s.statCard}>
              <Text style={[s.statVal, { color: st.color }]}>{st.value}</Text>
              <Text style={s.statLabel}>{st.label}</Text>
            </View>
          ))}
        </View>

        <View style={s.section}>
          <View style={s.sectionHeader}>
            <Text style={s.sectionTitle}>Installed Apps</Text>
            <Text style={s.sectionNote}>RAM share · estimated</Text>
          </View>
          {loadingApps ? (
            <ActivityIndicator color={C.primary} style={{ marginTop: 20 }} />
          ) : apps.length === 0 ? (
            <View style={s.emptyRow}>
              <Icon name="information-outline" size={16} color={C.textMuted} />
              <Text style={s.emptyText}>No user apps found</Text>
            </View>
          ) : (
            apps.map(app => {
              const barPct = Math.min(100, Math.round((app.ramMB / (deviceStats.ramUsed * 1024)) * 100));
              return (
                <View key={app.pkg} style={s.appRow}>
                  <View style={[s.appIcon, { backgroundColor: app.color + '22' }]}>
                    <Icon name="apps" size={20} color={app.color} />
                  </View>
                  <View style={s.appInfo}>
                    <Text style={s.appName} numberOfLines={1}>{app.name}</Text>
                    <View style={s.barTrack}>
                      <View style={[s.barFill, { width: `${barPct}%` as any, backgroundColor: app.color }]} />
                    </View>
                  </View>
                  <Text style={[s.appRam, { color: app.color }]}>{app.ramMB} MB</Text>
                </View>
              );
            })
          )}
        </View>

        <View style={s.boostSection}>
          {boosted && (
            <View style={s.boostedMsg}>
              <Icon name="check-circle" size={18} color={C.success} />
              <Text style={s.boostedText}>RAM cleared successfully!</Text>
            </View>
          )}
          <TouchableOpacity onPress={handleBoost} disabled={boosting} style={s.boostWrapper}>
            <LinearGradient colors={['#22C55E','#16A34A']} style={s.boostBtn}>
              {boosting
                ? <ActivityIndicator color="#fff" size="small" />
                : <><Icon name="rocket-launch" size={22} color="#fff" /><Text style={s.boostText}>Boost RAM</Text></>
              }
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container: { flex:1 },
  header: { flexDirection:'row', alignItems:'center', justifyContent:'space-between', paddingTop:56, paddingHorizontal:20, paddingBottom:12 },
  back: { width:40, height:40, justifyContent:'center', alignItems:'center' },
  title: { fontSize:18, fontWeight:'700', color:C.textPrimary },
  gaugeSection: { alignItems:'center', paddingVertical:24 },
  gaugeNum: { fontSize:24, fontWeight:'900', marginTop:4 },
  gaugeSub: { fontSize:11, color:C.textMuted },
  statsGrid: { flexDirection:'row', flexWrap:'wrap', gap:12, paddingHorizontal:20 },
  statCard: { flex:1, minWidth:'40%', backgroundColor:C.card, borderRadius:radius.xl, padding:16, alignItems:'center', gap:6, borderWidth:1, borderColor:C.border },
  statVal: { fontSize:20, fontWeight:'900' },
  statLabel: { fontSize:11, color:C.textMuted },
  section: { paddingHorizontal:20, marginTop:20 },
  sectionHeader: { flexDirection:'row', alignItems:'center', justifyContent:'space-between', marginBottom:12 },
  sectionTitle: { fontSize:14, fontWeight:'700', color:C.textSecondary },
  sectionNote: { fontSize:11, color:C.textMuted },
  emptyRow: { flexDirection:'row', alignItems:'center', gap:8, paddingVertical:16, justifyContent:'center' },
  emptyText: { fontSize:13, color:C.textMuted },
  appRow: { flexDirection:'row', alignItems:'center', gap:12, backgroundColor:C.card, borderRadius:radius.xl, padding:14, marginBottom:8, borderWidth:1, borderColor:C.border },
  appIcon: { width:40, height:40, borderRadius:radius.md, justifyContent:'center', alignItems:'center', flexShrink:0 },
  appInfo: { flex:1, gap:6 },
  appName: { fontSize:13, fontWeight:'600', color:C.textPrimary },
  barTrack: { height:4, backgroundColor:C.border, borderRadius:2, overflow:'hidden' },
  barFill: { height:4, borderRadius:2 },
  appRam: { fontSize:12, fontWeight:'700', flexShrink:0 },
  boostSection: { paddingHorizontal:20, marginTop:24 },
  boostedMsg: { flexDirection:'row', alignItems:'center', gap:8, justifyContent:'center', marginBottom:12 },
  boostedText: { fontSize:13, color:C.success, fontWeight:'700' },
  boostWrapper: { borderRadius:radius.button, overflow:'hidden' },
  boostBtn: { flexDirection:'row', alignItems:'center', justifyContent:'center', paddingVertical:16, gap:10 },
  boostText: { fontSize:17, fontWeight:'700', color:'#fff' },
});
