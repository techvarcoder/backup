import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { CircularProgress } from '../../components/ui/CircularProgress';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

export default function BatteryMonitorScreen() {
  const navigation = useNavigation();
  const { deviceStats, refreshDeviceStats } = useAppStore();

  useFocusEffect(React.useCallback(() => { refreshDeviceStats(); }, []));

  const lvl   = deviceStats.batteryLevel;
  const color = lvl > 50 ? C.success : lvl > 20 ? C.warning : C.danger;
  const icon  = deviceStats.isCharging ? 'battery-charging' : lvl > 80 ? 'battery' : lvl > 50 ? 'battery-70' : lvl > 20 ? 'battery-30' : 'battery-10';

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Battery Monitor</Text>
        <TouchableOpacity onPress={refreshDeviceStats} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.body}>
        <View style={s.gaugeCard}>
          <CircularProgress size={160} progress={lvl} strokeWidth={14} color={color} bgColor={C.border}>
            <Icon name={icon} size={30} color={color}/>
            <Text style={[s.gaugeNum,{color}]}>{lvl}%</Text>
            <Text style={s.gaugeSub}>{deviceStats.isCharging ? 'Charging' : 'On Battery'}</Text>
          </CircularProgress>
        </View>

        <View style={s.statsGrid}>
          {[
            { label:'Level',       value:`${lvl}%`,                                                                              color },
            { label:'Charging',    value: deviceStats.isCharging?'Yes':'No',                                                      color: deviceStats.isCharging?C.success:C.textMuted },
            { label:'Health',      value: deviceStats.batteryHealth > 0 ? `${deviceStats.batteryHealth}%` : '—',              color: deviceStats.batteryHealth >= 70 ? C.success : deviceStats.batteryHealth > 0 ? C.warning : C.textMuted },
            { label:'Temperature', value: deviceStats.temperature > 0 ? `${deviceStats.temperature}°C` : '—',            color: deviceStats.temperature > 40 ? C.danger : deviceStats.temperature > 0 ? C.warning : C.textMuted },
          ].map(st => (
            <View key={st.label} style={s.statCard}>
              <Text style={[s.statVal,{color:st.color}]}>{st.value}</Text>
              <Text style={s.statLabel}>{st.label}</Text>
            </View>
          ))}
        </View>

        <Text style={s.sectionTitle}>Battery Status</Text>
        <View style={s.infoCard}>
          {[
            { icon:'battery-check',   label:'Health',      value: deviceStats.batteryHealth > 0 ? `${deviceStats.batteryHealth}%${deviceStats.batteryHealth >= 90 ? ' — Excellent' : deviceStats.batteryHealth >= 70 ? ' — Good' : deviceStats.batteryHealth >= 50 ? ' — Fair' : ' — Poor'}` : '—', color: deviceStats.batteryHealth >= 70 ? C.success : deviceStats.batteryHealth > 0 ? C.warning : C.textMuted },
            { icon:'thermometer',     label:'Temperature', value: deviceStats.temperature > 0 ? `${deviceStats.temperature}°C` : '—', color: deviceStats.temperature > 40 ? C.danger : deviceStats.temperature > 0 ? C.warning : C.textMuted },
            { icon:'lightning-bolt',  label:'Charging',    value: deviceStats.isCharging?'Yes — plugged in':'No — on battery', color: deviceStats.isCharging?C.success:C.textMuted },
          ].map(r => (
            <View key={r.label} style={s.infoRow}>
              <Icon name={r.icon} size={18} color={r.color}/>
              <Text style={s.infoLabel}>{r.label}</Text>
              <Text style={[s.infoValue,{color:r.color}]}>{r.value}</Text>
            </View>
          ))}
        </View>
        <View style={{height:40}}/>
      </ScrollView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:12},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  body:{paddingHorizontal:20,paddingTop:8},
  gaugeCard:{backgroundColor:C.card,borderRadius:radius.card,padding:28,alignItems:'center',borderWidth:1,borderColor:C.border,marginBottom:16},
  gaugeNum:{fontSize:28,fontWeight:'900',marginTop:4}, gaugeSub:{fontSize:11,color:C.textMuted},
  statsGrid:{flexDirection:'row',flexWrap:'wrap',gap:12,marginBottom:20},
  statCard:{flex:1,minWidth:'40%',backgroundColor:C.card,borderRadius:radius.xl,padding:16,alignItems:'center',gap:8,borderWidth:1,borderColor:C.border},
  statVal:{fontSize:20,fontWeight:'900'}, statLabel:{fontSize:11,color:C.textMuted},
  sectionTitle:{fontSize:16,fontWeight:'700',color:C.textPrimary,marginBottom:12},
  infoCard:{backgroundColor:C.card,borderRadius:radius.card,overflow:'hidden',borderWidth:1,borderColor:C.border},
  infoRow:{flexDirection:'row',alignItems:'center',gap:12,padding:14,borderBottomWidth:1,borderBottomColor:C.border},
  infoLabel:{flex:1,fontSize:13,color:C.textSecondary}, infoValue:{fontSize:13,fontWeight:'600',color:C.textPrimary,maxWidth:180,textAlign:'right'},
});
