import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

interface NetDetail { ip: string; subnet: string; ssid: string; strength: number; }

export default function NetworkMonitorScreen() {
  const navigation = useNavigation();
  const { deviceStats, refreshDeviceStats } = useAppStore();
  const [detail, setDetail] = useState<NetDetail|null>(null);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const NI = require('@react-native-community/netinfo').default ?? require('@react-native-community/netinfo');
      const state = await NI.fetch();
      setDetail({
        ip:       state?.details?.ipAddress   ?? '—',
        subnet:   state?.details?.subnet      ?? '—',
        ssid:     state?.details?.ssid        ?? (state?.type === 'wifi' ? 'Connected' : state?.type ?? '—'),
        strength: state?.details?.strength    ?? 0,
      });
    } catch { setDetail(null); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { refreshDeviceStats(); load(); }, []));

  const isWifi = deviceStats.networkType === 'wifi';
  const dlColor = deviceStats.networkDownload > 50 ? C.success : deviceStats.networkDownload > 10 ? C.warning : C.danger;
  const ulColor = deviceStats.networkUpload  > 20 ? C.success : deviceStats.networkUpload  > 5  ? C.warning : C.danger;

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Network Monitor</Text>
        <TouchableOpacity onPress={()=>{refreshDeviceStats();load();}} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.body}>

        {/* Live speed */}
        <View style={s.speedRow}>
          <LinearGradient colors={['#1E293B','#0F172A']} style={s.speedCard}>
            <Icon name="arrow-down-bold" size={24} color={dlColor}/>
            <Text style={[s.speedVal,{color:dlColor}]}>{deviceStats.networkDownload} Mbps</Text>
            <Text style={s.speedLabel}>Download</Text>
          </LinearGradient>
          <LinearGradient colors={['#1E293B','#0F172A']} style={s.speedCard}>
            <Icon name="arrow-up-bold" size={24} color={ulColor}/>
            <Text style={[s.speedVal,{color:ulColor}]}>{deviceStats.networkUpload} Mbps</Text>
            <Text style={s.speedLabel}>Upload</Text>
          </LinearGradient>
        </View>

        {/* Connection type */}
        <View style={s.typeCard}>
          <Icon name={isWifi ? 'wifi' : 'signal-cellular-3'} size={32} color={C.primary}/>
          <View style={{flex:1,marginLeft:16}}>
            <Text style={s.typeLabel}>{isWifi ? 'Wi-Fi' : 'Mobile Data'}</Text>
            <Text style={s.typeSub}>Connected · {deviceStats.networkType.toUpperCase()}</Text>
          </View>
          <View style={[s.statusDot,{backgroundColor:C.success}]}/>
        </View>

        {/* Real network details */}
        <Text style={s.sectionTitle}>Connection Details</Text>
        {loading
          ? <ActivityIndicator color={C.primary} style={{marginTop:16}}/>
          : (
            <View style={s.detailCard}>
              {[
                { label:'IP Address',  value: detail?.ip     ?? '—', icon:'ip-network' },
                { label:'Subnet Mask', value: detail?.subnet ?? '—', icon:'vector-polygon' },
                { label:'Network',     value: detail?.ssid   ?? '—', icon:'wifi-settings' },
                { label:'Type',        value: deviceStats.networkType.toUpperCase(), icon:'router-wireless' },
              ].map(r => (
                <View key={r.label} style={s.detailRow}>
                  <Icon name={r.icon} size={16} color={C.primary}/>
                  <Text style={s.detailLabel}>{r.label}</Text>
                  <Text style={s.detailValue} numberOfLines={1}>{r.value}</Text>
                </View>
              ))}
            </View>
          )
        }
        <View style={{height:40}}/>
      </ScrollView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:4},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  body:{paddingHorizontal:20,paddingTop:20},
  speedRow:{flexDirection:'row',gap:12,marginBottom:16},
  speedCard:{flex:1,borderRadius:radius.card,padding:20,alignItems:'center',gap:8,borderWidth:1,borderColor:C.border},
  speedVal:{fontSize:22,fontWeight:'900'}, speedLabel:{fontSize:11,color:C.textMuted},
  typeCard:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.card,padding:20,marginBottom:20,borderWidth:1,borderColor:C.border},
  typeLabel:{fontSize:16,fontWeight:'700',color:C.textPrimary}, typeSub:{fontSize:12,color:C.textMuted,marginTop:2},
  statusDot:{width:12,height:12,borderRadius:6},
  sectionTitle:{fontSize:16,fontWeight:'700',color:C.textPrimary,marginBottom:12},
  detailCard:{backgroundColor:C.card,borderRadius:radius.card,overflow:'hidden',borderWidth:1,borderColor:C.border},
  detailRow:{flexDirection:'row',alignItems:'center',gap:10,padding:14,borderBottomWidth:1,borderBottomColor:C.border},
  detailLabel:{flex:1,fontSize:13,color:C.textSecondary}, detailValue:{fontSize:13,fontWeight:'700',color:C.textPrimary,maxWidth:160},
});
