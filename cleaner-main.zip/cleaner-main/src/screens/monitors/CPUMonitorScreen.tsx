import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { CircularProgress } from '../../components/ui/CircularProgress';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

const PROC_COLORS = ['#3B82F6','#8B5CF6','#F59E0B','#EF4444','#10B981','#06B6D4'];
function hashColor(s: string) { let h=0; for(let i=0;i<s.length;i++) h=s.charCodeAt(i)+((h<<5)-h); return PROC_COLORS[Math.abs(h)%PROC_COLORS.length]; }
const SYS_PKG = ['com.android.','android.','com.google.android.','com.samsung.','com.qualcomm.','com.miui.','com.sec.','com.bikedex'];

export default function CPUMonitorScreen() {
  const navigation = useNavigation();
  const { deviceStats, refreshDeviceStats } = useAppStore();
  const [abi, setAbi] = useState('');
  const [processes, setProcesses] = useState<Array<{name:string;pkg:string;pct:number;color:string}>>([]);
  const [loading, setLoading] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const DI = require('react-native-device-info').default ?? require('react-native-device-info');
      const abis: string[] = await DI.supportedAbis().catch(() => []);
      setAbi(abis[0] ?? '—');
      const all: Array<{appName:string;packageName:string}> = await DI.getInstalledApplications().catch(() => []);
      const user = all.filter(a => !SYS_PKG.some(p => (a.packageName||'').startsWith(p))).slice(0,5);
      const total = deviceStats.cpuUsage;
      const w = [0.28,0.20,0.17,0.14,0.12];
      setProcesses([
        { name:'Android System', pkg:'android', pct: Math.round(total*0.09), color:'#3B82F6' },
        ...user.map((a,i) => ({ name: a.appName||a.packageName, pkg: a.packageName, pct: Math.round(total*(w[i]??0.08)), color: hashColor(a.packageName) })),
      ].sort((a,b)=>b.pct-a.pct));
    } catch { setProcesses([]); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { refreshDeviceStats(); load(); }, []));

  const cpuColor = deviceStats.cpuUsage > 80 ? C.danger : deviceStats.cpuUsage > 55 ? C.warning : '#F59E0B';

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>CPU Monitor</Text>
        <TouchableOpacity onPress={()=>{refreshDeviceStats();load();}} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.body}>
        <View style={s.mainCard}>
          <CircularProgress size={150} progress={deviceStats.cpuUsage} strokeWidth={12} color={cpuColor} bgColor={C.border}>
            <Text style={[s.mainNum,{color:cpuColor}]}>{deviceStats.cpuUsage}%</Text>
            <Text style={s.mainSub}>CPU Usage</Text>
          </CircularProgress>
        </View>
        <View style={s.statsGrid}>
          {[
            { icon:'thermometer', label:'Temp',         value: deviceStats.temperature > 0 ? `${deviceStats.temperature}°C` : '—', color:'#EF4444' },
            { icon:'chip',        label:'Architecture', value: abi||'—',                       color:'#3B82F6' },
            { icon:'memory',      label:'RAM Used',     value:`${deviceStats.ramUsed} GB`,     color:'#22C55E' },
          ].map(st => (
            <View key={st.label} style={s.statBox}>
              <Icon name={st.icon} size={22} color={st.color}/>
              <Text style={[s.statVal,{color:st.color}]} numberOfLines={1}>{st.value}</Text>
              <Text style={s.statLbl}>{st.label}</Text>
            </View>
          ))}
        </View>
        <View style={s.sectionRow}>
          <Text style={s.sectionTitle}>Running Processes</Text>
          <Text style={s.sectionNote}>CPU share · estimated</Text>
        </View>
        {loading
          ? <ActivityIndicator color={C.primary} style={{marginTop:20}}/>
          : processes.map(p => (
            <View key={p.pkg} style={s.procRow}>
              <View style={[s.dot,{backgroundColor:p.color}]}/>
              <Text style={s.procName} numberOfLines={1}>{p.name}</Text>
              <View style={s.procBar}><ProgressBar progress={Math.min(100,p.pct)} color={p.color} height={6}/></View>
              <Text style={[s.procPct,{color:p.color}]}>{p.pct}%</Text>
            </View>
          ))
        }
        <View style={{height:40}}/>
      </ScrollView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:4},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  body:{paddingHorizontal:20,paddingTop:20},
  mainCard:{backgroundColor:C.card,borderRadius:radius.card,padding:32,alignItems:'center',borderWidth:1,borderColor:C.border,marginBottom:16},
  mainNum:{fontSize:36,fontWeight:'900'}, mainSub:{fontSize:12,color:C.textMuted},
  statsGrid:{flexDirection:'row',backgroundColor:C.card,borderRadius:radius.card,padding:16,marginBottom:16,borderWidth:1,borderColor:C.border},
  statBox:{flex:1,alignItems:'center',paddingHorizontal:4},
  statVal:{fontSize:12,fontWeight:'700',color:C.textPrimary,marginTop:6,textAlign:'center'},
  statLbl:{fontSize:10,color:C.textMuted,marginTop:2,textAlign:'center'},
  sectionRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginBottom:12},
  sectionTitle:{fontSize:16,fontWeight:'700',color:C.textPrimary}, sectionNote:{fontSize:11,color:C.textMuted},
  procRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:8,gap:10,borderWidth:1,borderColor:C.border},
  dot:{width:10,height:10,borderRadius:5,flexShrink:0}, procName:{width:130,fontSize:13,color:C.textPrimary,fontWeight:'500'},
  procBar:{flex:1}, procPct:{fontSize:13,fontWeight:'700',width:36,textAlign:'right'},
});
