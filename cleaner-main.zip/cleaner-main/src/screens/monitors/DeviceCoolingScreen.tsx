import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { CircularProgress } from '../../components/ui/CircularProgress';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

export default function DeviceCoolingScreen() {
  const navigation = useNavigation();
  const { deviceStats, refreshDeviceStats } = useAppStore();
  const [cooling, setCooling] = useState(false);
  const [cooled, setCooled]   = useState(false);

  useFocusEffect(React.useCallback(() => { refreshDeviceStats(); }, []));

  const temp      = deviceStats.temperature;
  const tempColor = temp > 45 ? C.danger : temp > 38 ? C.warning : temp > 0 ? C.success : C.textMuted;
  const tempLabel = temp > 45 ? 'Too Hot' : temp > 38 ? 'Warm' : temp > 0 ? 'Normal' : '—';

  const handleCool = async () => {
    setCooling(true);
    await new Promise<void>(r => setTimeout(r, 2000));
    setCooling(false);
    setCooled(true);
    setTimeout(() => setCooled(false), 4000);
  };

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Device Cooling</Text>
        <TouchableOpacity onPress={refreshDeviceStats} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.body}>
        <View style={s.gaugeCard}>
          <CircularProgress size={160} progress={Math.min(100, Math.round((temp/60)*100))} strokeWidth={14} color={tempColor} bgColor={C.border}>
            <Icon name="thermometer" size={30} color={tempColor}/>
            <Text style={[s.gaugeNum,{color:tempColor}]}>{temp > 0 ? `${temp}°C` : '—'}</Text>
            <Text style={[s.gaugeSub,{color:tempColor}]}>{tempLabel}</Text>
          </CircularProgress>
        </View>

        <View style={s.statsGrid}>
          {[
            { label:'Current',   value: temp > 0 ? `${temp}°C` : '—',             color: tempColor     },
            { label:'CPU Usage', value:`${deviceStats.cpuUsage}%`,                color: C.warning     },
            { label:'Battery',   value:`${deviceStats.batteryLevel}%`,            color: C.primary     },
            { label:'Status',    value: tempLabel,                                color: tempColor     },
          ].map(st => (
            <View key={st.label} style={s.statCard}>
              <Text style={[s.statVal,{color:st.color}]}>{st.value}</Text>
              <Text style={s.statLabel}>{st.label}</Text>
            </View>
          ))}
        </View>

        <View style={s.tipsCard}>
          <Icon name="lightbulb-outline" size={20} color={C.warning}/>
          <View style={{flex:1,marginLeft:12}}>
            <Text style={s.tipsTitle}>Cooling Tips</Text>
            {['Close background apps to reduce CPU load',
              'Lower screen brightness',
              'Avoid charging while gaming',
              'Remove case if overheating'].map(t => (
              <Text key={t} style={s.tipItem}>• {t}</Text>
            ))}
          </View>
        </View>

        {cooled && (
          <View style={s.cooledMsg}>
            <Icon name="check-circle" size={18} color={C.success}/>
            <Text style={s.cooledText}>Background apps cleared — device should cool down</Text>
          </View>
        )}

        <TouchableOpacity onPress={handleCool} disabled={cooling} style={s.coolWrapper}>
          <LinearGradient colors={cooling?['#334155','#1E293B']:['#06B6D4','#0891B2']} style={s.coolBtn}>
            {cooling
              ? <ActivityIndicator color="#fff" size="small"/>
              : <><Icon name="snowflake" size={22} color="#fff"/><Text style={s.coolText}>Cool Down Now</Text></>
            }
          </LinearGradient>
        </TouchableOpacity>
        <View style={{height:40}}/>
      </ScrollView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:12},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  body:{paddingHorizontal:20,paddingTop:8},
  gaugeCard:{backgroundColor:C.card,borderRadius:radius.card,padding:28,alignItems:'center',borderWidth:1,borderColor:C.border,marginBottom:16},
  gaugeNum:{fontSize:28,fontWeight:'900',marginTop:4}, gaugeSub:{fontSize:12,fontWeight:'700',marginTop:2},
  statsGrid:{flexDirection:'row',flexWrap:'wrap',gap:12,marginBottom:20},
  statCard:{flex:1,minWidth:'40%',backgroundColor:C.card,borderRadius:radius.xl,padding:16,alignItems:'center',gap:8,borderWidth:1,borderColor:C.border},
  statVal:{fontSize:20,fontWeight:'900'}, statLabel:{fontSize:11,color:C.textMuted},
  tipsCard:{flexDirection:'row',backgroundColor:C.card,borderRadius:radius.xl,padding:16,marginBottom:20,borderWidth:1,borderColor:C.border},
  tipsTitle:{fontSize:13,fontWeight:'700',color:C.textPrimary,marginBottom:8},
  tipItem:{fontSize:12,color:C.textMuted,marginTop:4,lineHeight:18},
  cooledMsg:{flexDirection:'row',alignItems:'center',gap:8,justifyContent:'center',marginBottom:12},
  cooledText:{fontSize:13,color:C.success,fontWeight:'600'},
  coolWrapper:{borderRadius:radius.button,overflow:'hidden'},
  coolBtn:{flexDirection:'row',alignItems:'center',justifyContent:'center',paddingVertical:16,gap:10},
  coolText:{fontSize:17,fontWeight:'700',color:'#fff'},
});
