import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { darkColors as C, radius, spacing } from '../../theme';

const FEATURES = [
  { icon: 'infinity', label: 'Unlimited Deep Clean' },
  { icon: 'robot-outline', label: 'AI Automation' },
  { icon: 'battery-heart', label: 'Battery Analytics' },
  { icon: 'cloud-sync', label: 'Cloud Sync & Backup' },
  { icon: 'block-helper', label: 'Ad-Free Experience' },
];

export default function PremiumScreen() {
  const navigation = useNavigation();

  return (
    <LinearGradient colors={['#080612', '#0F172A']} style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.closeBtn}>
          <Icon name="close" size={22} color={C.textSecondary} />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.body}>
        {/* Hero */}
        <View style={styles.heroSection}>
          <LinearGradient colors={['#1E1B4B', '#312E81']} style={styles.crownBox}>
            <Icon name="crown" size={48} color="#F59E0B" />
          </LinearGradient>
          <Text style={styles.premiumLabel}>AI Phone Optimizer</Text>
          <Text style={styles.premiumTitle}>Premium</Text>
          <Text style={styles.premiumSub}>Unlock the full power of AI-driven phone care</Text>
        </View>

        {/* Features */}
        <View style={styles.featuresCard}>
          {FEATURES.map((f) => (
            <View key={f.label} style={styles.featureRow}>
              <LinearGradient colors={['#F59E0B', '#D97706']} style={styles.featureIcon}>
                <Icon name={f.icon} size={18} color="#fff" />
              </LinearGradient>
              <Text style={styles.featureLabel}>{f.label}</Text>
              <Icon name="check-circle" size={20} color={C.success} />
            </View>
          ))}
        </View>

        {/* Pricing */}
        <TouchableOpacity activeOpacity={0.9}>
          <LinearGradient colors={['#F59E0B', '#D97706']} style={styles.ctaBtn}>
            <Text style={styles.ctaText}>Try 7 Days Free</Text>
            <Text style={styles.ctaSub}>₹ 599 / year after trial</Text>
          </LinearGradient>
        </TouchableOpacity>

        <TouchableOpacity style={styles.restoreBtn}>
          <Text style={styles.restoreText}>Restore Purchase</Text>
        </TouchableOpacity>
        <Text style={styles.legal}>Cancel anytime. No questions asked.</Text>
        <View style={{ height: 40 }} />
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingTop: 56, paddingHorizontal: 20, paddingBottom: 4 },
  closeBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  body: { paddingHorizontal: 24 },
  heroSection: { alignItems: 'center', paddingVertical: 28 },
  crownBox: { width: 100, height: 100, borderRadius: 30, justifyContent: 'center', alignItems: 'center', marginBottom: 20, shadowColor: '#F59E0B', shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.5, shadowRadius: 30, elevation: 16 },
  premiumLabel: { fontSize: 12, color: C.textMuted, letterSpacing: 2, textTransform: 'uppercase', marginBottom: 4 },
  premiumTitle: { fontSize: 40, fontWeight: '900', color: '#F59E0B', letterSpacing: 0.5 },
  premiumSub: { fontSize: 14, color: C.textMuted, textAlign: 'center', marginTop: 8, lineHeight: 22 },
  featuresCard: { backgroundColor: C.card, borderRadius: radius.card, padding: 20, marginBottom: 24, borderWidth: 1, borderColor: C.border },
  featureRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, gap: 14, borderBottomWidth: 1, borderBottomColor: C.border },
  featureIcon: { width: 36, height: 36, borderRadius: radius.md, justifyContent: 'center', alignItems: 'center' },
  featureLabel: { flex: 1, fontSize: 14, color: C.textPrimary, fontWeight: '500' },
  ctaBtn: { borderRadius: radius.button, padding: 20, alignItems: 'center' },
  ctaText: { fontSize: 18, fontWeight: '800', color: '#fff' },
  ctaSub: { fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 4 },
  restoreBtn: { alignItems: 'center', paddingVertical: 16 },
  restoreText: { fontSize: 14, color: C.textMuted },
  legal: { fontSize: 11, color: C.textDisabled, textAlign: 'center' },
});
