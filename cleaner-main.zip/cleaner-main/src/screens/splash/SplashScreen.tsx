import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, Animated, StatusBar, Dimensions,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../navigation/types';
import { darkColors as C } from '../../theme';

const { width, height } = Dimensions.get('window');

type Props = {
  navigation: NativeStackNavigationProp<RootStackParamList, 'Splash'>;
};

export default function SplashScreen({ navigation }: Props) {
  const logoScale = useRef(new Animated.Value(0)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const textOpacity = useRef(new Animated.Value(0)).current;
  const ring1 = useRef(new Animated.Value(0.6)).current;
  const ring2 = useRef(new Animated.Value(0.6)).current;

  useEffect(() => {
    // Pulse rings
    const ringAnim = Animated.loop(
      Animated.sequence([
        Animated.timing(ring1, { toValue: 1.2, duration: 1200, useNativeDriver: true }),
        Animated.timing(ring1, { toValue: 0.8, duration: 1200, useNativeDriver: true }),
      ])
    );
    const ringAnim2 = Animated.loop(
      Animated.sequence([
        Animated.timing(ring2, { toValue: 1.4, duration: 1600, useNativeDriver: true }),
        Animated.timing(ring2, { toValue: 0.7, duration: 1600, useNativeDriver: true }),
      ])
    );

    Animated.sequence([
      Animated.delay(300),
      Animated.parallel([
        Animated.spring(logoScale, { toValue: 1, tension: 60, friction: 8, useNativeDriver: true }),
        Animated.timing(logoOpacity, { toValue: 1, duration: 600, useNativeDriver: true }),
      ]),
      Animated.timing(textOpacity, { toValue: 1, duration: 500, useNativeDriver: true }),
    ]).start();

    ringAnim.start();
    ringAnim2.start();

    const timer = setTimeout(() => navigation.replace('Onboarding'), 2800);
    return () => {
      clearTimeout(timer);
      ringAnim.stop();
      ringAnim2.stop();
    };
  }, []);

  return (
    <LinearGradient colors={['#0A0F1E', '#0F172A', '#0A0F1E']} style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />

      {/* Glow rings */}
      <Animated.View style={[styles.ring2, { transform: [{ scale: ring2 }] }]} />
      <Animated.View style={[styles.ring1, { transform: [{ scale: ring1 }] }]} />

      <Animated.View style={{ alignItems: 'center', transform: [{ scale: logoScale }], opacity: logoOpacity }}>
        <LinearGradient colors={['#3B82F6', '#2563EB']} style={styles.logoBox}>
          <Icon name="lightning-bolt" size={44} color="#fff" />
        </LinearGradient>
      </Animated.View>

      <Animated.View style={[styles.textBlock, { opacity: textOpacity }]}>
        <Text style={styles.appName}>AuroCleaner</Text>
        <Text style={styles.tagline}>Smart Clean. Smart Phone.</Text>
      </Animated.View>

      <View style={styles.bottom}>
        <Text style={styles.powered}>Powered by AI</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  ring1: {
    position: 'absolute',
    width: 220,
    height: 220,
    borderRadius: 110,
    borderWidth: 1.5,
    borderColor: 'rgba(59,130,246,0.3)',
    backgroundColor: 'transparent',
  },
  ring2: {
    position: 'absolute',
    width: 320,
    height: 320,
    borderRadius: 160,
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.12)',
    backgroundColor: 'transparent',
  },
  logoBox: {
    width: 100,
    height: 100,
    borderRadius: 30,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#3B82F6',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 30,
    elevation: 20,
  },
  textBlock: { alignItems: 'center', marginTop: 28 },
  appName: {
    fontSize: 32,
    fontWeight: '800',
    color: '#F8FAFC',
    letterSpacing: 0.5,
  },
  tagline: {
    fontSize: 15,
    color: C.textMuted,
    marginTop: 6,
    letterSpacing: 1.2,
  },
  bottom: {
    position: 'absolute',
    bottom: 48,
  },
  powered: {
    fontSize: 12,
    color: C.textDisabled,
    letterSpacing: 1,
  },
});
