import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, StatusBar, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

interface SecurityIssue { id: string; severity: 'high'|'medium'|'low'; title: string; desc: string; icon: string; fixed: boolean; }

const SEV_COLOR = { high:'#EF4444', medium:'#F59E0B', low:'#22C55E' };
const SEV_ORDER = { high:0, medium:1, low:2 };

export default function SecurityScannerScreen() {
  const navigation = useNavigation();
  const { deviceStats, refreshDeviceStats } = useAppStore();
  const [issues, setIssues]   = useState<SecurityIssue[]>([]);
  const [loading, setLoading] = useState(false);
  const [scanned, setScanned] = useState(false);

  const runScan = async () => {
    setLoading(true);
    setScanned(false);
    await refreshDeviceStats();
    // Wait a bit for deviceStats to update
    await new Promise<void>(resolve => { setTimeout(() => resolve(), 500); });
    const found: SecurityIssue[] = [];

    // Real checks based on actual device state
    if (!deviceStats.isCharging && deviceStats.batteryLevel < 15) {
      found.push({ id:'bat', severity:'high', title:'Critical Battery Level', desc:`Battery at ${deviceStats.batteryLevel}% — device may shut down unexpectedly`, icon:'battery-alert', fixed:false });
    }
    if (deviceStats.temperature > 45) {
      found.push({ id:'temp', severity:'high', title:'Device Overheating', desc:`Temperature ${deviceStats.temperature}°C exceeds safe threshold (45°C)`, icon:'thermometer-alert', fixed:false });
    }
    if (deviceStats.storageUsed / deviceStats.storageTotal > 0.9) {
      found.push({ id:'storage', severity:'high', title:'Storage Critical', desc:`${Math.round(deviceStats.storageUsed/deviceStats.storageTotal*100)}% storage used — system stability at risk`, icon:'harddisk-remove', fixed:false });
    }
    if (deviceStats.ramUsed / deviceStats.ramTotal > 0.85) {
      found.push({ id:'ram', severity:'medium', title:'High Memory Pressure', desc:`RAM at ${Math.round(deviceStats.ramUsed/deviceStats.ramTotal*100)}% — apps may crash or freeze`, icon:'memory', fixed:false });
    }
    if (deviceStats.batteryHealth > 0 && deviceStats.batteryHealth < 70) {
      found.push({ id:'batHealth', severity:'medium', title:'Battery Health Degraded', desc:`Battery health at ${deviceStats.batteryHealth}% — capacity is reduced`, icon:'battery-heart-outline', fixed:false });
    }
    if (deviceStats.storageUsed / deviceStats.storageTotal > 0.7) {
      found.push({ id:'storageWarn', severity:'low', title:'Storage Usage High', desc:`${Math.round(deviceStats.storageUsed/deviceStats.storageTotal*100)}% used — consider cleaning up files`, icon:'harddisk-plus', fixed:false });
    }
    if (deviceStats.cpuUsage > 80) {
      found.push({ id:'cpu', severity:'medium', title:'High CPU Load', desc:`CPU at ${deviceStats.cpuUsage}% — background apps consuming resources`, icon:'chip', fixed:false });
    }

    if (found.length === 0) {
      found.push({ id:'ok', severity:'low', title:'No Issues Detected', desc:'Your device appears secure and healthy right now', icon:'shield-check', fixed:true });
    }

    setIssues(found.sort((a,b) => SEV_ORDER[a.severity] - SEV_ORDER[b.severity]));
    setLoading(false);
    setScanned(true);
  };

  useFocusEffect(React.useCallback(() => { runScan(); }, []));

  const fix = (id: string) => {
    setIssues(prev => prev.map(i => i.id===id ? {...i, fixed:true} : i));
    const target =
      id === 'bat' || id === 'batHealth' ? 'BatteryMonitor'
      : id === 'temp' ? 'DeviceCooling'
      : id === 'ram' ? 'RAMMonitor'
      : id === 'cpu' ? 'CPUMonitor'
      : id === 'storage' || id === 'storageWarn' ? 'LargeFileFinder'
      : null;

    if (target) {
      (navigation as any).navigate(target);
    }
  };

  const open = !scanned && !loading;
  const highCount = issues.filter(i=>i.severity==='high'&&!i.fixed).length;

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Security Scanner</Text>
        <TouchableOpacity onPress={runScan} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>

      {scanned && (
        <LinearGradient colors={highCount>0?['#7F1D1D','#EF444433']:['#14532D','#22C55E33']} style={s.heroBanner}>
          <Icon name={highCount>0?'shield-alert':'shield-check'} size={28} color={highCount>0?'#EF4444':'#22C55E'}/>
          <View style={{marginLeft:12}}>
            <Text style={s.heroTitle}>{highCount>0?`${highCount} Critical Issue${highCount!==1?'s':''} Found`:'Device is Secure'}</Text>
            <Text style={s.heroSub}>{issues.length} check{issues.length!==1?'s':''} completed</Text>
          </View>
        </LinearGradient>
      )}

      {loading
        ? <View style={s.scanWrap}><ActivityIndicator color={C.primary} size="large"/><Text style={s.scanText}>Scanning device...</Text></View>
        : <FlatList
            data={issues}
            keyExtractor={i=>i.id}
            contentContainerStyle={{paddingHorizontal:20,paddingBottom:40}}
            renderItem={({item:i}) => (
              <View style={[s.issueCard,i.fixed&&s.fixedCard]}>
                <View style={[s.issueIcon,{backgroundColor:SEV_COLOR[i.severity]+'22'}]}>
                  <Icon name={i.icon} size={22} color={SEV_COLOR[i.severity]}/>
                </View>
                <View style={{flex:1,marginLeft:12}}>
                  <View style={s.issueHeader}>
                    <Text style={s.issueTitle}>{i.title}</Text>
                    <View style={[s.sevBadge,{backgroundColor:SEV_COLOR[i.severity]+'22'}]}>
                      <Text style={[s.sevText,{color:SEV_COLOR[i.severity]}]}>{i.severity.toUpperCase()}</Text>
                    </View>
                  </View>
                  <Text style={s.issueSub}>{i.desc}</Text>
                  {!i.fixed && (
                    <TouchableOpacity onPress={()=>fix(i.id)} style={[s.fixBtn,{borderColor:SEV_COLOR[i.severity]}]}>
                      <Text style={[s.fixText,{color:SEV_COLOR[i.severity]}]}>Fix</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            )}
          />
      }
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:8},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  heroBanner:{flexDirection:'row',alignItems:'center',marginHorizontal:20,marginBottom:16,borderRadius:radius.xl,padding:16},
  heroTitle:{fontSize:15,fontWeight:'800',color:C.textPrimary}, heroSub:{fontSize:12,color:C.textMuted,marginTop:2},
  scanWrap:{flex:1,justifyContent:'center',alignItems:'center',gap:16}, scanText:{fontSize:14,color:C.textMuted},
  issueCard:{flexDirection:'row',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:10,borderWidth:1,borderColor:C.border},
  fixedCard:{opacity:0.5},
  issueIcon:{width:46,height:46,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  issueHeader:{flexDirection:'row',alignItems:'center',gap:8,marginBottom:4},
  issueTitle:{fontSize:13,fontWeight:'700',color:C.textPrimary,flex:1}, issueSub:{fontSize:12,color:C.textMuted,lineHeight:17},
  sevBadge:{borderRadius:radius.pill,paddingHorizontal:8,paddingVertical:3},
  sevText:{fontSize:10,fontWeight:'800',letterSpacing:0.5},
  fixBtn:{alignSelf:'flex-start',marginTop:8,paddingHorizontal:14,paddingVertical:6,borderRadius:radius.pill,borderWidth:1.5},
  fixText:{fontSize:12,fontWeight:'700'},
});
