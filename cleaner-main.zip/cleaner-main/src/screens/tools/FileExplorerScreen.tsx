import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, StatusBar, ActivityIndicator, TextInput } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

interface DirEntry {
  name: string;
  path: string;
  fileCount: number;
  sizeBytes: number;
  icon: string;
  colors: string[];
  typeCounts: {
    images: number;
    videos: number;
    audio: number;
    docs: number;
    apk: number;
  };
}

function fmtSize(b: number) { if(b>=1073741824) return (b/1073741824).toFixed(2)+' GB'; if(b>=1048576) return (b/1048576).toFixed(0)+' MB'; return (b/1024).toFixed(0)+' KB'; }

const DIR_CONFIG: Array<{name:string;rel:string;icon:string;colors:string[]}> = [
  { name:'DCIM / Camera',  rel:'/DCIM/Camera',           icon:'camera',          colors:['#2563EB','#1D4ED8'] },
  { name:'Screenshots',    rel:'/Pictures/Screenshots',  icon:'monitor-screenshot', colors:['#7C3AED','#6D28D9'] },
  { name:'Download',       rel:'/Download',              icon:'download',        colors:['#D97706','#B45309'] },
  { name:'Pictures',       rel:'/Pictures',              icon:'image-multiple',  colors:['#EC4899','#BE185D'] },
  { name:'Movies',         rel:'/Movies',                icon:'movie',           colors:['#EF4444','#DC2626'] },
  { name:'Music',          rel:'/Music',                 icon:'music',           colors:['#8B5CF6','#6D28D9'] },
  { name:'Documents',      rel:'/Documents',             icon:'file-document',   colors:['#0891B2','#0E7490'] },
  { name:'Android',        rel:'/Android',               icon:'android',         colors:['#16A34A','#15803D'] },
];

const FILTER_TABS = ['Images','Videos','Audio','Docs','APK'];

const IMG_EXT = ['jpg', 'jpeg', 'png', 'heic', 'webp', 'gif'];
const VID_EXT = ['mp4', 'mkv', 'mov', 'avi', '3gp', 'webm'];
const AUD_EXT = ['mp3', 'aac', 'wav', 'flac', 'ogg', 'm4a'];
const DOC_EXT = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'zip'];

export default function FileExplorerScreen() {
  const navigation = useNavigation();
  const { deviceStats } = useAppStore();
  const [dirs, setDirs]       = useState<DirEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter]   = useState(0);
  const [search, setSearch]   = useState('');

  const load = async () => {
    setLoading(true);
    try {
      const RNFS = require('react-native-fs').default ?? require('react-native-fs');
      const base = RNFS.ExternalStorageDirectoryPath ?? '';
      const results: DirEntry[] = [];
      for (const cfg of DIR_CONFIG) {
        const fullPath = base + cfg.rel;
        try {
          const items = await RNFS.readDir(fullPath).catch(() => null);
          if (!items) continue;
          const files = items.filter((i:any) => i.isFile());
          const totalSize = files.reduce((t:number,f:any)=>t+(f.size??0),0);
          const typeCounts = { images: 0, videos: 0, audio: 0, docs: 0, apk: 0 };
          for (const f of files) {
            const ext = (f.name?.split('.').pop() || '').toLowerCase();
            if (IMG_EXT.includes(ext)) typeCounts.images += 1;
            else if (VID_EXT.includes(ext)) typeCounts.videos += 1;
            else if (AUD_EXT.includes(ext)) typeCounts.audio += 1;
            else if (ext === 'apk') typeCounts.apk += 1;
            else if (DOC_EXT.includes(ext)) typeCounts.docs += 1;
          }
          results.push({ name:cfg.name, path:fullPath, fileCount:files.length, sizeBytes:totalSize, icon:cfg.icon, colors:cfg.colors, typeCounts });
        } catch {}
      }
      setDirs(results.filter(d=>d.fileCount>0||d.sizeBytes>=0));
    } catch { setDirs([]); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { load(); }, []));

  const typeKey: Array<'images'|'videos'|'audio'|'docs'|'apk'> = ['images','videos','audio','docs','apk'];
  const activeType = typeKey[filter];
  const filtered = dirs.filter(d => {
    const matchesSearch = !search || d.name.toLowerCase().includes(search.toLowerCase());
    const matchesType = d.typeCounts[activeType] > 0;
    return matchesSearch && matchesType;
  });

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <View style={{flex:1,marginLeft:8}}>
          <Text style={s.title}>File Explorer</Text>
          <Text style={s.subtitle}>{deviceStats.storageUsed} GB / {deviceStats.storageTotal} GB used</Text>
        </View>
        <TouchableOpacity onPress={load} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>

      <View style={s.searchRow}>
        <Icon name="magnify" size={18} color={C.textMuted}/>
        <TextInput placeholder="Search folders..." placeholderTextColor={C.textMuted} style={s.searchInput} value={search} onChangeText={setSearch}/>
      </View>

      <View style={s.tabs}>
        {FILTER_TABS.map((t,i) => (
          <TouchableOpacity key={t} style={[s.tab,filter===i&&s.tabActive]} onPress={()=>setFilter(i)}>
            <Text style={[s.tabText,filter===i&&s.tabTextActive]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading
        ? <ActivityIndicator color={C.primary} style={{marginTop:40}}/>
        : filtered.length === 0
          ? <View style={s.empty}><Icon name="folder-open" size={48} color={C.textMuted}/><Text style={s.emptyText}>No folders found</Text></View>
          : <FlatList
              data={filtered}
              keyExtractor={d=>d.name}
              numColumns={2}
              contentContainerStyle={{paddingHorizontal:16,paddingBottom:40,gap:12}}
              columnWrapperStyle={{gap:12}}
              renderItem={({item:d}) => (
                <TouchableOpacity style={s.dirCard}>
                  <LinearGradient colors={d.colors} style={s.dirGrad}>
                    <Icon name={d.icon} size={28} color="#fff"/>
                  </LinearGradient>
                  <Text style={s.dirName} numberOfLines={1}>{d.name}</Text>
                  <Text style={s.dirCount}>{d.fileCount} files</Text>
                  <Text style={s.dirSize}>{fmtSize(d.sizeBytes)}</Text>
                </TouchableOpacity>
              )}
            />
      }
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',paddingTop:56,paddingHorizontal:20,paddingBottom:8},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'},
  title:{fontSize:16,fontWeight:'700',color:C.textPrimary}, subtitle:{fontSize:11,color:C.textMuted,marginTop:1},
  searchRow:{flexDirection:'row',alignItems:'center',gap:8,marginHorizontal:20,backgroundColor:C.card,borderRadius:radius.pill,paddingHorizontal:14,paddingVertical:10,marginBottom:10,borderWidth:1,borderColor:C.border},
  searchInput:{flex:1,fontSize:13,color:C.textPrimary,padding:0},
  tabs:{flexDirection:'row',marginHorizontal:20,gap:8,marginBottom:16},
  tab:{paddingHorizontal:12,paddingVertical:7,borderRadius:radius.pill,borderWidth:1,borderColor:C.border},
  tabActive:{backgroundColor:C.primary,borderColor:C.primary},
  tabText:{fontSize:11,color:C.textMuted,fontWeight:'600'}, tabTextActive:{color:'#fff'},
  empty:{flex:1,justifyContent:'center',alignItems:'center',gap:12,paddingBottom:60},
  emptyText:{fontSize:14,color:C.textMuted},
  dirCard:{flex:1,backgroundColor:C.card,borderRadius:radius.xl,padding:14,gap:8,borderWidth:1,borderColor:C.border},
  dirGrad:{width:52,height:52,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  dirName:{fontSize:13,fontWeight:'700',color:C.textPrimary}, dirCount:{fontSize:11,color:C.textMuted}, dirSize:{fontSize:12,fontWeight:'700',color:C.primary},
});
