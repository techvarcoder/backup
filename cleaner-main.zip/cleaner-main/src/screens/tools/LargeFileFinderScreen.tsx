import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, StatusBar, ActivityIndicator, Alert } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';

interface LargeFile { id: string; name: string; path: string; displayPath: string; size: number; ext: string; }

function extIcon(ext: string): string {
  if (['mp4','mkv','mov','avi'].includes(ext)) return 'file-video';
  if (['jpg','jpeg','png','heic'].includes(ext)) return 'file-image';
  if (['zip','tar','gz','rar'].includes(ext)) return 'folder-zip';
  if (['apk'].includes(ext)) return 'android';
  if (['pdf'].includes(ext)) return 'file-pdf-box';
  if (['mp3','aac','flac'].includes(ext)) return 'file-music';
  return 'file';
}

function fmtSize(b: number): string {
  if (b >= 1073741824) return (b/1073741824).toFixed(2)+' GB';
  if (b >= 1048576)    return (b/1048576).toFixed(0)+' MB';
  return (b/1024).toFixed(0)+' KB';
}

const EXT_COLORS: Record<string,string> = { mp4:'#7C3AED', mkv:'#7C3AED', mov:'#7C3AED', jpg:'#2563EB', jpeg:'#2563EB', png:'#2563EB', zip:'#D97706', apk:'#16A34A', pdf:'#EF4444', mp3:'#0891B2', default:'#4B5563' };

export default function LargeFileFinderScreen() {
  const navigation = useNavigation();
  const [sort, setSort]         = useState(0);
  const [files, setFiles]       = useState<LargeFile[]>([]);
  const [loading, setLoading]   = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [scanning, setScanning] = useState(false);

  const scan = async () => {
    setLoading(true);
    setFiles([]);
    setSelected(new Set());
    try {
      const RNFS = require('react-native-fs').default ?? require('react-native-fs');
      const dirs = [RNFS.DownloadDirectoryPath, RNFS.ExternalStorageDirectoryPath+'/DCIM',
                    RNFS.ExternalStorageDirectoryPath+'/Movies', RNFS.ExternalStorageDirectoryPath+'/Music'].filter(Boolean);
      const found: LargeFile[] = [];
      let id = 0;
      for (const dir of dirs) {
        try {
          const items = await RNFS.readDir(dir).catch(() => []);
          for (const item of items) {
            if (!item.isFile()) continue;
            if (item.size < 10 * 1024 * 1024) continue; // > 10 MB only
            const nameParts = item.name.split('.');
            const ext = nameParts.length > 1 ? nameParts[nameParts.length-1].toLowerCase() : '';
            const shortPath = item.path.replace(RNFS.ExternalStorageDirectoryPath??'', '').replace(/^\/+/,'') || item.path;
            found.push({ id: String(id++), name: item.name, path: item.path, displayPath: shortPath, size: item.size, ext });
          }
        } catch {}
      }
      found.sort((a,b) => b.size - a.size);
      setFiles(found.slice(0, 50));
    } catch { setFiles([]); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { scan(); }, []));

  const toggle = (id: string) => setSelected(prev => { const s=new Set(prev); s.has(id)?s.delete(id):s.add(id); return s; });
  const selBytes = files.filter(f=>selected.has(f.id)).reduce((t,f)=>t+f.size,0);
  const SORT_TABS = ['Size','Name','Type'];
  const sorted = [...files].sort((a,b) => sort===1 ? a.name.localeCompare(b.name) : sort===2 ? a.ext.localeCompare(b.ext) : b.size-a.size);

  const deleteSelected = async () => {
    if (selected.size === 0) return;
    Alert.alert('Delete Files', `Delete ${selected.size} file(s) (${fmtSize(selBytes)})?`, [
      { text:'Cancel', style:'cancel' },
      { text:'Delete', style:'destructive', onPress: async () => {
        try {
          const RNFS = require('react-native-fs').default ?? require('react-native-fs');
          const sel = files.filter(f=>selected.has(f.id));
          for (const f of sel) {
            try { await RNFS.unlink(f.path); } catch {}
          }
        } catch {}
        await scan();
      }},
    ]);
  };

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Large File Finder</Text>
        <TouchableOpacity onPress={scan} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>
      <View style={s.sortRow}>
        {SORT_TABS.map((t,i) => (
          <TouchableOpacity key={t} style={[s.sortTab,sort===i&&s.sortTabActive]} onPress={()=>setSort(i)}>
            <Text style={[s.sortText,sort===i&&s.sortTextActive]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>
      {loading
        ? <ActivityIndicator color={C.primary} style={{marginTop:40}}/>
        : files.length === 0
          ? <View style={s.empty}><Icon name="check-circle" size={48} color={C.success}/><Text style={s.emptyText}>No large files found</Text></View>
          : <FlatList
              data={sorted}
              keyExtractor={f=>f.id}
              contentContainerStyle={{paddingHorizontal:20,paddingBottom:100}}
              renderItem={({item:f}) => {
                const col = EXT_COLORS[f.ext] ?? EXT_COLORS.default;
                return (
                  <TouchableOpacity style={s.fileRow} onPress={()=>toggle(f.id)}>
                    <View style={[s.fileIcon,{backgroundColor:col+'33'}]}>
                      <Icon name={extIcon(f.ext)} size={20} color={col}/>
                    </View>
                    <View style={{flex:1,marginLeft:14}}>
                      <Text style={s.fileName} numberOfLines={1}>{f.name}</Text>
                      <Text style={s.filePath} numberOfLines={1}>{f.displayPath}</Text>
                    </View>
                    <Text style={[s.fileSize,{color:col}]}>{fmtSize(f.size)}</Text>
                    <View style={[s.check,selected.has(f.id)&&s.checkActive]}>
                      {selected.has(f.id) && <Icon name="check" size={14} color="#fff"/>}
                    </View>
                  </TouchableOpacity>
                );
              }}
            />
      }
      {selected.size > 0 && (
        <View style={s.bottomBar}>
          <TouchableOpacity style={{flex:1}} onPress={deleteSelected}>
            <LinearGradient colors={C.gradientDanger} style={s.cleanBtn}>
              <Text style={s.cleanBtnText}>Delete {selected.size} File(s) ({fmtSize(selBytes)})</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:12},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  sortRow:{flexDirection:'row',marginHorizontal:20,marginBottom:12,gap:8},
  sortTab:{paddingHorizontal:16,paddingVertical:8,borderRadius:radius.pill,backgroundColor:C.card,borderWidth:1,borderColor:C.border},
  sortTabActive:{backgroundColor:C.primary,borderColor:C.primary},
  sortText:{fontSize:13,color:C.textMuted,fontWeight:'600'}, sortTextActive:{color:'#fff'},
  empty:{flex:1,justifyContent:'center',alignItems:'center',gap:16},
  emptyText:{fontSize:16,color:C.textMuted,fontWeight:'600'},
  fileRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:10,borderWidth:1,borderColor:C.border},
  fileIcon:{width:44,height:44,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  fileName:{fontSize:14,fontWeight:'700',color:C.textPrimary}, filePath:{fontSize:11,color:C.textMuted,marginTop:2},
  fileSize:{fontSize:13,fontWeight:'700',marginRight:10}, check:{width:26,height:26,borderRadius:13,borderWidth:2,borderColor:C.border,justifyContent:'center',alignItems:'center'},
  checkActive:{backgroundColor:C.primary,borderColor:C.primary},
  bottomBar:{position:'absolute',bottom:0,left:0,right:0,padding:20,paddingBottom:36,backgroundColor:'rgba(10,15,30,0.95)'},
  cleanBtn:{borderRadius:radius.button,paddingVertical:16,alignItems:'center'},
  cleanBtnText:{fontSize:16,fontWeight:'800',color:'#fff'},
});
