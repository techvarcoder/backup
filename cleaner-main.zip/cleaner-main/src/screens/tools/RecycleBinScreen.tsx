import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, StatusBar, Alert, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { darkColors as C, radius } from '../../theme';

const BIN_KEY = '@AuroCleaner:recycle_bin';

interface BinItem { id: string; name: string; path: string; size: number; deletedAt: number; }

function fmtSize(b: number) { if(b>=1073741824) return (b/1073741824).toFixed(2)+' GB'; if(b>=1048576) return (b/1048576).toFixed(0)+' MB'; return (b/1024).toFixed(0)+' KB'; }
function timeAgo(ts: number) {
  const diff = Math.floor((Date.now()-ts)/1000);
  if (diff < 60) return 'Just now';
  if (diff < 3600) return Math.floor(diff/60)+'m ago';
  if (diff < 86400) return Math.floor(diff/3600)+'h ago';
  return Math.floor(diff/86400)+'d ago';
}

export default function RecycleBinScreen() {
  const navigation = useNavigation();
  const [items, setItems]   = useState<BinItem[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const raw = await AsyncStorage.getItem(BIN_KEY);
      setItems(raw ? JSON.parse(raw) : []);
    } catch { setItems([]); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { load(); }, []));

  const totalBytes = items.reduce((t,i)=>t+i.size,0);

  const restore = (id: string) => {
    Alert.alert('Restore', 'Restore this file? It will be moved back to its original path.', [
      { text:'Cancel', style:'cancel' },
      { text:'Restore', onPress: async () => {
        // Note: actual file restoration would require RNFS.moveFile from the bin path back
        const updated = items.filter(i=>i.id!==id);
        await AsyncStorage.setItem(BIN_KEY, JSON.stringify(updated));
        setItems(updated);
      }},
    ]);
  };

  const permDelete = (id: string) => {
    Alert.alert('Permanently Delete', 'This cannot be undone.', [
      { text:'Cancel', style:'cancel' },
      { text:'Delete', style:'destructive', onPress: async () => {
        try {
          const item = items.find(i=>i.id===id);
          if (item) {
            const RNFS = require('react-native-fs').default ?? require('react-native-fs');
            await RNFS.unlink(item.path).catch(() => {});
          }
        } catch {}
        const updated = items.filter(i=>i.id!==id);
        await AsyncStorage.setItem(BIN_KEY, JSON.stringify(updated));
        setItems(updated);
      }},
    ]);
  };

  const emptyBin = () => {
    if (items.length === 0) return;
    Alert.alert('Empty Recycle Bin', `Permanently delete all ${items.length} items?`, [
      { text:'Cancel', style:'cancel' },
      { text:'Empty All', style:'destructive', onPress: async () => {
        try {
          const RNFS = require('react-native-fs').default ?? require('react-native-fs');
          for (const item of items) { try { await RNFS.unlink(item.path); } catch {} }
        } catch {}
        await AsyncStorage.setItem(BIN_KEY, JSON.stringify([]));
        setItems([]);
      }},
    ]);
  };

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Recycle Bin</Text>
        {items.length > 0 && <TouchableOpacity onPress={emptyBin} style={s.btn}><Icon name="delete-sweep" size={22} color={C.danger}/></TouchableOpacity>}
        {items.length === 0 && <View style={s.btn}/>}
      </View>

      {items.length > 0 && (
        <View style={s.statRow}>
          <Icon name="recycle" size={16} color={C.warning}/>
          <Text style={s.statText}>{items.length} item{items.length!==1?'s':''} · {fmtSize(totalBytes)} total</Text>
        </View>
      )}

      {loading
        ? <ActivityIndicator color={C.primary} style={{marginTop:40}}/>
        : items.length === 0
          ? <View style={s.empty}>
              <Icon name="recycle" size={56} color={C.textMuted}/>
              <Text style={s.emptyTitle}>Recycle Bin is Empty</Text>
              <Text style={s.emptySub}>Files deleted by AuroCleaner will appear here</Text>
            </View>
          : <FlatList
              data={items}
              keyExtractor={i=>i.id}
              contentContainerStyle={{paddingHorizontal:20,paddingBottom:40}}
              renderItem={({item:i}) => (
                <View style={s.itemRow}>
                  <View style={s.itemIcon}><Icon name="file" size={22} color={C.textSecondary}/></View>
                  <View style={{flex:1,marginLeft:12}}>
                    <Text style={s.itemName} numberOfLines={1}>{i.name}</Text>
                    <Text style={s.itemMeta}>{fmtSize(i.size)} · {timeAgo(i.deletedAt)}</Text>
                  </View>
                  <TouchableOpacity onPress={()=>restore(i.id)} style={s.restoreBtn}><Icon name="restore" size={16} color={C.primary}/></TouchableOpacity>
                  <TouchableOpacity onPress={()=>permDelete(i.id)} style={s.deleteBtn}><Icon name="delete" size={16} color={C.danger}/></TouchableOpacity>
                </View>
              )}
            />
      }
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:12},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  statRow:{flexDirection:'row',alignItems:'center',gap:8,marginHorizontal:20,marginBottom:12},
  statText:{fontSize:13,color:C.textMuted},
  empty:{flex:1,justifyContent:'center',alignItems:'center',gap:12,paddingBottom:60},
  emptyTitle:{fontSize:18,fontWeight:'700',color:C.textPrimary}, emptySub:{fontSize:13,color:C.textMuted,textAlign:'center',paddingHorizontal:40},
  itemRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:10,borderWidth:1,borderColor:C.border},
  itemIcon:{width:44,height:44,borderRadius:radius.md,backgroundColor:C.cardElevated,justifyContent:'center',alignItems:'center'},
  itemName:{fontSize:13,fontWeight:'700',color:C.textPrimary}, itemMeta:{fontSize:11,color:C.textMuted,marginTop:2},
  restoreBtn:{padding:10}, deleteBtn:{padding:10},
});
