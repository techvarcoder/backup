import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, StatusBar, ActivityIndicator, Alert } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';

interface DupGroup { id: string; name: string; ext: string; count: number; totalBytes: number; paths: string[]; }

function fmtSize(b: number) { if(b>=1073741824) return (b/1073741824).toFixed(2)+' GB'; if(b>=1048576) return (b/1048576).toFixed(0)+' MB'; return (b/1024).toFixed(0)+' KB'; }

export default function DuplicateCleanerScreen() {
  const navigation = useNavigation();
  const [groups, setGroups]     = useState<DupGroup[]>([]);
  const [loading, setLoading]   = useState(false);
  const [scanned, setScanned]   = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const scan = async () => {
    setLoading(true);
    setScanned(false);
    setGroups([]);
    setSelected(new Set());
    try {
      const RNFS = require('react-native-fs').default ?? require('react-native-fs');
      const dirs = [
        RNFS.DownloadDirectoryPath,
        RNFS.ExternalStorageDirectoryPath+'/DCIM',
        RNFS.ExternalStorageDirectoryPath+'/Pictures',
      ].filter(Boolean);

      // Group files by name (potential duplicates)
      const byName: Record<string, Array<{path:string;size:number}>> = {};
      for (const dir of dirs) {
        try {
          const items = await RNFS.readDir(dir).catch(() => []);
          for (const item of items) {
            if (!item.isFile()) continue;
            const base = item.name.replace(/[ _-]copy[\d]*/i,'').replace(/ \(\d+\)/,'');
            if (!byName[base]) byName[base] = [];
            byName[base].push({ path: item.path, size: item.size });
          }
        } catch {}
      }

      let id = 0;
      const dupes: DupGroup[] = Object.entries(byName)
        .filter(([,files]) => files.length >= 2)
        .map(([name, files]) => ({
          id: String(id++),
          name,
          ext: name.split('.').pop()?.toLowerCase() ?? '',
          count: files.length,
          totalBytes: files.slice(1).reduce((t,f)=>t+f.size,0), // keep 1 copy
          paths: files.slice(1).map(f=>f.path), // paths to delete (keep first)
        }))
        .sort((a,b) => b.totalBytes - a.totalBytes);

      setGroups(dupes);
    } catch { setGroups([]); }
    finally { setLoading(false); setScanned(true); }
  };

  const toggle = (id: string) => setSelected(prev => { const s=new Set(prev); s.has(id)?s.delete(id):s.add(id); return s; });
  const selBytes = groups.filter(g=>selected.has(g.id)).reduce((t,g)=>t+g.totalBytes,0);

  const deleteDupes = () => {
    if (selected.size === 0) return;
    Alert.alert('Delete Duplicates', `Remove duplicates for ${selected.size} group(s) (${fmtSize(selBytes)})?`, [
      { text:'Cancel', style:'cancel' },
      { text:'Delete', style:'destructive', onPress: async () => {
        try {
          const RNFS = require('react-native-fs').default ?? require('react-native-fs');
          for (const g of groups.filter(g=>selected.has(g.id))) {
            for (const path of g.paths) {
              try { await RNFS.unlink(path); } catch {}
            }
          }
        } catch {}
        await scan();
      }},
    ]);
  };

  function extIcon(ext: string) {
    if (['jpg','jpeg','png','heic','webp'].includes(ext)) return 'image-multiple';
    if (['mp4','mkv','mov'].includes(ext)) return 'video-multiple';
    if (['mp3','aac','flac'].includes(ext)) return 'music-note-multiple';
    if (['pdf','doc','docx'].includes(ext)) return 'file-multiple';
    return 'content-copy';
  }

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Duplicate Cleaner</Text>
        <View style={s.btn}/>
      </View>

      {!scanned && !loading && (
        <View style={s.startWrap}>
          <Icon name="content-copy" size={56} color={C.textMuted}/>
          <Text style={s.startTitle}>Find Duplicate Files</Text>
          <Text style={s.startSub}>Scans Downloads, DCIM and Pictures for duplicate file names</Text>
          <TouchableOpacity onPress={scan} style={s.scanWrapper}>
            <LinearGradient colors={C.gradientPrimary} style={s.scanBtn}>
              <Icon name="magnify" size={22} color="#fff"/>
              <Text style={s.scanBtnText}>Start Scan</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}

      {loading && <ActivityIndicator color={C.primary} style={{marginTop:40}}/>}

      {scanned && !loading && groups.length === 0 && (
        <View style={s.empty}>
          <Icon name="check-circle" size={48} color={C.success}/>
          <Text style={s.emptyTitle}>No duplicates found</Text>
          <TouchableOpacity onPress={scan} style={s.rescanBtn}><Text style={s.rescanText}>Scan Again</Text></TouchableOpacity>
        </View>
      )}

      {scanned && groups.length > 0 && (
        <>
          <View style={s.summaryRow}>
            <Text style={s.summaryText}>{groups.length} duplicate group{groups.length!==1?'s':''} · {fmtSize(groups.reduce((t,g)=>t+g.totalBytes,0))} reclaimable</Text>
            <TouchableOpacity onPress={scan}><Icon name="refresh" size={18} color={C.primary}/></TouchableOpacity>
          </View>
          <FlatList
            data={groups}
            keyExtractor={g=>g.id}
            contentContainerStyle={{paddingHorizontal:20,paddingBottom:100}}
            renderItem={({item:g}) => (
              <TouchableOpacity style={s.groupRow} onPress={()=>toggle(g.id)}>
                <View style={[s.groupIcon,{backgroundColor:'#2563EB22'}]}>
                  <Icon name={extIcon(g.ext)} size={22} color="#2563EB"/>
                </View>
                <View style={{flex:1,marginLeft:14}}>
                  <Text style={s.groupName} numberOfLines={1}>{g.name}</Text>
                  <Text style={s.groupMeta}>{g.count} copies · {fmtSize(g.totalBytes)} to free</Text>
                </View>
                <View style={[s.check,selected.has(g.id)&&s.checkActive]}>
                  {selected.has(g.id) && <Icon name="check" size={14} color="#fff"/>}
                </View>
              </TouchableOpacity>
            )}
          />
          {selected.size > 0 && (
            <View style={s.bottomBar}>
              <TouchableOpacity style={{flex:1}} onPress={deleteDupes}>
                <LinearGradient colors={C.gradientDanger} style={s.cleanBtn}>
                  <Text style={s.cleanBtnText}>Delete Duplicates ({fmtSize(selBytes)})</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          )}
        </>
      )}
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:12},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  startWrap:{flex:1,justifyContent:'center',alignItems:'center',gap:16,paddingHorizontal:40,paddingBottom:60},
  startTitle:{fontSize:20,fontWeight:'800',color:C.textPrimary}, startSub:{fontSize:13,color:C.textMuted,textAlign:'center'},
  scanWrapper:{borderRadius:radius.button,overflow:'hidden',width:'100%',marginTop:8},
  scanBtn:{flexDirection:'row',alignItems:'center',justifyContent:'center',paddingVertical:16,gap:10},
  scanBtnText:{fontSize:17,fontWeight:'700',color:'#fff'},
  empty:{flex:1,justifyContent:'center',alignItems:'center',gap:16,paddingBottom:60},
  emptyTitle:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  rescanBtn:{paddingHorizontal:24,paddingVertical:10,borderRadius:radius.pill,borderWidth:1,borderColor:C.primary},
  rescanText:{fontSize:14,color:C.primary,fontWeight:'700'},
  summaryRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginHorizontal:20,marginBottom:12},
  summaryText:{fontSize:13,color:C.textMuted,flex:1},
  groupRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:10,borderWidth:1,borderColor:C.border},
  groupIcon:{width:46,height:46,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  groupName:{fontSize:14,fontWeight:'700',color:C.textPrimary}, groupMeta:{fontSize:11,color:C.textMuted,marginTop:2},
  check:{width:26,height:26,borderRadius:13,borderWidth:2,borderColor:C.border,justifyContent:'center',alignItems:'center'},
  checkActive:{backgroundColor:C.primary,borderColor:C.primary},
  bottomBar:{position:'absolute',bottom:0,left:0,right:0,padding:20,paddingBottom:36,backgroundColor:'rgba(10,15,30,0.95)'},
  cleanBtn:{borderRadius:radius.button,paddingVertical:16,alignItems:'center'},
  cleanBtnText:{fontSize:16,fontWeight:'800',color:'#fff'},
});
