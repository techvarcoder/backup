import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, ActivityIndicator, Alert } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';

interface WaCategory { icon:string; label:string; path:string; exts:string[]; count:number; bytes:number; checked:boolean; }

function fmtSize(b: number) { if(b>=1073741824) return (b/1073741824).toFixed(2)+' GB'; if(b>=1048576) return (b/1048576).toFixed(0)+' MB'; return (b/1024).toFixed(0)+' KB'; }

const INIT_CATS: WaCategory[] = [
  { icon:'video-outline',   label:'Videos',         path:'WhatsApp/Media/WhatsApp Video',    exts:['mp4','3gp'],  count:0, bytes:0, checked:true  },
  { icon:'image-outline',   label:'Images',         path:'WhatsApp/Media/WhatsApp Images',   exts:['jpg','jpeg'], count:0, bytes:0, checked:false },
  { icon:'microphone',      label:'Voice Notes',    path:'WhatsApp/Media/WhatsApp Audio',    exts:['opus','m4a','aac'], count:0, bytes:0, checked:false },
  { icon:'sticker-emoji',   label:'Stickers',       path:'WhatsApp/Media/WhatsApp Stickers', exts:['webp'],       count:0, bytes:0, checked:false },
  { icon:'download-circle', label:'Documents',      path:'WhatsApp/Media/WhatsApp Documents',exts:['pdf','doc','zip','apk'], count:0, bytes:0, checked:true },
  { icon:'image-size-select-large', label:'Status Saves', path:'WhatsApp/Media/.Statuses',  exts:['jpg','mp4','webp'], count:0, bytes:0, checked:true },
];

const TABS = ['CHATS','IMAGES','VIDEOS','DOCS'];

export default function WhatsAppCleanerScreen() {
  const navigation = useNavigation();
  const [cats, setCats]       = useState<WaCategory[]>(INIT_CATS.map(c=>({...c})));
  const [loading, setLoading] = useState(true);
  const [tab, setTab]         = useState(0);

  const scan = async () => {
    setLoading(true);
    try {
      const RNFS = require('react-native-fs').default ?? require('react-native-fs');
      const base = RNFS.ExternalStorageDirectoryPath ?? '';
      const updated = await Promise.all(INIT_CATS.map(async cat => {
        let count = 0; let bytes = 0;
        try {
          const dir = `${base}/${cat.path}`;
          const items = await RNFS.readDir(dir).catch(() => []);
          for (const item of items) {
            if (!item.isFile()) continue;
            const ext = item.name.split('.').pop()?.toLowerCase() ?? '';
            if (cat.exts.includes(ext)) { count++; bytes += item.size ?? 0; }
          }
        } catch {}
        return { ...cat, count, bytes };
      }));
      setCats(updated);
    } catch {}
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { scan(); }, []));

  const toggle = (idx: number) => setCats(prev => prev.map((c,i) => i===idx?{...c,checked:!c.checked}:c));
  const selectedBytes = cats.filter(c=>c.checked).reduce((t,c)=>t+c.bytes,0);
  const totalBytes    = cats.reduce((t,c)=>t+c.bytes,0);

  const clean = () => {
    const sel = cats.filter(c=>c.checked);
    if (sel.length === 0) return;
    Alert.alert('Clean WhatsApp Media', `Delete ${sel.length} category(s) (${fmtSize(selectedBytes)})?`, [
      { text:'Cancel', style:'cancel' },
      { text:'Clean', style:'destructive', onPress: async () => {
        try {
          const RNFS = require('react-native-fs').default ?? require('react-native-fs');
          const base = RNFS.ExternalStorageDirectoryPath ?? '';
          for (const cat of sel) {
            try {
              const dir = `${base}/${cat.path}`;
              const items = await RNFS.readDir(dir).catch(() => []);
              for (const item of items) {
                const ext = item.name.split('.').pop()?.toLowerCase()??'';
                if (cat.exts.includes(ext)) { try { await RNFS.unlink(item.path); } catch {} }
              }
            } catch {}
          }
        } catch {}
        await scan();
      }},
    ]);
  };

  const waInstalled = totalBytes > 0;

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>WhatsApp Cleaner</Text>
        <TouchableOpacity onPress={scan} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>

      <LinearGradient colors={['#16A34A22','#15803D11']} style={s.summaryCard}>
        <LinearGradient colors={['#16A34A','#15803D']} style={s.waIcon}>
          <Icon name="whatsapp" size={28} color="#fff"/>
        </LinearGradient>
        <View style={{marginLeft:16,flex:1}}>
          {loading
            ? <ActivityIndicator color={C.success} size="small"/>
            : <>
                <Text style={s.summarySize}>{fmtSize(totalBytes)}</Text>
                <Text style={s.summarySub}>{waInstalled?'WhatsApp media found':'WhatsApp not found on device'}</Text>
              </>
          }
        </View>
        {!loading && <View style={s.selBadge}><Text style={s.selText}>{cats.filter(c=>c.checked).length} Selected</Text></View>}
      </LinearGradient>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={s.tabScroll} contentContainerStyle={{paddingHorizontal:20,gap:8}}>
        {TABS.map((t,i) => (
          <TouchableOpacity key={t} style={[s.tab,tab===i&&s.tabActive]} onPress={()=>setTab(i)}>
            <Text style={[s.tabText,tab===i&&s.tabTextActive]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <ScrollView contentContainerStyle={s.body}>
        {cats.map((cat,i) => (
          <TouchableOpacity key={cat.label} style={s.catRow} onPress={()=>toggle(i)}>
            <LinearGradient colors={cat.checked?['#16A34A','#15803D']:['#1E293B','#1E293B']} style={s.catIcon}>
              <Icon name={cat.icon} size={20} color={cat.checked?'#fff':C.textMuted}/>
            </LinearGradient>
            <View style={{flex:1,marginLeft:14}}>
              <Text style={s.catLabel}>{cat.label}</Text>
              <Text style={s.catMeta}>{cat.count} files · {fmtSize(cat.bytes)}</Text>
            </View>
            <View style={[s.check,cat.checked&&s.checkActive]}>
              {cat.checked&&<Icon name="check" size={14} color="#fff"/>}
            </View>
          </TouchableOpacity>
        ))}
        <View style={{height:100}}/>
      </ScrollView>

      <View style={s.bottomBar}>
        <TouchableOpacity style={{flex:1}} onPress={clean} disabled={selectedBytes===0}>
          <LinearGradient colors={selectedBytes>0?['#16A34A','#15803D']:['#1E293B','#1E293B']} style={s.cleanBtn}>
            <Text style={s.cleanBtnText}>Clean · {fmtSize(selectedBytes)}</Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:8},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  summaryCard:{flexDirection:'row',alignItems:'center',marginHorizontal:20,marginBottom:12,borderRadius:radius.xl,padding:16},
  waIcon:{width:52,height:52,borderRadius:16,justifyContent:'center',alignItems:'center'},
  summarySize:{fontSize:22,fontWeight:'900',color:C.textPrimary}, summarySub:{fontSize:12,color:C.textMuted,marginTop:2},
  selBadge:{backgroundColor:'#16A34A22',borderRadius:radius.pill,paddingHorizontal:10,paddingVertical:4},
  selText:{fontSize:12,color:C.success,fontWeight:'700'},
  tabScroll:{maxHeight:48,marginBottom:8},
  tab:{paddingHorizontal:16,paddingVertical:8,borderRadius:radius.pill,borderWidth:1,borderColor:C.border},
  tabActive:{backgroundColor:'#16A34A',borderColor:'#16A34A'},
  tabText:{fontSize:12,color:C.textMuted,fontWeight:'700'}, tabTextActive:{color:'#fff'},
  body:{paddingHorizontal:20},
  catRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:10,borderWidth:1,borderColor:C.border},
  catIcon:{width:44,height:44,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  catLabel:{fontSize:14,fontWeight:'700',color:C.textPrimary}, catMeta:{fontSize:11,color:C.textMuted,marginTop:2},
  check:{width:26,height:26,borderRadius:13,borderWidth:2,borderColor:C.border,justifyContent:'center',alignItems:'center'},
  checkActive:{backgroundColor:C.success,borderColor:C.success},
  bottomBar:{position:'absolute',bottom:0,left:0,right:0,padding:20,paddingBottom:36,backgroundColor:'rgba(10,15,30,0.95)'},
  cleanBtn:{borderRadius:radius.button,paddingVertical:16,alignItems:'center'},
  cleanBtnText:{fontSize:16,fontWeight:'800',color:'#fff'},
});
