import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

interface Alert { icon: string; title: string; sub: string; action: string; color: string; severity: 'High'|'Medium'|'Low'; }

const SEV_COLOR = { High:'#EF4444', Medium:'#F59E0B', Low:'#22C55E' };

export default function SmartAlertsScreen() {
  const navigation = useNavigation();
  const { deviceStats, cleanHistory, refreshDeviceStats } = useAppStore();

  useFocusEffect(React.useCallback(() => { refreshDeviceStats(); }, []));

  const alerts: Alert[] = useMemo(() => {
    const list: Alert[] = [];
    const storagePct = Math.round(deviceStats.storageUsed / deviceStats.storageTotal * 100);
    const ramPct     = Math.round(deviceStats.ramUsed     / deviceStats.ramTotal     * 100);

    if (storagePct > 90)
      list.push({ icon:'harddisk-remove', title:'Storage Critical', sub:`${storagePct}% storage used — only ${(deviceStats.storageTotal-deviceStats.storageUsed).toFixed(1)} GB free`, action:'Clean Now', color:'#EF4444', severity:'High' });
    else if (storagePct > 70)
      list.push({ icon:'harddisk',        title:'Storage Almost Full', sub:`${storagePct}% of ${deviceStats.storageTotal} GB used`, action:'Clean Now', color:'#F59E0B', severity:'Medium' });

    if (deviceStats.temperature > 45)
      list.push({ icon:'thermometer-alert', title:'Device Overheating', sub:`Temperature at ${deviceStats.temperature}°C — close background apps`, action:'Cool Down', color:'#EF4444', severity:'High' });
    else if (deviceStats.temperature > 38)
      list.push({ icon:'thermometer-high',  title:'Elevated Temperature', sub:`Temperature at ${deviceStats.temperature}°C`, action:'Monitor', color:'#F59E0B', severity:'Medium' });

    if (ramPct > 85)
      list.push({ icon:'memory', title:'RAM Pressure', sub:`${deviceStats.ramUsed} GB of ${deviceStats.ramTotal} GB RAM used (${ramPct}%)`, action:'Boost RAM', color:'#EF4444', severity:'High' });
    else if (ramPct > 70)
      list.push({ icon:'memory', title:'Memory Usage High', sub:`${ramPct}% RAM in use`, action:'Boost', color:'#F59E0B', severity:'Medium' });

    if (!deviceStats.isCharging && deviceStats.batteryLevel < 20)
      list.push({ icon:'battery-alert',     title:'Battery Low', sub:`Battery at ${deviceStats.batteryLevel}% — please charge`, action:'View', color:'#EF4444', severity:'High' });
    if (deviceStats.batteryHealth > 0 && deviceStats.batteryHealth < 70)
      list.push({ icon:'battery-heart-outline', title:'Battery Health Declining', sub:`Health at ${deviceStats.batteryHealth}% — consider replacement`, action:'View', color:'#F59E0B', severity:'Medium' });

    if (cleanHistory.length > 0) {
      const daysSince = Math.floor((Date.now() - new Date(cleanHistory[0].date).getTime()) / 86400000);
      if (daysSince >= 14)
        list.push({ icon:'broom', title:'Cleanup Overdue', sub:`Last cleaned ${daysSince} days ago`, action:'Clean', color:'#3B82F6', severity:'Medium' });
    } else {
      list.push({ icon:'broom', title:'No Cleanups Yet', sub:'Start your first cleanup to free up space', action:'Clean', color:'#3B82F6', severity:'Low' });
    }

    if (list.length === 0)
      list.push({ icon:'shield-check', title:'All Clear', sub:'No issues detected — your device is healthy', action:'View', color:'#22C55E', severity:'Low' });

    return list.sort((a,b) => Object.keys(SEV_COLOR).indexOf(a.severity) - Object.keys(SEV_COLOR).indexOf(b.severity));
  }, [deviceStats, cleanHistory]);

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.back}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Smart Alerts</Text>
        <View style={s.countBadge}><Text style={s.countText}>{alerts.length}</Text></View>
      </View>

      <ScrollView contentContainerStyle={{paddingHorizontal:20,paddingBottom:40}}>
        {alerts.map((a,i) => (
          <View key={i} style={s.alertCard}>
            <View style={[s.alertIcon,{backgroundColor:a.color+'22'}]}>
              <Icon name={a.icon} size={22} color={a.color}/>
            </View>
            <View style={{flex:1,marginLeft:14}}>
              <View style={s.alertHeader}>
                <Text style={s.alertTitle}>{a.title}</Text>
                <View style={[s.sevBadge,{backgroundColor:SEV_COLOR[a.severity]+'22'}]}>
                  <Text style={[s.sevText,{color:SEV_COLOR[a.severity]}]}>{a.severity}</Text>
                </View>
              </View>
              <Text style={s.alertSub}>{a.sub}</Text>
              <TouchableOpacity style={[s.actionBtn,{borderColor:a.color}]}>
                <Text style={[s.actionText,{color:a.color}]}>{a.action}</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:16},
  back:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  countBadge:{backgroundColor:C.primary,borderRadius:10,paddingHorizontal:8,paddingVertical:4}, countText:{fontSize:13,fontWeight:'800',color:'#fff'},
  alertCard:{flexDirection:'row',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:10,borderWidth:1,borderColor:C.border},
  alertIcon:{width:46,height:46,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  alertHeader:{flexDirection:'row',alignItems:'center',marginBottom:4,gap:8},
  alertTitle:{fontSize:13,fontWeight:'700',color:C.textPrimary,flex:1},
  sevBadge:{borderRadius:radius.pill,paddingHorizontal:8,paddingVertical:3}, sevText:{fontSize:10,fontWeight:'800'},
  alertSub:{fontSize:12,color:C.textMuted,lineHeight:17},
  actionBtn:{alignSelf:'flex-start',marginTop:8,paddingHorizontal:14,paddingVertical:6,borderRadius:radius.pill,borderWidth:1.5},
  actionText:{fontSize:12,fontWeight:'700'},
});
