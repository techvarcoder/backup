import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, Switch } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius, spacing } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

const TOOLS = [
  { icon:'bell-off',        label:'Block Notifications', key:'notif'  },
  { icon:'brightness-5',    label:'Lock Brightness',     key:'bright' },
  { icon:'rocket-launch',   label:'Performance Mode',    key:'perf'   },
  { icon:'memory',          label:'Auto Clean RAM',      key:'ram'    },
  { icon:'speedometer',     label:'FPS Monitor',         key:'fps'    },
  { icon:'wifi-strength-4', label:'Prioritize Network',  key:'net'    },
];

export default function GamingModeScreen() {
  const navigation = useNavigation();
  const { deviceStats, refreshDeviceStats } = useAppStore();
  const [enabled, setEnabled] = useState<Record<string,boolean>>({ notif:true, bright:false, perf:true, ram:true, fps:true, net:false });
  const [active, setActive]   = useState(false);

  useFocusEffect(React.useCallback(() => { refreshDeviceStats(); }, []));

  const tempColor = deviceStats.temperature > 45 ? C.danger : deviceStats.temperature > 38 ? C.warning : deviceStats.temperature > 0 ? C.success : C.textMuted;
  const ramPct    = Math.round(deviceStats.ramUsed / deviceStats.ramTotal * 100);
  const ramColor  = ramPct > 80 ? C.danger : ramPct > 60 ? C.warning : C.success;

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.back}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Gaming Mode</Text>
        <View style={{width:40}}/>
      </View>

      <ScrollView contentContainerStyle={{paddingHorizontal:20,paddingBottom:40}}>
        {/* Status Card */}
        <LinearGradient colors={['#1E293B','#0F172A']} style={s.statusCard}>
          <Text style={s.statusLabel}>Device Status</Text>
          <View style={s.statusRow}>
            <View style={s.statusStat}>
              <Icon name="thermometer" size={18} color={tempColor}/>
              <Text style={[s.statusVal,{color:tempColor}]}>{deviceStats.temperature > 0 ? `${deviceStats.temperature}°C` : '—'}</Text>
              <Text style={s.statusSub}>Temp</Text>
            </View>
            <View style={s.statusStat}>
              <Icon name="memory" size={18} color={ramColor}/>
              <Text style={[s.statusVal,{color:ramColor}]}>{ramPct}%</Text>
              <Text style={s.statusSub}>RAM</Text>
            </View>
            <View style={s.statusStat}>
              <Icon name="battery" size={18} color={deviceStats.batteryLevel>50?C.success:C.warning}/>
              <Text style={[s.statusVal,{color:deviceStats.batteryLevel>50?C.success:C.warning}]}>{deviceStats.batteryLevel}%</Text>
              <Text style={s.statusSub}>Battery</Text>
            </View>
            <View style={s.statusStat}>
              <Icon name="cpu-64-bit" size={18} color={deviceStats.cpuUsage>70?C.warning:C.success}/>
              <Text style={[s.statusVal,{color:deviceStats.cpuUsage>70?C.warning:C.success}]}>{deviceStats.cpuUsage}%</Text>
              <Text style={s.statusSub}>CPU</Text>
            </View>
          </View>
        </LinearGradient>

        {/* Activate Gaming Mode */}
        <View style={s.activateRow}>
          <View style={{flex:1}}>
            <Text style={s.activateTitle}>Gaming Mode</Text>
            <Text style={s.activateSub}>{active?'Active — device optimized for gaming':'Inactive — tap to enable'}</Text>
          </View>
          <Switch
            value={active}
            onValueChange={setActive}
            trackColor={{ false:C.border, true:C.success+'88' }}
            thumbColor={active?C.success:C.textMuted}
          />
        </View>

        <Text style={s.sectionTitle}>Gaming Tools</Text>
        <View style={s.toolsCard}>
          {TOOLS.map(t => (
            <View key={t.key} style={s.toolRow}>
              <LinearGradient colors={enabled[t.key]?['#22C55E33','#16A34A11']:['#1E293B','#1E293B']} style={s.toolIcon}>
                <Icon name={t.icon} size={18} color={enabled[t.key]?C.success:C.textMuted}/>
              </LinearGradient>
              <Text style={s.toolLabel}>{t.label}</Text>
              <Switch
                value={enabled[t.key]}
                onValueChange={v=>setEnabled(prev=>({...prev,[t.key]:v}))}
                trackColor={{ false:C.border, true:C.success+'88' }}
                thumbColor={enabled[t.key]?C.success:C.textMuted}
              />
            </View>
          ))}
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:12},
  back:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  statusCard:{borderRadius:radius.card,padding:20,marginBottom:16,borderWidth:1,borderColor:'#22293B'},
  statusLabel:{fontSize:14,fontWeight:'700',color:C.textSecondary,marginBottom:14},
  statusRow:{flexDirection:'row',justifyContent:'space-around'},
  statusStat:{alignItems:'center',gap:4}, statusVal:{fontSize:16,fontWeight:'800'}, statusSub:{fontSize:10,color:C.textMuted},
  activateRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:16,marginBottom:20,borderWidth:1,borderColor:C.border},
  activateTitle:{fontSize:15,fontWeight:'700',color:C.textPrimary}, activateSub:{fontSize:12,color:C.textMuted,marginTop:2},
  sectionTitle:{fontSize:15,fontWeight:'700',color:C.textSecondary,marginBottom:12},
  toolsCard:{backgroundColor:C.card,borderRadius:radius.card,overflow:'hidden',borderWidth:1,borderColor:C.border},
  toolRow:{flexDirection:'row',alignItems:'center',padding:16,gap:14,borderBottomWidth:1,borderBottomColor:C.border},
  toolIcon:{width:38,height:38,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  toolLabel:{flex:1,fontSize:14,fontWeight:'600',color:C.textPrimary},
});
