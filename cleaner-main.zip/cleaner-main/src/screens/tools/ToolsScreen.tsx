import React from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../navigation/types';
import { darkColors as C, radius, spacing } from '../../theme';

type Nav = NativeStackNavigationProp<RootStackParamList>;

const TOOLS = [
  { icon: 'delete-sweep', label: 'Junk Cleaner', colors: ['#2563EB', '#1D4ED8'], nav: 'SmartScan' },
  { icon: 'content-copy', label: 'Duplicate\nCleaner', colors: ['#7C3AED', '#6D28D9'], nav: 'DuplicateCleaner' },
  { icon: 'whatsapp', label: 'WhatsApp\nCleaner', colors: ['#16A34A', '#15803D'], nav: 'WhatsAppCleaner' },
  { icon: 'camera-outline', label: 'Screenshot\nCleaner', colors: ['#0891B2', '#0E7490'], nav: 'ScreenshotCleaner' },
  { icon: 'magnify', label: 'Large File\nFinder', colors: ['#D97706', '#B45309'], nav: 'LargeFileFinder' },
  { icon: 'image-multiple-outline', label: 'App\nManager', colors: ['#DC2626', '#B91C1C'], nav: 'AppManager' },
  { icon: 'battery-charging', label: 'Battery\nMonitor', colors: ['#059669', '#047857'], nav: 'BatteryMonitor' },
  { icon: 'cpu-64-bit', label: 'CPU\nMonitor', colors: ['#7C3AED', '#5B21B6'], nav: 'CPUMonitor' },
  { icon: 'wifi-strength-3', label: 'Network\nMonitor', colors: ['#0284C7', '#0369A1'], nav: 'NetworkMonitor' },
  { icon: 'shield-check-outline', label: 'Security\nMonitor', colors: ['#B45309', '#92400E'], nav: 'SecurityScanner' },
  { icon: 'robot-outline', label: 'AI\nInsights', colors: ['#4F46E5', '#4338CA'], nav: 'AIInsights' },
  { icon: 'chart-timeline-variant', label: 'Storage\nForecast', colors: ['#0F766E', '#115E59'], nav: 'StoragePrediction' },
  // Hidden until native controls are fully implemented end-to-end.
  // { icon: 'gamepad-variant', label: 'Gaming\nMode', colors: ['#BE185D', '#9D174D'], nav: 'GamingMode' },
  // { icon: 'recycle', label: 'Recycle\nBin', colors: ['#4B5563', '#374151'], nav: 'RecycleBin' },
];

export default function ToolsScreen() {
  const navigation = useNavigation<Nav>();

  return (
    <LinearGradient colors={['#0A0F1E', '#0F172A']} style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />

      <View style={styles.header}>
        <Text style={styles.title}>Tools</Text>
        <TouchableOpacity style={styles.searchBtn}>
          <Icon name="magnify" size={22} color={C.textSecondary} />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.grid}>
        {TOOLS.map((tool) => (
          <TouchableOpacity
            key={tool.label}
            style={styles.toolCard}
            activeOpacity={0.75}
            onPress={() => navigation.navigate(tool.nav as any)}
          >
            <LinearGradient colors={tool.colors} style={styles.iconBox}>
              <Icon name={tool.icon} size={26} color="#fff" />
            </LinearGradient>
            <Text style={styles.toolLabel} numberOfLines={2}>{tool.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingTop: 56, paddingHorizontal: 24, paddingBottom: 12 },
  title: { fontSize: 24, fontWeight: '800', color: C.textPrimary },
  searchBtn: { width: 40, height: 40, backgroundColor: C.card, borderRadius: 20, justifyContent: 'center', alignItems: 'center' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 16, paddingBottom: 100 },
  toolCard: { width: '25%', alignItems: 'center', paddingVertical: 12, paddingHorizontal: 4 },
  iconBox: { width: 60, height: 60, borderRadius: radius.xl, justifyContent: 'center', alignItems: 'center', marginBottom: 8, shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.25, shadowRadius: 8, elevation: 6 },
  toolLabel: { fontSize: 11, color: C.textSecondary, textAlign: 'center', lineHeight: 16 },
});
