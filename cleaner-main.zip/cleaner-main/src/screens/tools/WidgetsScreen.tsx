import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { darkColors as C, radius, spacing } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

const WIDGETS = [
  { id:'1', name:'Storage Widget', desc:'Shows storage usage at a glance', icon:'harddisk', color:['#2563EB','#1D4ED8'], size:'2x1' },
  { id:'2', name:'Quick Clean', desc:'One-tap clean from home screen', icon:'broom', color:['#22C55E','#16A34A'], size:'1x1' },
  { id:'3', name:'AI Insights', desc:'Daily AI tips & recommendations', icon:'robot-outline', color:['#7C3AED','#6D28D9'], size:'2x1' },
  { id:'4', name:'Battery Monitor', desc:'Live battery health widget', icon:'battery-heart', color:['#F59E0B','#D97706'], size:'1x1' },
  { id:'5', name:'Health Score', desc:'Device health score at a glance', icon:'heart-pulse', color:['#EF4444','#DC2626'], size:'2x2' },
];

export default function WidgetsScreen() {
  const navigation = useNavigation();
  const { deviceStats } = useAppStore();
  const [enabled, setEnabled] = useState<Set<string>>(new Set(['1', '2']));
  const storagePct = Math.round(deviceStats.storageUsed / deviceStats.storageTotal * 100);
  const freeGB = (deviceStats.storageTotal - deviceStats.storageUsed).toFixed(1);
  const junkGB = deviceStats.junkSize.toFixed(1);

  const toggleWidget = (id: string) => {
    setEnabled(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  return (
    <LinearGradient colors={["#0A0F1E","#0F172A"]} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}>
          <Icon name="arrow-left" size={22} color={C.textSecondary} />
        </TouchableOpacity>
        <Text style={s.title}>Widgets</Text>
        <View style={{ width: 40 }} />
      </View>

      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40 }}>
        {/* Preview */}
        <Text style={s.sectionTitle}>Preview</Text>
        <LinearGradient colors={['#1A2035','#0F172A']} style={s.previewCard}>
          <View style={s.previewRow}>
            <LinearGradient colors={['#2563EB','#1D4ED8']} style={s.previewWidget}>
              <Icon name="harddisk" size={20} color="#fff" />
              <Text style={s.previewPct}>{storagePct}%</Text>
              <Text style={s.previewSub}>{freeGB} GB left</Text>
            </LinearGradient>
            <LinearGradient colors={['#22C55E','#16A34A']} style={[s.previewWidget, s.smallWidget]}>
              <Icon name="broom" size={22} color="#fff" />
              <Text style={s.previewSmallLabel}>Quick's Clean</Text>
            </LinearGradient>
          </View>
          <LinearGradient colors={['#7C3AED22','#1E293B']} style={s.previewAI}>
            <Icon name="robot-outline" size={22} color="#A78BFA" />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={s.aiWidgetTitle}>AI Insights</Text>
              <Text style={s.aiWidgetSub}>{junkGB} GB can be cleaned</Text>
            </View>
            <TouchableOpacity style={s.aiWidgetBtn}><Text style={s.aiWidgetBtnText}>Clean</Text></TouchableOpacity>
          </LinearGradient>
        </LinearGradient>

        {/* Available Widgets */}
        <Text style={s.sectionTitle}>Available Widgets</Text>
        {WIDGETS.map(w => (
          <View key={w.id} style={s.widgetRow}>
            <LinearGradient colors={w.color} style={s.widgetIcon}>
              <Icon name={w.icon} size={22} color="#fff" />
            </LinearGradient>
            <View style={{ flex: 1, marginLeft: 14 }}>
              <Text style={s.widgetName}>{w.name}</Text>
              <Text style={s.widgetDesc}>{w.desc}</Text>
              <View style={s.sizeBadge}><Text style={s.sizeText}>{w.size}</Text></View>
            </View>
            <TouchableOpacity onPress={() => toggleWidget(w.id)} style={[s.addBtn, s.toggleBtn, enabled.has(w.id) && s.toggleBtnActive]}>
              <Icon name={enabled.has(w.id) ? 'check' : 'plus'} size={14} color={enabled.has(w.id) ? '#fff' : C.primary} />
            </TouchableOpacity>
          </View>
        ))}

        <Text style={s.sectionTitle}>Quick Launch</Text>
        <View style={s.quickWrap}>
          <TouchableOpacity style={s.quickBtn} onPress={() => (navigation as any).navigate('StorageTimeline')}>
            <Icon name="chart-bar" size={16} color={C.primary} />
            <Text style={s.quickText}>Storage</Text>
          </TouchableOpacity>
          <TouchableOpacity style={s.quickBtn} onPress={() => (navigation as any).navigate('SmartScan')}>
            <Icon name="broom" size={16} color={C.primary} />
            <Text style={s.quickText}>Clean</Text>
          </TouchableOpacity>
          <TouchableOpacity style={s.quickBtn} onPress={() => (navigation as any).navigate('AIInsights')}>
            <Icon name="robot-outline" size={16} color={C.primary} />
            <Text style={s.quickText}>AI</Text>
          </TouchableOpacity>
        </View>

        <View style={s.hint}>
          <Icon name="information-outline" size={16} color={C.textMuted} />
          <Text style={s.hintText}>{enabled.size} widget(s) enabled in app preview. Native home screen widgets can be added from launcher widgets panel.</Text>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 56, paddingHorizontal: 20, paddingBottom: 12 },
  back: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 18, fontWeight: '700', color: C.textPrimary },
  sectionTitle: { fontSize: 14, fontWeight: '700', color: C.textSecondary, marginBottom: 12 },
  previewCard: { borderRadius: radius.card, padding: 16, marginBottom: 24, borderWidth: 1, borderColor: C.border, gap: 10 },
  previewRow: { flexDirection: 'row', gap: 10 },
  previewWidget: { flex: 2, height: 80, borderRadius: radius.xl, padding: 12, justifyContent: 'space-between' },
  smallWidget: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 4 },
  previewPct: { fontSize: 22, fontWeight: '900', color: '#fff' },
  previewSub: { fontSize: 10, color: 'rgba(255,255,255,0.7)' },
  previewSmallLabel: { fontSize: 10, color: '#fff', textAlign: 'center', fontWeight: '700' },
  previewAI: { flexDirection: 'row', alignItems: 'center', borderRadius: radius.xl, padding: 14, borderWidth: 1, borderColor: '#7C3AED44' },
  aiWidgetTitle: { fontSize: 13, fontWeight: '700', color: C.textPrimary },
  aiWidgetSub: { fontSize: 11, color: C.textMuted },
  aiWidgetBtn: { backgroundColor: C.primary, paddingHorizontal: 12, paddingVertical: 6, borderRadius: radius.pill },
  aiWidgetBtnText: { fontSize: 12, color: '#fff', fontWeight: '700' },
  widgetRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: C.card, borderRadius: radius.xl, padding: 16, marginBottom: 10, borderWidth: 1, borderColor: C.border },
  widgetIcon: { width: 48, height: 48, borderRadius: radius.md, justifyContent: 'center', alignItems: 'center' },
  widgetName: { fontSize: 14, fontWeight: '700', color: C.textPrimary },
  widgetDesc: { fontSize: 12, color: C.textMuted, marginTop: 2, marginBottom: 6 },
  sizeBadge: { backgroundColor: C.cardElevated, paddingHorizontal: 8, paddingVertical: 2, borderRadius: radius.pill, alignSelf: 'flex-start' },
  sizeText: { fontSize: 10, color: C.textMuted, fontWeight: '700' },
  addBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  toggleBtn: { width: 28, height: 28, borderRadius: 14, borderWidth: 1, borderColor: C.primary, justifyContent: 'center', alignItems: 'center' },
  toggleBtnActive: { backgroundColor: C.primary },
  quickWrap: { flexDirection: 'row', gap: 8, marginBottom: 10 },
  quickBtn: { flex: 1, flexDirection: 'row', gap: 6, justifyContent: 'center', alignItems: 'center', backgroundColor: C.card, borderWidth: 1, borderColor: C.border, borderRadius: radius.pill, paddingVertical: 10 },
  quickText: { fontSize: 12, color: C.textSecondary, fontWeight: '700' },
  hint: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, backgroundColor: C.card, borderRadius: radius.xl, padding: 14, marginTop: 4, borderWidth: 1, borderColor: C.border },
  hintText: { flex: 1, fontSize: 12, color: C.textMuted, lineHeight: 18 },
});
