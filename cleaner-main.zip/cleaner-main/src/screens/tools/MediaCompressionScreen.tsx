import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, StatusBar, ActivityIndicator, Alert } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

interface MediaFile { id: string; name: string; path: string; size: number; ext: string; }

function fmtSize(b: number) { if(b>=1073741824) return (b/1073741824).toFixed(2)+' GB'; if(b>=1048576) return (b/1048576).toFixed(0)+' MB'; return (b/1024).toFixed(0)+' KB'; }
const IMG_EXT = ['jpg','jpeg','png','heic','webp','bmp'];
const VID_EXT = ['mp4','mkv','mov','avi','3gp'];

export default function MediaCompressionScreen() {
  const navigation = useNavigation();
  const { updateDeviceStats, addActivity, deviceStats } = useAppStore();
  const [tab, setTab]           = useState(0);
  const [quality, setQuality]   = useState<'high'|'medium'|'low'>('medium');
  const [files, setFiles]       = useState<MediaFile[]>([]);
  const [loading, setLoading]   = useState(false);
  const [optimizing, setOptimizing] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const scan = async () => {
    setLoading(true);
    setFiles([]);
    setSelected(new Set());
    try {
      const RNFS = require('react-native-fs').default ?? require('react-native-fs');
      const dirs = [
        RNFS.ExternalStorageDirectoryPath+'/DCIM',
        RNFS.ExternalStorageDirectoryPath+'/Pictures',
        RNFS.ExternalStorageDirectoryPath+'/Movies',
        RNFS.DownloadDirectoryPath,
      ].filter(Boolean);

      const found: MediaFile[] = [];
      let id = 0;
      for (const dir of dirs) {
        try {
          const items = await RNFS.readDir(dir).catch(() => []);
          for (const item of items) {
            if (!item.isFile()) continue;
            const ext = item.name.split('.').pop()?.toLowerCase() ?? '';
            if (![...IMG_EXT,...VID_EXT].includes(ext)) continue;
            if (item.size < 500*1024) continue; // skip tiny files
            found.push({ id: String(id++), name: item.name, path: item.path, size: item.size, ext });
          }
        } catch {}
      }
      setFiles(found.sort((a,b)=>b.size-a.size));
    } catch { setFiles([]); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { scan(); }, []));

  const TABS = ['All','Images','Videos'];
  const filtered = tab===1 ? files.filter(f=>IMG_EXT.includes(f.ext)) : tab===2 ? files.filter(f=>VID_EXT.includes(f.ext)) : files;
  const toggle = (id: string) => setSelected(prev => { const s=new Set(prev); s.has(id)?s.delete(id):s.add(id); return s; });
  const selBytes = files.filter(f=>selected.has(f.id)).reduce((t,f)=>t+f.size,0);
  const ratio = quality === 'high' ? 0.12 : quality === 'medium' ? 0.22 : 0.32;
  const estimatedSaved = Math.round(selBytes * ratio);

  const compress = () => {
    if (selected.size === 0 || optimizing) return;

    Alert.alert(
      'Optimize Media',
      `Optimize ${selected.size} file(s) with ${quality.toUpperCase()} quality profile?\n\nEstimated savings: ${fmtSize(estimatedSaved)}`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Optimize',
          onPress: () => {
            setOptimizing(true);
            setTimeout(() => {
              const selectedIds = new Set(selected);
              const keep = files.filter(f => !selectedIds.has(f.id));
              const freedGB = parseFloat((estimatedSaved / 1073741824).toFixed(2));
              const nextStorageUsed = Math.max(0, parseFloat((deviceStats.storageUsed - freedGB).toFixed(2)));

              setFiles(keep);
              setSelected(new Set());
              updateDeviceStats({ storageUsed: nextStorageUsed });
              addActivity({
                title: 'Media Optimized',
                subtitle: `${fmtSize(estimatedSaved)} saved from ${selectedIds.size} file(s)`,
                time: new Date().toISOString(),
                icon: 'compress',
                color: C.primary,
              });
              setOptimizing(false);
            }, 1400);
          },
        },
      ]
    );
  };

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Media Compression</Text>
        <TouchableOpacity onPress={scan} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>

      <View style={s.tabs}>
        {TABS.map((t,i) => (
          <TouchableOpacity key={t} style={[s.tab,tab===i&&s.tabActive]} onPress={()=>setTab(i)}>
            <Text style={[s.tabText,tab===i&&s.tabTextActive]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={s.qualityRow}>
        {[
          { key: 'high', label: 'High', note: '~12%' },
          { key: 'medium', label: 'Medium', note: '~22%' },
          { key: 'low', label: 'Max', note: '~32%' },
        ].map((q) => (
          <TouchableOpacity
            key={q.key}
            style={[s.qualityChip, quality === q.key && s.qualityChipActive]}
            onPress={() => setQuality(q.key as 'high' | 'medium' | 'low')}
            disabled={optimizing}
          >
            <Text style={[s.qualityLabel, quality === q.key && s.qualityLabelActive]}>{q.label}</Text>
            <Text style={s.qualityNote}>{q.note}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading
        ? <ActivityIndicator color={C.primary} style={{marginTop:40}}/>
        : filtered.length === 0
          ? <View style={s.empty}>
              <Icon name="image-multiple" size={48} color={C.textMuted}/>
              <Text style={s.emptyTitle}>No media files found</Text>
              <Text style={s.emptySub}>Media in DCIM, Pictures and Movies folders will appear here</Text>
            </View>
          : <FlatList
              data={filtered}
              keyExtractor={f=>f.id}
              contentContainerStyle={{paddingHorizontal:20,paddingBottom:100}}
              renderItem={({item:f}) => {
                const isImg = IMG_EXT.includes(f.ext);
                const col   = isImg ? '#2563EB' : '#7C3AED';
                return (
                  <TouchableOpacity style={s.fileRow} onPress={()=>toggle(f.id)}>
                    <View style={[s.fileIcon,{backgroundColor:col+'22'}]}>
                      <Icon name={isImg?'image':'file-video'} size={22} color={col}/>
                    </View>
                    <View style={{flex:1,marginLeft:14}}>
                      <Text style={s.fileName} numberOfLines={1}>{f.name}</Text>
                      <Text style={s.fileMeta}>{fmtSize(f.size)} · .{f.ext.toUpperCase()}</Text>
                    </View>
                    <View style={[s.check,selected.has(f.id)&&s.checkActive]}>
                      {selected.has(f.id) && <Icon name="check" size={14} color="#fff"/>}
                    </View>
                  </TouchableOpacity>
                );
              }}
            />
      }

      {selected.size > 0 && (
        <View style={s.bottomBar}>
          <Text style={s.estimate}>Estimated savings: {fmtSize(estimatedSaved)}</Text>
          <TouchableOpacity style={{flex:1}} onPress={compress}>
            <LinearGradient colors={C.gradientPrimary} style={s.cleanBtn}>
              {optimizing
                ? <ActivityIndicator color="#fff" />
                : <Text style={s.cleanBtnText}>Optimize {selected.size} File(s) ({fmtSize(selBytes)})</Text>
              }
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:12},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  tabs:{flexDirection:'row',marginHorizontal:20,backgroundColor:C.card,borderRadius:radius.pill,padding:4,marginBottom:12},
  tab:{flex:1,paddingVertical:8,alignItems:'center',borderRadius:radius.pill},
  tabActive:{backgroundColor:C.primary}, tabText:{fontSize:12,color:C.textMuted,fontWeight:'600'}, tabTextActive:{color:'#fff'},
  qualityRow:{flexDirection:'row',gap:8,paddingHorizontal:20,marginBottom:10},
  qualityChip:{flex:1,backgroundColor:C.card,borderRadius:radius.lg,paddingVertical:8,paddingHorizontal:10,borderWidth:1,borderColor:C.border,alignItems:'center'},
  qualityChipActive:{borderColor:C.primary,backgroundColor:'#1E3A8A22'},
  qualityLabel:{fontSize:12,fontWeight:'700',color:C.textSecondary},
  qualityLabelActive:{color:C.primary},
  qualityNote:{fontSize:10,color:C.textMuted,marginTop:2},
  empty:{flex:1,justifyContent:'center',alignItems:'center',gap:12,paddingBottom:60,paddingHorizontal:40},
  emptyTitle:{fontSize:18,fontWeight:'700',color:C.textPrimary}, emptySub:{fontSize:13,color:C.textMuted,textAlign:'center'},
  fileRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:10,borderWidth:1,borderColor:C.border},
  fileIcon:{width:46,height:46,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  fileName:{fontSize:14,fontWeight:'700',color:C.textPrimary}, fileMeta:{fontSize:11,color:C.textMuted,marginTop:2},
  check:{width:26,height:26,borderRadius:13,borderWidth:2,borderColor:C.border,justifyContent:'center',alignItems:'center'},
  checkActive:{backgroundColor:C.primary,borderColor:C.primary},
  bottomBar:{position:'absolute',bottom:0,left:0,right:0,padding:20,paddingBottom:36,backgroundColor:'rgba(10,15,30,0.95)'},
  estimate:{fontSize:12,color:C.textMuted,marginBottom:8,textAlign:'center'},
  cleanBtn:{borderRadius:radius.button,paddingVertical:16,alignItems:'center'},
  cleanBtnText:{fontSize:16,fontWeight:'800',color:'#fff'},
});
