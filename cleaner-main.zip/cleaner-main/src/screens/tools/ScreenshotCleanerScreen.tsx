import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, StatusBar, ActivityIndicator, Alert } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';

interface ScreenshotFile { id: string; name: string; path: string; size: number; }

function fmtSize(b: number) { if(b>=1073741824) return (b/1073741824).toFixed(2)+' GB'; if(b>=1048576) return (b/1048576).toFixed(0)+' MB'; return (b/1024).toFixed(0)+' KB'; }

export default function ScreenshotCleanerScreen() {
  const navigation = useNavigation();
  const [files, setFiles]       = useState<ScreenshotFile[]>([]);
  const [loading, setLoading]   = useState(true);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const scan = async () => {
    setLoading(true);
    setFiles([]);
    setSelected(new Set());
    try {
      const RNFS = require('react-native-fs').default ?? require('react-native-fs');
      const base = RNFS.ExternalStorageDirectoryPath ?? '';
      const dirs = [
        base+'/Pictures/Screenshots',
        base+'/DCIM/Screenshots',
        base+'/Screenshots',
      ].filter(Boolean);

      const found: ScreenshotFile[] = [];
      let id = 0;
      for (const dir of dirs) {
        try {
          const items = await RNFS.readDir(dir).catch(() => []);
          for (const item of items) {
            if (!item.isFile()) continue;
            const ext = item.name.split('.').pop()?.toLowerCase() ?? '';
            if (!['png','jpg','jpeg','webp'].includes(ext)) continue;
            found.push({ id: String(id++), name: item.name, path: item.path, size: item.size });
          }
        } catch {}
      }
      setFiles(found.sort((a,b) => b.size - a.size));
    } catch { setFiles([]); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { scan(); }, []));

  const toggle = (id: string) => setSelected(prev => { const s=new Set(prev); s.has(id)?s.delete(id):s.add(id); return s; });
  const selAll = () => setSelected(new Set(files.map(f=>f.id)));
  const selBytes = files.filter(f=>selected.has(f.id)).reduce((t,f)=>t+f.size,0);

  const deleteSelected = () => {
    if (selected.size === 0) return;
    Alert.alert('Delete Screenshots', `Permanently delete ${selected.size} screenshot(s) (${fmtSize(selBytes)})?`, [
      { text:'Cancel', style:'cancel' },
      { text:'Delete', style:'destructive', onPress: async () => {
        try {
          const RNFS = require('react-native-fs').default ?? require('react-native-fs');
          for (const f of files.filter(f=>selected.has(f.id))) {
            try { await RNFS.unlink(f.path); } catch {}
          }
        } catch {}
        await scan();
      }},
    ]);
  };

  const totalSize = files.reduce((t,f)=>t+f.size,0);

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Screenshot Cleaner</Text>
        <TouchableOpacity onPress={scan} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>

      {files.length > 0 && (
        <View style={s.statsRow}>
          <Text style={s.statText}>{files.length} screenshots · {fmtSize(totalSize)}</Text>
          <TouchableOpacity onPress={selAll}><Text style={s.selAllText}>Select All</Text></TouchableOpacity>
        </View>
      )}

      {loading
        ? <ActivityIndicator color={C.primary} style={{marginTop:40}}/>
        : files.length === 0
          ? <View style={s.empty}>
              <Icon name="monitor-screenshot" size={48} color={C.textMuted}/>
              <Text style={s.emptyTitle}>No screenshots found</Text>
              <Text style={s.emptySub}>Screenshots from Pictures/Screenshots and DCIM/Screenshots will appear here</Text>
            </View>
          : <FlatList
              data={files}
              keyExtractor={f=>f.id}
              contentContainerStyle={{paddingHorizontal:20,paddingBottom:100}}
              renderItem={({item:f}) => (
                <TouchableOpacity style={s.fileRow} onPress={()=>toggle(f.id)}>
                  <View style={[s.fileIcon,{backgroundColor:'#7C3AED22'}]}>
                    <Icon name="monitor-screenshot" size={22} color="#7C3AED"/>
                  </View>
                  <View style={{flex:1,marginLeft:14}}>
                    <Text style={s.fileName} numberOfLines={1}>{f.name}</Text>
                    <Text style={s.fileMeta}>{fmtSize(f.size)}</Text>
                  </View>
                  <View style={[s.check,selected.has(f.id)&&s.checkActive]}>
                    {selected.has(f.id)&&<Icon name="check" size={14} color="#fff"/>}
                  </View>
                </TouchableOpacity>
              )}
            />
      }

      {selected.size > 0 && (
        <View style={s.bottomBar}>
          <TouchableOpacity style={{flex:1}} onPress={deleteSelected}>
            <LinearGradient colors={C.gradientDanger} style={s.deleteBtn}>
              <Text style={s.deleteBtnText}>Delete {selected.size} Selected ({fmtSize(selBytes)})</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:8},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  statsRow:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginHorizontal:20,marginBottom:10},
  statText:{fontSize:12,color:C.textMuted}, selAllText:{fontSize:12,color:C.primary,fontWeight:'700'},
  empty:{flex:1,justifyContent:'center',alignItems:'center',gap:12,paddingBottom:60,paddingHorizontal:40},
  emptyTitle:{fontSize:18,fontWeight:'700',color:C.textPrimary}, emptySub:{fontSize:13,color:C.textMuted,textAlign:'center'},
  fileRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:8,borderWidth:1,borderColor:C.border},
  fileIcon:{width:46,height:46,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  fileName:{fontSize:13,fontWeight:'700',color:C.textPrimary}, fileMeta:{fontSize:11,color:C.textMuted,marginTop:2},
  check:{width:26,height:26,borderRadius:13,borderWidth:2,borderColor:C.border,justifyContent:'center',alignItems:'center'},
  checkActive:{backgroundColor:C.primary,borderColor:C.primary},
  bottomBar:{position:'absolute',bottom:0,left:0,right:0,padding:20,paddingBottom:36,backgroundColor:'rgba(10,15,30,0.95)'},
  deleteBtn:{borderRadius:radius.button,paddingVertical:16,alignItems:'center'},
  deleteBtnText:{fontSize:16,fontWeight:'800',color:'#fff'},
});
