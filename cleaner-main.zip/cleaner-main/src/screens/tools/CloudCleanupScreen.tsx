import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, Alert } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

interface CloudFile {
  id: string;
  service: string;
  name: string;
  sizeMB: number;
}

const SERVICES = [
  { name:'Google Drive', icon:'google-drive', color:['#2563EB','#1D4ED8'], key:'gdrive' },
  { name:'OneDrive',     icon:'microsoft-onedrive', color:['#0891B2','#0E7490'], key:'onedrive' },
  { name:'Dropbox',      icon:'dropbox', color:['#0061FF','#1040AC'], key:'dropbox' },
];

export default function CloudCleanupScreen() {
  const navigation = useNavigation();
  const { deviceStats, addActivity } = useAppStore();
  const [connected, setConnected] = useState<Set<string>>(new Set());
  const [cloudFiles, setCloudFiles] = useState<CloudFile[]>([]);
  const [selected, setSelected] = useState<Set<string>>(new Set());

  const makeFiles = (service: string): CloudFile[] => {
    const base = [
      'Camera_2026_01.jpg',
      'Vacation_Reel.mp4',
      'Invoice_April.pdf',
      'Screenshot_3381.png',
      'Family_Photo.jpg',
      'Project_Backup.zip',
    ];
    return base.map((name, i) => ({
      id: `${service}-${i}-${Date.now()}`,
      service,
      name: i % 3 === 0 ? 'Camera_2026_01.jpg' : name,
      sizeMB: Math.round((Math.random() * 420 + 25) * 10) / 10,
    }));
  };

  const connect = (key: string, name: string) => {
    if (connected.has(key)) {
      setConnected(prev => {
        const next = new Set(prev);
        next.delete(key);
        return next;
      });
      setCloudFiles(prev => prev.filter(f => f.service !== key));
      setSelected(prev => {
        const next = new Set(prev);
        cloudFiles.filter(f => f.service === key).forEach(f => next.delete(f.id));
        return next;
      });
      return;
    }

    setConnected(prev => new Set([...prev, key]));
    setCloudFiles(prev => [...prev, ...makeFiles(key)]);
    addActivity({
      title: 'Cloud Connected',
      subtitle: `${name} connected for cloud cleanup`,
      time: new Date().toISOString(),
      icon: 'cloud-check-outline',
      color: '#22C55E',
    });
  };

  const duplicateNames = new Set<string>();
  const seen = new Set<string>();
  cloudFiles.forEach((f) => {
    const key = f.name.toLowerCase();
    if (seen.has(key)) duplicateNames.add(key);
    seen.add(key);
  });

  const cleanupCandidates = cloudFiles.filter(f => duplicateNames.has(f.name.toLowerCase()) || f.sizeMB > 250);

  const toggleSelect = (id: string) => {
    setSelected(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const selectedMB = cleanupCandidates.filter(f => selected.has(f.id)).reduce((sum, f) => sum + f.sizeMB, 0);

  const cleanSelected = () => {
    if (selected.size === 0) return;
    Alert.alert('Clean Cloud Files', `Remove ${selected.size} file(s) from connected cloud accounts?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Clean',
        style: 'destructive',
        onPress: () => {
          const ids = new Set(selected);
          const removed = cleanupCandidates.filter(f => ids.has(f.id));
          setCloudFiles(prev => prev.filter(f => !ids.has(f.id)));
          setSelected(new Set());
          addActivity({
            title: 'Cloud Cleanup Done',
            subtitle: `${removed.length} file(s) removed · ${(selectedMB / 1024).toFixed(2)} GB freed`,
            time: new Date().toISOString(),
            icon: 'cloud-check-outline',
            color: C.primary,
          });
        },
      },
    ]);
  };

  const storageFreePct = Math.round(((deviceStats.storageTotal - deviceStats.storageUsed) / deviceStats.storageTotal) * 100);

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Cloud Cleanup</Text>
        <View style={s.btn}/>
      </View>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.body}>

        <View style={s.localCard}>
          <Icon name="harddisk" size={24} color={C.primary}/>
          <View style={{flex:1,marginLeft:12}}>
            <Text style={s.localTitle}>Local Storage</Text>
            <Text style={s.localSub}>{deviceStats.storageUsed} GB used of {deviceStats.storageTotal} GB · {storageFreePct}% free</Text>
          </View>
        </View>

        <Text style={s.sectionTitle}>Cloud Services</Text>
        {SERVICES.map(svc => (
          <View key={svc.key} style={s.svcCard}>
            <LinearGradient colors={svc.color} style={s.svcIcon}>
              <Icon name={svc.icon} size={22} color="#fff"/>
            </LinearGradient>
            <View style={{flex:1,marginLeft:14}}>
              <Text style={s.svcName}>{svc.name}</Text>
              <Text style={s.svcStatus}>
                {connected.has(svc.key) ? 'Connected' : 'Not connected'}
              </Text>
            </View>
            <TouchableOpacity
              style={[s.connectBtn,connected.has(svc.key)&&s.connectedBtn]}
              onPress={()=>connect(svc.key, svc.name)}>
              <Text style={[s.connectText,connected.has(svc.key)&&s.connectedText]}>
                {connected.has(svc.key)?'Disconnect':'Connect'}
              </Text>
            </TouchableOpacity>
          </View>
        ))}

        {connected.size > 0 && (
          <>
            <Text style={s.sectionTitle}>Cleanup Candidates ({cleanupCandidates.length})</Text>
            {cleanupCandidates.length === 0 ? (
              <View style={s.noteBanner}>
                <Icon name="check-circle-outline" size={18} color={C.success}/>
                <Text style={s.noteText}>No duplicates or oversized cloud files found in connected accounts.</Text>
              </View>
            ) : (
              cleanupCandidates.map((f) => (
                <TouchableOpacity key={f.id} style={s.fileRow} onPress={() => toggleSelect(f.id)}>
                  <View style={[s.check, selected.has(f.id) && s.checkActive]}>
                    {selected.has(f.id) && <Icon name="check" size={12} color="#fff" />}
                  </View>
                  <View style={{ flex: 1, marginLeft: 10 }}>
                    <Text style={s.fileName} numberOfLines={1}>{f.name}</Text>
                    <Text style={s.fileMeta}>{f.service} · {f.sizeMB.toFixed(1)} MB</Text>
                  </View>
                </TouchableOpacity>
              ))
            )}

            {selected.size > 0 && (
              <TouchableOpacity style={s.cleanBtn} onPress={cleanSelected}>
                <Text style={s.cleanBtnText}>Clean {selected.size} File(s) · {(selectedMB / 1024).toFixed(2)} GB</Text>
              </TouchableOpacity>
            )}
          </>
        )}

        <View style={s.noteBanner}>
          <Icon name="information-outline" size={18} color={C.warning}/>
          <Text style={s.noteText}>
            Cloud cleanup is running in demo mode. Connect providers to preview duplicates and oversized files before production OAuth integration.
          </Text>
        </View>
        <View style={{height:40}}/>
      </ScrollView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:12},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  body:{paddingHorizontal:20,paddingTop:8},
  localCard:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:16,marginBottom:20,borderWidth:1,borderColor:C.border},
  localTitle:{fontSize:14,fontWeight:'700',color:C.textPrimary}, localSub:{fontSize:12,color:C.textMuted,marginTop:2},
  sectionTitle:{fontSize:14,fontWeight:'700',color:C.textSecondary,marginBottom:12},
  svcCard:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:10,borderWidth:1,borderColor:C.border},
  svcIcon:{width:46,height:46,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  svcName:{fontSize:14,fontWeight:'700',color:C.textPrimary}, svcStatus:{fontSize:12,color:C.textMuted,marginTop:2},
  connectBtn:{paddingHorizontal:14,paddingVertical:8,borderRadius:radius.pill,borderWidth:1,borderColor:C.primary},
  connectedBtn:{borderColor:C.success},
  connectText:{fontSize:13,color:C.primary,fontWeight:'700'}, connectedText:{color:C.success},
  fileRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.lg,padding:12,borderWidth:1,borderColor:C.border,marginBottom:8},
  check:{width:20,height:20,borderRadius:10,borderWidth:1,borderColor:C.border,justifyContent:'center',alignItems:'center'},
  checkActive:{backgroundColor:C.primary,borderColor:C.primary},
  fileName:{fontSize:13,fontWeight:'700',color:C.textPrimary},
  fileMeta:{fontSize:11,color:C.textMuted,marginTop:2},
  cleanBtn:{marginTop:8,backgroundColor:C.primary,paddingVertical:12,borderRadius:radius.pill,alignItems:'center'},
  cleanBtnText:{fontSize:13,color:'#fff',fontWeight:'800'},
  noteBanner:{flexDirection:'row',gap:10,backgroundColor:C.card,borderRadius:radius.xl,padding:14,borderWidth:1,borderColor:C.border,marginTop:8},
  noteText:{flex:1,fontSize:12,color:C.textMuted,lineHeight:18},
});
