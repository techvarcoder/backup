import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, StatusBar, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Linking, Platform } from 'react-native';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

interface AppNotif { id: string; name: string; pkg: string; color: string; }
const MUTE_PREF_KEY = '@AuroCleaner:mutedApps';

const COLORS = ['#22C55E','#3B82F6','#F59E0B','#8B5CF6','#EF4444','#06B6D4','#EC4899'];
function pkgColor(pkg: string) { let h=0; for(let i=0;i<pkg.length;i++) h=pkg.charCodeAt(i)+((h<<5)-h); return COLORS[Math.abs(h)%COLORS.length]; }
const SYS = ['com.android.','android.','com.google.android.','com.samsung.','com.qualcomm.','com.miui.','com.sec.','com.bikedex'];

export default function NotificationAnalyzerScreen() {
  const navigation = useNavigation();
  const { addActivity } = useAppStore();
  const [apps, setApps]       = useState<AppNotif[]>([]);
  const [loading, setLoading] = useState(true);
  const [blocked, setBlocked] = useState<Set<string>>(new Set());

  const persistMuted = async (next: Set<string>) => {
    try {
      await AsyncStorage.setItem(MUTE_PREF_KEY, JSON.stringify(Array.from(next)));
    } catch {}
  };

  const loadMuted = async () => {
    try {
      const raw = await AsyncStorage.getItem(MUTE_PREF_KEY);
      if (!raw) return;
      const list = JSON.parse(raw);
      if (Array.isArray(list)) setBlocked(new Set(list.map(String)));
    } catch {}
  };

  const load = async () => {
    setLoading(true);
    try {
      const DI = require('react-native-device-info').default ?? require('react-native-device-info');
      const all: Array<{appName:string;packageName:string}> =
        await DI.getInstalledApplications().catch(() => []);
      let id = 0;
      const items: AppNotif[] = all
        .filter(a => !SYS.some(p => (a.packageName||'').startsWith(p)))
        .map(a => ({ id: String(id++), name: a.appName||a.packageName, pkg: a.packageName||'', color: pkgColor(a.packageName||'') }))
        .sort((a,b) => a.name.localeCompare(b.name));
      setApps(items);
    } catch { setApps([]); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { load(); loadMuted(); }, []));

  const toggle = (pkg: string, appName: string) => {
    setBlocked(prev => {
      const s = new Set(prev);
      const nowMuted = !s.has(pkg);
      if (nowMuted) s.add(pkg); else s.delete(pkg);
      persistMuted(s);
      addActivity({
        title: 'Notification Rule Updated',
        subtitle: `${appName}: ${nowMuted ? 'Muted in AuroCleaner' : 'Unmuted in AuroCleaner'}`,
        time: new Date().toISOString(),
        icon: nowMuted ? 'bell-off-outline' : 'bell-outline',
        color: nowMuted ? '#EF4444' : '#22C55E',
      });
      return s;
    });
  };

  const openAppNotificationSettings = async (pkg: string) => {
    if (Platform.OS !== 'android') {
      await Linking.openSettings();
      return;
    }

    try {
      await Linking.sendIntent('android.settings.APP_NOTIFICATION_SETTINGS', [
        { key: 'android.provider.extra.APP_PACKAGE', value: pkg },
        { key: 'app_package', value: pkg },
      ]);
      return;
    } catch {}

    try {
      await Linking.openSettings();
    } catch {}
  };

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Notification Manager</Text>
        <TouchableOpacity onPress={load} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>
      <View style={s.infoBanner}>
        <Icon name="information-outline" size={16} color={C.warning}/>
        <Text style={s.infoText}>{apps.length} installed apps · {blocked.size} muted in app</Text>
      </View>
      {loading
        ? <ActivityIndicator color={C.primary} style={{marginTop:40}}/>
        : <FlatList
            data={apps}
            keyExtractor={a=>a.id}
            contentContainerStyle={{paddingHorizontal:20,paddingBottom:40}}
            renderItem={({item:a}) => (
              <View style={s.appRow}>
                <View style={[s.appIcon,{backgroundColor:a.color+'22'}]}>
                  <Icon name="apps" size={22} color={a.color}/>
                </View>
                <View style={{flex:1,marginLeft:14}}>
                  <Text style={s.appName} numberOfLines={1}>{a.name}</Text>
                  <Text style={s.appPkg} numberOfLines={1}>{a.pkg}</Text>
                </View>
                <View style={s.rowActions}>
                  <TouchableOpacity onPress={()=>toggle(a.pkg, a.name)} style={[s.toggleBtn,blocked.has(a.pkg)&&s.toggleOff]}>
                    <Icon name={blocked.has(a.pkg)?'bell-off':'bell'} size={16} color={blocked.has(a.pkg)?C.danger:C.success}/>
                    <Text style={[s.toggleText,{color:blocked.has(a.pkg)?C.danger:C.success}]}>{blocked.has(a.pkg)?'Muted':'Live'}</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => openAppNotificationSettings(a.pkg)} style={s.manageBtn}>
                    <Text style={s.manageText}>Manage</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          />
      }
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:8},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  infoBanner:{flexDirection:'row',alignItems:'center',gap:8,marginHorizontal:20,marginBottom:12},
  infoText:{fontSize:12,color:C.textMuted,flex:1},
  appRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:12,marginBottom:8,borderWidth:1,borderColor:C.border},
  appIcon:{width:42,height:42,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  appName:{fontSize:13,fontWeight:'700',color:C.textPrimary}, appPkg:{fontSize:10,color:C.textMuted,marginTop:2},
  rowActions:{alignItems:'flex-end',gap:6},
  toggleBtn:{flexDirection:'row',alignItems:'center',gap:4,paddingHorizontal:10,paddingVertical:6,borderRadius:radius.pill,borderWidth:1,borderColor:C.success},
  toggleOff:{borderColor:C.danger},
  toggleText:{fontSize:11,fontWeight:'700'},
  manageBtn:{paddingHorizontal:12,paddingVertical:5,borderRadius:radius.pill,borderWidth:1,borderColor:C.border},
  manageText:{fontSize:11,fontWeight:'700',color:C.textMuted},
});
