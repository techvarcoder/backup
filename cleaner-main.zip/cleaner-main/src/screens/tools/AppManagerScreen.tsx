import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, StatusBar, ActivityIndicator, Linking, Platform } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';

interface AppItem { id: string; name: string; pkg: string; sizeMB: number; color: string; system: boolean; }
const COLORS = ['#3B82F6','#8B5CF6','#EC4899','#F59E0B','#10B981','#EF4444','#06B6D4','#F97316'];
function pkgColor(pkg: string) { let h=0; for(let i=0;i<pkg.length;i++) h=pkg.charCodeAt(i)+((h<<5)-h); return COLORS[Math.abs(h)%COLORS.length]; }
const SYS = ['com.android.','android.','com.google.android.','com.samsung.','com.qualcomm.','com.miui.','com.sec.','com.bikedex'];

async function readExtDataSize(pkg: string, extBase: string): Promise<number> {
  try {
    const RNFS = require('react-native-fs').default ?? require('react-native-fs');
    const dir = `${extBase}/${pkg}`;
    if (!(await RNFS.exists(dir))) return 0;
    const entries = await RNFS.readDir(dir);
    let bytes = 0;
    for (const e of entries) { bytes += Number(e.size) || 0; }
    return bytes;
  } catch { return 0; }
}

export default function AppManagerScreen() {
  const navigation = useNavigation();
  const [tab, setTab]     = useState(0);
  const [apps, setApps]   = useState<AppItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalMB, setTotalMB] = useState(0);

  const load = async () => {
    setLoading(true);
    try {
      const DI = require('react-native-device-info').default ?? require('react-native-device-info');
      const RNFS = require('react-native-fs').default ?? require('react-native-fs');
      const extBase = `${RNFS.ExternalStorageDirectoryPath}/Android/data`;
      const all: Array<{appName:string;packageName:string;firstInstallTime:number;lastUpdateTime:number}> =
        await DI.getInstalledApplications().catch(() => []);

      let id = 0;
      const items: AppItem[] = await Promise.all(
        all.filter(a => a.packageName).map(async a => {
          const sys = SYS.some(p => (a.packageName||'').startsWith(p));
          const bytes = await readExtDataSize(a.packageName, extBase);
          const sizeMB = Math.round(bytes / 1048576);
          return { id: String(id++), name: a.appName||a.packageName, pkg: a.packageName||'', sizeMB, color: pkgColor(a.packageName||''), system: sys };
        })
      );
      items.sort((a, b) => b.sizeMB - a.sizeMB);

      setApps(items);
      setTotalMB(items.reduce((s,a)=>s+a.sizeMB,0));
    } catch { setApps([]); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { load(); }, []));

  const TABS = ['All', 'User Apps', 'By Size'];
  const filtered = tab === 1 ? apps.filter(a=>!a.system) : tab === 2 ? [...apps].sort((a,b)=>b.sizeMB-a.sizeMB) : apps;
  const userCount = apps.filter(a=>!a.system).length;
  const totalGB   = (totalMB/1024).toFixed(1);

  const openManage = async (pkg: string) => {
    if (Platform.OS !== 'android') {
      await Linking.openSettings();
      return;
    }

    try {
      await Linking.sendIntent('android.settings.APPLICATION_DETAILS_SETTINGS', [
        { key: 'android.provider.extra.APP_PACKAGE', value: pkg },
        { key: 'app_package', value: pkg },
      ]);
      return;
    } catch {}

    try { await Linking.openSettings(); } catch {}
  };

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>App Manager</Text>
        <TouchableOpacity onPress={load} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>

      <View style={s.statsRow}>
        {[
          { label:'Total Apps',  val: String(apps.length), icon:'apps',     c:C.primary  },
          { label:'User Apps',   val: String(userCount),   icon:'account',  c:C.warning  },
          { label:'Total Size',  val: `${totalGB} GB`,     icon:'harddisk', c:C.danger   },
        ].map(st => (
          <View key={st.label} style={s.statCard}>
            <Icon name={st.icon} size={18} color={st.c}/>
            <Text style={[s.statVal,{color:st.c}]}>{st.val}</Text>
            <Text style={s.statLabel}>{st.label}</Text>
          </View>
        ))}
      </View>

      <View style={s.tabs}>
        {TABS.map((t,i) => (
          <TouchableOpacity key={t} style={[s.tab,tab===i&&s.tabActive]} onPress={()=>setTab(i)}>
            <Text style={[s.tabText,tab===i&&s.tabTextActive]}>{t}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading
        ? <ActivityIndicator color={C.primary} style={{marginTop:40}}/>
        : <FlatList
            data={filtered}
            keyExtractor={a=>a.id}
            contentContainerStyle={{paddingHorizontal:20,paddingBottom:40}}
            renderItem={({item:a}) => (
              <View style={s.appRow}>
                <View style={[s.appIcon,{backgroundColor:a.color+'33'}]}>
                  <Icon name={a.system?'cog':'apps'} size={22} color={a.color}/>
                </View>
                <View style={{flex:1,marginLeft:14}}>
                  <Text style={s.appName} numberOfLines={1}>{a.name}</Text>
                  <Text style={s.appMeta} numberOfLines={1}>{a.pkg} · {a.sizeMB > 0 ? `${a.sizeMB} MB` : '—'}</Text>
                </View>
                {a.system
                  ? <Text style={s.sysLabel}>System</Text>
                  : <TouchableOpacity style={s.uninstallBtn} onPress={()=>openManage(a.pkg)}>
                      <Text style={s.uninstallText}>Manage</Text>
                    </TouchableOpacity>
                }
              </View>
            )}
          />
      }
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:12},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  statsRow:{flexDirection:'row',marginHorizontal:20,gap:10,marginBottom:14},
  statCard:{flex:1,backgroundColor:C.card,borderRadius:radius.xl,padding:12,alignItems:'center',gap:4,borderWidth:1,borderColor:C.border},
  statVal:{fontSize:16,fontWeight:'800'}, statLabel:{fontSize:10,color:C.textMuted},
  tabs:{flexDirection:'row',marginHorizontal:20,backgroundColor:C.card,borderRadius:radius.pill,padding:4,marginBottom:12},
  tab:{flex:1,paddingVertical:8,alignItems:'center',borderRadius:radius.pill},
  tabActive:{backgroundColor:C.primary}, tabText:{fontSize:12,color:C.textMuted,fontWeight:'600'}, tabTextActive:{color:'#fff'},
  appRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:10,borderWidth:1,borderColor:C.border},
  appIcon:{width:46,height:46,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  appName:{fontSize:14,fontWeight:'700',color:C.textPrimary}, appMeta:{fontSize:11,color:C.textMuted,marginTop:2},
  uninstallBtn:{paddingHorizontal:12,paddingVertical:6,borderRadius:radius.pill,borderWidth:1,borderColor:C.warning},
  uninstallText:{fontSize:12,color:C.warning,fontWeight:'700'}, sysLabel:{fontSize:11,color:C.textMuted},
});
