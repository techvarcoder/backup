import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, StatusBar, ActivityIndicator, Alert } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';

interface ApkItem { id: string; name: string; pkg: string; sizeMB: number; path: string; installed: boolean; version: string; }

function fmtSize(b: number) { if(b>=1073741824) return (b/1073741824).toFixed(2)+' GB'; if(b>=1048576) return (b/1048576).toFixed(0)+' MB'; return (b/1024).toFixed(0)+' KB'; }

export default function APKAnalyzerScreen() {
  const navigation = useNavigation();
  const [apks, setApks]         = useState<ApkItem[]>([]);
  const [loading, setLoading]   = useState(true);
  const [selected, setSelected] = useState<ApkItem|null>(null);

  const scan = async () => {
    setLoading(true);
    setApks([]);
    try {
      const RNFS = require('react-native-fs').default ?? require('react-native-fs');
      const scanDirs = [
        RNFS.DownloadDirectoryPath,
        RNFS.ExternalStorageDirectoryPath,
        (RNFS.ExternalStorageDirectoryPath??'')+'/Download',
      ].filter(Boolean);

      const found: ApkItem[] = [];
      let id = 0;
      for (const dir of scanDirs) {
        try {
          const items = await RNFS.readDir(dir).catch(() => []);
          for (const item of items) {
            if (!item.isFile()) continue;
            if (!item.name.toLowerCase().endsWith('.apk')) continue;
            found.push({
              id: String(id++),
              name: item.name,
              pkg:  item.name.replace('.apk','').replace(/_v[\d.]+.*/,''),
              sizeMB: Math.round(item.size / 1048576),
              path: item.path,
              installed: false,
              version: item.name.match(/_v?([\d.]+)/)?.[1] ?? '—',
            });
          }
        } catch {}
      }
      setApks(found.sort((a,b) => b.sizeMB - a.sizeMB));
    } catch { setApks([]); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { scan(); }, []));

  const deleteApk = (item: ApkItem) => {
    Alert.alert('Delete APK', `Delete ${item.name} (${item.sizeMB} MB)?`, [
      { text:'Cancel', style:'cancel' },
      { text:'Delete', style:'destructive', onPress: async () => {
        try {
          const RNFS = require('react-native-fs').default ?? require('react-native-fs');
          await RNFS.unlink(item.path);
        } catch {}
        setSelected(null);
        await scan();
      }},
    ]);
  };

  const totalMB = apks.reduce((t,a)=>t+a.sizeMB,0);

  if (selected) {
    return (
      <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
        <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
        <View style={s.header}>
          <TouchableOpacity onPress={()=>setSelected(null)} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
          <Text style={s.title} numberOfLines={1}>{selected.name}</Text>
          <View style={s.btn}/>
        </View>
        <View style={s.detailHero}>
          <View style={[s.detailIcon,{backgroundColor:'#16A34A33'}]}>
            <Icon name="android" size={36} color="#16A34A"/>
          </View>
          <Text style={s.detailName}>{selected.name}</Text>
          <Text style={s.detailPkg}>{selected.path}</Text>
        </View>
        <View style={s.infoGrid}>
          {[
            { label:'Size',    value:`${selected.sizeMB} MB` },
            { label:'Version', value: selected.version },
            { label:'Type',    value:'Android APK' },
            { label:'Status',  value:'Not Installed' },
          ].map(r => (
            <View key={r.label} style={s.infoCard}>
              <Text style={s.infoVal}>{r.value}</Text>
              <Text style={s.infoLabel}>{r.label}</Text>
            </View>
          ))}
        </View>
        <View style={s.actionWrap}>
          <TouchableOpacity onPress={()=>deleteApk(selected)} style={s.actionBtn}>
            <LinearGradient colors={['#EF4444','#DC2626']} style={s.actionGrad}>
              <Icon name="delete" size={20} color="#fff"/>
              <Text style={s.actionText}>Delete APK File</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </LinearGradient>
    );
  }

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>APK Analyzer</Text>
        <TouchableOpacity onPress={scan} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>

      {apks.length > 0 && (
        <View style={s.statBanner}>
          <Icon name="android" size={16} color={C.warning}/>
          <Text style={s.statText}>{apks.length} APK{apks.length!==1?'s':''} found · {totalMB} MB total</Text>
        </View>
      )}

      {loading
        ? <ActivityIndicator color={C.primary} style={{marginTop:40}}/>
        : apks.length === 0
          ? <View style={s.empty}>
              <Icon name="android" size={48} color={C.textMuted}/>
              <Text style={s.emptyTitle}>No APK files found</Text>
              <Text style={s.emptySub}>Downloaded APK files will appear here</Text>
            </View>
          : <FlatList
              data={apks}
              keyExtractor={a=>a.id}
              contentContainerStyle={{paddingHorizontal:20,paddingBottom:40}}
              renderItem={({item:a}) => (
                <TouchableOpacity style={s.apkRow} onPress={()=>setSelected(a)}>
                  <View style={[s.apkIcon,{backgroundColor:'#16A34A33'}]}>
                    <Icon name="android" size={22} color="#16A34A"/>
                  </View>
                  <View style={{flex:1,marginLeft:14}}>
                    <Text style={s.apkName} numberOfLines={1}>{a.name}</Text>
                    <Text style={s.apkMeta}>{a.sizeMB} MB · v{a.version}</Text>
                  </View>
                  <Icon name="chevron-right" size={20} color={C.textMuted}/>
                </TouchableOpacity>
              )}
            />
      }
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:12},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary,flex:1,textAlign:'center'},
  statBanner:{flexDirection:'row',alignItems:'center',gap:8,marginHorizontal:20,marginBottom:12},
  statText:{fontSize:13,color:C.textMuted},
  empty:{flex:1,justifyContent:'center',alignItems:'center',gap:12,paddingBottom:60},
  emptyTitle:{fontSize:18,fontWeight:'700',color:C.textPrimary}, emptySub:{fontSize:13,color:C.textMuted,textAlign:'center',paddingHorizontal:40},
  apkRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:10,borderWidth:1,borderColor:C.border},
  apkIcon:{width:46,height:46,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  apkName:{fontSize:14,fontWeight:'700',color:C.textPrimary}, apkMeta:{fontSize:11,color:C.textMuted,marginTop:2},
  detailHero:{backgroundColor:C.card,borderRadius:radius.xl,padding:24,alignItems:'center',gap:10,marginHorizontal:20,marginBottom:20,borderWidth:1,borderColor:C.border},
  detailIcon:{width:80,height:80,borderRadius:24,justifyContent:'center',alignItems:'center'},
  detailName:{fontSize:14,fontWeight:'700',color:C.textPrimary,textAlign:'center'}, detailPkg:{fontSize:11,color:C.textMuted,textAlign:'center'},
  infoGrid:{flexDirection:'row',flexWrap:'wrap',gap:12,marginHorizontal:20,marginBottom:20},
  infoCard:{flex:1,minWidth:'40%',backgroundColor:C.card,borderRadius:radius.xl,padding:14,alignItems:'center',borderWidth:1,borderColor:C.border},
  infoVal:{fontSize:15,fontWeight:'800',color:C.textPrimary}, infoLabel:{fontSize:11,color:C.textMuted,marginTop:4},
  actionWrap:{paddingHorizontal:20}, actionBtn:{borderRadius:radius.button,overflow:'hidden'},
  actionGrad:{flexDirection:'row',alignItems:'center',justifyContent:'center',paddingVertical:16,gap:10},
  actionText:{fontSize:16,fontWeight:'700',color:'#fff'},
});
