import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, ActivityIndicator } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';
import { ScanService } from '../../services/ScanService';

function fmtSize(b: number): string {
  if (b >= 1073741824) return (b/1073741824).toFixed(2)+' GB';
  if (b >= 1048576)    return (b/1048576).toFixed(0)+' MB';
  return (b/1024).toFixed(0)+' KB';
}

export default function DeepCleanScreen() {
  const navigation = useNavigation();
  const { addActivity } = useAppStore();
  const [categories, setCategories] = useState<Array<{key:string;icon:string;label:string;bytes:number;color:string[]}>>([]);
  const [loading, setLoading]       = useState(true);
  const [selected, setSelected]     = useState<Set<string>>(new Set());
  const [cleaning, setCleaning]     = useState(false);
  const [done, setDone]             = useState(false);

  const scan = async () => {
    setLoading(true);
    setDone(false);
    try {
      const items = await ScanService.scan(() => {});
      const grouped = ScanService.groupByCategory(items);
      const cats = [
        { key:'cache',    icon:'layers',               label:'App Cache',    color:['#EF4444','#DC2626'] },
        { key:'temp',     icon:'trash-can',            label:'Temp Files',   color:['#F59E0B','#D97706'] },
        { key:'junk',     icon:'block-helper',         label:'Junk Files',   color:['#8B5CF6','#6D28D9'] },
        { key:'residual', icon:'folder-remove',        label:'App Residuals',color:['#4B5563','#374151'] },
        { key:'apk',      icon:'android',              label:'Old APKs',     color:['#0891B2','#0E7490'] },
      ].map(c => ({ ...c, bytes: grouped[c.key]?.bytes ?? 0 })).filter(c => c.bytes > 0);
      setCategories(cats);
      setSelected(new Set(cats.map(c => c.key)));
    } catch { setCategories([]); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { scan(); }, []));

  const toggle = (key: string) => setSelected(prev => { const s=new Set(prev); s.has(key)?s.delete(key):s.add(key); return s; });
  const selBytes = categories.filter(c=>selected.has(c.key)).reduce((t,c)=>t+c.bytes,0);

  const clean = async () => {
    setCleaning(true);
    try {
      const RNFS = require('react-native-fs').default ?? require('react-native-fs');
      const dirs: string[] = [];
      if (selected.has('cache') || selected.has('temp')) {
        dirs.push(RNFS.CachesDirectoryPath);
        if (RNFS.ExternalCachesDirectoryPath) dirs.push(RNFS.ExternalCachesDirectoryPath);
        if (RNFS.TemporaryDirectoryPath) dirs.push(RNFS.TemporaryDirectoryPath);
      }
      for (const dir of dirs) {
        try {
          const items = await RNFS.readDir(dir).catch(() => []);
          for (const item of items) {
            try { await RNFS.unlink(item.path); } catch {}
          }
        } catch {}
      }
      addActivity({ title:'Deep Clean Done', subtitle: `~${fmtSize(selBytes)} cleared`, time: new Date().toISOString(), icon:'broom', color:C.success });
      setDone(true);
      await scan();
    } catch {}
    finally { setCleaning(false); }
  };

  const totalBytes = categories.reduce((t,c)=>t+c.bytes,0);

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>Deep Clean</Text>
        <TouchableOpacity onPress={scan} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.body}>
        <LinearGradient colors={['#1E1B4B','#2563EB']} style={s.heroCard}>
          <Icon name="broom" size={32} color="#fff"/>
          <Text style={s.heroVal}>{fmtSize(totalBytes)}</Text>
          <Text style={s.heroSub}>Total junk found on your device</Text>
        </LinearGradient>

        {loading
          ? <ActivityIndicator color={C.primary} style={{marginTop:20}}/>
          : categories.length === 0
            ? <View style={s.clean}><Icon name="check-circle" size={48} color={C.success}/><Text style={s.cleanText}>Your device is clean!</Text></View>
            : categories.map(c => (
                <TouchableOpacity key={c.key} style={s.catRow} onPress={()=>toggle(c.key)}>
                  <LinearGradient colors={c.color} style={s.catIcon}>
                    <Icon name={c.icon} size={22} color="#fff"/>
                  </LinearGradient>
                  <View style={{flex:1,marginLeft:14}}>
                    <Text style={s.catLabel}>{c.label}</Text>
                    <Text style={s.catSize}>{fmtSize(c.bytes)}</Text>
                  </View>
                  <View style={[s.check,selected.has(c.key)&&s.checkActive]}>
                    {selected.has(c.key) && <Icon name="check" size={14} color="#fff"/>}
                  </View>
                </TouchableOpacity>
              ))
        }

        {done && (
          <View style={s.doneRow}>
            <Icon name="check-circle" size={18} color={C.success}/>
            <Text style={s.doneText}>Device cleaned successfully</Text>
          </View>
        )}

        <TouchableOpacity onPress={clean} disabled={cleaning||selected.size===0} style={s.cleanWrapper}>
          <LinearGradient colors={selected.size===0?['#334155','#1E293B']:['#EF4444','#DC2626']} style={s.cleanBtn}>
            {cleaning ? <ActivityIndicator color="#fff" size="small"/>
              : <><Icon name="broom" size={22} color="#fff"/><Text style={s.cleanBtnText}>Clean Selected ({fmtSize(selBytes)})</Text></>
            }
          </LinearGradient>
        </TouchableOpacity>
        <View style={{height:40}}/>
      </ScrollView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:12},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  body:{paddingHorizontal:20,paddingTop:8},
  heroCard:{borderRadius:radius.card,padding:28,alignItems:'center',marginBottom:20,gap:8},
  heroVal:{fontSize:36,fontWeight:'900',color:'#fff'}, heroSub:{fontSize:13,color:'rgba(255,255,255,0.7)'},
  clean:{alignItems:'center',paddingVertical:40,gap:16}, cleanText:{fontSize:16,color:C.textMuted,fontWeight:'600'},
  catRow:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:14,marginBottom:10,borderWidth:1,borderColor:C.border},
  catIcon:{width:46,height:46,borderRadius:radius.md,justifyContent:'center',alignItems:'center'},
  catLabel:{fontSize:14,fontWeight:'700',color:C.textPrimary}, catSize:{fontSize:12,color:C.danger,fontWeight:'600',marginTop:2},
  check:{width:26,height:26,borderRadius:13,borderWidth:2,borderColor:C.border,justifyContent:'center',alignItems:'center'},
  checkActive:{backgroundColor:C.primary,borderColor:C.primary},
  doneRow:{flexDirection:'row',alignItems:'center',gap:8,justifyContent:'center',marginBottom:12},
  doneText:{fontSize:13,color:C.success,fontWeight:'700'},
  cleanWrapper:{borderRadius:radius.button,overflow:'hidden',marginTop:8},
  cleanBtn:{flexDirection:'row',alignItems:'center',justifyContent:'center',paddingVertical:16,gap:10},
  cleanBtnText:{fontSize:16,fontWeight:'800',color:'#fff'},
});
