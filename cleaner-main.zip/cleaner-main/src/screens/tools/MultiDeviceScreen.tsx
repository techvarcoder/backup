import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, ActivityIndicator, Alert } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

interface DeviceInfo { model: string; manufacturer: string; androidVersion: string; }
interface LinkedDevice { id: string; name: string; status: 'online' | 'offline'; battery: number; storageUsed: number; storageTotal: number; }

export default function MultiDeviceScreen() {
  const navigation = useNavigation();
  const { deviceStats, totalCleaned, refreshDeviceStats } = useAppStore();
  const healthScore = deviceStats.healthScore;
  const [deviceInfo, setDeviceInfo] = useState<DeviceInfo|null>(null);
  const [loading, setLoading] = useState(true);
  const [activeDeviceId, setActiveDeviceId] = useState('local');
  const [linkedDevices, setLinkedDevices] = useState<LinkedDevice[]>([
    { id: 'local', name: 'This Device', status: 'online', battery: deviceStats.batteryLevel, storageUsed: deviceStats.storageUsed, storageTotal: deviceStats.storageTotal },
  ]);

  const load = async () => {
    setLoading(true);
    try {
      const DI = require('react-native-device-info').default ?? require('react-native-device-info');
      const [model, manufacturer, sysVer] = await Promise.all([
        DI.getModel().catch(() => 'Android Device'),
        DI.getManufacturer().catch(() => 'Unknown'),
        DI.getSystemVersion().catch(() => '—'),
      ]);
      setDeviceInfo({ model: String(model), manufacturer: String(manufacturer), androidVersion: String(sysVer) });
    } catch { setDeviceInfo(null); }
    finally { setLoading(false); }
  };

  useFocusEffect(React.useCallback(() => { refreshDeviceStats(); load(); }, []));

  useFocusEffect(React.useCallback(() => {
    setLinkedDevices(prev => prev.map(d => d.id === 'local'
      ? { ...d, battery: deviceStats.batteryLevel, storageUsed: deviceStats.storageUsed, storageTotal: deviceStats.storageTotal }
      : d
    ));
  }, [deviceStats]));

  const storageUsedPct = Math.round((deviceStats.storageUsed/deviceStats.storageTotal)*100);
  const cleanedGB = (totalCleaned/1073741824).toFixed(2);

  const addMockDevice = () => {
    const suffix = Math.floor(Math.random() * 900 + 100);
    const newDevice: LinkedDevice = {
      id: `d-${Date.now()}`,
      name: `Android ${suffix}`,
      status: Math.random() > 0.2 ? 'online' : 'offline',
      battery: Math.floor(Math.random() * 60) + 35,
      storageUsed: parseFloat((Math.random() * 80 + 20).toFixed(1)),
      storageTotal: 128,
    };
    setLinkedDevices(prev => [...prev, newDevice]);
  };

  const removeDevice = (id: string) => {
    if (id === 'local') return;
    Alert.alert('Remove Device', 'Unlink this device from your dashboard?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => {
          setLinkedDevices(prev => prev.filter(d => d.id !== id));
          if (activeDeviceId === id) setActiveDeviceId('local');
        },
      },
    ]);
  };

  return (
    <LinearGradient colors={['#0A0F1E','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent/>
      <View style={s.header}>
        <TouchableOpacity onPress={()=>navigation.goBack()} style={s.btn}><Icon name="arrow-left" size={22} color={C.textSecondary}/></TouchableOpacity>
        <Text style={s.title}>My Device</Text>
        <TouchableOpacity onPress={()=>{refreshDeviceStats();load();}} style={s.btn}><Icon name="refresh" size={20} color={C.primary}/></TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={s.body}>
        {loading
          ? <ActivityIndicator color={C.primary} style={{marginTop:40}}/>
          : (
            <LinearGradient colors={['#1E3A5F','#1E293B']} style={s.deviceCard}>
              <View style={s.deviceHeader}>
                <View style={[s.deviceIcon,{backgroundColor:'#3B82F633'}]}>
                  <Icon name="cellphone" size={32} color="#3B82F6"/>
                </View>
                <View style={{flex:1,marginLeft:16}}>
                  <Text style={s.deviceModel}>{deviceInfo?.model ?? 'Android Device'}</Text>
                  <Text style={s.deviceMfr}>{deviceInfo?.manufacturer} · Android {deviceInfo?.androidVersion}</Text>
                </View>
                <View style={[s.onlineDot,{backgroundColor:C.success}]}/>
              </View>
              <View style={s.deviceStats}>
                {[
                  { icon:'shield-check', label:'Health',   value:`${healthScore}%`,          color: healthScore>70?C.success:C.warning },
                  { icon:'harddisk',     label:'Storage',  value:`${storageUsedPct}% used`,   color: storageUsedPct>80?C.danger:C.primary },
                  { icon:'battery',      label:'Battery',  value:`${deviceStats.batteryLevel}%`, color: deviceStats.batteryLevel>50?C.success:C.warning },
                  { icon:'broom',        label:'Cleaned',  value:`${cleanedGB} GB`,           color: C.success },
                ].map(st => (
                  <View key={st.label} style={s.dStat}>
                    <Icon name={st.icon} size={16} color={st.color}/>
                    <Text style={[s.dStatVal,{color:st.color}]}>{st.value}</Text>
                    <Text style={s.dStatLabel}>{st.label}</Text>
                  </View>
                ))}
              </View>
            </LinearGradient>
          )
        }

        <View style={s.infoCard}>
          {[
            { icon:'information',    label:'Model',    value: deviceInfo?.model ?? '—' },
            { icon:'factory',        label:'Brand',    value: deviceInfo?.manufacturer ?? '—' },
            { icon:'android',        label:'Android',  value: deviceInfo?.androidVersion ?? '—' },
            { icon:'memory',         label:'RAM',      value:`${deviceStats.ramUsed} / ${deviceStats.ramTotal} GB` },
            { icon:'harddisk',       label:'Storage',  value:`${deviceStats.storageUsed} / ${deviceStats.storageTotal} GB` },
            { icon:'thermometer',    label:'Temp',     value: deviceStats.temperature > 0 ? `${deviceStats.temperature}°C` : '—' },
          ].map(r => (
            <View key={r.label} style={s.infoRow}>
              <Icon name={r.icon} size={16} color={C.primary}/>
              <Text style={s.infoLabel}>{r.label}</Text>
              <Text style={s.infoValue} numberOfLines={1}>{r.value}</Text>
            </View>
          ))}
        </View>

        <View style={s.otherBanner}>
          <Icon name="devices" size={22} color={C.textMuted}/>
          <View style={{flex:1,marginLeft:12}}>
            <Text style={s.otherTitle}>Connected Devices</Text>
            <Text style={s.otherSub}>{linkedDevices.length} linked · tap any device to switch context</Text>
          </View>
          <TouchableOpacity style={s.linkBtn} onPress={addMockDevice}>
            <Icon name="plus" size={16} color="#fff" />
            <Text style={s.linkBtnText}>Add</Text>
          </TouchableOpacity>
        </View>

        {linkedDevices.map((d) => {
          const pct = Math.round((d.storageUsed / Math.max(d.storageTotal, 1)) * 100);
          const active = d.id === activeDeviceId;
          return (
            <TouchableOpacity key={d.id} style={[s.deviceRow, active && s.deviceRowActive]} onPress={() => setActiveDeviceId(d.id)}>
              <View style={[s.rowDot, { backgroundColor: d.status === 'online' ? '#22C55E' : '#6B7280' }]} />
              <View style={{ flex: 1 }}>
                <Text style={s.rowName}>{d.name}</Text>
                <Text style={s.rowSub}>Battery {d.battery}% · Storage {pct}% used</Text>
              </View>
              {d.id !== 'local' && (
                <TouchableOpacity onPress={() => removeDevice(d.id)} style={s.unlinkBtn}>
                  <Text style={s.unlinkText}>Unlink</Text>
                </TouchableOpacity>
              )}
            </TouchableOpacity>
          );
        })}
        <View style={{height:40}}/>
      </ScrollView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container:{flex:1}, header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',paddingTop:56,paddingHorizontal:20,paddingBottom:12},
  btn:{width:40,height:40,justifyContent:'center',alignItems:'center'}, title:{fontSize:18,fontWeight:'700',color:C.textPrimary},
  body:{paddingHorizontal:20,paddingTop:8},
  deviceCard:{borderRadius:radius.card,padding:20,marginBottom:16,borderWidth:1,borderColor:'#3B82F644'},
  deviceHeader:{flexDirection:'row',alignItems:'center',marginBottom:16},
  deviceIcon:{width:60,height:60,borderRadius:16,justifyContent:'center',alignItems:'center'},
  deviceModel:{fontSize:16,fontWeight:'800',color:'#fff'}, deviceMfr:{fontSize:12,color:'rgba(255,255,255,0.6)',marginTop:2},
  onlineDot:{width:12,height:12,borderRadius:6},
  deviceStats:{flexDirection:'row',justifyContent:'space-between'},
  dStat:{alignItems:'center',gap:4}, dStatVal:{fontSize:13,fontWeight:'800'}, dStatLabel:{fontSize:10,color:'rgba(255,255,255,0.5)'},
  infoCard:{backgroundColor:C.card,borderRadius:radius.card,overflow:'hidden',borderWidth:1,borderColor:C.border,marginBottom:16},
  infoRow:{flexDirection:'row',alignItems:'center',gap:10,padding:14,borderBottomWidth:1,borderBottomColor:C.border},
  infoLabel:{flex:1,fontSize:13,color:C.textSecondary}, infoValue:{fontSize:13,fontWeight:'700',color:C.textPrimary,maxWidth:160},
  otherBanner:{flexDirection:'row',alignItems:'center',backgroundColor:C.card,borderRadius:radius.xl,padding:16,borderWidth:1,borderColor:C.border,borderStyle:'dashed'},
  otherTitle:{fontSize:14,fontWeight:'700',color:C.textPrimary}, otherSub:{fontSize:12,color:C.textMuted,marginTop:2},
  linkBtn:{flexDirection:'row',alignItems:'center',gap:4,backgroundColor:C.primary,paddingHorizontal:10,paddingVertical:6,borderRadius:radius.pill},
  linkBtnText:{fontSize:12,color:'#fff',fontWeight:'700'},
  deviceRow:{flexDirection:'row',alignItems:'center',gap:10,backgroundColor:C.card,borderRadius:radius.xl,padding:12,marginTop:10,borderWidth:1,borderColor:C.border},
  deviceRowActive:{borderColor:C.primary,backgroundColor:'#1E3A8A22'},
  rowDot:{width:10,height:10,borderRadius:5},
  rowName:{fontSize:13,fontWeight:'700',color:C.textPrimary},
  rowSub:{fontSize:11,color:C.textMuted,marginTop:2},
  unlinkBtn:{paddingHorizontal:10,paddingVertical:6,borderRadius:radius.pill,borderWidth:1,borderColor:'#EF444455'},
  unlinkText:{fontSize:11,color:'#EF4444',fontWeight:'700'},
});
