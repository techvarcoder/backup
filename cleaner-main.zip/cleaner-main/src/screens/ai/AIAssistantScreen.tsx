import React, { useState, useRef, useMemo } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput,
  KeyboardAvoidingView, Platform, StatusBar, Animated, useWindowDimensions,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

const TAB_BAR_HEIGHT = 70;

const QUICK_PROMPTS = [
  'Why is my phone slow?',
  'How to free up storage?',
  'Is my battery healthy?',
  'What is using my RAM?',
];

interface Message {
  id: string;
  role: 'user' | 'ai';
  text: string;
}

export default function AIAssistantScreen() {
  const navigation = useNavigation();
  const { height } = useWindowDimensions();
  const { deviceStats, cleanHistory, refreshDeviceStats } = useAppStore();
  const compactLayout = height < 760;

  useFocusEffect(React.useCallback(() => { refreshDeviceStats(); }, []));

  // Build real AI responses from live device data
  const aiResponses = useMemo(() => {
    const storagePct = Math.round(deviceStats.storageUsed / deviceStats.storageTotal * 100);
    const ramPct     = Math.round(deviceStats.ramUsed     / deviceStats.ramTotal     * 100);
    const freeGB     = (deviceStats.storageTotal - deviceStats.storageUsed).toFixed(1);
    const lastClean  = cleanHistory.length > 0 ? cleanHistory[0] : null;
    const daysSince  = lastClean ? Math.floor((Date.now() - new Date(lastClean.date).getTime()) / 86400000) : null;

    return {
      default: `I've analyzed your device. Health score is ${deviceStats.healthScore}%. Storage is ${storagePct}% used with ${freeGB} GB free. RAM at ${ramPct}%${deviceStats.temperature > 38 ? `. Temperature is ${deviceStats.temperature}°C — a bit warm.` : '.'}`,

      slow: `Your phone may be slow because: RAM is at ${ramPct}% (${deviceStats.ramUsed}/${deviceStats.ramTotal} GB). CPU at ${deviceStats.cpuUsage}%${deviceStats.temperature > 38 ? `. Device temperature is ${deviceStats.temperature}°C.` : '.'} Try a Smart Scan to clear cache and free RAM.`,

      storage: `Storage is ${storagePct}% used — ${deviceStats.storageUsed} GB of ${deviceStats.storageTotal} GB. ${freeGB} GB remaining.${daysSince !== null ? ` Last cleanup was ${daysSince} day${daysSince !== 1 ? 's' : ''} ago freeing ${lastClean!.freedGB.toFixed(2)} GB.` : ' No cleanups yet — run a scan now.'}`,

      battery: `Battery is at ${deviceStats.batteryLevel}%${deviceStats.isCharging ? ' and currently charging.' : '.'}${deviceStats.batteryHealth > 0 ? ` Health: ${deviceStats.batteryHealth}%.` : ''}${deviceStats.temperature > 0 ? ` Temperature: ${deviceStats.temperature}°C.` : ''}${deviceStats.batteryHealth > 0 && deviceStats.batteryHealth < 70 ? ' Battery health is below 70% — consider replacement.' : ''}`,

      ram: `RAM usage: ${deviceStats.ramUsed} GB used of ${deviceStats.ramTotal} GB (${ramPct}%). ${ramPct > 80 ? 'Memory pressure is high — close background apps.' : ramPct > 60 ? 'RAM usage is moderate.' : 'RAM usage is healthy.'}`,
    };
  }, [deviceStats, cleanHistory]);

  // Real cards from live device data
  const cards = useMemo(() => [
    {
      icon: 'chart-line',
      title: 'Storage Used',
      val: `${Math.round(deviceStats.storageUsed / deviceStats.storageTotal * 100)}% — ${deviceStats.storageUsed} GB`,
      color: deviceStats.storageUsed / deviceStats.storageTotal > 0.8 ? '#EF4444' : '#22C55E',
    },
    {
      icon: 'battery-heart',
      title: 'Battery Health',
      val: deviceStats.batteryHealth > 0
        ? `${deviceStats.batteryHealth >= 80 ? 'Good' : deviceStats.batteryHealth >= 60 ? 'Fair' : 'Poor'} — ${deviceStats.batteryHealth}%`
        : '—',
      color: deviceStats.batteryHealth >= 80 ? '#22C55E' : deviceStats.batteryHealth >= 60 ? '#F59E0B' : deviceStats.batteryHealth > 0 ? '#EF4444' : C.textMuted,
    },
    {
      icon: 'memory',
      title: 'RAM',
      val: `${deviceStats.ramUsed} / ${deviceStats.ramTotal} GB`,
      color: deviceStats.ramUsed / deviceStats.ramTotal > 0.8 ? '#EF4444' : '#3B82F6',
    },
    {
      icon: 'thermometer',
      title: 'Temperature',
      val: deviceStats.temperature > 0
        ? `${deviceStats.temperature}°C — ${deviceStats.temperature > 45 ? 'Hot' : deviceStats.temperature > 38 ? 'Warm' : 'Normal'}`
        : '—',
      color: deviceStats.temperature > 45 ? '#EF4444' : deviceStats.temperature > 38 ? '#F59E0B' : deviceStats.temperature > 0 ? '#22C55E' : C.textMuted,
    },
  ], [deviceStats]);

  const [messages, setMessages] = useState<Message[]>([
    { id: '0', role: 'ai', text: "Hi! I'm your AI assistant. Ask me anything about your device or tap a quick prompt below." },
  ]);
  const [input, setInput] = useState('');
  const scrollRef = useRef<ScrollView>(null);
  const aiOrb = useRef(new Animated.Value(1)).current;

  const pulseOrb = () => {
    Animated.sequence([
      Animated.timing(aiOrb, { toValue: 1.2, duration: 300, useNativeDriver: true }),
      Animated.timing(aiOrb, { toValue: 1,   duration: 300, useNativeDriver: true }),
    ]).start();
  };

  const sendMessage = (text: string) => {
    if (!text.trim()) return;
    pulseOrb();
    const userMsg: Message = { id: Date.now().toString(), role: 'user', text };
    setMessages(prev => [...prev, userMsg]);
    setInput('');

    setTimeout(() => {
      const lower = text.toLowerCase();
      const key = lower.includes('slow') || lower.includes('fast') || lower.includes('lag') ? 'slow'
        : lower.includes('storage') || lower.includes('space') || lower.includes('full') ? 'storage'
        : lower.includes('battery') || lower.includes('charge') || lower.includes('drain') ? 'battery'
        : lower.includes('ram') || lower.includes('memory') || lower.includes('process') ? 'ram'
        : 'default';
      const aiMsg: Message = { id: (Date.now() + 1).toString(), role: 'ai', text: aiResponses[key] };
      setMessages(prev => [...prev, aiMsg]);
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
    }, 800);

    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
  };

  return (
    <LinearGradient colors={['#0A0F1E', '#0F172A']} style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Icon name="arrow-left" size={22} color={C.textSecondary} />
        </TouchableOpacity>
        <Text style={styles.title}>AI Assistant</Text>
        <Text style={styles.today}>Today</Text>
      </View>

      {/* AI Orb */}
      {!compactLayout && (
        <View style={styles.orbSection}>
          <Animated.View style={[styles.outerGlow, { transform: [{ scale: aiOrb }] }]} />
          <LinearGradient colors={['#4F46E5', '#2563EB']} style={styles.orb}>
            <Icon name="robot-outline" size={22} color="#fff" />
          </LinearGradient>
        </View>
      )}

      {/* Recommendation summary */}
      <View style={styles.compactTopRow}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.compactTopRowContent}>
          {cards.map((card) => (
            <View key={card.title} style={styles.compactStatPill}>
              <Icon name={card.icon} size={13} color={card.color} />
              <Text style={styles.compactStatLabel}>{card.title}</Text>
              <Text style={[styles.compactStatValue, { color: card.color }]} numberOfLines={1}>{card.val}</Text>
            </View>
          ))}
        </ScrollView>
        <TouchableOpacity style={styles.compactCleanBtn} onPress={() => (navigation as any).navigate('SmartScan' as any)}>
          <Icon name="broom" size={12} color="#fff" />
          <Text style={styles.compactCleanText}>Clean</Text>
        </TouchableOpacity>
      </View>

      {/* Messages */}
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 10 : 0}
        style={styles.chatContainer}
      >
        <ScrollView
          ref={scrollRef}
          style={styles.messages}
          contentContainerStyle={styles.messagesContent}
          keyboardShouldPersistTaps="handled"
        >
          {messages.map((msg) => (
            <View key={msg.id} style={[styles.msgRow, msg.role === 'user' && styles.msgRowUser]}>
              {msg.role === 'ai' && (
                <LinearGradient colors={['#4F46E5', '#2563EB']} style={styles.msgAvatar}>
                  <Icon name="robot-outline" size={14} color="#fff" />
                </LinearGradient>
              )}
              <View style={[styles.bubble, msg.role === 'user' ? styles.userBubble : styles.aiBubble]}>
                <Text style={[styles.bubbleText, msg.role === 'user' && styles.userBubbleText]}>{msg.text}</Text>
              </View>
            </View>
          ))}
        </ScrollView>

        <View style={styles.composer}>
          {/* Quick prompts */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.quickRow}
            contentContainerStyle={styles.quickRowContent}
            keyboardShouldPersistTaps="handled"
          >
            {QUICK_PROMPTS.map((p) => (
              <TouchableOpacity key={p} style={styles.quickPill} onPress={() => sendMessage(p)}>
                <Text style={styles.quickText}>{p}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          {/* Input */}
          <View style={styles.inputRow}>
            <TextInput
              style={styles.input}
              placeholder="Ask anything..."
              placeholderTextColor={C.textDisabled}
              value={input}
              onChangeText={setInput}
              onSubmitEditing={() => sendMessage(input)}
            />
            <TouchableOpacity style={styles.sendBtn} onPress={() => sendMessage(input)}>
              <LinearGradient colors={C.gradientPrimary} style={styles.sendGrad}>
                <Icon name="send" size={18} color="#fff" />
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', paddingTop: 56, paddingHorizontal: 20, paddingBottom: 4 },
  backBtn: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  title: { flex: 1, fontSize: 18, fontWeight: '700', color: C.textPrimary, marginLeft: 4 },
  today: { fontSize: 12, color: C.textMuted },
  orbSection: { alignItems: 'center', marginVertical: 6 },
  outerGlow: { position: 'absolute', width: 68, height: 68, borderRadius: 34, backgroundColor: 'rgba(79,70,229,0.15)' },
  orb: { width: 52, height: 52, borderRadius: 26, justifyContent: 'center', alignItems: 'center', shadowColor: '#4F46E5', shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.7, shadowRadius: 16, elevation: 12 },
  compactTopRow: { flexDirection: 'row', alignItems: 'center', paddingLeft: 12, marginBottom: 4, maxHeight: 34 },
  compactTopRowContent: { paddingRight: 8, gap: 6, alignItems: 'center' },
  compactStatPill: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: C.card, borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 5, borderWidth: 1, borderColor: C.border, maxWidth: 185, height: 30 },
  compactStatLabel: { fontSize: 10, color: C.textMuted },
  compactStatValue: { fontSize: 10, fontWeight: '700', maxWidth: 85 },
  compactCleanBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: C.primary, borderRadius: radius.pill, paddingHorizontal: 10, paddingVertical: 6, marginRight: 12 },
  compactCleanText: { fontSize: 10, color: '#fff', fontWeight: '700' },
  chatContainer: { flex: 1 },
  messages: { flex: 1 },
  messagesContent: {
    paddingHorizontal: 20,
    paddingVertical: 12,
    paddingBottom: 12,
    flexGrow: 1,
    justifyContent: 'flex-end',
  },
  composer: {
    paddingBottom: TAB_BAR_HEIGHT + 8,
  },
  msgRow: { flexDirection: 'row', alignItems: 'flex-end', marginBottom: 12 },
  msgRowUser: { flexDirection: 'row-reverse' },
  msgAvatar: { width: 28, height: 28, borderRadius: 14, justifyContent: 'center', alignItems: 'center', marginRight: 8 },
  bubble: { maxWidth: '75%', borderRadius: radius.xl, padding: 14 },
  aiBubble: { backgroundColor: C.card, borderWidth: 1, borderColor: C.border },
  userBubble: { backgroundColor: C.primary },
  bubbleText: { fontSize: 14, color: C.textPrimary, lineHeight: 20 },
  userBubbleText: { color: '#fff' },
  quickRow: { paddingTop: 4, paddingBottom: 6, maxHeight: 42, flexGrow: 0 },
  quickRowContent: { paddingHorizontal: 16, gap: 8 },
  quickPill: { height: 28, justifyContent: 'center', alignItems: 'center', backgroundColor: C.card, borderRadius: radius.pill, paddingHorizontal: 14, borderWidth: 1, borderColor: C.border },
  quickText: { fontSize: 12, color: C.textSecondary, fontWeight: '500', lineHeight: 16, includeFontPadding: false } as any,
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 0,
    gap: 8,
  },
  input: { flex: 1, backgroundColor: C.card, borderRadius: radius.pill, paddingHorizontal: 16, paddingVertical: 10, color: C.textPrimary, fontSize: 14, borderWidth: 1, borderColor: C.border },
  sendBtn: { width: 42, height: 42, borderRadius: 21, overflow: 'hidden' },
  sendGrad: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});
