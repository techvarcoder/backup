import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated, Easing, TouchableOpacity, StatusBar } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../navigation/types';
import { darkColors as C, radius } from '../../theme';
import { useAppStore } from '../../store/useAppStore';
import { ScanService } from '../../services/ScanService';

type Props = { navigation: NativeStackNavigationProp<RootStackParamList, 'SmartScan'> };

export default function SmartScanScreen({ navigation }: Props) {
  const { startScan, updateScanProgress, setScanResult } = useAppStore();
  const [progress, setProgress] = useState(0);
  const [scanText, setScanText]  = useState('Initializing scan...');
  const [filesFound, setFilesFound] = useState(0);
  const [bytesFound, setBytesFound] = useState(0);
  const isMounted = useRef(true);

  const rotate    = useRef(new Animated.Value(0)).current;
  const ringScale = useRef(new Animated.Value(1)).current;
  const glowAnim  = useRef(new Animated.Value(0)).current;

  const rotateInterp = rotate.interpolate({ inputRange:[0,1], outputRange:['0deg','360deg'] });
  const glowOpacity  = glowAnim.interpolate({ inputRange:[0,1], outputRange:[0.2, 0.6] });

  useEffect(() => {
    isMounted.current = true;
    startScan();

    const rotAnim = Animated.loop(
      Animated.timing(rotate, { toValue:1, duration:2000, easing:Easing.linear, useNativeDriver:true })
    );
    const pulseAnim = Animated.loop(
      Animated.sequence([
        Animated.timing(ringScale, { toValue:1.06, duration:800, useNativeDriver:true }),
        Animated.timing(ringScale, { toValue:1, duration:800, useNativeDriver:true }),
      ])
    );
    const glowLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(glowAnim, { toValue:1, duration:1200, useNativeDriver:false }),
        Animated.timing(glowAnim, { toValue:0.3, duration:1200, useNativeDriver:false }),
      ])
    );
    rotAnim.start(); pulseAnim.start(); glowLoop.start();

    const startTime = Date.now();

    ScanService.scan(p => {
      if (!isMounted.current) return;
      setProgress(p.percent);
      setScanText(p.currentPath);
      setFilesFound(p.filesFound);
      setBytesFound(p.bytesFound);
      updateScanProgress(p.percent, p.currentPath);
    }).then(items => {
      if (!isMounted.current) return;
      const elapsed = Math.round((Date.now() - startTime) / 1000);
      const mm = String(Math.floor(elapsed / 60)).padStart(2, '0');
      const ss = String(elapsed % 60).padStart(2, '0');
      const groups = ScanService.groupByCategory(items);

      setScanResult({
        cacheFiles:    ScanService.toGB(groups.cache?.bytes    ?? 0),
        junkFiles:     ScanService.toGB(groups.junk?.bytes     ?? 0),
        residualFiles: ScanService.toGB(groups.residual?.bytes ?? 0),
        apkFiles:      ScanService.toGB(groups.apk?.bytes      ?? 0),
        tempFiles:     ScanService.toGB(groups.temp?.bytes     ?? 0),
        totalJunk:     ScanService.toGB(items.reduce((s, x) => s + x.size, 0)),
        filesScanned:  items.length,
        timeElapsed:   `${mm}:${ss}`,
      }, items);

      rotAnim.stop(); pulseAnim.stop(); glowLoop.stop();
      setTimeout(() => { if (isMounted.current) navigation.replace('ScanResults'); }, 500);
    }).catch(() => {
      if (isMounted.current) navigation.goBack();
    });

    return () => { isMounted.current = false; };
  }, []);

  return (
    <LinearGradient colors={['#060B18','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.backBtn}>
          <Icon name="arrow-left" size={22} color={C.textSecondary} />
        </TouchableOpacity>
        <Text style={s.title}>Smart Scan</Text>
        <View style={{ width:40 }} />
      </View>

      <View style={s.scanner}>
        <Animated.View style={[s.outerGlow, { opacity: glowOpacity }]} />
        <Animated.View style={[s.ring3, { transform:[{ scale:ringScale }] }]} />
        <View style={s.ring2} />
        <LinearGradient colors={C.gradientPrimary} style={s.innerCircle}>
          <Animated.View style={{ transform:[{ rotate: rotateInterp }] }}>
            <Icon name="radar" size={44} color="#fff" />
          </Animated.View>
        </LinearGradient>
      </View>

      <View style={s.statsRow}>
        <StatBox label="Progress" value={`${progress}%`} color={C.primary} />
        <StatBox label="Files Found" value={filesFound > 0 ? filesFound.toString() : '—'} color={C.success} />
        <StatBox label="Junk Size" value={bytesFound > 0 ? ScanService.formatSize(bytesFound) : '—'} color={C.danger} />
      </View>

      <View style={s.progressTrack}>
        <Animated.View style={[s.progressBar, { width: `${progress}%` }]} />
      </View>
      <Text style={s.scanText} numberOfLines={1}>{scanText}</Text>
    </LinearGradient>
  );
}

const StatBox = ({ label, value, color }: { label:string; value:string; color:string }) => (
  <View style={s.statBox}>
    <Text style={[s.statVal, { color }]}>{value}</Text>
    <Text style={s.statLabel}>{label}</Text>
  </View>
);

const s = StyleSheet.create({
  container: { flex:1 },
  header: { flexDirection:'row', alignItems:'center', justifyContent:'space-between', paddingTop:56, paddingHorizontal:20, paddingBottom:8 },
  backBtn: { width:40, height:40, justifyContent:'center', alignItems:'center' },
  title: { fontSize:18, fontWeight:'700', color:C.textPrimary },
  scanner: { flex:1, justifyContent:'center', alignItems:'center' },
  outerGlow: { position:'absolute', width:280, height:280, borderRadius:140, backgroundColor:C.primary },
  ring3: { position:'absolute', width:240, height:240, borderRadius:120, borderWidth:2, borderColor:C.primary+'44', backgroundColor:'transparent' },
  ring2: { position:'absolute', width:180, height:180, borderRadius:90, borderWidth:1, borderColor:C.primary+'66', backgroundColor:'transparent' },
  innerCircle: { width:120, height:120, borderRadius:60, justifyContent:'center', alignItems:'center' },
  statsRow: { flexDirection:'row', paddingHorizontal:20, marginBottom:16, gap:12 },
  statBox: { flex:1, backgroundColor:C.card, borderRadius:radius.xl, padding:14, alignItems:'center', borderWidth:1, borderColor:C.border },
  statVal: { fontSize:18, fontWeight:'900' },
  statLabel: { fontSize:10, color:C.textMuted, marginTop:4 },
  progressTrack: { height:4, marginHorizontal:20, backgroundColor:C.cardElevated, borderRadius:2, marginBottom:12, overflow:'hidden' },
  progressBar: { height:4, backgroundColor:C.primary, borderRadius:2 },
  scanText: { fontSize:12, color:C.textMuted, textAlign:'center', paddingHorizontal:24, marginBottom:32 },
});
