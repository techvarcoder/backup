import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, ActivityIndicator, BackHandler } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../navigation/types';
import { ProgressBar } from '../../components/ui/ProgressBar';
import { darkColors as C, radius, spacing } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

type Props = { navigation: NativeStackNavigationProp<RootStackParamList, 'ScanResults'> };

const FILE_TYPES = [
  { icon:'layers-outline',       label:'Cache Files',    key:'cacheFiles',    color:'#3B82F6' },
  { icon:'trash-can-outline',    label:'Junk Files',     key:'junkFiles',     color:'#F59E0B' },
  { icon:'file-multiple-outline',label:'Residual Files', key:'residualFiles', color:'#8B5CF6' },
  { icon:'package-down',         label:'APK Files',      key:'apkFiles',      color:'#06B6D4' },
  { icon:'timer-sand',           label:'Temp Files',     key:'tempFiles',     color:'#EF4444' },
];

export default function ScanResultsScreen({ navigation }: Props) {
  const { scanResult, cleanNow, isCleaning } = useAppStore();
  const [cleaning, setCleaning] = useState(false);

  const goHome = () => navigation.navigate('Main');

  useFocusEffect(
    React.useCallback(() => {
      const sub = BackHandler.addEventListener('hardwareBackPress', () => {
        goHome();
        return true;
      });
      return () => sub.remove();
    }, [])
  );

  const result = scanResult ?? {
    cacheFiles:0, junkFiles:0, residualFiles:0,
    apkFiles:0, tempFiles:0, totalJunk:0,
    filesScanned:0, timeElapsed:'00:00',
  };

  const handleClean = async () => {
    setCleaning(true);
    const totalFiles = (result.cacheFiles ?? 0) + (result.junkFiles ?? 0) + (result.residualFiles ?? 0) + (result.apkFiles ?? 0) + (result.tempFiles ?? 0);
    try {
      const freed = await cleanNow();
      navigation.navigate('CleanupSuccess', { cleaned: freed > 0 ? freed : result.totalJunk, filesRemoved: totalFiles });
    } catch {
      navigation.navigate('CleanupSuccess', { cleaned: result.totalJunk, filesRemoved: totalFiles });
    } finally {
      setCleaning(false);
    }
  };

  return (
    <LinearGradient colors={['#060B18','#0F172A']} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <View style={s.header}>
        <TouchableOpacity onPress={goHome} style={s.backBtn}>
          <Icon name="arrow-left" size={22} color={C.textSecondary} />
        </TouchableOpacity>
        <Text style={s.title}>Scan Results</Text>
        <View style={{ width:40 }} />
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        <View style={s.totalCard}>
          <Text style={s.totalNum}>{result.totalJunk.toFixed(2)} GB</Text>
          <Text style={s.totalLabel}>Can be Cleaned</Text>
          <View style={s.metaRow}>
            <MetaStat label="Files Scanned" value={result.filesScanned > 999 ? (result.filesScanned/1000).toFixed(0)+'k' : String(result.filesScanned)} />
            <MetaStat label="Junk Found"    value={result.totalJunk.toFixed(2)+' GB'} />
            <MetaStat label="Time Elapsed"  value={result.timeElapsed} />
          </View>
        </View>

        <View style={s.breakdownCard}>
          {FILE_TYPES.map(ft => {
            const val = (result as any)[ft.key] as number ?? 0;
            const pct = result.totalJunk > 0 ? Math.round((val / result.totalJunk) * 100) : 0;
            return (
              <View key={ft.key} style={s.fileRow}>
                <View style={[s.fileIcon, { backgroundColor: ft.color+'20' }]}>
                  <Icon name={ft.icon} size={20} color={ft.color} />
                </View>
                <View style={{ flex:1 }}>
                  <View style={s.fileLabelRow}>
                    <Text style={s.fileLabel}>{ft.label}</Text>
                    <Text style={s.fileSize}>{val.toFixed(2)} GB</Text>
                  </View>
                  <ProgressBar progress={pct} color={ft.color} height={4} style={{ marginTop:6 }} />
                </View>
              </View>
            );
          })}
        </View>

        <View style={s.tipCard}>
          <Icon name="information-outline" size={18} color={C.primary} />
          <Text style={s.tipText}>Cleaning will permanently delete these files. Your personal data and app settings won't be affected.</Text>
        </View>

        <View style={{ height:20 }} />
      </ScrollView>

      <View style={s.cta}>
        <TouchableOpacity style={s.skipBtn} onPress={() => navigation.navigate('Main' as any)}>
          <Text style={s.skipText}>Skip</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[s.cleanWrapper, { flex:1 }]}
          onPress={handleClean}
          disabled={cleaning || isCleaning}
        >
          <LinearGradient colors={C.gradientPrimary} style={s.cleanBtn}>
            {(cleaning || isCleaning)
              ? <ActivityIndicator color="#fff" size="small" />
              : <><Icon name="broom" size={22} color="#fff" /><Text style={s.cleanText}>Clean Now</Text></>
            }
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const MetaStat = ({ label, value }: { label:string; value:string }) => (
  <View style={{ alignItems:'center', flex:1 }}>
    <Text style={{ fontSize:16, fontWeight:'800', color:C.textPrimary }}>{value}</Text>
    <Text style={{ fontSize:10, color:C.textMuted, marginTop:2 }}>{label}</Text>
  </View>
);

const s = StyleSheet.create({
  container: { flex:1 },
  header: { flexDirection:'row', alignItems:'center', justifyContent:'space-between', paddingTop:56, paddingHorizontal:20, paddingBottom:8 },
  backBtn: { width:40, height:40, justifyContent:'center', alignItems:'center' },
  title: { fontSize:18, fontWeight:'700', color:C.textPrimary },
  totalCard: { margin:20, backgroundColor:C.cardElevated, borderRadius:radius.card, padding:spacing.xxl, alignItems:'center', borderWidth:1, borderColor:C.border },
  totalNum: { fontSize:48, fontWeight:'900', color:C.danger },
  totalLabel: { fontSize:16, color:C.textMuted, marginTop:4, marginBottom:20 },
  metaRow: { flexDirection:'row', width:'100%', borderTopWidth:1, borderTopColor:C.border, paddingTop:16 },
  breakdownCard: { marginHorizontal:20, backgroundColor:C.card, borderRadius:radius.card, padding:spacing.lg, gap:spacing.md },
  fileRow: { flexDirection:'row', alignItems:'center', gap:spacing.md },
  fileIcon: { width:44, height:44, borderRadius:radius.lg, justifyContent:'center', alignItems:'center', flexShrink:0 },
  fileLabelRow: { flexDirection:'row', justifyContent:'space-between' },
  fileLabel: { fontSize:14, color:C.textPrimary, fontWeight:'500' },
  fileSize: { fontSize:14, color:C.textSecondary, fontWeight:'600' },
  tipCard: { flexDirection:'row', alignItems:'flex-start', gap:10, marginHorizontal:20, marginTop:16, backgroundColor:C.card, borderRadius:radius.xl, padding:14, borderWidth:1, borderColor:C.border },
  tipText: { flex:1, fontSize:12, color:C.textMuted, lineHeight:18 },
  cta: { flexDirection:'row', alignItems:'center', gap:12, paddingHorizontal:20, paddingBottom:32, paddingTop:8 },
  skipBtn: { paddingHorizontal:20, paddingVertical:16 },
  skipText: { fontSize:15, color:C.textMuted, fontWeight:'600' },
  cleanWrapper: { borderRadius:radius.button, overflow:'hidden' },
  cleanBtn: { flexDirection:'row', alignItems:'center', justifyContent:'center', paddingVertical:16, gap:10 },
  cleanText: { fontSize:17, fontWeight:'700', color:'#fff' },
});
