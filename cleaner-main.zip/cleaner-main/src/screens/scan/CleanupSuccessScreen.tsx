import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, TouchableOpacity, StatusBar } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../../navigation/types';
import { darkColors as C, radius, spacing } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

type Props = {
  navigation: NativeStackNavigationProp<RootStackParamList, 'CleanupSuccess'>;
  route: RouteProp<RootStackParamList, 'CleanupSuccess'>;
};

export default function CleanupSuccessScreen({ navigation, route }: Props) {
  const cleaned = route.params?.cleaned ?? 0;
  const filesRemoved = route.params?.filesRemoved ?? 0;
  const { resetScan, deviceStats } = useAppStore();
  const scale = useRef(new Animated.Value(0)).current;
  const ring1 = useRef(new Animated.Value(0.5)).current;
  const ring2 = useRef(new Animated.Value(0.5)).current;
  const textOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.spring(scale, { toValue: 1, tension: 60, friction: 7, useNativeDriver: true }),
      Animated.parallel([
        Animated.timing(ring1, { toValue: 1.3, duration: 600, useNativeDriver: true }),
        Animated.timing(ring2, { toValue: 1.6, duration: 800, useNativeDriver: true }),
        Animated.timing(textOpacity, { toValue: 1, duration: 400, useNativeDriver: true }),
      ]),
    ]).start();
  }, []);

  return (
    <LinearGradient colors={['#020F06', '#0F172A']} style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />

      <View style={styles.center}>
        <Animated.View style={[styles.outerRing, { transform: [{ scale: ring2 }], opacity: ring2.interpolate({ inputRange: [0.5, 1.6], outputRange: [0, 0.3] }) }]} />
        <Animated.View style={[styles.innerRing, { transform: [{ scale: ring1 }], opacity: ring1.interpolate({ inputRange: [0.5, 1.3], outputRange: [0, 0.5] }) }]} />

        <Animated.View style={[styles.iconCircle, { transform: [{ scale }] }]}>
          <LinearGradient colors={['#22C55E', '#16A34A']} style={styles.iconGradient}>
            <Icon name="check-bold" size={52} color="#fff" />
          </LinearGradient>
        </Animated.View>

        <Animated.View style={{ alignItems: 'center', marginTop: 32, opacity: textOpacity }}>
          <Text style={styles.doneTitle}>Cleaning Completed!</Text>
          <Text style={styles.cleanedAmt}>{cleaned} GB cleaned</Text>

          <View style={styles.statsRow}>
            <StatBox icon="file-remove-outline" label="Files Removed" value={filesRemoved > 0 ? filesRemoved.toLocaleString() : '—'} />
            <StatBox icon="harddisk" label="Space Restored" value={`${cleaned} GB`} />
            <StatBox icon="shield-check" label="Health Score" value={`${deviceStats.healthScore}`} />
          </View>
        </Animated.View>
      </View>

      <View style={styles.cta}>
        <TouchableOpacity
          style={styles.doneWrapper}
          onPress={() => { resetScan(); navigation.navigate('Main'); }}
        >
          <LinearGradient colors={C.gradientSuccess} style={styles.doneBtn}>
            <Text style={styles.doneText}>Done</Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const StatBox = ({ icon, label, value }: { icon: string; label: string; value: string }) => (
  <View style={sb.box}>
    <Icon name={icon} size={20} color={C.success} />
    <Text style={sb.val}>{value}</Text>
    <Text style={sb.lbl}>{label}</Text>
  </View>
);
const sb = StyleSheet.create({
  box: { flex: 1, alignItems: 'center', gap: 4 },
  val: { fontSize: 16, fontWeight: '800', color: C.textPrimary },
  lbl: { fontSize: 10, color: C.textMuted, textAlign: 'center' },
});

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  outerRing: { position: 'absolute', width: 320, height: 320, borderRadius: 160, backgroundColor: 'rgba(34,197,94,0.08)' },
  innerRing: { position: 'absolute', width: 220, height: 220, borderRadius: 110, backgroundColor: 'rgba(34,197,94,0.12)' },
  iconCircle: { width: 140, height: 140, borderRadius: 70 },
  iconGradient: { width: 140, height: 140, borderRadius: 70, justifyContent: 'center', alignItems: 'center', shadowColor: '#22C55E', shadowOffset: { width: 0, height: 0 }, shadowOpacity: 0.7, shadowRadius: 40, elevation: 20 },
  doneTitle: { fontSize: 28, fontWeight: '800', color: C.textPrimary, marginBottom: 8 },
  cleanedAmt: { fontSize: 16, color: C.success, fontWeight: '700', marginBottom: 32 },
  statsRow: { flexDirection: 'row', gap: spacing.lg, width: '100%', paddingHorizontal: 32 },
  cta: { paddingHorizontal: 24, paddingBottom: 40 },
  doneWrapper: { borderRadius: radius.button, overflow: 'hidden' },
  doneBtn: { paddingVertical: 16, alignItems: 'center' },
  doneText: { fontSize: 17, fontWeight: '700', color: '#fff' },
});
