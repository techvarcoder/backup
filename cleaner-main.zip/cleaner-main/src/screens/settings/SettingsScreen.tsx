import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, StatusBar, Switch } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { darkColors as C, radius, spacing } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

const APP_VERSION: string = (require('../../../package.json') as { version: string }).version;

interface SettingItem {
  icon: string;
  label: string;
  type: 'toggle' | 'nav' | 'info';
  key?: string;
  value?: string;
  color: string;
}

const SECTIONS: Array<{ title: string; items: SettingItem[] }> = [
  {
    title: 'General',
    items: [
      { icon:'bell-outline', label:'Notifications', type:'toggle', key:'notif', color:'#3B82F6' },
      { icon:'moon-waning-crescent', label:'Dark Mode', type:'toggle', key:'dark', color:'#8B5CF6' },
      { icon:'translate', label:'Language', type:'nav', value:'English', color:'#06B6D4' },
    ],
  },
  {
    title: 'Cleaning',
    items: [
      { icon:'calendar-clock', label:'Auto Schedule', type:'toggle', key:'schedule', color:'#22C55E' },
      { icon:'recycle', label:'Recycle Bin', type:'toggle', key:'recycle', color:'#D97706' },
      { icon:'shield-check-outline', label:'Safe Delete', type:'toggle', key:'safe', color:'#EF4444' },
    ],
  },
  {
    title: 'Storage',
    items: [
      { icon:'chart-donut', label:'Storage Analysis', type:'nav', color:'#3B82F6' },
      { icon:'folder-cog-outline', label:'Excluded Folders', type:'nav', color:'#8B5CF6' },
    ],
  },
  {
    title: 'About',
    items: [
      { icon:'information-outline', label:'App Version', type:'info', value: APP_VERSION, color:'#4B5563' },
      { icon:'star-outline', label:'Rate Us', type:'nav', color:'#F59E0B' },
      { icon:'share-variant', label:'Share App', type:'nav', color:'#22C55E' },
      { icon:'shield-outline', label:'Privacy Policy', type:'nav', color:'#3B82F6' },
    ],
  },
];

export default function SettingsScreen() {
  const navigation = useNavigation();
  const { deviceStats } = useAppStore();
  const [toggles, setToggles] = useState<Record<string,boolean>>({ notif:true, dark:true, schedule:false, recycle:true, safe:true });
  const toggle = (k: string) => setToggles(prev => ({ ...prev, [k]: !prev[k] }));

  return (
    <LinearGradient colors={["#0A0F1E","#0F172A"]} style={s.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <View style={s.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={s.back}>
          <Icon name="arrow-left" size={22} color={C.textSecondary} />
        </TouchableOpacity>
        <Text style={s.title}>Settings</Text>
        <View style={{ width: 40 }} />
      </View>

      {/* Profile card */}
      <LinearGradient colors={['#1E293B','#162032']} style={s.profileCard}>
        <LinearGradient colors={C.gradientPrimary} style={s.avatar}>
          <Icon name="account" size={28} color="#fff" />
        </LinearGradient>
        <View style={{ flex: 1, marginLeft: 14 }}>
          <Text style={s.profileName}>{deviceStats.deviceModel || 'My Device'}</Text>
          <Text style={s.profileSub}>Free Plan · Upgrade to Premium</Text>
        </View>
        <TouchableOpacity onPress={() => (navigation as any).navigate('Premium' as any)}>
          <LinearGradient colors={['#F59E0B','#D97706']} style={s.upgradeBtn}>
            <Text style={s.upgradeText}>Upgrade</Text>
          </LinearGradient>
        </TouchableOpacity>
      </LinearGradient>

      <ScrollView contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 40 }}>
        {SECTIONS.map(sec => (
          <View key={sec.title} style={s.section}>
            <Text style={s.sectionTitle}>{sec.title}</Text>
            <View style={s.sectionCard}>
              {sec.items.map((item, i) => (
                <View key={item.label} style={[s.row, i < sec.items.length - 1 && s.rowBorder]}>
                  <View style={[s.iconBox, { backgroundColor: item.color + '22' }]}>
                    <Icon name={item.icon} size={18} color={item.color} />
                  </View>
                  <Text style={s.rowLabel}>{item.label}</Text>
                  {item.type === 'toggle' && (
                    <Switch
                      value={toggles[item.key as string] ?? false}
                      onValueChange={() => toggle(item.key as string)}
                      trackColor={{ false: C.border, true: C.primary + '88' }}
                      thumbColor={toggles[item.key as string] ? C.primary : C.textDisabled}
                    />
                  )}
                  {item.type === 'nav' && (
                    <View style={s.navRight}>
                      {item.value && <Text style={s.navValue}>{item.value}</Text>}
                      <Icon name="chevron-right" size={18} color={C.textMuted} />
                    </View>
                  )}
                  {item.type === 'info' && (
                    <Text style={s.infoValue}>{item.value}</Text>
                  )}
                </View>
              ))}
            </View>
          </View>
        ))}
      </ScrollView>
    </LinearGradient>
  );
}

const s = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingTop: 56, paddingHorizontal: 20, paddingBottom: 12 },
  back: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  title: { fontSize: 18, fontWeight: '700', color: C.textPrimary },
  profileCard: { flexDirection: 'row', alignItems: 'center', marginHorizontal: 20, borderRadius: radius.xl, padding: 16, marginBottom: 20, borderWidth: 1, borderColor: C.border },
  avatar: { width: 52, height: 52, borderRadius: 26, justifyContent: 'center', alignItems: 'center' },
  profileName: { fontSize: 16, fontWeight: '700', color: C.textPrimary },
  profileSub: { fontSize: 12, color: C.textMuted, marginTop: 2 },
  upgradeBtn: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: radius.pill },
  upgradeText: { fontSize: 12, color: '#fff', fontWeight: '700' },
  section: { marginBottom: 20 },
  sectionTitle: { fontSize: 12, fontWeight: '700', color: C.textMuted, letterSpacing: 1.2, textTransform: 'uppercase', marginBottom: 8 },
  sectionCard: { backgroundColor: C.card, borderRadius: radius.xl, overflow: 'hidden', borderWidth: 1, borderColor: C.border },
  row: { flexDirection: 'row', alignItems: 'center', padding: 16, gap: 14 },
  rowBorder: { borderBottomWidth: 1, borderBottomColor: C.border },
  iconBox: { width: 36, height: 36, borderRadius: radius.md, justifyContent: 'center', alignItems: 'center' },
  rowLabel: { flex: 1, fontSize: 14, color: C.textPrimary, fontWeight: '500' },
  navRight: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  navValue: { fontSize: 13, color: C.textMuted },
  infoValue: { fontSize: 13, color: C.textMuted },
});
