import React, { useRef, useState } from 'react';
import {
  View, Text, StyleSheet, Dimensions, FlatList, Animated, TouchableOpacity,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../navigation/types';
import { PrimaryButton } from '../../components/ui/PrimaryButton';
import { darkColors as C, radius, spacing } from '../../theme';
import { useAppStore } from '../../store/useAppStore';

const { width } = Dimensions.get('window');

type Props = { navigation: NativeStackNavigationProp<RootStackParamList, 'Onboarding'> };

const SLIDES = [
  {
    id: '1',
    icon: 'lightning-bolt',
    iconColors: ['#2563EB', '#1D4ED8'] as string[],
    title: 'Welcome to\nAuroCleaner',
    subtitle: 'Clean junk, boost performance\nand keep your device safe.',
    badge: 'AI Powered',
  },
  {
    id: '2',
    icon: 'robot-outline',
    iconColors: ['#4F46E5', '#2563EB'] as string[],
    title: 'AI Powered\nCleaning',
    subtitle: 'AI identifies junk files, duplicate\nphotos and hidden storage waste.',
    badge: 'Smart AI',
  },
  {
    id: '3',
    icon: 'battery-charging',
    iconColors: ['#22C55E', '#16A34A'] as string[],
    title: 'Battery & Performance\nMonitoring',
    subtitle: 'Track battery health, CPU temperature,\nRAM usage and device speed.',
    badge: 'Live Monitor',
  },
  {
    id: '4',
    icon: 'shield-check',
    iconColors: ['#8B5CF6', '#6D28D9'] as string[],
    title: 'Protect Your\nPrivacy',
    subtitle: 'Hide files, scan security risks and\nmanage app permissions safely.',
    badge: 'Privacy First',
  },
];

export default function OnboardingScreen({ navigation }: Props) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);
  const { setOnboardingComplete } = useAppStore();

  const handleNext = () => {
    if (currentIndex < SLIDES.length - 1) {
      flatListRef.current?.scrollToIndex({ index: currentIndex + 1 });
      setCurrentIndex(currentIndex + 1);
    } else {
      setOnboardingComplete();
      navigation.replace('Permissions');
    }
  };

  const handleSkip = () => {
    setOnboardingComplete();
    navigation.replace('Permissions');
  };

  const { icon, iconColors, title, subtitle, badge } = SLIDES[currentIndex];

  return (
    <LinearGradient colors={['#0A0F1E', '#0F172A']} style={styles.container}>
      {/* Skip */}
      <TouchableOpacity style={styles.skipBtn} onPress={handleSkip}>
        <Text style={styles.skipText}>Skip</Text>
      </TouchableOpacity>

      {/* Slides */}
      <FlatList
        ref={flatListRef}
        data={SLIDES}
        horizontal
        pagingEnabled
        scrollEnabled={false}
        showsHorizontalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={{ width, flex: 1 }}>
            <SlideContent {...item} />
          </View>
        )}
        keyExtractor={(i) => i.id}
      />

      {/* Dots */}
      <View style={styles.dots}>
        {SLIDES.map((_, i) => (
          <View
            key={i}
            style={[styles.dot, i === currentIndex && styles.dotActive]}
          />
        ))}
      </View>

      {/* CTA */}
      <View style={styles.cta}>
        <PrimaryButton
          title={currentIndex === SLIDES.length - 1 ? "Get Started" : "Next"}
          onPress={handleNext}
          style={styles.btn}
        />
      </View>
    </LinearGradient>
  );
}

const SlideContent = ({
  icon, iconColors, title, subtitle, badge,
}: { icon: string; iconColors: string[]; title: string; subtitle: string; badge: string }) => (
  <View style={styles.slide}>
    {/* Glow orb */}
    <View style={styles.glowOrb} />

    {/* Illustration area */}
    <View style={styles.illustrationBox}>
      <LinearGradient colors={iconColors} style={styles.iconCircle}>
        <Icon name={icon} size={64} color="#fff" />
      </LinearGradient>
      <View style={styles.badgePill}>
        <Text style={styles.badgeText}>{badge}</Text>
      </View>
    </View>

    {/* Text */}
    <Text style={styles.title}>{title}</Text>
    <Text style={styles.subtitle}>{subtitle}</Text>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1 },
  skipBtn: {
    position: 'absolute',
    top: 56,
    right: 24,
    zIndex: 10,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: radius.pill,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  skipText: { color: C.textSecondary, fontSize: 14, fontWeight: '600' },
  slide: {
    flex: 1,
    alignItems: 'center',
    paddingTop: 100,
    paddingHorizontal: 32,
  },
  glowOrb: {
    position: 'absolute',
    top: 60,
    width: 280,
    height: 280,
    borderRadius: 140,
    backgroundColor: 'rgba(59,130,246,0.06)',
    alignSelf: 'center',
  },
  illustrationBox: { alignItems: 'center', marginBottom: 48 },
  iconCircle: {
    width: 160,
    height: 160,
    borderRadius: 80,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#3B82F6',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 40,
    elevation: 16,
  },
  badgePill: {
    marginTop: 20,
    backgroundColor: 'rgba(59,130,246,0.15)',
    borderRadius: radius.pill,
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.3)',
  },
  badgeText: { fontSize: 12, color: C.primaryLight, fontWeight: '700', letterSpacing: 0.8 },
  title: {
    fontSize: 30,
    fontWeight: '800',
    color: C.textPrimary,
    textAlign: 'center',
    lineHeight: 40,
    letterSpacing: 0.3,
  },
  subtitle: {
    fontSize: 15,
    color: C.textMuted,
    textAlign: 'center',
    marginTop: 16,
    lineHeight: 24,
  },
  dots: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 24,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: C.border,
    marginHorizontal: 4,
  },
  dotActive: {
    width: 24,
    backgroundColor: C.primary,
  },
  cta: { paddingHorizontal: 24, paddingBottom: 40 },
  btn: { width: '100%' },
});
