import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { darkColors as C, radius, spacing, shadow } from '../../theme';

interface GradientCardProps {
  colors?: string[];
  children: React.ReactNode;
  style?: ViewStyle;
  onPress?: () => void;
  padding?: number;
}

export const GradientCard: React.FC<GradientCardProps> = ({
  colors = C.gradientCard,
  children,
  style,
  onPress,
  padding = spacing.lg,
}) => {
  const content = (
    <LinearGradient colors={colors} style={[styles.card, { padding }, style]}>
      {children}
    </LinearGradient>
  );
  if (onPress) return <TouchableOpacity activeOpacity={0.85} onPress={onPress}>{content}</TouchableOpacity>;
  return content;
};

interface CardProps {
  children: React.ReactNode;
  style?: ViewStyle;
  onPress?: () => void;
  padding?: number;
}

export const Card: React.FC<CardProps> = ({ children, style, onPress, padding = spacing.lg }) => {
  const content = (
    <View style={[styles.plainCard, { padding }, style]}>{children}</View>
  );
  if (onPress) return <TouchableOpacity activeOpacity={0.85} onPress={onPress}>{content}</TouchableOpacity>;
  return content;
};

const styles = StyleSheet.create({
  card: {
    borderRadius: radius.card,
    overflow: 'hidden',
    ...shadow.md,
  },
  plainCard: {
    backgroundColor: C.card,
    borderRadius: radius.card,
    ...shadow.md,
  },
});
