import React from 'react';
import {
  TouchableOpacity, Text, StyleSheet, ViewStyle, ActivityIndicator,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { darkColors as C, radius, spacing } from '../../theme';

interface PrimaryButtonProps {
  title: string;
  onPress: () => void;
  style?: ViewStyle;
  loading?: boolean;
  disabled?: boolean;
  variant?: 'gradient' | 'outline' | 'ghost';
  colors?: string[];
  small?: boolean;
}

export const PrimaryButton: React.FC<PrimaryButtonProps> = ({
  title, onPress, style, loading, disabled, variant = 'gradient',
  colors = C.gradientPrimary, small = false,
}) => {
  const h = small ? 44 : 56;
  const fs = small ? 14 : 16;

  if (variant === 'gradient') {
    return (
      <TouchableOpacity
        activeOpacity={0.85}
        onPress={onPress}
        disabled={disabled || loading}
        style={[{ borderRadius: radius.button, overflow: 'hidden' }, style]}
      >
        <LinearGradient
          colors={disabled ? ['#334155', '#334155'] : colors}
          start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
          style={[styles.base, { height: h }]}
        >
          {loading ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <Text style={[styles.label, { fontSize: fs }]}>{title}</Text>
          )}
        </LinearGradient>
      </TouchableOpacity>
    );
  }

  if (variant === 'outline') {
    return (
      <TouchableOpacity
        activeOpacity={0.8}
        onPress={onPress}
        disabled={disabled}
        style={[styles.base, styles.outline, { height: h }, style]}
      >
        <Text style={[styles.label, { fontSize: fs, color: C.primary }]}>{title}</Text>
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity activeOpacity={0.7} onPress={onPress} disabled={disabled} style={[{ height: h, justifyContent: 'center', alignItems: 'center' }, style]}>
      <Text style={[styles.label, { fontSize: fs, color: C.primary }]}>{title}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  base: {
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: radius.button,
    paddingHorizontal: spacing.xxl,
  },
  outline: {
    borderWidth: 1.5,
    borderColor: C.primary,
    backgroundColor: 'transparent',
  },
  label: {
    color: '#fff',
    fontWeight: '600',
    letterSpacing: 0.3,
  },
});
