import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { darkColors as C, radius, spacing } from '../../theme';

interface StatRowProps {
  icon: string;
  iconColor?: string;
  label: string;
  value: string;
  subValue?: string;
  onPress?: () => void;
}

export const StatRow: React.FC<StatRowProps> = ({ icon, iconColor = C.primary, label, value, subValue, onPress }) => {
  const content = (
    <View style={styles.row}>
      <View style={[styles.iconBox, { backgroundColor: iconColor + '22' }]}>
        <Icon name={icon} size={20} color={iconColor} />
      </View>
      <View style={styles.info}>
        <Text style={styles.label}>{label}</Text>
        {subValue && <Text style={styles.sub}>{subValue}</Text>}
      </View>
      <Text style={styles.value}>{value}</Text>
    </View>
  );
  if (onPress) return <TouchableOpacity activeOpacity={0.7} onPress={onPress}>{content}</TouchableOpacity>;
  return content;
};

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm,
  },
  iconBox: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: spacing.md,
  },
  info: { flex: 1 },
  label: { fontSize: 14, color: C.textPrimary, fontWeight: '500' },
  sub: { fontSize: 12, color: C.textMuted, marginTop: 2 },
  value: { fontSize: 14, color: C.textPrimary, fontWeight: '700' },
});
