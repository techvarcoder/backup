import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { darkColors as C, radius, spacing } from '../../theme';

interface ToolCardProps {
  icon: string;
  label: string;
  colors: string[];
  onPress?: () => void;
  badge?: string;
}

export const ToolCard: React.FC<ToolCardProps> = ({ icon, label, colors, onPress, badge }) => (
  <TouchableOpacity activeOpacity={0.8} onPress={onPress} style={styles.wrapper}>
    <LinearGradient colors={colors} style={styles.iconBox}>
      <Icon name={icon} size={26} color="#fff" />
    </LinearGradient>
    <Text style={styles.label} numberOfLines={2}>{label}</Text>
    {badge && (
      <View style={styles.badge}>
        <Text style={styles.badgeText}>{badge}</Text>
      </View>
    )}
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  wrapper: {
    alignItems: 'center',
    width: '22%',
    marginBottom: spacing.xl,
  },
  iconBox: {
    width: 58,
    height: 58,
    borderRadius: radius.xl,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  label: {
    fontSize: 11,
    color: C.textSecondary,
    textAlign: 'center',
    fontWeight: '500',
  },
  badge: {
    position: 'absolute',
    top: -4,
    right: 2,
    backgroundColor: C.danger,
    borderRadius: radius.pill,
    paddingHorizontal: 5,
    paddingVertical: 1,
  },
  badgeText: {
    fontSize: 9,
    color: '#fff',
    fontWeight: '700',
  },
});
