import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Animated } from 'react-native';
import { darkColors as C, radius } from '../../theme';

interface ProgressBarProps {
  progress: number; // 0-100
  color?: string;
  height?: number;
  bgColor?: string;
  animated?: boolean;
  style?: object;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  progress,
  color = C.primary,
  height = 6,
  bgColor = C.border,
  animated = true,
  style,
}) => {
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (animated) {
      Animated.timing(anim, {
        toValue: progress,
        duration: 900,
        useNativeDriver: false,
      }).start();
    } else {
      anim.setValue(progress);
    }
  }, [progress]);

  const width = anim.interpolate({
    inputRange: [0, 100],
    outputRange: ['0%', '100%'],
    extrapolate: 'clamp',
  });

  return (
    <View style={[{ height, backgroundColor: bgColor, borderRadius: radius.pill, overflow: 'hidden' }, style]}>
      <Animated.View style={{ height, width, backgroundColor: color, borderRadius: radius.pill }} />
    </View>
  );
};
