import React, { useEffect, useRef } from 'react';
import { View, Animated, StyleSheet } from 'react-native';
import { darkColors as C, radius } from '../../theme';

interface ShimmerProps {
  width?: number | string;
  height?: number;
  borderRadius?: number;
  style?: object;
}

export const Shimmer: React.FC<ShimmerProps> = ({
  width = '100%',
  height = 20,
  borderRadius = radius.md,
  style,
}) => {
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(anim, { toValue: 1, duration: 900, useNativeDriver: true }),
        Animated.timing(anim, { toValue: 0, duration: 900, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, []);

  const opacity = anim.interpolate({ inputRange: [0, 1], outputRange: [0.3, 0.7] });

  return (
    <Animated.View
      style={[
        { width: width as any, height, borderRadius, backgroundColor: C.cardElevated, opacity },
        style,
      ]}
    />
  );
};

export const SkeletonCard: React.FC = () => (
  <View style={styles.skCard}>
    <View style={styles.row}>
      <Shimmer width={44} height={44} borderRadius={radius.lg} />
      <View style={{ marginLeft: 12, flex: 1 }}>
        <Shimmer width="60%" height={14} style={{ marginBottom: 8 }} />
        <Shimmer width="40%" height={10} />
      </View>
    </View>
    <Shimmer height={12} style={{ marginTop: 16 }} />
    <Shimmer width="80%" height={12} style={{ marginTop: 8 }} />
  </View>
);

const styles = StyleSheet.create({
  skCard: {
    backgroundColor: C.card,
    borderRadius: radius.card,
    padding: 16,
    marginBottom: 12,
  },
  row: { flexDirection: 'row', alignItems: 'center' },
});
