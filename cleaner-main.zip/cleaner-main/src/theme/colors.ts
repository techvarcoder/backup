export const darkColors = {
  // Backgrounds
  background: '#0F172A',
  backgroundSecondary: '#111827',
  card: '#111827',
  cardElevated: '#1E293B',
  surface: '#162032',
  overlay: 'rgba(0,0,0,0.7)',

  // Brand
  primary: '#3B82F6',
  primaryDark: '#2563EB',
  primaryLight: '#60A5FA',
  secondary: '#6366F1',
  accent: '#8B5CF6',
  accentCyan: '#06B6D4',

  // Semantic
  success: '#22C55E',
  successDark: '#16A34A',
  warning: '#F59E0B',
  danger: '#EF4444',
  dangerDark: '#DC2626',
  info: '#06B6D4',

  // Text
  textPrimary: '#F8FAFC',
  textSecondary: '#CBD5E1',
  textMuted: '#94A3B8',
  textDisabled: '#475569',

  // Borders
  border: '#1E293B',
  divider: '#334155',
  borderLight: 'rgba(255,255,255,0.08)',

  // Gradients (start/end)
  gradientPrimary: ['#2563EB', '#1D4ED8'] as string[],
  gradientAI: ['#4F46E5', '#2563EB'] as string[],
  gradientSuccess: ['#22C55E', '#16A34A'] as string[],
  gradientDanger: ['#EF4444', '#DC2626'] as string[],
  gradientPremium: ['#1E1B4B', '#F59E0B'] as string[],
  gradientCard: ['#1E293B', '#0F172A'] as string[],
  gradientOrange: ['#F97316', '#EA580C'] as string[],
  gradientCyan: ['#06B6D4', '#0891B2'] as string[],
  gradientPurple: ['#8B5CF6', '#6D28D9'] as string[],
  gradientGreen: ['#22C55E', '#15803D'] as string[],

  // Misc
  white: '#FFFFFF',
  black: '#000000',
  tabBar: '#0D1426',
  tabBarBorder: 'rgba(255,255,255,0.06)',
  glow: 'rgba(59,130,246,0.35)',
  glowPurple: 'rgba(139,92,246,0.35)',
  glowGreen: 'rgba(34,197,94,0.35)',
};

export type ColorPalette = typeof darkColors;
export const colors = darkColors;

export const lightColors = {
  background: '#F8FAFC',
  backgroundSecondary: '#F1F5F9',
  card: '#FFFFFF',
  cardElevated: '#FFFFFF',
  surface: '#F1F5F9',
  overlay: 'rgba(0,0,0,0.5)',
  primary: '#2563EB',
  primaryDark: '#1D4ED8',
  primaryLight: '#3B82F6',
  secondary: '#6366F1',
  accent: '#8B5CF6',
  accentCyan: '#06B6D4',
  success: '#22C55E',
  successDark: '#16A34A',
  warning: '#F59E0B',
  danger: '#EF4444',
  dangerDark: '#DC2626',
  info: '#06B6D4',
  textPrimary: '#111827',
  textSecondary: '#6B7280',
  textMuted: '#9CA3AF',
  textDisabled: '#D1D5DB',
  border: '#E5E7EB',
  divider: '#EDF2F7',
  borderLight: 'rgba(0,0,0,0.06)',
  gradientPrimary: ['#2563EB', '#1D4ED8'] as string[],
  gradientAI: ['#4F46E5', '#2563EB'] as string[],
  gradientSuccess: ['#22C55E', '#16A34A'] as string[],
  gradientDanger: ['#EF4444', '#DC2626'] as string[],
  gradientPremium: ['#111827', '#F59E0B'] as string[],
  gradientCard: ['#FFFFFF', '#F1F5F9'] as string[],
  gradientOrange: ['#F97316', '#EA580C'] as string[],
  gradientCyan: ['#06B6D4', '#0891B2'] as string[],
  gradientPurple: ['#8B5CF6', '#6D28D9'] as string[],
  gradientGreen: ['#22C55E', '#15803D'] as string[],
  white: '#FFFFFF',
  black: '#000000',
  tabBar: '#FFFFFF',
  tabBarBorder: 'rgba(0,0,0,0.06)',
  glow: 'rgba(37,99,235,0.25)',
  glowPurple: 'rgba(139,92,246,0.25)',
  glowGreen: 'rgba(34,197,94,0.25)',

};

export const gradients = {
  primary: ['#2563EB', '#1D4ED8'] as string[],
  ai: ['#4F46E5', '#2563EB'] as string[],
  purple: ['#8B5CF6', '#6D28D9'] as string[],
  orange: ['#F97316', '#EA580C'] as string[],
  blue: ['#3B82F6', '#1D4ED8'] as string[],
  green: ['#22C55E', '#16A34A'] as string[],
  cyan: ['#06B6D4', '#0891B2'] as string[],
  danger: ['#EF4444', '#DC2626'] as string[],
  premium: ['#1E1B4B', '#F59E0B'] as string[],
  card: ['#1E293B', '#162032'] as string[],
  dark: ['#0F172A', '#111827'] as string[],
};

export type Colors = typeof darkColors;
