import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { DeviceService } from '../services/DeviceService';
import { ScanService, ScanItem } from '../services/ScanService';

const PERSIST_KEY = '@AuroCleaner:persist';

export interface DeviceStats {
  storageUsed: number;
  storageTotal: number;
  batteryLevel: number;
  batteryHealth: number;
  isCharging: boolean;
  ramUsed: number;
  ramTotal: number;
  cpuUsage: number;
  temperature: number;
  networkDownload: number;
  networkUpload: number;
  networkType: string;
  junkSize: number;
  healthScore: number;
  deviceModel: string;
  systemVersion: string;
}

export interface ScanResult {
  cacheFiles: number;
  junkFiles: number;
  residualFiles: number;
  apkFiles: number;
  tempFiles: number;
  totalJunk: number;
  filesScanned: number;
  timeElapsed: string;
}

export interface RecentActivity {
  id: string;
  title: string;
  subtitle: string;
  time: string;
  icon: string;
  color: string;
}

export interface CleanHistory {
  id: string;
  date: string;
  freedGB: number;
  score: number;
}

interface AppState {
  hasCompletedOnboarding: boolean;
  hasGrantedPermissions: boolean;
  isDarkTheme: boolean;

  // Device stats
  deviceStats: DeviceStats;
  isLoadingStats: boolean;

  // Scan
  isScanning: boolean;
  scanProgress: number;
  scanCurrentPath: string;
  scanResult: ScanResult | null;
  pendingScanItems: ScanItem[];
  isCleaning: boolean;

  // History
  recentActivity: RecentActivity[];
  cleanHistory: CleanHistory[];
  totalCleaned: number; // GB

  // Actions
  setOnboardingComplete: () => void;
  setPermissionsGranted: () => void;
  toggleTheme: () => void;
  refreshDeviceStats: () => Promise<void>;
  updateDeviceStats: (stats: Partial<DeviceStats>) => void;
  startScan: () => void;
  updateScanProgress: (progress: number, path?: string) => void;
  setScanResult: (result: ScanResult, items: ScanItem[]) => void;
  resetScan: () => void;
  cleanNow: () => Promise<number>;
  addActivity: (activity: Omit<RecentActivity, 'id'>) => void;
  loadPersistedState: () => Promise<void>;
  _persist: () => Promise<void>;
}

const DEFAULT_STATS: DeviceStats = {
  storageUsed: 0, storageTotal: 1,        // avoid division by zero
  batteryLevel: 0, batteryHealth: 0, isCharging: false,
  ramUsed: 0, ramTotal: 1,               // avoid division by zero
  cpuUsage: 0, temperature: 0,
  networkDownload: 0, networkUpload: 0, networkType: 'unknown',
  junkSize: 0, healthScore: 0,
  deviceModel: '', systemVersion: '',
};

const DEFAULT_ACTIVITY: RecentActivity[] = [];

function calcHealthScore(stats: DeviceStats): number {
  const storage = 100 - Math.round((stats.storageUsed / Math.max(stats.storageTotal, 0.001)) * 100);
  const battery = stats.batteryLevel;
  const ram     = 100 - Math.round((stats.ramUsed    / Math.max(stats.ramTotal,     0.001)) * 100);
  const cpu     = 100 - stats.cpuUsage;
  return Math.round((storage * 0.25) + (battery * 0.25) + (ram * 0.25) + (cpu * 0.25));
}

export const useAppStore = create<AppState>((set, get) => ({
  hasCompletedOnboarding: false,
  hasGrantedPermissions: false,
  isDarkTheme: true,

  deviceStats: DEFAULT_STATS,
  isLoadingStats: false,

  isScanning: false,
  scanProgress: 0,
  scanCurrentPath: '',
  scanResult: null,
  pendingScanItems: [],
  isCleaning: false,

  recentActivity: DEFAULT_ACTIVITY,
  cleanHistory: [],
  totalCleaned: 0,

  setOnboardingComplete: () => {
    set({ hasCompletedOnboarding: true });
    get().loadPersistedState(); // also persist
  },

  setPermissionsGranted: () => {
    set({ hasGrantedPermissions: true });
  },

  toggleTheme: () => set(s => ({ isDarkTheme: !s.isDarkTheme })),

  refreshDeviceStats: async () => {
    set({ isLoadingStats: true });
    try {
      const data = await DeviceService.getStats();
      const partial: DeviceStats = {
        storageUsed:     data.storageUsed,
        storageTotal:    data.storageTotal,
        batteryLevel:    data.batteryLevel,
        batteryHealth:   data.batteryHealth,
        isCharging:      data.isCharging,
        ramUsed:         data.ramUsed,
        ramTotal:        data.ramTotal,
        cpuUsage:        data.cpuUsage,
        temperature:     data.temperature,
        networkDownload: data.networkDownload,
        networkUpload:   data.networkUpload,
        networkType:     data.networkType,
        junkSize:        get().deviceStats.junkSize,
        healthScore:     0,
        deviceModel:     data.deviceModel,
        systemVersion:   data.systemVersion,
      };
      partial.healthScore = calcHealthScore(partial);
      set({ deviceStats: partial, isLoadingStats: false });
    } catch {
      set({ isLoadingStats: false });
    }
  },

  updateDeviceStats: (stats: Partial<DeviceStats>) =>
    set(s => {
      const merged = { ...s.deviceStats, ...stats };
      merged.healthScore = calcHealthScore(merged);
      return { deviceStats: merged };
    }),

  startScan: () => set({
    isScanning: true, scanProgress: 0,
    scanCurrentPath: '', scanResult: null, pendingScanItems: [],
  }),

  updateScanProgress: (progress: number, path?: string) =>
    set({ scanProgress: progress, scanCurrentPath: path ?? '' }),

  setScanResult: (result: ScanResult, items: ScanItem[]) => {
    set({ scanResult: result, isScanning: false, pendingScanItems: items });
    // Update junkSize in device stats
    set(s => ({
      deviceStats: { ...s.deviceStats, junkSize: result.totalJunk },
    }));
  },

  resetScan: () => set({
    isScanning: false, scanProgress: 0,
    scanCurrentPath: '', scanResult: null, pendingScanItems: [],
  }),

  cleanNow: async () => {
    const items = get().pendingScanItems;
    set({ isCleaning: true });
    try {
      const freedBytes = await ScanService.clean(items);
      const freedGB = ScanService.toGB(freedBytes);

      const activity: RecentActivity = {
        id: Date.now().toString(),
        title: 'Junk cleaned',
        subtitle: `${freedGB.toFixed(2)} GB freed`,
        time: new Date().toISOString(),
        icon: 'broom',
        color: '#3B82F6',
      };

      const historyEntry: CleanHistory = {
        id: Date.now().toString(),
        date: new Date().toLocaleDateString(),
        freedGB,
        score: get().deviceStats.healthScore,
      };

      set(s => ({
        isCleaning: false,
        pendingScanItems: [],
        totalCleaned: parseFloat((s.totalCleaned + freedGB).toFixed(2)),
        recentActivity: [activity, ...s.recentActivity.slice(0, 9)],
        cleanHistory: [historyEntry, ...s.cleanHistory.slice(0, 29)],
        deviceStats: {
          ...s.deviceStats,
          junkSize: 0,
          healthScore: Math.min(100, s.deviceStats.healthScore + 8),
        },
      }));

      // Persist updated history
      get()._persist();
      return freedGB;
    } catch {
      set({ isCleaning: false });
      return 0;
    }
  },

  addActivity: (activity: Omit<RecentActivity, 'id'>) =>
    set(s => ({
      recentActivity: [
        { ...activity, id: Date.now().toString() },
        ...s.recentActivity.slice(0, 9),
      ],
    })),

  loadPersistedState: async () => {
    try {
      const raw = await AsyncStorage.getItem(PERSIST_KEY);
      if (!raw) return;
      const saved = JSON.parse(raw);
      set({
        hasCompletedOnboarding: saved.hasCompletedOnboarding ?? false,
        hasGrantedPermissions:  saved.hasGrantedPermissions  ?? false,
        isDarkTheme:            saved.isDarkTheme             ?? true,
        totalCleaned:           saved.totalCleaned            ?? 0,
        recentActivity:         saved.recentActivity          ?? DEFAULT_ACTIVITY,
        cleanHistory:           saved.cleanHistory            ?? [],
      });
    } catch {}
  },

  _persist: async () => {
    const s = get();
    try {
      await AsyncStorage.setItem(PERSIST_KEY, JSON.stringify({
        hasCompletedOnboarding: s.hasCompletedOnboarding,
        hasGrantedPermissions:  s.hasGrantedPermissions,
        isDarkTheme:            s.isDarkTheme,
        totalCleaned:           s.totalCleaned,
        recentActivity:         s.recentActivity,
        cleanHistory:           s.cleanHistory,
      }));
    } catch {}
  },
}));
