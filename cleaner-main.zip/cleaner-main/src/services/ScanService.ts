// eslint-disable-next-line @typescript-eslint/no-explicit-any
let RNFS: any = null;
try { RNFS = require('react-native-fs'); } catch {}

export interface ScanItem {
  path: string;
  size: number;   // bytes
  category: 'cache' | 'junk' | 'temp' | 'residual' | 'apk';
  name: string;
}

export interface ScanProgress {
  percent: number;
  currentPath: string;
  filesFound: number;
  bytesFound: number;
}

const SCAN_PATHS = [
  'Scanning system cache...',
  'Scanning app data...',
  'Scanning WhatsApp files...',
  'Scanning Instagram cache...',
  'Scanning YouTube cache...',
  'Scanning temp directories...',
  'Scanning residual data...',
  'Checking obsolete APKs...',
  'Scanning download folder...',
  'Analyzing junk files...',
  'Finalizing results...',
];

async function walkDir(path: string, category: ScanItem['category'], out: ScanItem[]): Promise<void> {
  if (!RNFS) return;
  try {
    const FS = RNFS.default ?? RNFS;
    if (!(await FS.exists(path))) return;
    const entries = await FS.readDir(path);
    for (const e of entries) {
      if (out.length >= 1000) break;
      if (e.isFile()) {
        out.push({ path: e.path, size: Number(e.size) || 0, category, name: e.name });
      } else if (e.isDirectory() && !e.name.startsWith('.')) {
        await walkDir(e.path, category, out);
      }
    }
  } catch { /* skip inaccessible */ }
}

export const ScanService = {
  async scan(onProgress: (p: ScanProgress) => void): Promise<ScanItem[]> {
    const items: ScanItem[] = [];

    if (!RNFS) {
      // RNFS unavailable — report clean device, no fake data
      onProgress({ percent: 100, currentPath: 'Scan complete', filesFound: 0, bytesFound: 0 });
      return [];
    }

    const FS = RNFS.default ?? RNFS;
    const dirs: Array<{ path: string; category: ScanItem['category'] }> = [
      { path: FS.CachesDirectoryPath,   category: 'cache' },
      { path: FS.TemporaryDirectoryPath, category: 'temp' },
    ];
    if (FS.ExternalCachesDirectoryPath) {
      dirs.push({ path: FS.ExternalCachesDirectoryPath, category: 'cache' });
    }

    for (let i = 0; i < dirs.length; i++) {
      await walkDir(dirs[i].path, dirs[i].category, items);
      onProgress({
        percent: Math.round(((i + 1) / dirs.length) * 100),
        currentPath: dirs[i].path,
        filesFound: items.length,
        bytesFound: items.reduce((s, x) => s + x.size, 0),
      });
    }

    return items;
  },

  async clean(items: ScanItem[]): Promise<number> {
    let freed = 0;
    if (!RNFS) {
      await new Promise<void>(r => setTimeout(r, 1200));
      return items.reduce((s, i) => s + i.size, 0);
    }
    const FS = RNFS.default ?? RNFS;
    for (const item of items) {
      try { await FS.unlink(item.path); freed += item.size; } catch {}
    }
    return freed;
  },

  groupByCategory(items: ScanItem[]) {
    const g: Record<string, { count: number; bytes: number }> = {};
    for (const i of items) {
      if (!g[i.category]) g[i.category] = { count: 0, bytes: 0 };
      g[i.category].count++;
      g[i.category].bytes += i.size;
    }
    return g;
  },

  formatSize(bytes: number): string {
    if (bytes >= 1073741824) return `${(bytes / 1073741824).toFixed(2)} GB`;
    if (bytes >= 1048576)    return `${(bytes / 1048576).toFixed(0)} MB`;
    return `${(bytes / 1024).toFixed(0)} KB`;
  },

  toGB(bytes: number): number {
    return parseFloat((bytes / 1073741824).toFixed(2));
  },
};
