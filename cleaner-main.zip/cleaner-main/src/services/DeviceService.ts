// eslint-disable-next-line @typescript-eslint/no-explicit-any
let RNDeviceInfo: any = null;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let RNNetInfo: any = null;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let RNFS: any = null;
try { RNDeviceInfo = require('react-native-device-info'); } catch {}
try { RNNetInfo    = require('@react-native-community/netinfo'); } catch {}
try { RNFS         = require('react-native-fs'); } catch {}

export interface DeviceData {
  batteryLevel: number;
  isCharging: boolean;
  batteryHealth: number;
  ramUsed: number;
  ramTotal: number;
  storageUsed: number;
  storageTotal: number;
  cpuUsage: number;
  temperature: number;
  networkType: string;
  networkDownload: number;
  networkUpload: number;
  deviceModel: string;
  systemVersion: string;
}

const MOCK: DeviceData = {
  batteryLevel: 0, isCharging: false, batteryHealth: 0,
  ramUsed: 0, ramTotal: 1,
  storageUsed: 0, storageTotal: 1,
  cpuUsage: 0, temperature: 0,
  networkType: 'unknown', networkDownload: 0, networkUpload: 0,
  deviceModel: '', systemVersion: '',
};

// Read battery level directly from sysfs (/sys/class/power_supply/battery/capacity)
// Returns 0-100, or -1 if unavailable
async function readBatteryLevelSysfs(): Promise<number> {
  if (!RNFS) return -1;
  const paths = [
    '/sys/class/power_supply/battery/capacity',
    '/sys/class/power_supply/Battery/capacity',
  ];
  for (const p of paths) {
    try {
      const raw: string = await RNFS.readFile(p, 'utf8');
      const val = parseInt(raw.trim(), 10);
      if (!isNaN(val) && val >= 0 && val <= 100) return val;
    } catch { /* try next */ }
  }
  return -1;
}

// Read battery temperature from sysfs (/sys/class/power_supply/battery/temp)
// Value is in tenths of °C (e.g. 320 = 32.0°C)
async function readTemperature(): Promise<number> {
  if (!RNFS) return 0;
  const paths = [
    '/sys/class/power_supply/battery/temp',
    '/sys/class/thermal/thermal_zone0/temp',
    '/sys/class/thermal/thermal_zone1/temp',
  ];
  for (const p of paths) {
    try {
      const raw: string = await RNFS.readFile(p, 'utf8');
      const val = parseInt(raw.trim(), 10);
      if (!isNaN(val) && val > 0) {
        // battery/temp → tenths of °C; thermal_zone → millidegrees or °C
        if (val > 10000) return Math.round(val / 1000);  // millidegrees
        if (val > 1000)  return Math.round(val / 100);   // centidegrees
        if (val > 100)   return Math.round(val / 10);    // tenths
        return val;
      }
    } catch { /* try next path */ }
  }
  return 0;
}

// Read battery health string from sysfs and map to a percentage
async function readBatteryHealth(): Promise<number> {
  if (!RNFS) return 0;
  try {
    const raw: string = await RNFS.readFile('/sys/class/power_supply/battery/health', 'utf8');
    switch (raw.trim().toLowerCase()) {
      case 'good':          return 95;
      case 'cold':          return 75;
      case 'over voltage':  return 65;
      case 'overheat':      return 50;
      case 'dead':          return 5;
      default:              return 0;
    }
  } catch {
    return 0;
  }
}

// Read CPU usage from /proc/stat (two samples 500 ms apart)
async function readCpuUsage(): Promise<number> {
  if (!RNFS) return 0;
  try {
    const parse = (data: string) => {
      const parts = data.split('\n')[0].split(/\s+/).slice(1).map(Number);
      const idle  = (parts[3] ?? 0) + (parts[4] ?? 0); // idle + iowait
      const total = parts.reduce((a, b) => a + b, 0);
      return { idle, total };
    };
    const s1 = parse(await RNFS.readFile('/proc/stat', 'utf8'));
    await new Promise<void>(r => setTimeout(r, 500));
    const s2 = parse(await RNFS.readFile('/proc/stat', 'utf8'));
    const dt = s2.total - s1.total;
    const di = s2.idle  - s1.idle;
    if (dt <= 0) return 0;
    return Math.min(100, Math.max(0, Math.round(((dt - di) / dt) * 100)));
  } catch {
    return 0;
  }
}

// Read network throughput from /proc/net/dev (two samples 1 s apart)
async function readNetworkSpeed(): Promise<{ download: number; upload: number }> {
  if (!RNFS) return { download: 0, upload: 0 };
  try {
    const parse = (data: string) => {
      let rx = 0, tx = 0;
      for (const line of data.split('\n').slice(2)) {
        const parts = line.trim().split(/\s+/);
        if (parts.length < 10) continue;
        const iface = parts[0].replace(':', '');
        if (iface === 'lo') continue; // skip loopback
        rx += parseInt(parts[1], 10) || 0;
        tx += parseInt(parts[9], 10) || 0;
      }
      return { rx, tx };
    };
    const d1 = parse(await RNFS.readFile('/proc/net/dev', 'utf8'));
    await new Promise<void>(r => setTimeout(r, 1000));
    const d2 = parse(await RNFS.readFile('/proc/net/dev', 'utf8'));
    const dlMbps = Math.max(0, parseFloat((((d2.rx - d1.rx) * 8) / 1_000_000).toFixed(1)));
    const ulMbps = Math.max(0, parseFloat((((d2.tx - d1.tx) * 8) / 1_000_000).toFixed(1)));
    return { download: dlMbps, upload: ulMbps };
  } catch {
    return { download: 0, upload: 0 };
  }
}

export const DeviceService = {
  async getStats(): Promise<DeviceData> {
    if (!RNDeviceInfo) return { ...MOCK };
    try {
      const DI = RNDeviceInfo.default ?? RNDeviceInfo;

      // Run all real measurements in parallel
      const [
        battLevel, charging,
        usedMem, totalMem,
        freeDisk, totalDisk,
        model, sysVer,
        temp, health, cpuUsage, netSpeed, battLevelSysfs,
      ] = await Promise.all([
        DI.getBatteryLevel().catch(() => -1),
        DI.isBatteryCharging().catch(() => false),
        DI.getUsedMemory().catch(() => 0),
        DI.getTotalMemory().catch(() => 0),
        DI.getFreeDiskStorage().catch(() => 0),
        DI.getTotalDiskCapacity().catch(() => 0),
        DI.getModel().catch(() => ''),
        DI.getSystemVersion().catch(() => ''),
        readTemperature(),
        readBatteryHealth(),
        readCpuUsage(),
        readNetworkSpeed(),
        readBatteryLevelSysfs(),
      ]);

      let networkType = 'wifi';
      if (RNNetInfo) {
        try {
          const NI = RNNetInfo.default ?? RNNetInfo;
          const ns = await NI.fetch();
          networkType = ns?.type ?? 'wifi';
        } catch {}
      }

      const batt = battLevel as number;
      const sysfsLevel = battLevelSysfs as number;
      // getBatteryLevel() returns -1 on emulators → fall back to sysfs capacity file
      // If both sources fail the device is clearly running, so assume 100% charged.
      const effectiveBatt = batt >= 0 ? Math.min(100, Math.round(batt * 100))
                          : sysfsLevel >= 0 ? sysfsLevel
                          : 100;
      const uMem = usedMem  as number;
      const tMem = totalMem as number;
      const fDisk = freeDisk as number;
      const tDisk = totalDisk as number;

      return {
        batteryLevel:    effectiveBatt,
        isCharging:      Boolean(charging),
        batteryHealth:   health,
        ramUsed:         tMem > 0 ? parseFloat((uMem  / 1073741824).toFixed(1)) : 0,
        ramTotal:        tMem > 0 ? parseFloat((tMem  / 1073741824).toFixed(1)) : 1,
        storageUsed:     tDisk > 0 ? parseFloat(((tDisk - fDisk) / 1073741824).toFixed(1)) : 0,
        storageTotal:    tDisk > 0 ? parseFloat((tDisk  / 1073741824).toFixed(1)) : 1,
        cpuUsage,
        temperature:     temp,
        networkType,
        networkDownload: netSpeed.download,
        networkUpload:   netSpeed.upload,
        deviceModel:     String(model) || '',
        systemVersion:   String(sysVer) || '',
      };
    } catch {
      return { ...MOCK };
    }
  },

  async getModel(): Promise<string> {
    if (!RNDeviceInfo) return 'Android Device';
    try {
      const DI = RNDeviceInfo.default ?? RNDeviceInfo;
      return String(await DI.getModel());
    } catch { return 'Android Device'; }
  },
};
