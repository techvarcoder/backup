import React from 'react';
import { View, TouchableOpacity, StyleSheet, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import LinearGradient from 'react-native-linear-gradient';

import { RootStackParamList, MainTabParamList } from './types';
import { darkColors as C, radius } from '../theme';

// Screens
import SplashScreen from '../screens/splash/SplashScreen';
import OnboardingScreen from '../screens/onboarding/OnboardingScreen';
import PermissionsScreen from '../screens/permissions/PermissionsScreen';
import HomeScreen from '../screens/home/HomeScreen';
import ToolsScreen from '../screens/tools/ToolsScreen';
import AIAssistantScreen from '../screens/ai/AIAssistantScreen';
import SmartScanScreen from '../screens/scan/SmartScanScreen';
import ScanResultsScreen from '../screens/scan/ScanResultsScreen';
import CleanupSuccessScreen from '../screens/scan/CleanupSuccessScreen';
import BatteryMonitorScreen from '../screens/monitors/BatteryMonitorScreen';
import CPUMonitorScreen from '../screens/monitors/CPUMonitorScreen';
import RAMMonitorScreen from '../screens/monitors/RAMMonitorScreen';
import NetworkMonitorScreen from '../screens/monitors/NetworkMonitorScreen';
import DeviceCoolingScreen from '../screens/monitors/DeviceCoolingScreen';
import AIInsightsScreen from '../screens/analytics/AIInsightsScreen';
import AppUsageScreen from '../screens/analytics/AppUsageScreen';
import StorageTimelineScreen from '../screens/analytics/StorageTimelineScreen';
import StoragePredictionScreen from '../screens/analytics/StoragePredictionScreen';
import HealthHistoryScreen from '../screens/analytics/HealthHistoryScreen';
import ScheduleCleanupScreen from '../screens/cleanup/ScheduleCleanupScreen';
import PremiumScreen from '../screens/premium/PremiumScreen';
import SettingsScreen from '../screens/settings/SettingsScreen';
import DuplicateCleanerScreen from '../screens/tools/DuplicateCleanerScreen';
import WhatsAppCleanerScreen from '../screens/tools/WhatsAppCleanerScreen';
import ScreenshotCleanerScreen from '../screens/tools/ScreenshotCleanerScreen';
import LargeFileFinderScreen from '../screens/tools/LargeFileFinderScreen';
import FileExplorerScreen from '../screens/tools/FileExplorerScreen';
import MediaCompressionScreen from '../screens/tools/MediaCompressionScreen';
import RecycleBinScreen from '../screens/tools/RecycleBinScreen';
import CloudCleanupScreen from '../screens/tools/CloudCleanupScreen';
import DeepCleanScreen from '../screens/tools/DeepCleanScreen';
import AppManagerScreen from '../screens/tools/AppManagerScreen';
import SecurityScannerScreen from '../screens/tools/SecurityScannerScreen';
import APKAnalyzerScreen from '../screens/tools/APKAnalyzerScreen';
import SmartAlertsScreen from '../screens/tools/SmartAlertsScreen';
import NotificationAnalyzerScreen from '../screens/tools/NotificationAnalyzerScreen';
import GamingModeScreen from '../screens/tools/GamingModeScreen';
import MultiDeviceScreen from '../screens/tools/MultiDeviceScreen';
import WidgetsScreen from '../screens/tools/WidgetsScreen';

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<MainTabParamList>();

const TAB_ICONS: Record<string, string> = {
  Home: 'home-outline',
  Scan: 'magnify-scan',
  ToolsTab: 'tools',
  AITab: 'robot-outline',
  FilesTab: 'folder-outline',
};
const TAB_LABELS: Record<string, string> = {
  Home: 'Home',
  Scan: 'Scan',
  ToolsTab: 'Tools',
  AITab: 'AI',
  FilesTab: 'Files',
};

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: styles.tabBar,
        tabBarBackground: () => (
          <LinearGradient colors={['#0D1426', '#0A0F1E']} style={{ flex: 1, borderRadius: 0 }} />
        ),
        tabBarShowLabel: true,
        tabBarIcon: ({ focused, color }) => (
          <View style={[styles.tabIconWrap, focused && styles.tabIconActive]}>
            {focused && (
              <LinearGradient colors={['#2563EB22', '#2563EB11']} style={styles.tabActiveBg} />
            )}
            <Icon
              name={focused ? TAB_ICONS[route.name].replace('-outline', '') : TAB_ICONS[route.name]}
              size={22}
              color={focused ? C.primary : C.textDisabled}
            />
          </View>
        ),
        tabBarLabel: ({ focused }) => (
          <Text style={[styles.tabLabel, focused && styles.tabLabelActive]}>
            {TAB_LABELS[route.name]}
          </Text>
        ),
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Scan" component={SmartScanScreen} />
      <Tab.Screen name="ToolsTab" component={ToolsScreen} />
      <Tab.Screen name="AITab" component={AIAssistantScreen} />
      <Tab.Screen name="FilesTab" component={FileExplorerScreen} />
    </Tab.Navigator>
  );
}

export const AppNavigator = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_right' }}>
        <Stack.Screen name="Splash" component={SplashScreen} />
        <Stack.Screen name="Onboarding" component={OnboardingScreen} />
        <Stack.Screen name="Permissions" component={PermissionsScreen} />
        <Stack.Screen name="Main" component={MainTabs} />
        <Stack.Screen name="SmartScan" component={SmartScanScreen} />
        <Stack.Screen name="ScanResults" component={ScanResultsScreen} />
        <Stack.Screen name="CleanupSuccess" component={CleanupSuccessScreen} options={{ animation: 'fade' }} />
        <Stack.Screen name="Tools" component={ToolsScreen} />
        <Stack.Screen name="BatteryMonitor" component={BatteryMonitorScreen} />
        <Stack.Screen name="CPUMonitor" component={CPUMonitorScreen} />
        <Stack.Screen name="RAMMonitor" component={RAMMonitorScreen} />
        <Stack.Screen name="NetworkMonitor" component={NetworkMonitorScreen} />
        <Stack.Screen name="DeviceCooling" component={DeviceCoolingScreen} />
        <Stack.Screen name="AIInsights" component={AIInsightsScreen} />
        <Stack.Screen name="AIAssistant" component={AIAssistantScreen} />
        <Stack.Screen name="AppUsageAnalytics" component={AppUsageScreen} />
        <Stack.Screen name="StorageTimeline" component={StorageTimelineScreen} />
        <Stack.Screen name="StoragePrediction" component={StoragePredictionScreen} />
        <Stack.Screen name="HealthHistory" component={HealthHistoryScreen} />
        <Stack.Screen name="ScheduleCleanup" component={ScheduleCleanupScreen} />
        <Stack.Screen name="Premium" component={PremiumScreen} options={{ animation: 'slide_from_bottom' }} />
        <Stack.Screen name="Settings" component={SettingsScreen} />
        <Stack.Screen name="DuplicateCleaner" component={DuplicateCleanerScreen} />
        <Stack.Screen name="WhatsAppCleaner" component={WhatsAppCleanerScreen} />
        <Stack.Screen name="ScreenshotCleaner" component={ScreenshotCleanerScreen} />
        <Stack.Screen name="LargeFileFinder" component={LargeFileFinderScreen} />
        <Stack.Screen name="FileExplorer" component={FileExplorerScreen} />
        <Stack.Screen name="MediaCompression" component={MediaCompressionScreen} />
        <Stack.Screen name="RecycleBin" component={RecycleBinScreen} />
        <Stack.Screen name="CloudCleanup" component={CloudCleanupScreen} />
        <Stack.Screen name="DeepClean" component={DeepCleanScreen} />
        <Stack.Screen name="AppManager" component={AppManagerScreen} />
        <Stack.Screen name="SecurityScanner" component={SecurityScannerScreen} />
        <Stack.Screen name="APKAnalyzer" component={APKAnalyzerScreen} />
        <Stack.Screen name="SmartAlerts" component={SmartAlertsScreen} />
        <Stack.Screen name="NotificationAnalyzer" component={NotificationAnalyzerScreen} />
        <Stack.Screen name="GamingMode" component={GamingModeScreen} />
        <Stack.Screen name="MultiDevice" component={MultiDeviceScreen} />
        <Stack.Screen name="Widgets" component={WidgetsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

const styles = StyleSheet.create({
  tabBar: {
    height: 70,
    backgroundColor: 'transparent',
    borderTopWidth: 1,
    borderTopColor: C.tabBarBorder,
    elevation: 0,
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  tabIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  tabIconActive: {},
  tabActiveBg: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: 14,
  },
  tabLabel: {
    fontSize: 10,
    color: C.textDisabled,
    fontWeight: '500',
    marginTop: -4,
  },
  tabLabelActive: {
    color: C.primary,
    fontWeight: '700',
  },
});

