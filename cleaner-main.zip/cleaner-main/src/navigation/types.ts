export type RootStackParamList = {
  Splash: undefined;
  Onboarding: undefined;
  Permissions: undefined;
  Main: undefined;

  // Scan
  SmartScan: undefined;
  ScanResults: undefined;
  CleanupSuccess: { cleaned: number; filesRemoved?: number };

  // Tools
  Tools: undefined;
  DuplicateCleaner: undefined;
  WhatsAppCleaner: undefined;
  ScreenshotCleaner: undefined;
  LargeFileFinder: undefined;
  FileExplorer: undefined;
  MediaCompression: undefined;
  RecycleBin: undefined;
  CloudCleanup: undefined;
  DeepClean: undefined;
  AppManager: undefined;
  SecurityScanner: undefined;
  APKAnalyzer: undefined;

  // Monitors
  BatteryMonitor: undefined;
  CPUMonitor: undefined;
  RAMMonitor: undefined;
  NetworkMonitor: undefined;
  DeviceCooling: undefined;
  GamingMode: undefined;

  // Analytics & AI
  AIInsights: undefined;
  AIAssistant: undefined;
  AppUsageAnalytics: undefined;
  StorageTimeline: undefined;
  StoragePrediction: undefined;
  NotificationAnalyzer: undefined;
  HealthHistory: undefined;

  // Management
  ScheduleCleanup: undefined;
  SmartAlerts: undefined;
  MultiDevice: undefined;

  // Settings & Premium
  Premium: undefined;
  Settings: undefined;
  About: undefined;
  Themes: undefined;
  Widgets: undefined;
};

export type MainTabParamList = {
  Home: undefined;
  Scan: undefined;
  ToolsTab: undefined;
  AITab: undefined;
  FilesTab: undefined;
};

