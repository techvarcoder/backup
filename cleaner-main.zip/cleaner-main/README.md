# AuroCleaner

A React Native motivation app.

## Getting Started

### Prerequisites

- Node >= 18
- Xcode (iOS) or Android Studio (Android)
- CocoaPods (iOS)

### Install

```bash
npm install
cd ios && pod install   # iOS only
```

### Run

```bash
# iOS
npm run ios

# Android
npm run android

# Start Metro only
npm run start
```
