import { ResumeData } from '../../types';

// Placeholder Firestore service
// Install @react-native-firebase/firestore and replace with real implementation

export const firestoreService = {
  saveResume: async (_userId: string, _resume: ResumeData): Promise<void> => {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 500));
  },

  getResumes: async (_userId: string): Promise<ResumeData[]> => {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 500));
    return [];
  },

  deleteResume: async (_userId: string, _resumeId: string): Promise<void> => {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 300));
  },

  getUserProfile: async (_userId: string): Promise<Record<string, unknown> | null> => {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 300));
    return null;
  },

  updateUserProfile: async (_userId: string, _data: Record<string, unknown>): Promise<void> => {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 300));
  },
};
