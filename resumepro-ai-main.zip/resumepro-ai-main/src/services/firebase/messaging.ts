// Placeholder Firebase Messaging service
// Install @react-native-firebase/messaging and replace with real implementation

export const messagingService = {
  getToken: async (): Promise<string> => {
    return 'placeholder-fcm-token';
  },

  requestPermission: async (): Promise<boolean> => {
    return true;
  },

  onMessage: (_callback: (message: Record<string, unknown>) => void): (() => void) => {
    return () => {};
  },

  onNotificationOpenedApp: (_callback: (notification: Record<string, unknown>) => void): (() => void) => {
    return () => {};
  },
};
