// Placeholder Firebase Remote Config service
// Install @react-native-firebase/remote-config and replace with real implementation

const defaults: Record<string, string | number | boolean> = {
  premium_price_monthly: 99,
  premium_price_yearly: 499,
  ai_daily_limit: 5,
  show_premium_banner: true,
};

export const remoteConfigService = {
  fetchAndActivate: async (): Promise<void> => {
    // placeholder
  },

  getValue: (key: string): string | number | boolean => {
    return defaults[key] ?? '';
  },
};
