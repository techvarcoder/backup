import { User } from '../../types';

// Placeholder Firebase Auth service
// Install @react-native-firebase/auth and replace with real implementation

export interface AuthCredentials {
  email: string;
  password: string;
}

export interface AuthResult {
  user: User | null;
  error: string | null;
}

const mockUser: User = {
  uid: 'mock-uid-123',
  email: 'john.doe@example.com',
  displayName: 'John Doe',
  isPremium: false,
  createdAt: new Date().toISOString(),
};

export const authService = {
  signIn: async (_credentials: AuthCredentials): Promise<AuthResult> => {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 1000));
    return { user: mockUser, error: null };
  },

  signUp: async (_credentials: AuthCredentials & { displayName: string }): Promise<AuthResult> => {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 1000));
    return { user: mockUser, error: null };
  },

  signInWithGoogle: async (): Promise<AuthResult> => {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 1000));
    return { user: mockUser, error: null };
  },

  signOut: async (): Promise<void> => {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 500));
  },

  sendPasswordResetEmail: async (_email: string): Promise<{ error: string | null }> => {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 1000));
    return { error: null };
  },

  getCurrentUser: (): User | null => {
    return null;
  },

  onAuthStateChanged: (_callback: (user: User | null) => void): (() => void) => {
    return () => {};
  },
};
