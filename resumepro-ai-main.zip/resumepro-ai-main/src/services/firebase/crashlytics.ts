// Placeholder Firebase Crashlytics service
// Install @react-native-firebase/crashlytics and replace with real implementation

export const crashlyticsService = {
  recordError: (_error: Error): void => {
    // placeholder
  },

  setUserId: (_id: string): void => {
    // placeholder
  },

  log: (_message: string): void => {
    // placeholder
  },
};
