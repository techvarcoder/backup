// Placeholder Firebase Storage service
// Install @react-native-firebase/storage and replace with real implementation

export const storageService = {
  uploadResumePDF: async (_userId: string, _resumeId: string, _fileUri: string): Promise<string> => {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 2000));
    return 'https://placeholder-download-url.com/resume.pdf';
  },

  uploadProfilePhoto: async (_userId: string, _fileUri: string): Promise<string> => {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 1500));
    return 'https://placeholder-download-url.com/photo.jpg';
  },

  deleteFile: async (_path: string): Promise<void> => {
    await new Promise<void>(resolve => setTimeout(() => resolve(), 300));
  },
};
