// Placeholder Firebase Analytics service
// Install @react-native-firebase/analytics and replace with real implementation

export const analyticsService = {
  logEvent: async (_name: string, _params?: Record<string, unknown>): Promise<void> => {
    // placeholder
  },

  setUserProperty: async (_name: string, _value: string): Promise<void> => {
    // placeholder
  },

  setUserId: async (_id: string): Promise<void> => {
    // placeholder
  },

  logScreenView: async (_screenName: string): Promise<void> => {
    // placeholder
  },
};
