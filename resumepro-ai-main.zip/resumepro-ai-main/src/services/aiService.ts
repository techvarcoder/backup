import axios from 'axios';
import { AI_CONFIG } from '../config/ai';
import {
  ResumeData,
  PersonalInfo,
  WorkExperience,
  Education,
  Skill,
  Project,
  Certificate,
  Language,
  Award,
  Reference,
} from '../types';

// ─── Types ────────────────────────────────────────────────────────────────────

export interface ResumeWriterResult {
  summary: string;
  bullets: string[];
}

export type SuggestionType = 'good' | 'warn' | 'error';
export interface ReviewSuggestion {
  icon: string;
  text: string;
  type: SuggestionType;
}
export interface ResumeReviewResult {
  suggestions: ReviewSuggestion[];
}

export interface ATSCriteria {
  label: string;
  score: number;
  detail: string;
}
export interface ATSScoreResult {
  overall: number;
  criteria: ATSCriteria[];
  suggestions: string[];
}

export interface CoverLetterResult {
  letter: string;
}

// ─── Gemini helper ────────────────────────────────────────────────────────────

export const isConfigured = () => !!AI_CONFIG.GEMINI_API_KEY.trim();

type GeminiPart = { text: string } | { inlineData: { mimeType: string; data: string } };

async function askGeminiParts(parts: GeminiPart[], timeoutMs: number = AI_CONFIG.TIMEOUT_MS): Promise<string> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${AI_CONFIG.GEMINI_MODEL}:generateContent?key=${AI_CONFIG.GEMINI_API_KEY}`;
  const { data } = await axios.post(
    url,
    { contents: [{ parts }] },
    { timeout: timeoutMs, headers: { 'Content-Type': 'application/json' } },
  );
  return data?.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
}

async function askGemini(prompt: string, timeoutMs?: number): Promise<string> {
  return askGeminiParts([{ text: prompt }], timeoutMs);
}

function parseJSON<T>(raw: string, fallback: T): T {
  try {
    const match = raw.match(/```(?:json)?\s*([\s\S]*?)```/) ?? raw.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
    return JSON.parse(match ? match[1] : raw) as T;
  } catch {
    return fallback;
  }
}

function parseJSONStrict<T>(raw: string): T {
  const match = raw.match(/```(?:json)?\s*([\s\S]*?)```/) ?? raw.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
  return JSON.parse(match ? match[1] : raw) as T;
}

export class AINotConfiguredError extends Error {}

// ─── Public API ───────────────────────────────────────────────────────────────

export async function generateResumeSummary(
  jobRole: string, skills: string, experience: string,
): Promise<ResumeWriterResult> {
  if (!isConfigured()) { throw new AINotConfiguredError('Add a Gemini API key in src/config/ai.ts to use AI features.'); }
  const prompt = `You are a professional resume writer. Generate a resume summary and 4 achievement bullet points for a ${jobRole} with ${experience || '2'} years of experience and skills: ${skills || 'general software skills'}.

Respond ONLY with valid JSON in this exact format:
{
  "summary": "3-4 sentence professional summary",
  "bullets": ["bullet 1", "bullet 2", "bullet 3", "bullet 4"]
}`;
  const raw = await askGemini(prompt);
  return parseJSONStrict<ResumeWriterResult>(raw);
}

export async function reviewResume(resume: ResumeData): Promise<ResumeReviewResult> {
  if (!isConfigured()) { throw new AINotConfiguredError('Add a Gemini API key in src/config/ai.ts to use AI features.'); }
  const p = resume.personalInfo;
  const prompt = `You are a professional resume reviewer. Analyze this resume and provide specific, actionable suggestions.

Resume data:
- Name: ${p.fullName}, Job Title: ${p.jobTitle}
- Has email: ${!!p.email}, phone: ${!!p.phone}, LinkedIn: ${!!p.linkedin}
- Summary length: ${p.summary?.length ?? 0} chars
- Work experience entries: ${resume.workExperience.length}
- Skills count: ${resume.skills.length}
- Education entries: ${resume.education.length}
- Projects: ${resume.projects.length}, Certificates: ${resume.certificates.length}
- Experience descriptions: ${resume.workExperience.map(e => e.description?.substring(0, 100)).join(' | ')}

Respond ONLY with valid JSON:
{
  "suggestions": [
    { "icon": "✅", "text": "specific positive observation", "type": "good" },
    { "icon": "⚠️", "text": "specific improvement suggestion", "type": "warn" },
    { "icon": "❌", "text": "critical issue to fix", "type": "error" }
  ]
}
Provide 5-8 suggestions. Use "✅" for good, "⚠️" for warn, "❌" for error.`;
  const raw = await askGemini(prompt);
  return parseJSONStrict<ResumeReviewResult>(raw);
}

export async function checkATSScore(
  resume: ResumeData, jobRole: string = '', jobDescription: string = '',
): Promise<ATSScoreResult> {
  if (!isConfigured()) { throw new AINotConfiguredError('Add a Gemini API key in src/config/ai.ts to use AI features.'); }
  const p = resume.personalInfo;
  const hasJob = !!(jobRole.trim() || jobDescription.trim());
  const jobSection = hasJob
    ? `\n\nTarget job to match against:\n- Role: ${jobRole.trim() || 'Not specified'}\n- Job description: ${jobDescription.trim() || 'Not specified'}\n\nAlso score how well this resume's skills and experience match the target job above.`
    : '';
  const prompt = `You are an ATS (Applicant Tracking System) expert. Score this resume from 0-100 across ${hasJob ? '5' : '4'} dimensions.

Resume data:
- Name: ${p.fullName}, Title: ${p.jobTitle}, Summary: ${p.summary ? 'Yes (' + p.summary.length + ' chars)' : 'No'}
- Contact: email ${!!p.email}, phone ${!!p.phone}, location ${!!p.location}, LinkedIn ${!!p.linkedin}
- Work experience: ${resume.workExperience.length} entries, ${resume.workExperience.filter(e => e.description && e.description.length > 50).length} with good descriptions
- Skills: ${resume.skills.map(s => s.name).join(', ') || 'None listed'}
- Education: ${resume.education.length} entries
- Projects: ${resume.projects.length}, Certificates: ${resume.certificates.length}${jobSection}

Respond ONLY with valid JSON:
{
  "overall": <0-100>,
  "criteria": [
    { "label": "Content", "score": <0-100>, "detail": "Profile completeness" },
    { "label": "Keywords", "score": <0-100>, "detail": "Skills & terminology" },
    { "label": "Structure", "score": <0-100>, "detail": "Sections filled" },
    { "label": "Formatting", "score": <0-100>, "detail": "Description quality" }${hasJob ? ',\n    { "label": "Job Match", "score": <0-100>, "detail": "Fit for the target role" }' : ''}
  ],
  "suggestions": ["specific suggestion 1", "specific suggestion 2", "specific suggestion 3"${hasJob ? ', "specific missing keyword/skill from the job description"' : ''}]
}`;
  const raw = await askGemini(prompt);
  return parseJSONStrict<ATSScoreResult>(raw);
}

export async function generateCoverLetter(
  jobTitle: string, company: string, name: string,
  experience: string, skills: string, summary: string,
): Promise<CoverLetterResult> {
  if (!isConfigured()) { throw new AINotConfiguredError('Add a Gemini API key in src/config/ai.ts to use AI features.'); }
  const today = new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  const prompt = `Write a professional, personalized cover letter for a job application.

Details:
- Applicant name: ${name || 'the applicant'}
- Applying for: ${jobTitle} at ${company}
- Years of experience: ${experience || '2-3'}
- Key skills: ${skills || 'software development'}
- Professional summary: ${summary || 'experienced professional'}
- Date: ${today}

Write a 3-paragraph cover letter (opening, body, closing). Make it specific to the role and company. Sound human and confident, not generic.

Respond ONLY with valid JSON:
{ "letter": "the full cover letter text with newlines as \\n" }`;
  const raw = await askGemini(prompt);
  return parseJSONStrict<CoverLetterResult>(raw);
}

export interface SalaryEstimateResult {
  min: number;
  max: number;
  avg: number;
  note: string;
}

export async function estimateSalaryRange(
  role: string, experience: string, location: string, company: string, skills: string,
): Promise<SalaryEstimateResult> {
  if (!isConfigured()) { throw new AINotConfiguredError('Add a Gemini API key in src/config/ai.ts to use AI features.'); }
  const prompt = `You are a compensation research analyst with knowledge of the Indian job market. Estimate a realistic annual salary range for this profile.

Role: ${role}
Years of experience: ${experience || '2'}
Location: ${location || 'India'}
Company: ${company || 'a typical company for this role'}
Key skills: ${skills || 'general skills for this role'}

Respond ONLY with valid JSON in this exact format (amounts in Indian Rupees, expressed as plain numbers in LPA — Lakhs Per Annum, e.g. 8.5):
{
  "min": <number>,
  "max": <number>,
  "avg": <number>,
  "note": "one sentence on what drives this estimate (role seniority, location cost of living, company, market demand)"
}`;
  const raw = await askGemini(prompt);
  return parseJSONStrict<SalaryEstimateResult>(raw);
}

export type OfferVerdictTone = 'error' | 'warning' | 'success';
export interface OfferVerdict {
  label: string;
  tone: OfferVerdictTone;
  detail: string;
}

export function getOfferVerdict(offerLPA: number, result: SalaryEstimateResult): OfferVerdict {
  const diffPct = Math.round(((offerLPA - result.avg) / result.avg) * 100);
  if (offerLPA < result.min) {
    return { label: 'Below Market', tone: 'error', detail: `${Math.abs(diffPct)}% below the average market pay for this role.` };
  }
  if (offerLPA > result.max) {
    return { label: 'Above Market', tone: 'success', detail: `${diffPct}% above the average market pay — a strong offer.` };
  }
  return {
    label: 'Within Market Range',
    tone: 'warning',
    detail: `${diffPct >= 0 ? diffPct + '% above' : Math.abs(diffPct) + '% below'} the average market pay.`,
  };
}

// ─── Import Resume (PDF/DOCX extraction) ───────────────────────────────────────

interface RawExtractedResume {
  personalInfo?: Partial<PersonalInfo>;
  workExperience?: Array<Omit<WorkExperience, 'id'>>;
  education?: Array<Omit<Education, 'id'>>;
  skills?: Array<Omit<Skill, 'id'>>;
  projects?: Array<Omit<Project, 'id'>>;
  certificates?: Array<Omit<Certificate, 'id'>>;
  languages?: Array<Omit<Language, 'id'>>;
  awards?: Array<Omit<Award, 'id'>>;
  references?: Array<Omit<Reference, 'id'>>;
}

function buildExtractionInstructions(): string {
  return `You are a resume parser. Extract structured resume data from the provided document.

Respond ONLY with valid JSON in this exact shape (omit unknown string fields as "", unknown arrays as [], never invent data):
{
  "personalInfo": { "fullName": "", "jobTitle": "", "email": "", "phone": "", "location": "", "linkedin": "", "website": "", "github": "", "summary": "" },
  "workExperience": [ { "jobTitle": "", "company": "", "location": "", "startDate": "", "endDate": "", "isPresent": false, "description": "" } ],
  "education": [ { "degree": "", "institution": "", "fieldOfStudy": "", "startYear": "", "endYear": "", "grade": "" } ],
  "skills": [ { "name": "", "level": "" } ],
  "projects": [ { "name": "", "description": "", "technologies": "", "link": "", "startDate": "", "endDate": "" } ],
  "certificates": [ { "name": "", "issuer": "", "date": "", "link": "" } ],
  "languages": [ { "name": "", "proficiency": "" } ],
  "awards": [ { "title": "", "issuer": "", "date": "", "description": "" } ],
  "references": [ { "name": "", "position": "", "company": "", "email": "", "phone": "" } ]
}
Rules:
- "isPresent" true only if the role is explicitly current/ongoing.
- "proficiency" must be one of Beginner, Elementary, Intermediate, Professional, Native (or omit the field).
- "level" for skills must be one of Beginner, Intermediate, Advanced, Expert (or omit the field).
- Preserve description bullet points as newline-separated text, matching the source formatting where sensible.
- Return [] for any section with no data in the document — never omit a key entirely.`;
}

function withIds<T extends object>(items: T[] | undefined, prefix: string): (T & { id: string })[] {
  if (!Array.isArray(items)) { return []; }
  const ts = Date.now();
  return items.map((item, i) => ({ ...item, id: `${prefix}-${ts}-${i}` }));
}

function isMeaningfulExtraction(d: Partial<ResumeData>): boolean {
  return !!d.personalInfo?.fullName || (d.workExperience?.length ?? 0) > 0 || (d.education?.length ?? 0) > 0;
}

function normalizeExtractedResume(raw: RawExtractedResume | null): Partial<ResumeData> | null {
  if (!raw || typeof raw !== 'object') { return null; }
  const result: Partial<ResumeData> = {
    personalInfo: raw.personalInfo as PersonalInfo | undefined,
    workExperience: withIds(raw.workExperience, 'we'),
    education: withIds(raw.education, 'edu'),
    skills: withIds(raw.skills, 'sk'),
    projects: withIds(raw.projects, 'proj'),
    certificates: withIds(raw.certificates, 'cert'),
    languages: withIds(raw.languages, 'lang'),
    awards: withIds(raw.awards, 'awd'),
    references: withIds(raw.references, 'ref'),
  };
  return isMeaningfulExtraction(result) ? result : null;
}

export async function extractResumeFromPdf(base64Pdf: string): Promise<Partial<ResumeData> | null> {
  if (!isConfigured()) { return null; }
  const raw = await askGeminiParts(
    [
      { inlineData: { mimeType: 'application/pdf', data: base64Pdf } },
      { text: `${buildExtractionInstructions()}\n\nExtract the resume information from the attached PDF document.` },
    ],
    60000,
  );
  return normalizeExtractedResume(parseJSON<RawExtractedResume | null>(raw, null));
}

export async function extractResumeFromText(rawText: string): Promise<Partial<ResumeData> | null> {
  if (!isConfigured()) { return null; }
  const prompt = `${buildExtractionInstructions()}\n\nHere is the resume text extracted from a DOCX file:\n"""\n${rawText.slice(0, 20000)}\n"""`;
  const raw = await askGemini(prompt, 60000);
  return normalizeExtractedResume(parseJSON<RawExtractedResume | null>(raw, null));
}
