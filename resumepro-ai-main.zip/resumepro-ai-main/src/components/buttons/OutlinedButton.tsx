import React from 'react';
import { TouchableOpacity, Text, ActivityIndicator, StyleSheet, StyleProp, ViewStyle } from 'react-native';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { radius, spacing } from '../../theme/spacing';

interface Props {
  label: string;
  onPress: () => void;
  loading?: boolean;
  disabled?: boolean;
  style?: StyleProp<ViewStyle>;
  fullWidth?: boolean;
  color?: string;
}

export const OutlinedButton: React.FC<Props> = ({
  label,
  onPress,
  loading = false,
  disabled = false,
  style,
  fullWidth = true,
  color,
}) => {
  const { colors } = useThemeStore();
  const btnColor = color ?? colors.primary;
  const isDisabled = disabled || loading;

  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={isDisabled}
      accessibilityRole="button"
      accessibilityLabel={label}
      style={[
        styles.button,
        { borderColor: btnColor },
        isDisabled && { opacity: 0.5 },
        fullWidth && styles.fullWidth,
        style,
      ]}>
      {loading ? (
        <ActivityIndicator color={btnColor} size="small" />
      ) : (
        <Text style={[styles.label, { color: btnColor }]}>{label}</Text>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  fullWidth: { width: '100%' },
  button: {
    height: 52,
    borderRadius: radius.lg,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: spacing.xxl,
    borderWidth: 1.5,
  },
  label: {
    fontSize: fontSize.md,
    fontFamily: fontFamily.semiBold,
    letterSpacing: 0.3,
  },
});
