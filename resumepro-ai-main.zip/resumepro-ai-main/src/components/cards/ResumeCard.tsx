import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ViewStyle,
} from 'react-native';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { radius, shadow, spacing } from '../../theme/spacing';
import { ResumeData } from '../../types';

interface Props {
  resume: ResumeData;
  onPress: () => void;
  onMenu?: () => void;
  style?: ViewStyle;
}

export const ResumeCard: React.FC<Props> = ({ resume, onPress, onMenu, style }) => {
  const { colors } = useThemeStore();

  const updatedDate = new Date(resume.updatedAt).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

  const experienceCount = resume.workExperience.length;
  const completionItems = [
    resume.personalInfo.fullName,
    resume.personalInfo.email,
    resume.workExperience.length > 0,
    resume.education.length > 0,
    resume.skills.length > 0,
  ];
  const completion = Math.round((completionItems.filter(Boolean).length / completionItems.length) * 100);

  return (
    <TouchableOpacity
      onPress={onPress}
      style={[styles.card, { backgroundColor: colors.surface }, shadow.md, style]}
      accessibilityRole="button"
      accessibilityLabel={resume.title}>
      <View style={styles.header}>
        <View
          style={[styles.iconContainer, { backgroundColor: colors.primary + '15' }]}>
          <Text style={styles.icon}>📄</Text>
        </View>
        <View style={styles.info}>
          <Text style={[styles.title, { color: colors.text }]} numberOfLines={1}>
            {resume.title}
          </Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
            {resume.personalInfo.jobTitle || 'No title set'}
          </Text>
        </View>
        {onMenu ? (
          <TouchableOpacity onPress={onMenu} style={styles.menuBtn} accessibilityLabel="Resume options">
            <Text style={{ color: colors.textSecondary, fontSize: 20 }}>⋮</Text>
          </TouchableOpacity>
        ) : null}
      </View>

      <View style={styles.footer}>
        <View style={styles.meta}>
          <Text style={[styles.metaText, { color: colors.textMuted }]}>
            {experienceCount} exp • Updated {updatedDate}
          </Text>
        </View>
        <View style={styles.progressWrapper}>
          <View style={[styles.progressBar, { backgroundColor: colors.border }]}>
            <View
              style={[
                styles.progressFill,
                { width: `${completion}%` as any, backgroundColor: colors.primary },
              ]}
            />
          </View>
          <Text style={[styles.progressText, { color: colors.primary }]}>{completion}%</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.md,
  },
  icon: { fontSize: 22 },
  info: { flex: 1 },
  title: {
    fontSize: fontSize.md,
    fontFamily: fontFamily.semiBold,
    marginBottom: 2,
  },
  subtitle: {
    fontSize: fontSize.sm,
    fontFamily: fontFamily.regular,
  },
  menuBtn: {
    padding: spacing.xs,
  },
  footer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  meta: { flex: 1 },
  metaText: {
    fontSize: fontSize.xs,
    fontFamily: fontFamily.regular,
  },
  progressWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
  },
  progressBar: {
    width: 80,
    height: 4,
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  progressText: {
    fontSize: fontSize.xs,
    fontFamily: fontFamily.semiBold,
  },
});
