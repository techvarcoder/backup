import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ViewStyle } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { fontFamily, fontSize } from '../../theme/typography';
import { isProLocked } from '../../constants';
import { radius, shadow, spacing } from '../../theme/spacing';

interface Props {
  title: string;
  description: string;
  icon: string;
  gradient: string[];
  onPress: () => void;
  isPremium?: boolean;
  style?: ViewStyle;
}

export const AIFeatureCard: React.FC<Props> = ({
  title,
  description,
  icon,
  gradient,
  onPress,
  isPremium = false,
  style,
}) => {
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[styles.wrapper, shadow.md, style]}
      accessibilityRole="button"
      accessibilityLabel={title}>
      <LinearGradient colors={gradient} style={styles.card} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}>
        <View style={styles.iconWrapper}>
          <Text style={styles.icon}>{icon}</Text>
        </View>
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.description} numberOfLines={2}>{description}</Text>
        {isProLocked(isPremium) ? (
          <View style={styles.premiumBadge}>
            <Text style={styles.premiumText}>PRO</Text>
          </View>
        ) : null}
      </LinearGradient>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    borderRadius: radius.lg,
    overflow: 'hidden',
    marginRight: spacing.md,
    width: 160,
  },
  card: {
    padding: spacing.lg,
    minHeight: 160,
    justifyContent: 'space-between',
  },
  iconWrapper: {
    width: 44,
    height: 44,
    backgroundColor: 'rgba(255,255,255,0.25)',
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.md,
  },
  icon: { fontSize: 22 },
  title: {
    fontSize: fontSize.base,
    fontFamily: fontFamily.semiBold,
    color: '#FFFFFF',
    marginBottom: spacing.xs,
  },
  description: {
    fontSize: fontSize.xs,
    fontFamily: fontFamily.regular,
    color: 'rgba(255,255,255,0.8)',
    lineHeight: 16,
  },
  premiumBadge: {
    position: 'absolute',
    top: spacing.md,
    right: spacing.md,
    backgroundColor: '#F59E0B',
    borderRadius: radius.full,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  premiumText: {
    fontSize: 9,
    fontFamily: 'Poppins-Bold',
    color: '#FFF',
  },
});
