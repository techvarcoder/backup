import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ViewStyle,
} from 'react-native';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { radius, shadow, spacing } from '../../theme/spacing';
import { ResumeTemplate } from '../../types';
import { isProLocked } from '../../constants';

interface Props {
  template: ResumeTemplate;
  selected?: boolean;
  onPress: () => void;
  style?: ViewStyle;
}

// ─── Per-template miniature layout previews ──────────────────────────────────

function PreviewProfessional({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff' }]}>
      {/* Full-width colored header */}
      <View style={[p.header, { backgroundColor: accent }]}>
        <View style={[p.nameLine, { backgroundColor: 'rgba(255,255,255,0.9)', width: '60%' }]} />
        <View style={[p.subLine, { backgroundColor: 'rgba(255,255,255,0.6)', width: '40%' }]} />
      </View>
      {/* Body with left accent bars */}
      <View style={p.body}>
        <View style={p.sectionRow}>
          <View style={[p.sectionBar, { backgroundColor: accent }]} />
          <View style={[p.sectionTitle, { backgroundColor: accent + '60' }]} />
        </View>
        <View style={[p.line, { width: '85%' }]} />
        <View style={[p.line, { width: '70%' }]} />
        <View style={p.sectionRow}>
          <View style={[p.sectionBar, { backgroundColor: accent }]} />
          <View style={[p.sectionTitle, { backgroundColor: accent + '60' }]} />
        </View>
        <View style={[p.line, { width: '90%' }]} />
        <View style={[p.line, { width: '65%' }]} />
        <View style={[p.line, { width: '75%' }]} />
        <View style={p.skillRow}>
          {[40, 50, 35, 45].map((w, i) => (
            <View key={i} style={[p.skillPill, { width: w, borderColor: accent }]} />
          ))}
        </View>
      </View>
    </View>
  );
}

function PreviewModern({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { flexDirection: 'row', backgroundColor: '#fff' }]}>
      {/* Colored left sidebar */}
      <View style={[p.sidebar, { backgroundColor: accent }]}>
        <View style={[p.avatarCircle, { backgroundColor: 'rgba(255,255,255,0.3)' }]} />
        <View style={[p.sideNameLine, { backgroundColor: 'rgba(255,255,255,0.85)' }]} />
        <View style={[p.sideLine, { backgroundColor: 'rgba(255,255,255,0.5)', width: '70%' }]} />
        <View style={[p.sideDivider, { backgroundColor: 'rgba(255,255,255,0.3)' }]} />
        {[55, 70, 50, 65, 45].map((w, i) => (
          <View key={i} style={[p.sideSkill, { width: `${w}%` as any, backgroundColor: 'rgba(255,255,255,0.2)' }]} />
        ))}
      </View>
      {/* White main area */}
      <View style={p.mainArea}>
        <View style={[p.mainSectionTitle, { borderBottomColor: accent, borderBottomWidth: 1.5 }]}>
          <View style={[p.line, { width: '50%', backgroundColor: accent }]} />
        </View>
        <View style={[p.line, { width: '90%' }]} />
        <View style={[p.line, { width: '70%' }]} />
        <View style={[p.mainSectionTitle, { borderBottomColor: accent, borderBottomWidth: 1.5 }]}>
          <View style={[p.line, { width: '50%', backgroundColor: accent }]} />
        </View>
        <View style={[p.line, { width: '85%' }]} />
        <View style={[p.line, { width: '65%' }]} />
        <View style={[p.line, { width: '75%' }]} />
      </View>
    </View>
  );
}

function PreviewMinimal({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 8 }]}>
      {/* Centered header */}
      <View style={p.centerHeader}>
        <View style={[p.nameLine, { backgroundColor: '#111', width: '55%', alignSelf: 'center' }]} />
        <View style={[p.subLine, { backgroundColor: '#9CA3AF', width: '40%', alignSelf: 'center' }]} />
        <View style={[p.subLine, { backgroundColor: '#D1D5DB', width: '70%', alignSelf: 'center' }]} />
        <View style={[p.divider, { backgroundColor: '#E5E7EB' }]} />
      </View>
      {/* Timeline rows */}
      {[1, 2, 3].map(i => (
        <View key={i} style={p.timelineRow}>
          <View style={p.timelineDate}>
            <View style={[p.subLine, { width: '90%', backgroundColor: '#D1D5DB' }]} />
          </View>
          <View style={[p.timelineLine, { borderLeftColor: '#E5E7EB' }]}>
            <View style={[p.line, { width: '80%' }]} />
            <View style={[p.subLine, { width: '55%', backgroundColor: '#9CA3AF' }]} />
          </View>
        </View>
      ))}
    </View>
  );
}

function PreviewCreative({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { flexDirection: 'row', backgroundColor: '#FAFAFA' }]}>
      {/* Bold colored sidebar with initials */}
      <View style={[p.sidebarWide, { backgroundColor: accent }]}>
        <View style={[p.initialsCircle, { backgroundColor: 'rgba(255,255,255,0.25)', borderRadius: 20 }]}>
          <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: 'rgba(255,255,255,0.7)' }} />
        </View>
        <View style={[p.sideNameLine, { backgroundColor: 'rgba(255,255,255,0.9)' }]} />
        <View style={[p.sideLine, { backgroundColor: 'rgba(255,255,255,0.55)', width: '65%' }]} />
        <View style={[p.sideDivider, { backgroundColor: 'rgba(255,255,255,0.25)' }]} />
        {[60, 75, 50, 65].map((w, i) => (
          <View key={i} style={[p.sideSkill, { width: `${w}%` as any, backgroundColor: 'rgba(255,255,255,0.18)', borderRadius: 3 }]} />
        ))}
      </View>
      {/* Light gray main area */}
      <View style={p.mainArea}>
        {[1, 2].map(sec => (
          <View key={sec} style={{ marginBottom: 6 }}>
            <View style={p.creativeSecHead}>
              <View style={[p.creativeIcon, { backgroundColor: accent }]} />
              <View style={[p.subLine, { width: '45%', backgroundColor: '#374151' }]} />
            </View>
            <View style={[p.entryBar, { borderLeftColor: accent + '40' }]}>
              <View style={[p.line, { width: '85%' }]} />
              <View style={[p.subLine, { width: '55%', backgroundColor: accent }]} />
              <View style={[p.line, { width: '70%' }]} />
            </View>
          </View>
        ))}
      </View>
    </View>
  );
}

function PreviewATS({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 8 }]}>
      {/* Plain centered header */}
      <View style={p.centerHeader}>
        <View style={[p.nameLine, { backgroundColor: '#000', width: '50%', alignSelf: 'center' }]} />
        <View style={[p.subLine, { backgroundColor: '#333', width: '35%', alignSelf: 'center' }]} />
        <View style={[p.subLine, { backgroundColor: '#666', width: '65%', alignSelf: 'center' }]} />
      </View>
      {/* Plain black underline sections */}
      {[1, 2, 3].map(i => (
        <View key={i} style={{ marginBottom: 5 }}>
          <View style={[p.atsSection, { borderBottomColor: '#000' }]}>
            <View style={[p.line, { width: '40%', backgroundColor: '#000', height: 5 }]} />
          </View>
          <View style={[p.line, { width: '90%' }]} />
          <View style={[p.line, { width: '70%' }]} />
        </View>
      ))}
    </View>
  );
}

function PreviewExecutive({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 8 }]}>
      {/* Double accent lines + centered name */}
      <View style={[p.accentLine, { backgroundColor: accent }]} />
      <View style={p.centerHeader}>
        <View style={[p.nameLine, { backgroundColor: '#111', width: '55%', alignSelf: 'center' }]} />
        <View style={[p.subLine, { backgroundColor: '#6B7280', width: '40%', alignSelf: 'center' }]} />
        <View style={[p.subLine, { backgroundColor: '#9CA3AF', width: '60%', alignSelf: 'center' }]} />
      </View>
      <View style={[p.accentLine, { backgroundColor: accent }]} />
      {/* Centered section titles */}
      {[1, 2].map(i => (
        <View key={i} style={{ marginBottom: 6 }}>
          <View style={p.execSectionHead}>
            <View style={[p.subLine, { width: '35%', backgroundColor: accent, alignSelf: 'center' }]} />
          </View>
          <View style={[p.line, { width: '90%' }]} />
          <View style={[p.line, { width: '65%' }]} />
        </View>
      ))}
    </View>
  );
}

function PreviewTechPro({ accent }: { accent: string }) {
  const dark = '#0F172A';
  return (
    <View style={[p.wrap, { backgroundColor: dark }]}>
      {/* Dark gradient header with accent border */}
      <View style={[p.techHeader, { backgroundColor: '#1E293B', borderBottomColor: accent, borderBottomWidth: 2 }]}>
        <View style={[p.nameLine, { backgroundColor: '#F8FAFC', width: '55%' }]} />
        <View style={[p.subLine, { backgroundColor: accent, width: '45%' }]} />
        <View style={[p.subLine, { backgroundColor: '#475569', width: '70%' }]} />
      </View>
      <View style={{ padding: 6 }}>
        {[1, 2].map(sec => (
          <View key={sec} style={{ marginBottom: 6 }}>
            <View style={p.techSectionHead}>
              <View style={[p.subLine, { width: 10, backgroundColor: accent }]} />
              <View style={[p.subLine, { width: '35%', backgroundColor: '#CBD5E1' }]} />
              <View style={[p.techDivider, { backgroundColor: accent + '50' }]} />
            </View>
            <View style={[p.line, { width: '90%', backgroundColor: '#334155' }]} />
            <View style={[p.line, { width: '65%', backgroundColor: '#334155' }]} />
          </View>
        ))}
        {/* Tech skill pills */}
        <View style={p.skillRow}>
          {[30, 42, 28, 36].map((w, i) => (
            <View key={i} style={[p.techPill, { width: w, borderColor: accent + '70', backgroundColor: accent + '20' }]} />
          ))}
        </View>
      </View>
    </View>
  );
}

function PreviewCleanSlate({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 8 }]}>
      {/* Ultra-minimal header with gradient accent line */}
      <View style={{ marginBottom: 6 }}>
        <View style={[p.nameLine, { backgroundColor: '#111', width: '60%', height: 7 }]} />
        <View style={[p.subLine, { backgroundColor: accent, width: '40%' }]} />
        <View style={[p.subLine, { backgroundColor: '#9CA3AF', width: '70%' }]} />
        <View style={[p.gradientLine, { backgroundColor: accent }]} />
      </View>
      {/* Dot + line sections */}
      {[1, 2, 3].map(i => (
        <View key={i} style={{ marginBottom: 5 }}>
          <View style={p.cleanSectionHead}>
            <View style={[p.dot, { backgroundColor: accent }]} />
            <View style={[p.subLine, { width: '40%', backgroundColor: '#374151' }]} />
            <View style={[p.cleanDivider, { backgroundColor: '#E5E7EB' }]} />
          </View>
          <View style={p.cleanEntry}>
            <View style={[p.cleanDate, { backgroundColor: '#E5E7EB' }]} />
            <View style={{ flex: 1 }}>
              <View style={[p.line, { width: '85%' }]} />
              <View style={[p.subLine, { width: '55%', backgroundColor: '#9CA3AF' }]} />
            </View>
          </View>
        </View>
      ))}
    </View>
  );
}

// ─── 12 new previews ──────────────────────────────────────────────────────────

function PreviewBoldImpact({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff' }]}>
      {/* Giant name block at top with thick accent underline */}
      <View style={{ padding: 7, paddingBottom: 4, borderBottomWidth: 3, borderBottomColor: accent }}>
        <View style={[p.nameLine, { backgroundColor: '#111', width: '75%', height: 9 }]} />
        <View style={[p.subLine, { backgroundColor: accent, width: '50%' }]} />
        <View style={[p.subLine, { backgroundColor: '#9CA3AF', width: '65%' }]} />
      </View>
      <View style={{ padding: 7, gap: 4 }}>
        {[1, 2].map(i => (
          <View key={i} style={{ marginBottom: 4 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
              <View style={{ flex: 1, height: 1, backgroundColor: accent }} />
              <View style={[p.subLine, { width: '35%', backgroundColor: accent + '80' }]} />
              <View style={{ flex: 1, height: 1, backgroundColor: accent }} />
            </View>
            <View style={[p.line, { width: '85%' }]} />
            <View style={[p.line, { width: '65%' }]} />
          </View>
        ))}
        <View style={p.skillRow}>
          {[35, 45, 30].map((w, i) => (
            <View key={i} style={[p.skillPill, { width: w, borderColor: 'transparent', backgroundColor: accent }]} />
          ))}
        </View>
      </View>
    </View>
  );
}

function PreviewGradient({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#F8FAFC' }]}>
      {/* Gradient header simulation using opacity layers */}
      <View style={{ height: 44, backgroundColor: accent, padding: 7, justifyContent: 'flex-end', gap: 3 }}>
        <View style={{ position: 'absolute', top: 0, right: 0, bottom: 0, width: '40%', backgroundColor: '#6D28D9', opacity: 0.6 }} />
        <View style={[p.nameLine, { backgroundColor: 'rgba(255,255,255,0.95)', width: '60%' }]} />
        <View style={[p.subLine, { backgroundColor: 'rgba(255,255,255,0.7)', width: '40%' }]} />
      </View>
      {/* White rounded cards */}
      <View style={{ padding: 6, gap: 5 }}>
        {[1, 2].map(i => (
          <View key={i} style={{ backgroundColor: '#fff', borderRadius: 5, padding: 5, borderLeftWidth: 3, borderLeftColor: accent }}>
            <View style={[p.line, { width: '80%', backgroundColor: '#374151' }]} />
            <View style={[p.subLine, { width: '55%', backgroundColor: accent }]} />
            <View style={[p.line, { width: '70%' }]} />
          </View>
        ))}
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 3 }}>
          {[35, 45, 30, 40].map((w, i) => (
            <View key={i} style={[{ width: w, height: 10, borderRadius: 10, borderWidth: 1, borderColor: accent, backgroundColor: accent + '18' }]} />
          ))}
        </View>
      </View>
    </View>
  );
}

function PreviewSideAccent({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 7 }]}>
      {/* Header row with thick left bar */}
      <View style={{ flexDirection: 'row', gap: 0, marginBottom: 8, paddingBottom: 6, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' }}>
        <View style={{ width: 4, backgroundColor: accent, borderRadius: 2, marginRight: 6 }} />
        <View style={{ flex: 1 }}>
          <View style={[p.nameLine, { backgroundColor: '#111', width: '65%' }]} />
          <View style={[p.subLine, { backgroundColor: accent, width: '45%' }]} />
          <View style={[p.subLine, { backgroundColor: '#D1D5DB', width: '70%' }]} />
        </View>
      </View>
      {/* Sections with vertical bar */}
      {[1, 2].map(i => (
        <View key={i} style={{ flexDirection: 'row', gap: 0, marginBottom: 5 }}>
          <View style={{ width: 3, backgroundColor: accent, borderRadius: 2, marginRight: 6 }} />
          <View style={{ flex: 1 }}>
            <View style={[p.subLine, { width: '40%', backgroundColor: accent }]} />
            <View style={[p.line, { width: '85%' }]} />
            <View style={[p.line, { width: '65%' }]} />
          </View>
        </View>
      ))}
    </View>
  );
}

function PreviewAcademic({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 8 }]}>
      {/* Centered formal serif-style header */}
      <View style={{ alignItems: 'center', marginBottom: 4, paddingBottom: 5, borderBottomWidth: 2, borderBottomColor: accent, borderStyle: 'dashed' as any }}>
        <View style={[p.nameLine, { backgroundColor: accent, width: '55%' }]} />
        <View style={[p.subLine, { backgroundColor: '#6B7280', width: '40%' }]} />
        <View style={[p.subLine, { backgroundColor: '#9CA3AF', width: '65%' }]} />
      </View>
      {/* Underlined section headers */}
      {[1, 2, 3].map(i => (
        <View key={i} style={{ marginBottom: 5 }}>
          <View style={{ borderBottomWidth: 1.5, borderBottomColor: accent, paddingBottom: 2, marginBottom: 3 }}>
            <View style={[p.subLine, { width: '35%', backgroundColor: accent }]} />
          </View>
          <View style={[p.line, { width: '85%' }]} />
          <View style={[p.line, { width: '65%' }]} />
        </View>
      ))}
    </View>
  );
}

function PreviewCompact({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 5 }]}>
      {/* Two-column header row */}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 5, paddingBottom: 4, borderBottomWidth: 2, borderBottomColor: accent }}>
        <View>
          <View style={[p.nameLine, { backgroundColor: '#111', width: 60 }]} />
          <View style={[p.subLine, { backgroundColor: accent, width: 45 }]} />
        </View>
        <View style={{ alignItems: 'flex-end', gap: 2 }}>
          <View style={[p.subLine, { backgroundColor: '#D1D5DB', width: 50 }]} />
          <View style={[p.subLine, { backgroundColor: '#D1D5DB', width: 40 }]} />
        </View>
      </View>
      {/* Dense rows */}
      {[1, 2, 3, 4].map(i => (
        <View key={i} style={{ marginBottom: 3 }}>
          <View style={[p.subLine, { width: '30%', backgroundColor: accent + '90', height: 5 }]} />
          <View style={[p.line, { width: '90%', height: 3 }]} />
          <View style={[p.line, { width: '70%', height: 3 }]} />
        </View>
      ))}
    </View>
  );
}

function PreviewMagazine({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff' }]}>
      {/* Dark full-width header with right accent bar */}
      <View style={{ backgroundColor: '#111827', height: 48, padding: 7, justifyContent: 'flex-end', position: 'relative' }}>
        <View style={{ position: 'absolute', top: 0, right: 0, bottom: 0, width: 5, backgroundColor: accent }} />
        <View style={[p.nameLine, { backgroundColor: '#fff', width: '70%', height: 9 }]} />
        <View style={[p.subLine, { backgroundColor: accent, width: '45%' }]} />
      </View>
      {/* Editorial sections with large side-bar headers */}
      <View style={{ padding: 6, gap: 5 }}>
        {[1, 2].map(i => (
          <View key={i}>
            <View style={{ borderLeftWidth: 4, borderLeftColor: accent, paddingLeft: 5, marginBottom: 3 }}>
              <View style={[p.subLine, { width: '40%', backgroundColor: '#111827', height: 6 }]} />
            </View>
            <View style={[p.line, { width: '90%' }]} />
            <View style={[p.line, { width: '70%' }]} />
          </View>
        ))}
        <View style={p.skillRow}>
          {[35, 28, 40, 32].map((w, i) => (
            <View key={i} style={[{ width: w, height: 10, borderRadius: 2, backgroundColor: '#111827' }]} />
          ))}
        </View>
      </View>
    </View>
  );
}

function PreviewTimeline({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff' }]}>
      {/* Colored center header */}
      <View style={{ backgroundColor: accent, height: 36, padding: 6, alignItems: 'center', justifyContent: 'center', gap: 3 }}>
        <View style={[p.nameLine, { backgroundColor: 'rgba(255,255,255,0.9)', width: '55%', alignSelf: 'center' }]} />
        <View style={[p.subLine, { backgroundColor: 'rgba(255,255,255,0.65)', width: '38%', alignSelf: 'center' }]} />
      </View>
      {/* Alternating timeline entries with center dot */}
      <View style={{ padding: 6, gap: 0 }}>
        {[1, 2, 3].map(i => (
          <View key={i} style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 0, marginBottom: 5 }}>
            <View style={{ flex: 1, alignItems: i % 2 === 1 ? 'flex-end' : 'flex-start', paddingRight: i % 2 === 1 ? 6 : 0, paddingLeft: i % 2 === 0 ? 6 : 0 }}>
              <View style={[p.line, { width: '75%' }]} />
              <View style={[p.subLine, { width: '55%', backgroundColor: accent + '70' }]} />
            </View>
            <View style={{ width: 10, alignItems: 'center', gap: 2 }}>
              <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: accent }} />
              <View style={{ width: 1.5, height: 10, backgroundColor: accent + '40' }} />
            </View>
            <View style={{ flex: 1 }} />
          </View>
        ))}
      </View>
    </View>
  );
}

function PreviewFinance({ accent }: { accent: string }) {
  const navy = '#1E2B4A';
  return (
    <View style={[p.wrap, { backgroundColor: '#FAFAF7' }]}>
      {/* Navy header with gold accent bottom border */}
      <View style={{ backgroundColor: navy, padding: 7, paddingBottom: 6, borderBottomWidth: 3, borderBottomColor: accent }}>
        <View style={[p.nameLine, { backgroundColor: '#fff', width: '60%' }]} />
        <View style={[p.subLine, { backgroundColor: accent, width: '45%' }]} />
        <View style={[p.subLine, { backgroundColor: '#475569', width: '70%' }]} />
      </View>
      {/* Navy banner section labels */}
      <View style={{ padding: 6, gap: 5 }}>
        {[1, 2].map(i => (
          <View key={i}>
            <View style={{ backgroundColor: navy, height: 8, borderRadius: 1, width: '50%', marginBottom: 4 }}>
              <View style={{ height: '100%', width: '30%', backgroundColor: accent, borderRadius: 1 }} />
            </View>
            <View style={[p.line, { width: '85%' }]} />
            <View style={[p.line, { width: '65%' }]} />
          </View>
        ))}
        <View style={p.skillRow}>
          {[35, 45, 38].map((w, i) => (
            <View key={i} style={[{ width: w, height: 9, borderWidth: 1, borderColor: accent, borderRadius: 1 }]} />
          ))}
        </View>
      </View>
    </View>
  );
}

function PreviewStartup({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 7 }]}>
      {/* Name + pill tag */}
      <View style={{ marginBottom: 7 }}>
        <View style={[p.nameLine, { backgroundColor: '#111', width: '60%' }]} />
        <View style={{ flexDirection: 'row', marginTop: 3, gap: 3 }}>
          <View style={{ height: 11, width: 55, borderRadius: 10, backgroundColor: accent }} />
        </View>
        <View style={{ flexDirection: 'row', gap: 4, marginTop: 5 }}>
          {[40, 35, 28].map((w, i) => (
            <View key={i} style={{ height: 10, width: w, borderRadius: 10, backgroundColor: '#F3F4F6' }} />
          ))}
        </View>
      </View>
      {/* Card-style sections */}
      {[1, 2].map(i => (
        <View key={i} style={{ backgroundColor: '#F9FAFB', borderRadius: 6, padding: 5, marginBottom: 5, borderWidth: 1, borderColor: '#F3F4F6' }}>
          <View style={[p.line, { width: '75%', backgroundColor: '#374151' }]} />
          <View style={[p.subLine, { width: '50%', backgroundColor: accent }]} />
          <View style={[p.line, { width: '85%' }]} />
        </View>
      ))}
      <View style={p.skillRow}>
        {[32, 42, 28, 36].map((w, i) => (
          <View key={i} style={[{ width: w, height: 10, borderRadius: 10, backgroundColor: accent + '18', borderWidth: 1.5, borderColor: accent + '40' }]} />
        ))}
      </View>
    </View>
  );
}

function PreviewHealthcare({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff' }]}>
      {/* Teal header */}
      <View style={{ backgroundColor: accent, padding: 7, paddingBottom: 5 }}>
        <View style={[p.nameLine, { backgroundColor: 'rgba(255,255,255,0.95)', width: '60%' }]} />
        <View style={[p.subLine, { backgroundColor: 'rgba(255,255,255,0.7)', width: '42%' }]} />
      </View>
      {/* Light teal contact strip */}
      <View style={{ backgroundColor: accent + '25', padding: 5, marginBottom: 5 }}>
        <View style={[p.subLine, { width: '80%', backgroundColor: accent + '60' }]} />
      </View>
      {/* Left-bar sections */}
      <View style={{ padding: 6, gap: 5 }}>
        {[1, 2].map(i => (
          <View key={i}>
            <View style={{ backgroundColor: accent + '18', borderLeftWidth: 3, borderLeftColor: accent, padding: 3, marginBottom: 3 }}>
              <View style={[p.subLine, { width: '40%', backgroundColor: accent + '80' }]} />
            </View>
            <View style={[p.line, { width: '85%' }]} />
            <View style={[p.line, { width: '65%' }]} />
          </View>
        ))}
      </View>
    </View>
  );
}

function PreviewEuroCV({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff' }]}>
      {/* Colored header with avatar box */}
      <View style={{ backgroundColor: accent, padding: 7, flexDirection: 'row', gap: 6, alignItems: 'center' }}>
        <View style={{ width: 28, height: 34, backgroundColor: 'rgba(255,255,255,0.3)', borderRadius: 3 }} />
        <View>
          <View style={[p.nameLine, { backgroundColor: 'rgba(255,255,255,0.95)', width: 60 }]} />
          <View style={[p.subLine, { backgroundColor: 'rgba(255,255,255,0.65)', width: 45 }]} />
        </View>
      </View>
      {/* Table-style rows */}
      <View style={{ padding: 6, gap: 4 }}>
        {['Personal Info', 'Experience', 'Education'].map((s, i) => (
          <View key={i}>
            <View style={{ backgroundColor: accent, height: 7, borderRadius: 1, width: '45%', marginBottom: 3 }} />
            {i > 0 ? (
              <View style={{ flexDirection: 'row', gap: 5 }}>
                <View style={{ width: 32 }}>
                  <View style={[p.subLine, { backgroundColor: '#9CA3AF', width: '90%' }]} />
                </View>
                <View style={{ flex: 1 }}>
                  <View style={[p.line, { width: '90%' }]} />
                  <View style={[p.subLine, { width: '65%', backgroundColor: '#6B7280' }]} />
                </View>
              </View>
            ) : (
              <View style={{ flexDirection: 'row', gap: 5 }}>
                <View style={{ width: 30 }}>
                  <View style={[p.subLine, { backgroundColor: accent, width: '90%' }]} />
                  <View style={[p.subLine, { backgroundColor: accent, width: '80%' }]} />
                </View>
                <View style={{ flex: 1 }}>
                  <View style={[p.line, { width: '75%' }]} />
                  <View style={[p.line, { width: '65%' }]} />
                </View>
              </View>
            )}
          </View>
        ))}
      </View>
    </View>
  );
}

function PreviewInfographic({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { flexDirection: 'row', backgroundColor: '#fff' }]}>
      {/* Sidebar with skill bars */}
      <View style={{ width: 50, backgroundColor: accent + '12', padding: 5, borderRightWidth: 1.5, borderRightColor: accent + '30', gap: 3 }}>
        <View style={[p.nameLine, { backgroundColor: '#111', width: '90%', height: 5 }]} />
        <View style={[p.subLine, { backgroundColor: accent, width: '75%' }]} />
        <View style={{ height: 1, backgroundColor: accent + '40', marginVertical: 3 }} />
        <View style={[p.subLine, { backgroundColor: accent, width: '80%', height: 3 }]} />
        {[70, 85, 55, 90, 65].map((pct, i) => (
          <View key={i} style={{ height: 5, borderRadius: 2, backgroundColor: '#E5E7EB', overflow: 'hidden', marginTop: 1 }}>
            <View style={{ width: `${pct}%`, height: '100%', backgroundColor: accent }} />
          </View>
        ))}
      </View>
      {/* Main content */}
      <View style={p.mainArea}>
        {[1, 2].map(i => (
          <View key={i} style={{ marginBottom: 5 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 3 }}>
              <View style={{ width: 2, height: 12, backgroundColor: accent, borderRadius: 1 }} />
              <View style={[p.subLine, { width: '45%', backgroundColor: '#374151', height: 4 }]} />
            </View>
            <View style={[p.line, { width: '85%' }]} />
            <View style={[p.line, { width: '65%' }]} />
          </View>
        ))}
      </View>
    </View>
  );
}

// ─── 20 new previews (templates 21-40) ────────────────────────────────────────

function PreviewTwoColumn({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 7 }]}>
      <View style={{ marginBottom: 6, paddingBottom: 5, borderBottomWidth: 1, borderBottomColor: '#E5E7EB' }}>
        <View style={[p.nameLine, { backgroundColor: '#111', width: '60%' }]} />
        <View style={[p.subLine, { backgroundColor: accent, width: '40%' }]} />
      </View>
      <View style={{ flexDirection: 'row', flex: 1, gap: 0 }}>
        <View style={{ flex: 1.6 }}>
          <View style={[p.line, { width: '85%' }]} />
          <View style={[p.line, { width: '70%' }]} />
          <View style={[p.subLine, { width: '40%', backgroundColor: accent, marginTop: 5 }]} />
          <View style={[p.line, { width: '80%' }]} />
        </View>
        <View style={{ width: 1, backgroundColor: '#E5E7EB', marginHorizontal: 6 }} />
        <View style={{ flex: 1 }}>
          <View style={[p.subLine, { width: '70%', backgroundColor: accent }]} />
          <View style={[p.line, { width: '60%' }]} />
          <View style={[p.subLine, { width: '80%', backgroundColor: accent, marginTop: 5 }]} />
          <View style={[p.line, { width: '55%' }]} />
        </View>
      </View>
    </View>
  );
}

function PreviewNewspaper({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 8 }]}>
      <View style={{ borderTopWidth: 2, borderTopColor: '#111', paddingTop: 3, alignItems: 'center' }}>
        <View style={[p.nameLine, { backgroundColor: '#111', width: '70%' }]} />
      </View>
      <View style={{ borderBottomWidth: 2, borderBottomColor: '#111', paddingBottom: 4, marginBottom: 5, alignItems: 'center' }}>
        <View style={[p.subLine, { backgroundColor: accent, width: '45%' }]} />
      </View>
      <View style={{ flexDirection: 'row', gap: 6 }}>
        <View style={{ flex: 1 }}>
          <View style={[p.line, { width: '90%' }]} />
          <View style={[p.line, { width: '80%' }]} />
          <View style={[p.line, { width: '85%' }]} />
        </View>
        <View style={{ flex: 1 }}>
          <View style={[p.line, { width: '85%' }]} />
          <View style={[p.line, { width: '75%' }]} />
          <View style={[p.line, { width: '80%' }]} />
        </View>
      </View>
    </View>
  );
}

function PreviewDashboard({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 7 }]}>
      <View style={[p.nameLine, { backgroundColor: '#111', width: '60%' }]} />
      <View style={[p.subLine, { backgroundColor: accent, width: '40%', marginBottom: 5 }]} />
      <View style={{ flexDirection: 'row', gap: 3, marginBottom: 6 }}>
        {[1, 2, 3, 4].map(i => (
          <View key={i} style={{ flex: 1, height: 22, borderRadius: 4, backgroundColor: '#F9FAFB', alignItems: 'center', justifyContent: 'center', gap: 2 }}>
            <View style={{ width: 8, height: 5, borderRadius: 1, backgroundColor: accent }} />
            <View style={{ width: 12, height: 2, borderRadius: 1, backgroundColor: '#D1D5DB' }} />
          </View>
        ))}
      </View>
      <View style={[p.subLine, { width: '35%', backgroundColor: accent, height: 4 }]} />
      <View style={[p.line, { width: '90%' }]} />
      <View style={[p.line, { width: '70%' }]} />
    </View>
  );
}

function PreviewBoxedFrame({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 5 }]}>
      <View style={{ flex: 1, borderWidth: 2, borderColor: accent, padding: 8, alignItems: 'center' }}>
        <View style={[p.nameLine, { backgroundColor: '#111', width: '55%' }]} />
        <View style={[p.subLine, { backgroundColor: accent, width: '35%' }]} />
        <View style={[p.divider, { backgroundColor: '#E5E7EB', width: '80%', marginTop: 6 }]} />
        <View style={[p.line, { width: '70%' }]} />
        <View style={[p.line, { width: '55%' }]} />
      </View>
    </View>
  );
}

function PreviewTypewriter({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#FBF3E0', padding: 7 }]}>
      <View style={{ alignItems: 'center', marginBottom: 6 }}>
        <View style={[p.nameLine, { backgroundColor: '#292524', width: '55%' }]} />
        <View style={[p.subLine, { backgroundColor: accent, width: '35%' }]} />
      </View>
      {[1, 2].map(i => (
        <View key={i} style={{ borderWidth: 1, borderColor: '#A8A29E', borderStyle: 'dashed', padding: 4, marginBottom: 4 }}>
          <View style={[p.subLine, { width: '40%', backgroundColor: accent }]} />
          <View style={[p.line, { width: '80%' }]} />
        </View>
      ))}
    </View>
  );
}

function PreviewSwissGrid({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 7 }]}>
      <View style={[p.nameLine, { backgroundColor: '#111', width: '75%', height: 8 }]} />
      <View style={{ width: 24, height: 3, backgroundColor: accent, marginTop: 3, marginBottom: 6 }} />
      {[1, 2].map(i => (
        <View key={i} style={{ flexDirection: 'row', gap: 5, marginBottom: 5, borderTopWidth: 1, borderTopColor: '#111', paddingTop: 3 }}>
          <View style={{ width: 14, height: 14, alignItems: 'center', justifyContent: 'center' }}>
            <View style={{ width: 10, height: 10, borderRadius: 1, backgroundColor: accent }} />
          </View>
          <View style={{ flex: 1 }}>
            <View style={[p.line, { width: '85%' }]} />
            <View style={[p.line, { width: '60%' }]} />
          </View>
        </View>
      ))}
    </View>
  );
}

function PreviewKanban({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 7 }]}>
      <View style={[p.nameLine, { backgroundColor: '#111', width: '60%' }]} />
      <View style={[p.subLine, { backgroundColor: accent, width: '40%', marginBottom: 6 }]} />
      <View style={{ flexDirection: 'row', gap: 4 }}>
        {[1, 2, 3].map(col => (
          <View key={col} style={{ flex: 1, backgroundColor: '#F3F4F6', borderRadius: 4, padding: 3, gap: 2 }}>
            {[1, 2].map(card => (
              <View key={card} style={{ backgroundColor: '#fff', borderRadius: 3, height: 10, borderWidth: 1, borderColor: accent + '30' }} />
            ))}
          </View>
        ))}
      </View>
    </View>
  );
}

function PreviewRibbon({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 7, alignItems: 'center', justifyContent: 'center' }]}>
      <View style={{ flexDirection: 'row', alignItems: 'stretch', marginBottom: 8 }}>
        <View style={{ width: 0, height: 0, borderTopWidth: 10, borderBottomWidth: 10, borderRightWidth: 7, borderTopColor: 'transparent', borderBottomColor: 'transparent', borderRightColor: accent }} />
        <View style={{ backgroundColor: accent, paddingHorizontal: 10, paddingVertical: 8 }}>
          <View style={[p.nameLine, { backgroundColor: '#fff', width: 46 }]} />
        </View>
        <View style={{ width: 0, height: 0, borderTopWidth: 10, borderBottomWidth: 10, borderLeftWidth: 7, borderTopColor: 'transparent', borderBottomColor: 'transparent', borderLeftColor: accent }} />
      </View>
      <View style={[p.subLine, { backgroundColor: accent, width: '35%' }]} />
      <View style={[p.line, { width: '55%', marginTop: 6 }]} />
    </View>
  );
}

function PreviewDiagonalSplit({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff' }]}>
      <View style={{ height: 44, backgroundColor: '#F3F4F6', overflow: 'hidden' }}>
        <View style={{ position: 'absolute', top: -20, left: -10, width: 90, height: 90, backgroundColor: '#111827', transform: [{ rotate: '-12deg' }] }} />
        <View style={{ position: 'absolute', left: 8, top: 10, gap: 3 }}>
          <View style={[p.nameLine, { backgroundColor: '#fff', width: 46 }]} />
          <View style={[p.subLine, { backgroundColor: accent, width: 34 }]} />
        </View>
      </View>
      <View style={{ padding: 7 }}>
        <View style={[p.line, { width: '85%' }]} />
        <View style={[p.line, { width: '65%' }]} />
        <View style={p.skillRow}>
          {[35, 45, 30].map((w, i) => (
            <View key={i} style={[p.skillPill, { width: w, borderColor: accent }]} />
          ))}
        </View>
      </View>
    </View>
  );
}

function PreviewLetterpress({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#FAF7F0', padding: 9 }]}>
      <View style={{ alignItems: 'center', marginBottom: 8 }}>
        <View style={[p.nameLine, { backgroundColor: '#3F3A34', width: '50%' }]} />
        <View style={[p.subLine, { backgroundColor: accent, width: '32%' }]} />
      </View>
      <View style={{ height: 1, backgroundColor: '#E7E2D8', width: '90%', alignSelf: 'center', marginBottom: 6 }} />
      <View style={[p.line, { width: '75%', alignSelf: 'center', backgroundColor: '#C9C2B4' }]} />
      <View style={[p.line, { width: '60%', alignSelf: 'center', backgroundColor: '#C9C2B4' }]} />
    </View>
  );
}

function PreviewBlueprint({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#F8FBFF', padding: 7 }]}>
      <View style={[p.nameLine, { backgroundColor: '#1E293B', width: '65%' }]} />
      <View style={[p.subLine, { backgroundColor: accent, width: '40%', marginBottom: 6 }]} />
      <View style={{ borderWidth: 1, borderColor: accent + '50', padding: 5, position: 'relative' }}>
        {[
          { top: -1, left: -1, bt: 2, bl: 2 },
          { top: -1, right: -1, bt: 2, br: 2 },
          { bottom: -1, left: -1, bb: 2, bl: 2 },
          { bottom: -1, right: -1, bb: 2, br: 2 },
        ].map((c, i) => (
          <View key={i} style={{ position: 'absolute', top: c.top, bottom: c.bottom, left: c.left, right: c.right, width: 6, height: 6, borderTopWidth: c.bt, borderBottomWidth: c.bb, borderLeftWidth: c.bl, borderRightWidth: c.br, borderColor: accent }} />
        ))}
        <View style={[p.line, { width: '80%' }]} />
        <View style={[p.line, { width: '60%' }]} />
      </View>
    </View>
  );
}

function PreviewChatBubble({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 7 }]}>
      <View style={[p.avatarCircle, { backgroundColor: accent, width: 22, height: 22 }]} />
      <View style={[p.nameLine, { backgroundColor: '#111', width: '55%', alignSelf: 'center' }]} />
      <View style={{ marginTop: 8, gap: 5 }}>
        <View style={{ alignSelf: 'flex-start', maxWidth: '75%', backgroundColor: '#F3F4F6', borderRadius: 8, padding: 5 }}>
          <View style={[p.line, { width: 55 }]} />
        </View>
        <View style={{ alignSelf: 'flex-end', maxWidth: '75%', backgroundColor: accent + '18', borderRadius: 8, padding: 5 }}>
          <View style={[p.line, { width: 48, backgroundColor: accent + '80' }]} />
        </View>
      </View>
    </View>
  );
}

function PreviewVerticalTabs({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { flexDirection: 'row', backgroundColor: '#fff' }]}>
      <View style={{ width: 16, backgroundColor: accent }}>
        {[1, 2, 3].map(i => (
          <View key={i} style={{ flex: 1, borderBottomWidth: 1, borderBottomColor: 'rgba(255,255,255,0.3)' }} />
        ))}
      </View>
      <View style={p.mainArea}>
        <View style={[p.nameLine, { backgroundColor: '#111', width: '75%' }]} />
        <View style={[p.subLine, { backgroundColor: accent, width: '50%' }]} />
        <View style={[p.line, { width: '85%', marginTop: 4 }]} />
        <View style={[p.line, { width: '60%' }]} />
      </View>
    </View>
  );
}

function PreviewFolderTab({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#FEF9F0', padding: 9, paddingTop: 14 }]}>
      <View style={{ flex: 1, backgroundColor: '#fff', borderRadius: 5, padding: 7 }}>
        <View style={{ position: 'absolute', top: -9, left: 6, backgroundColor: accent, borderRadius: 3, paddingHorizontal: 6, paddingVertical: 3 }}>
          <View style={[p.nameLine, { backgroundColor: '#fff', width: 34, height: 4 }]} />
        </View>
        <View style={{ marginTop: 6 }}>
          <View style={[p.subLine, { backgroundColor: accent, width: '45%' }]} />
          <View style={[p.line, { width: '80%', marginTop: 4 }]} />
          <View style={[p.line, { width: '60%' }]} />
        </View>
      </View>
    </View>
  );
}

function PreviewStackedCards({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 6 }]}>
      <View style={[p.nameLine, { backgroundColor: '#111', width: '60%', marginBottom: 5 }]} />
      <View style={{ flexDirection: 'row', gap: 4, flex: 1 }}>
        <View style={{ flex: 1, gap: 4 }}>
          <View style={{ backgroundColor: '#F9FAFB', borderRadius: 5, padding: 4, height: 34 }}>
            <View style={[p.subLine, { backgroundColor: accent, width: '70%' }]} />
            <View style={[p.line, { width: '80%' }]} />
          </View>
          <View style={{ backgroundColor: '#F9FAFB', borderRadius: 5, padding: 4, height: 22 }}>
            <View style={[p.subLine, { backgroundColor: accent, width: '60%' }]} />
          </View>
        </View>
        <View style={{ flex: 1, gap: 4 }}>
          <View style={{ backgroundColor: '#F9FAFB', borderRadius: 5, padding: 4, height: 22 }}>
            <View style={[p.subLine, { backgroundColor: accent, width: '60%' }]} />
          </View>
          <View style={{ backgroundColor: '#F9FAFB', borderRadius: 5, padding: 4, height: 34 }}>
            <View style={[p.subLine, { backgroundColor: accent, width: '70%' }]} />
            <View style={[p.line, { width: '75%' }]} />
          </View>
        </View>
      </View>
    </View>
  );
}

function PreviewHalftone({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 6 }]}>
      <View style={{ backgroundColor: accent, borderWidth: 2.5, borderColor: '#111827', padding: 6, marginBottom: 6, transform: [{ rotate: '-1deg' }] }}>
        <View style={[p.nameLine, { backgroundColor: '#111827', width: '65%' }]} />
        <View style={[p.subLine, { backgroundColor: '#111827', width: '45%' }]} />
      </View>
      <View style={{ borderWidth: 2, borderColor: '#111827', padding: 4 }}>
        <View style={[p.line, { width: '80%' }]} />
        <View style={[p.line, { width: '55%' }]} />
      </View>
    </View>
  );
}

function PreviewWaveCurve({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff' }]}>
      <View style={{ height: 42, backgroundColor: accent, padding: 7, overflow: 'hidden' }}>
        <View style={[p.nameLine, { backgroundColor: '#fff', width: '55%' }]} />
        <View style={[p.subLine, { backgroundColor: 'rgba(255,255,255,0.7)', width: '38%' }]} />
        <View style={{ position: 'absolute', bottom: -16, left: -10, width: '130%', height: 28, borderRadius: 999, backgroundColor: '#fff' }} />
      </View>
      <View style={{ padding: 7, marginTop: 4 }}>
        <View style={[p.line, { width: '85%' }]} />
        <View style={[p.line, { width: '60%' }]} />
      </View>
    </View>
  );
}

function PreviewLedger({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#fff', padding: 6 }]}>
      {[1, 2, 3, 4].map(i => (
        <View key={i} style={{ flexDirection: 'row', borderWidth: 1, borderColor: '#999', marginBottom: -1 }}>
          <View style={{ width: 30, borderRightWidth: 1, borderRightColor: '#999', backgroundColor: '#F3F4F6', padding: 3 }}>
            <View style={[p.subLine, { width: '85%', backgroundColor: accent }]} />
          </View>
          <View style={{ flex: 1, padding: 3 }}>
            <View style={[p.line, { width: '80%' }]} />
          </View>
        </View>
      ))}
    </View>
  );
}

function PreviewNeonDark({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#0B0B12', padding: 8, alignItems: 'center' }]}>
      <View style={[p.nameLine, { backgroundColor: '#F1F5F9', width: '55%' }]} />
      <View style={[p.subLine, { backgroundColor: accent, width: '38%' }]} />
      <View style={{ borderWidth: 1, borderColor: accent + '60', borderRadius: 5, padding: 5, marginTop: 8, width: '90%' }}>
        <View style={[p.subLine, { backgroundColor: accent, width: '40%' }]} />
        <View style={[p.line, { width: '80%', backgroundColor: '#334155' }]} />
      </View>
    </View>
  );
}

function PreviewScrapbook({ accent }: { accent: string }) {
  return (
    <View style={[p.wrap, { backgroundColor: '#FFFBF0', padding: 8, alignItems: 'center' }]}>
      <View style={{ backgroundColor: '#fff', borderRadius: 5, padding: 6, transform: [{ rotate: '-1deg' }], marginBottom: 8 }}>
        <View style={[p.nameLine, { backgroundColor: '#78350F', width: 46 }]} />
        <View style={[p.subLine, { backgroundColor: accent, width: 34 }]} />
      </View>
      <View style={{ backgroundColor: accent + '30', borderWidth: 1, borderColor: accent, borderStyle: 'dashed', paddingHorizontal: 6, paddingVertical: 2, transform: [{ rotate: '-2deg' }] }}>
        <View style={[p.subLine, { width: 30, backgroundColor: '#78350F' }]} />
      </View>
    </View>
  );
}

const PREVIEW_MAP: Record<string, (accent: string) => React.ReactNode> = {
  'professional-1': (a) => <PreviewProfessional accent={a} />,
  'modern-1':       (a) => <PreviewModern accent={a} />,
  'minimal-1':      (a) => <PreviewMinimal accent={a} />,
  'creative-1':     (a) => <PreviewCreative accent={a} />,
  'ats-1':          (a) => <PreviewATS accent={a} />,
  'professional-2': (a) => <PreviewExecutive accent={a} />,
  'modern-2':       (a) => <PreviewTechPro accent={a} />,
  'minimal-2':      (a) => <PreviewCleanSlate accent={a} />,
  'bold-1':         (a) => <PreviewBoldImpact accent={a} />,
  'gradient-1':     (a) => <PreviewGradient accent={a} />,
  'accent-1':       (a) => <PreviewSideAccent accent={a} />,
  'academic-1':     (a) => <PreviewAcademic accent={a} />,
  'compact-1':      (a) => <PreviewCompact accent={a} />,
  'magazine-1':     (a) => <PreviewMagazine accent={a} />,
  'timeline-1':     (a) => <PreviewTimeline accent={a} />,
  'finance-1':      (a) => <PreviewFinance accent={a} />,
  'startup-1':      (a) => <PreviewStartup accent={a} />,
  'healthcare-1':   (a) => <PreviewHealthcare accent={a} />,
  'euro-1':         (a) => <PreviewEuroCV accent={a} />,
  'infographic-1':  (a) => <PreviewInfographic accent={a} />,
  'twocol-1':       (a) => <PreviewTwoColumn accent={a} />,
  'newspaper-1':    (a) => <PreviewNewspaper accent={a} />,
  'dashboard-1':    (a) => <PreviewDashboard accent={a} />,
  'boxed-1':        (a) => <PreviewBoxedFrame accent={a} />,
  'typewriter-1':   (a) => <PreviewTypewriter accent={a} />,
  'swiss-1':        (a) => <PreviewSwissGrid accent={a} />,
  'kanban-1':       (a) => <PreviewKanban accent={a} />,
  'ribbon-1':       (a) => <PreviewRibbon accent={a} />,
  'diagonal-1':     (a) => <PreviewDiagonalSplit accent={a} />,
  'letterpress-1':  (a) => <PreviewLetterpress accent={a} />,
  'blueprint-1':    (a) => <PreviewBlueprint accent={a} />,
  'chatbubble-1':   (a) => <PreviewChatBubble accent={a} />,
  'vtabs-1':        (a) => <PreviewVerticalTabs accent={a} />,
  'foldertab-1':    (a) => <PreviewFolderTab accent={a} />,
  'stackedcards-1': (a) => <PreviewStackedCards accent={a} />,
  'halftone-1':     (a) => <PreviewHalftone accent={a} />,
  'wave-1':         (a) => <PreviewWaveCurve accent={a} />,
  'ledger-1':       (a) => <PreviewLedger accent={a} />,
  'neon-1':         (a) => <PreviewNeonDark accent={a} />,
  'scrapbook-1':    (a) => <PreviewScrapbook accent={a} />,
};

// ─── Card ─────────────────────────────────────────────────────────────────────

export const TemplateCard: React.FC<Props> = ({ template, selected, onPress, style }) => {
  const { colors } = useThemeStore();
  const previewFn = PREVIEW_MAP[template.id];

  return (
    <TouchableOpacity
      onPress={onPress}
      style={[
        styles.card,
        { backgroundColor: colors.surface },
        shadow.sm,
        selected && { borderColor: colors.primary, borderWidth: 2 },
        style,
      ]}
      accessibilityRole="button"
      accessibilityLabel={template.name}>
      <View style={styles.previewContainer}>
        {previewFn
          ? previewFn(template.accentColor)
          : <View style={[styles.fallback, { backgroundColor: template.accentColor + '20' }]}>
              <View style={[styles.fallbackHeader, { backgroundColor: template.accentColor }]} />
            </View>
        }
        {isProLocked(template.isPremium) ? (
          <View style={styles.premiumBadge}>
            <Text style={styles.premiumText}>PRO</Text>
          </View>
        ) : null}
        {selected ? (
          <View style={[styles.selectedBadge, { backgroundColor: colors.primary }]}>
            <Text style={styles.selectedText}>✓</Text>
          </View>
        ) : null}
      </View>
      <View style={styles.info}>
        <Text style={[styles.name, { color: colors.text }]} numberOfLines={1}>
          {template.name}
        </Text>
        <Text style={[styles.category, { color: colors.textSecondary }]}>
          {template.category}
        </Text>
      </View>
    </TouchableOpacity>
  );
};

// ─── Shared preview sub-styles ────────────────────────────────────────────────

const p = StyleSheet.create({
  wrap:         { flex: 1, height: '100%', overflow: 'hidden' },
  header:       { height: 38, paddingHorizontal: 7, paddingVertical: 7, justifyContent: 'flex-end', gap: 3 },
  body:         { padding: 7, gap: 4 },
  sidebar:      { width: 52, paddingHorizontal: 6, paddingVertical: 8, gap: 3 },
  sidebarWide:  { width: 52, paddingHorizontal: 6, paddingVertical: 8, gap: 3 },
  mainArea:     { flex: 1, padding: 6, gap: 3 },
  nameLine:     { height: 6, borderRadius: 3 },
  subLine:      { height: 4, borderRadius: 2, marginTop: 2 },
  line:         { height: 4, borderRadius: 2, backgroundColor: '#D1D5DB', marginTop: 2 },
  sectionRow:   { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4, marginBottom: 2 },
  sectionBar:   { width: 3, height: 9, borderRadius: 1.5 },
  sectionTitle: { height: 4, width: '45%', borderRadius: 2 },
  skillRow:     { flexDirection: 'row', flexWrap: 'wrap', gap: 3, marginTop: 4 },
  skillPill:    { height: 8, borderRadius: 4, borderWidth: 1, marginBottom: 2 },
  divider:      { height: 1, marginVertical: 5 },
  avatarCircle: { width: 22, height: 22, borderRadius: 11, alignSelf: 'center', marginBottom: 4 },
  sideDivider:  { height: 1, marginVertical: 4 },
  sideNameLine: { height: 5, borderRadius: 2, width: '80%' },
  sideLine:     { height: 3, borderRadius: 1.5, marginTop: 2 },
  sideSkill:    { height: 9, borderRadius: 3, marginBottom: 3 },
  mainSectionTitle: { paddingBottom: 2, marginBottom: 3, marginTop: 4 },
  centerHeader: { alignItems: 'stretch', marginBottom: 4 },
  timelineRow:  { flexDirection: 'row', gap: 5, marginBottom: 4 },
  timelineDate: { width: 28 },
  timelineLine: { flex: 1, borderLeftWidth: 1.5, paddingLeft: 5, gap: 2 },
  accentLine:   { height: 2, borderRadius: 1, marginVertical: 4 },
  execSectionHead: { alignItems: 'center', marginBottom: 3, marginTop: 4 },
  techHeader:   { paddingHorizontal: 7, paddingVertical: 7, gap: 3 },
  techSectionHead: { flexDirection: 'row', alignItems: 'center', gap: 3, marginBottom: 3, marginTop: 3 },
  techDivider:  { flex: 1, height: 1 },
  techPill:     { height: 7, borderRadius: 3, borderWidth: 1 },
  gradientLine: { height: 2, width: '70%', borderRadius: 1, marginTop: 5 },
  cleanSectionHead: { flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 3, marginTop: 3 },
  dot:          { width: 5, height: 5, borderRadius: 2.5 },
  cleanDivider: { flex: 1, height: 1 },
  cleanEntry:   { flexDirection: 'row', gap: 6 },
  cleanDate:    { width: 20, height: 12, borderRadius: 2, marginTop: 1 },
  creativeSecHead: { flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 3 },
  creativeIcon: { width: 10, height: 10, borderRadius: 2 },
  entryBar:     { paddingLeft: 6, borderLeftWidth: 2, gap: 2 },
  initialsCircle: { width: 26, height: 26, alignSelf: 'center', alignItems: 'center', justifyContent: 'center', marginBottom: 4 },
  atsSection:   { borderBottomWidth: 1, paddingBottom: 2, marginBottom: 2 },
});

// ─── Card wrapper styles ──────────────────────────────────────────────────────

const styles = StyleSheet.create({
  card: {
    borderRadius: radius.lg,
    overflow: 'hidden',
    marginRight: spacing.md,
    marginBottom: spacing.md,
    width: 140,
    borderWidth: 1.5,
    borderColor: 'transparent',
  },
  previewContainer: {
    height: 180,
    overflow: 'hidden',
    position: 'relative',
  },
  fallback: { flex: 1 },
  fallbackHeader: { height: 32 },
  premiumBadge: {
    position: 'absolute',
    top: 6,
    right: 6,
    backgroundColor: '#F59E0B',
    borderRadius: radius.full,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  premiumText: { fontSize: 9, fontFamily: 'Poppins-Bold', color: '#FFF' },
  selectedBadge: {
    position: 'absolute',
    bottom: 6,
    right: 6,
    width: 24,
    height: 24,
    borderRadius: radius.full,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedText: { color: '#FFF', fontSize: 12, fontWeight: 'bold' },
  info: { padding: spacing.md },
  name: { fontSize: fontSize.sm, fontFamily: fontFamily.semiBold, marginBottom: 2 },
  category: { fontSize: fontSize.xs, fontFamily: fontFamily.regular },
});
