import React from 'react';
import { View, Text, StyleSheet, ViewStyle } from 'react-native';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { radius, shadow, spacing } from '../../theme/spacing';

interface Props {
  label: string;
  value: string;
  icon?: string;
  color?: string;
  style?: ViewStyle;
}

export const StatCard: React.FC<Props> = ({ label, value, icon, color, style }) => {
  const { colors } = useThemeStore();
  const cardColor = color ?? colors.primary;

  return (
    <View style={[styles.card, { backgroundColor: colors.surface }, shadow.sm, style]}>
      {icon ? (
        <View style={[styles.iconWrapper, { backgroundColor: cardColor + '15' }]}>
          <Text style={styles.icon}>{icon}</Text>
        </View>
      ) : null}
      <Text style={[styles.value, { color: cardColor }]}>{value}</Text>
      <Text style={[styles.label, { color: '#6B7280' }]}>{label}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: radius.lg,
    padding: spacing.lg,
    alignItems: 'center',
    flex: 1,
  },
  iconWrapper: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },
  icon: { fontSize: 20 },
  value: {
    fontSize: fontSize.xxl,
    fontFamily: fontFamily.bold,
    marginBottom: 2,
  },
  label: {
    fontSize: fontSize.xs,
    fontFamily: fontFamily.regular,
    textAlign: 'center',
  },
});
