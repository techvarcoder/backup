import React, { useEffect, useState } from 'react';
import { View, Text, Modal, TouchableOpacity, ScrollView, ActivityIndicator, StyleSheet } from 'react-native';
import { useThemeStore } from '../../store/useThemeStore';
import { useResumeStore } from '../../store/useResumeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { radius, shadow, spacing } from '../../theme/spacing';
import { ResumeData } from '../../types';
import { ResumeCard } from '../cards/ResumeCard';
import { OutlinedButton } from '../buttons/OutlinedButton';
import { importResumeFile } from '../../utils/importResumeFile';

interface Props {
  visible: boolean;
  title: string;
  onClose: () => void;
  onSelect: (resume: ResumeData) => void;
}

export const ResumePickerModal: React.FC<Props> = ({ visible, title, onClose, onSelect }) => {
  const { colors } = useThemeStore();
  const { resumes, addResume, updateResume } = useResumeStore();
  const [importing, setImporting] = useState(false);
  const [error, setError] = useState('');
  const [dropdownOpen, setDropdownOpen] = useState(false);

  useEffect(() => {
    if (visible) { setDropdownOpen(false); setError(''); }
  }, [visible]);

  const handleUpload = async () => {
    setError('');
    setImporting(true);
    try {
      const result = await importResumeFile();
      if (result.status === 'cancelled') { return; }
      if (result.status === 'error') { setError(result.message); return; }

      const resume = addResume(result.suggestedTitle);
      updateResume(resume.id, result.data);
      onSelect({ ...resume, ...result.data });
    } finally {
      setImporting(false);
    }
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      onRequestClose={onClose}
      statusBarTranslucent>
      <TouchableOpacity style={[styles.overlay, { backgroundColor: colors.overlay }]} activeOpacity={1} onPress={onClose}>
        <TouchableOpacity activeOpacity={1} onPress={() => {}} style={[styles.sheet, { backgroundColor: colors.surface }, shadow.lg]}>
          <Text style={[styles.title, { color: colors.text }]}>{title}</Text>

          <TouchableOpacity
            onPress={handleUpload}
            disabled={importing}
            style={[styles.uploadRow, { borderColor: colors.primary, opacity: importing ? 0.6 : 1 }]}>
            {importing
              ? <ActivityIndicator color={colors.primary} size="small" />
              : <Text style={[styles.uploadIcon]}>📤</Text>}
            <Text style={[styles.uploadText, { color: colors.primary }]}>
              {importing ? 'Importing…' : 'Upload Resume (PDF/DOCX)'}
            </Text>
          </TouchableOpacity>

          {error ? <Text style={[styles.error, { color: colors.error }]}>{error}</Text> : null}

          <TouchableOpacity
            onPress={() => setDropdownOpen(o => !o)}
            style={[styles.dropdownField, { borderColor: colors.border }]}
            accessibilityRole="button"
            accessibilityLabel="Select from my resumes">
            <Text style={[styles.dropdownLabel, { color: colors.text }]}>Select from My Resumes</Text>
            <Text style={[styles.dropdownChevron, { color: colors.textSecondary }]}>{dropdownOpen ? '▴' : '▾'}</Text>
          </TouchableOpacity>

          {dropdownOpen ? (
            <ScrollView style={styles.list} showsVerticalScrollIndicator={false}>
              {resumes.length === 0 ? (
                <Text style={[styles.emptyText, { color: colors.textSecondary }]}>
                  No resumes yet — upload one above to get started.
                </Text>
              ) : (
                resumes.map(resume => (
                  <ResumeCard key={resume.id} resume={resume} onPress={() => onSelect(resume)} />
                ))
              )}
            </ScrollView>
          ) : null}

          <OutlinedButton label="Cancel" onPress={onClose} style={styles.cancelBtn} />
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
};

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  sheet: {
    width: '100%',
    maxHeight: '80%',
    borderTopLeftRadius: radius.xl,
    borderTopRightRadius: radius.xl,
    padding: spacing.xxl,
  },
  title: {
    fontSize: fontSize.lg,
    fontFamily: fontFamily.semiBold,
    marginBottom: spacing.lg,
  },
  uploadRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: spacing.sm,
    borderWidth: 1.5,
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
    marginBottom: spacing.lg,
  },
  uploadIcon: { fontSize: 18 },
  uploadText: {
    fontSize: fontSize.sm,
    fontFamily: fontFamily.semiBold,
  },
  error: {
    fontSize: fontSize.xs,
    fontFamily: fontFamily.regular,
    marginBottom: spacing.lg,
    textAlign: 'center',
  },
  dropdownField: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.lg,
    marginBottom: spacing.md,
  },
  dropdownLabel: {
    fontSize: fontSize.sm,
    fontFamily: fontFamily.semiBold,
  },
  dropdownChevron: {
    fontSize: fontSize.base,
  },
  list: {
    maxHeight: 320,
    marginBottom: spacing.lg,
  },
  emptyText: {
    fontSize: fontSize.sm,
    fontFamily: fontFamily.regular,
    textAlign: 'center',
    paddingVertical: spacing.xxl,
  },
  cancelBtn: {
    marginBottom: spacing.sm,
  },
});
