import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { radius, spacing } from '../../theme/spacing';

interface Props {
  label: string;
  selected?: boolean;
  onPress?: () => void;
  onRemove?: () => void;
  removable?: boolean;
}

export const SkillChip: React.FC<Props> = ({
  label,
  selected = false,
  onPress,
  onRemove,
  removable = false,
}) => {
  const { colors } = useThemeStore();

  return (
    <TouchableOpacity
      onPress={onPress}
      style={[
        styles.chip,
        {
          backgroundColor: selected ? colors.primary : colors.surfaceVariant,
          borderColor: selected ? colors.primary : colors.border,
        },
      ]}
      accessibilityRole="button"
      accessibilityLabel={label}>
      <Text style={[styles.label, { color: selected ? '#FFF' : colors.text }]}>{label}</Text>
      {removable && onRemove ? (
        <TouchableOpacity onPress={onRemove} style={styles.removeBtn} accessibilityLabel={`Remove ${label}`}>
          <Text style={[styles.removeIcon, { color: selected ? '#FFF' : colors.textSecondary }]}>✕</Text>
        </TouchableOpacity>
      ) : null}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  chip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs + 2,
    borderRadius: radius.full,
    borderWidth: 1,
    marginRight: spacing.sm,
    marginBottom: spacing.sm,
  },
  label: {
    fontSize: fontSize.sm,
    fontFamily: fontFamily.medium,
  },
  removeBtn: { marginLeft: spacing.xs },
  removeIcon: { fontSize: 10 },
});
