import React, { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  runOnJS,
} from 'react-native-reanimated';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { radius, spacing } from '../../theme/spacing';

interface Props {
  message: string;
  visible: boolean;
  type?: 'success' | 'error' | 'info';
  onDismiss: () => void;
  duration?: number;
}

export const Snackbar: React.FC<Props> = ({
  message,
  visible,
  type = 'info',
  onDismiss,
  duration = 3000,
}) => {
  const { colors } = useThemeStore();
  const opacity = useSharedValue(0);
  const translateY = useSharedValue(60);

  const bgColor =
    type === 'success' ? colors.success :
    type === 'error' ? colors.error :
    colors.text;

  useEffect(() => {
    if (visible) {
      opacity.value = withTiming(1, { duration: 300 });
      translateY.value = withTiming(0, { duration: 300 });
      const timer = setTimeout(() => {
        opacity.value = withTiming(0, { duration: 300 }, (finished) => {
          if (finished) { runOnJS(onDismiss)(); }
        });
        translateY.value = withTiming(60, { duration: 300 });
      }, duration);
      return () => clearTimeout(timer);
    } else {
      opacity.value = 0;
      translateY.value = 60;
    }
  }, [visible, opacity, translateY, duration, onDismiss]);

  const animStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateY: translateY.value }],
  }));

  return (
    <Animated.View style={[styles.container, animStyle]} pointerEvents={visible ? 'auto' : 'none'}>
      <View style={[styles.snackbar, { backgroundColor: bgColor }]}>
        <Text style={styles.message}>{message}</Text>
      </View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 90,
    left: spacing.lg,
    right: spacing.lg,
    zIndex: 9999,
  },
  snackbar: {
    borderRadius: radius.md,
    padding: spacing.lg,
    ...{
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.2,
      shadowRadius: 8,
      elevation: 6,
    },
  },
  message: {
    color: '#FFFFFF',
    fontSize: fontSize.base,
    fontFamily: fontFamily.medium,
  },
});
