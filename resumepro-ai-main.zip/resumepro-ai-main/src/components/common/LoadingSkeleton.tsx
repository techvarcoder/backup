import React, { useEffect } from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  interpolateColor,
} from 'react-native-reanimated';
import { useThemeStore } from '../../store/useThemeStore';
import { radius } from '../../theme/spacing';

interface Props {
  width?: number | string;
  height?: number;
  borderRadius?: number;
  style?: ViewStyle;
}

export const LoadingSkeleton: React.FC<Props> = ({
  width = '100%',
  height = 16,
  borderRadius = radius.sm,
  style,
}) => {
  const { colors } = useThemeStore();
  const shimmer = useSharedValue(0);

  useEffect(() => {
    shimmer.value = withRepeat(withTiming(1, { duration: 1000 }), -1, true);
  }, [shimmer]);

  const animStyle = useAnimatedStyle(() => ({
    backgroundColor: interpolateColor(
      shimmer.value,
      [0, 1],
      [colors.skeleton, colors.skeletonHighlight],
    ),
  }));

  return (
    <Animated.View
      style={[{ width: width as number, height, borderRadius }, animStyle, style]}
    />
  );
};

export const ResumeCardSkeleton: React.FC = () => {
  const { colors } = useThemeStore();
  return (
    <View style={[styles.card, { backgroundColor: colors.surface }]}>
      <LoadingSkeleton width={120} height={14} />
      <View style={styles.gap} />
      <LoadingSkeleton width="80%" height={12} />
      <View style={styles.gap} />
      <LoadingSkeleton width="60%" height={12} />
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    padding: 16,
    borderRadius: 16,
    marginBottom: 12,
  },
  gap: { height: 8 },
});
