import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import {
  RootStackParamList,
  AuthStackParamList,
  MainTabParamList,
  HomeStackParamList,
  ResumeStackParamList,
  AIToolsStackParamList,
  ProfileStackParamList,
} from './types';

import { useThemeStore } from '../store/useThemeStore';
import { useAuthStore } from '../store/useAuthStore';
import { fontFamily } from '../theme/typography';

// Auth Screens
import SplashScreen from '../screens/auth/SplashScreen';
import OnboardingScreen from '../screens/auth/OnboardingScreen';
import LoginScreen from '../screens/auth/LoginScreen';
import RegisterScreen from '../screens/auth/RegisterScreen';
import ForgotPasswordScreen from '../screens/auth/ForgotPasswordScreen';

// Home Screens
import HomeScreen from '../screens/home/HomeScreen';
import NotificationsScreen from '../screens/home/NotificationsScreen';

// Resume Screens
import MyResumesScreen from '../screens/resumes/MyResumesScreen';
import CreateResumeScreen from '../screens/resumes/CreateResumeScreen';
import ResumeEditorScreen from '../screens/resumes/ResumeEditorScreen';
import ResumeTemplatesScreen from '../screens/resumes/ResumeTemplatesScreen';
import ResumePreviewScreen from '../screens/resumes/ResumePreviewScreen';
import ExportResumeScreen from '../screens/resumes/ExportResumeScreen';

// AI Tools Screens
import AIToolsHubScreen from '../screens/aitools/AIToolsHubScreen';
import AIResumeWriterScreen from '../screens/aitools/AIResumeWriterScreen';
import AIResumeReviewScreen from '../screens/aitools/AIResumeReviewScreen';
import ATSScoreScreen from '../screens/aitools/ATSScoreScreen';
import CoverLetterScreen from '../screens/aitools/CoverLetterScreen';

// Career tools (now part of AI Tools)
import SalaryCalculatorScreen from '../screens/career/SalaryCalculatorScreen';
import NoticePeriodCalculatorScreen from '../screens/career/NoticePeriodCalculatorScreen';

// Profile Screens
import ProfileScreen from '../screens/profile/ProfileScreen';
import SettingsScreen from '../screens/profile/SettingsScreen';
import PremiumScreen from '../screens/premium/PremiumScreen';
import SubscriptionScreen from '../screens/profile/SubscriptionScreen';
import PaymentScreen from '../screens/premium/PaymentScreen';
import PaymentSuccessScreen from '../screens/premium/PaymentSuccessScreen';
import EditProfileScreen from '../screens/profile/EditProfileScreen';
import HelpScreen from '../screens/profile/HelpScreen';
import AboutScreen from '../screens/profile/AboutScreen';
import FeedbackScreen from '../screens/profile/FeedbackScreen';
import PrivacyPolicyScreen from '../screens/profile/PrivacyPolicyScreen';
import TermsScreen from '../screens/profile/TermsScreen';
import DeleteAccountScreen from '../screens/profile/DeleteAccountScreen';

const RootStack = createNativeStackNavigator<RootStackParamList>();
const AuthStack = createNativeStackNavigator<AuthStackParamList>();
const Tab = createBottomTabNavigator<MainTabParamList>();
const HomeStack = createNativeStackNavigator<HomeStackParamList>();
const ResumeStack = createNativeStackNavigator<ResumeStackParamList>();
const AIStack = createNativeStackNavigator<AIToolsStackParamList>();
const ProfileStack = createNativeStackNavigator<ProfileStackParamList>();

const screenOptions = { headerShown: false, animation: 'slide_from_right' as const };

function AuthNavigator() {
  return (
    <AuthStack.Navigator screenOptions={screenOptions} initialRouteName="Onboarding">
      <AuthStack.Screen name="Onboarding" component={OnboardingScreen} />
      <AuthStack.Screen name="Login" component={LoginScreen} />
      <AuthStack.Screen name="Register" component={RegisterScreen} />
      <AuthStack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
    </AuthStack.Navigator>
  );
}

function HomeNavigator() {
  return (
    <HomeStack.Navigator screenOptions={screenOptions}>
      <HomeStack.Screen name="Home" component={HomeScreen} />
      <HomeStack.Screen name="Notifications" component={NotificationsScreen} />
    </HomeStack.Navigator>
  );
}

function ResumeNavigator() {
  return (
    <ResumeStack.Navigator screenOptions={screenOptions}>
      <ResumeStack.Screen name="MyResumes" component={MyResumesScreen} />
      <ResumeStack.Screen name="CreateResume" component={CreateResumeScreen} />
      <ResumeStack.Screen name="ResumeEditor" component={ResumeEditorScreen} />
      <ResumeStack.Screen name="ResumeTemplates" component={ResumeTemplatesScreen} />
      <ResumeStack.Screen name="ResumePreview" component={ResumePreviewScreen} />
      <ResumeStack.Screen name="ExportResume" component={ExportResumeScreen} />
    </ResumeStack.Navigator>
  );
}

function AINavigator() {
  return (
    <AIStack.Navigator screenOptions={screenOptions}>
      <AIStack.Screen name="AIToolsHub" component={AIToolsHubScreen} />
      <AIStack.Screen name="AIResumeWriter" component={AIResumeWriterScreen} />
      <AIStack.Screen name="AIResumeReview" component={AIResumeReviewScreen} />
      <AIStack.Screen name="ATSScore" component={ATSScoreScreen} />
      <AIStack.Screen name="CoverLetter" component={CoverLetterScreen} />
      <AIStack.Screen name="SalaryCalculator" component={SalaryCalculatorScreen} />
      <AIStack.Screen name="NoticePeriodCalculator" component={NoticePeriodCalculatorScreen} />
    </AIStack.Navigator>
  );
}

function ProfileNavigator() {
  return (
    <ProfileStack.Navigator screenOptions={screenOptions}>
      <ProfileStack.Screen name="Profile" component={ProfileScreen} />
      <ProfileStack.Screen name="Settings" component={SettingsScreen} />
      <ProfileStack.Screen name="Premium" component={PremiumScreen} />
      <ProfileStack.Screen name="Subscription" component={SubscriptionScreen} />
      <ProfileStack.Screen name="PaymentScreen" component={PaymentScreen} />
      <ProfileStack.Screen name="PaymentSuccess" component={PaymentSuccessScreen} options={{ animation: 'fade' }} />
      <ProfileStack.Screen name="EditProfile" component={EditProfileScreen} />
      <ProfileStack.Screen name="Help" component={HelpScreen} />
      <ProfileStack.Screen name="About" component={AboutScreen} />
      <ProfileStack.Screen name="Feedback" component={FeedbackScreen} />
      <ProfileStack.Screen name="PrivacyPolicy" component={PrivacyPolicyScreen} />
      <ProfileStack.Screen name="TermsAndConditions" component={TermsScreen} />
      <ProfileStack.Screen name="DeleteAccount" component={DeleteAccountScreen} />
    </ProfileStack.Navigator>
  );
}

interface TabIconProps {
  icon: string;
  label: string;
  focused: boolean;
  color: string;
}

function TabIcon({ icon, label, focused, color }: TabIconProps) {
  return (
    <View style={tabStyles.iconWrapper}>
      <Text style={[tabStyles.icon, focused && tabStyles.iconFocused]}>{icon}</Text>
      <Text style={[tabStyles.label, { color }]}>{label}</Text>
    </View>
  );
}

const TAB_ITEMS = [
  { name: 'HomeTab', icon: '🏠', label: 'Home', component: HomeNavigator },
  { name: 'ResumesTab', icon: '📄', label: 'Resumes', component: ResumeNavigator },
  { name: 'AIToolsTab', icon: '🤖', label: 'AI Tools', component: AINavigator },
  { name: 'ProfileTab', icon: '👤', label: 'Profile', component: ProfileNavigator },
] as const;

function MainNavigator() {
  const { colors } = useThemeStore();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => {
        const item = TAB_ITEMS.find(t => t.name === route.name);
        return {
          headerShown: false,
          tabBarShowLabel: false,
          tabBarStyle: [
            tabStyles.tabBar,
            {
              backgroundColor: colors.tabBar,
              borderTopColor: colors.tabBarBorder,
            },
          ],
          tabBarIcon: ({ focused, color }) => (
            <TabIcon
              icon={item?.icon ?? ''}
              label={item?.label ?? ''}
              focused={focused}
              color={color}
            />
          ),
          tabBarActiveTintColor: colors.primary,
          tabBarInactiveTintColor: colors.textMuted,
        };
      }}>
      {TAB_ITEMS.map(item => (
        <Tab.Screen
          key={item.name}
          name={item.name as any}
          component={item.component}
        />
      ))}
    </Tab.Navigator>
  );
}

export const AppNavigator: React.FC = () => {
  const { isAuthenticated, isGuest } = useAuthStore();
  const isLoggedIn = isAuthenticated || isGuest;

  return (
    <NavigationContainer>
      <RootStack.Navigator screenOptions={{ headerShown: false }}>
        {isLoggedIn ? (
          <RootStack.Screen name="Main" component={MainNavigator} options={{ animation: 'fade' }} />
        ) : (
          <>
            <RootStack.Screen name="Splash" component={SplashScreen} options={{ animation: 'fade' }} />
            <RootStack.Screen name="Auth" component={AuthNavigator} />
          </>
        )}
      </RootStack.Navigator>
    </NavigationContainer>
  );
};

const tabStyles = StyleSheet.create({
  tabBar: {
    height: 70,
    paddingBottom: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
  },
  iconWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  icon: {
    fontSize: 22,
    marginBottom: 2,
  },
  iconFocused: {
    transform: [{ scale: 1.1 }],
  },
  label: {
    fontSize: 10,
    fontFamily: fontFamily.medium,
  },
});
