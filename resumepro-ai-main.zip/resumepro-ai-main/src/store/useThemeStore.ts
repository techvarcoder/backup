import { create } from 'zustand';
import { Appearance } from 'react-native';
import { lightColors, darkColors, Colors } from '../theme/colors';
import { ThemeMode } from '../types';

interface ThemeState {
  mode: ThemeMode;
  isDark: boolean;
  colors: Colors;
  setMode: (mode: ThemeMode) => void;
}

const getIsDark = (mode: ThemeMode): boolean => {
  if (mode === 'system') {
    return Appearance.getColorScheme() === 'dark';
  }
  return mode === 'dark';
};

export const useThemeStore = create<ThemeState>(set => ({
  mode: 'light',
  isDark: false,
  colors: lightColors,

  setMode: (mode) => {
    const isDark = getIsDark(mode);
    set({ mode, isDark, colors: isDark ? darkColors : lightColors });
  },
}));
