import { create } from 'zustand';
import { AppSettings } from '../types';

const defaultSettings: AppSettings = {
  theme: 'light',
  language: 'en',
  notificationsEnabled: true,
  autoBackup: true,
  exportFormat: 'pdf',
};

interface SettingsState {
  settings: AppSettings;
  updateSettings: (updates: Partial<AppSettings>) => void;
}

export const useSettingsStore = create<SettingsState>(set => ({
  settings: defaultSettings,

  updateSettings: (updates) =>
    set(state => ({ settings: { ...state.settings, ...updates } })),
}));
