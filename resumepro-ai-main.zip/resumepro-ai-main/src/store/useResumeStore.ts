import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ResumeData } from '../types';

const createEmptyResume = (id: string, title: string): ResumeData => ({
  id,
  title,
  templateId: 'professional-1',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  personalInfo: {
    fullName: '',
    jobTitle: '',
    email: '',
    phone: '',
    location: '',
  },
  workExperience: [],
  education: [],
  skills: [],
  projects: [],
  certificates: [],
  languages: [],
  awards: [],
  references: [],
});

const createSampleResume = (id: string): ResumeData => ({
  id,
  title: 'Sample Resume',
  templateId: 'professional-1',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  atsScore: 87,
  personalInfo: {
    fullName: 'Alex Morgan',
    jobTitle: 'Senior Software Engineer',
    email: 'alex.morgan@email.com',
    phone: '+1 (415) 555-0192',
    location: 'San Francisco, CA',
    linkedin: 'linkedin.com/in/alexmorgan',
    website: 'alexmorgan.dev',
    github: 'github.com/alexmorgan',
    summary:
      'Results-driven Software Engineer with 7+ years of experience building scalable web and mobile applications. ' +
      'Passionate about clean architecture, developer experience, and delivering products that users love. ' +
      'Led teams of up to 8 engineers and shipped features used by millions of customers.',
  },
  workExperience: [
    {
      id: 'we1',
      jobTitle: 'Senior Software Engineer',
      company: 'Stripe',
      location: 'San Francisco, CA',
      startDate: 'Jan 2022',
      endDate: '',
      isPresent: true,
      description:
        '- Led development of the Payments Dashboard, reducing load time by 40%\n' +
        '- Architected a real-time notification system serving 5M+ daily active users\n' +
        '- Mentored a team of 4 junior engineers through code reviews and weekly 1:1s\n' +
        '- Reduced API error rate from 2.1% to 0.3% by implementing circuit-breaker patterns',
    },
    {
      id: 'we2',
      jobTitle: 'Software Engineer II',
      company: 'Airbnb',
      location: 'San Francisco, CA',
      startDate: 'Jun 2019',
      endDate: 'Dec 2021',
      isPresent: false,
      description:
        '- Built the Host Insights analytics module with React and GraphQL\n' +
        '- Migrated 3 legacy services from Ruby to Node.js, improving response time by 55%\n' +
        '- Implemented A/B testing framework adopted by 12 product teams\n' +
        '- Collaborated with design team to ship a redesigned search experience',
    },
    {
      id: 'we3',
      jobTitle: 'Frontend Developer',
      company: 'InVision',
      location: 'New York, NY',
      startDate: 'Aug 2017',
      endDate: 'May 2019',
      isPresent: false,
      description:
        '- Developed core design collaboration features in React and TypeScript\n' +
        '- Reduced bundle size by 35% through code splitting and lazy loading\n' +
        '- Integrated WebSocket-based real-time commenting used by 200k+ designers',
    },
  ],
  education: [
    {
      id: 'edu1',
      degree: 'B.S. Computer Science',
      institution: 'University of California, Berkeley',
      fieldOfStudy: 'Computer Science',
      startYear: '2013',
      endYear: '2017',
      grade: '3.8 / 4.0',
    },
  ],
  skills: [
    { id: 's1',  name: 'TypeScript' },
    { id: 's2',  name: 'React' },
    { id: 's3',  name: 'React Native' },
    { id: 's4',  name: 'Node.js' },
    { id: 's5',  name: 'GraphQL' },
    { id: 's6',  name: 'PostgreSQL' },
    { id: 's7',  name: 'Redis' },
    { id: 's8',  name: 'AWS' },
    { id: 's9',  name: 'Docker' },
    { id: 's10', name: 'Kubernetes' },
    { id: 's11', name: 'Git' },
    { id: 's12', name: 'CI/CD' },
  ],
  projects: [
    {
      id: 'p1',
      name: 'OpenCart — E-commerce Platform',
      description:
        '- Built a full-stack e-commerce platform with Next.js, Stripe Payments, and PostgreSQL\n' +
        '- Supports 10k+ products, real-time inventory tracking, and multi-currency checkout\n' +
        '- Achieved 99.9% uptime via blue-green deployments on AWS ECS',
      technologies: 'Next.js, TypeScript, PostgreSQL, Stripe, AWS ECS',
      link: 'github.com/alexmorgan/opencart',
      startDate: 'Mar 2023',
      endDate: 'Sep 2023',
    },
    {
      id: 'p2',
      name: 'DevPulse — Developer Productivity Dashboard',
      description:
        '- Chrome extension that aggregates PR reviews, CI status, and Jira tickets in one panel\n' +
        '- 2,400+ active installs on the Chrome Web Store with 4.7-star rating\n' +
        '- Built with React, TypeScript, and GitHub/Jira REST APIs',
      technologies: 'React, TypeScript, Chrome Extension API, GitHub API',
      link: 'github.com/alexmorgan/devpulse',
      startDate: 'Jan 2022',
      endDate: 'Jun 2022',
    },
  ],
  certificates: [
    {
      id: 'c1',
      name: 'AWS Certified Solutions Architect – Associate',
      issuer: 'Amazon Web Services',
      date: 'Mar 2023',
      link: '',
    },
    {
      id: 'c2',
      name: 'Professional Scrum Master I (PSM I)',
      issuer: 'Scrum.org',
      date: 'Nov 2021',
      link: '',
    },
    {
      id: 'c3',
      name: 'Google Associate Cloud Engineer',
      issuer: 'Google Cloud',
      date: 'Jun 2022',
      link: '',
    },
  ],
  languages: [
    { id: 'l1', name: 'English',  proficiency: 'Native' },
    { id: 'l2', name: 'Spanish',  proficiency: 'Professional' },
    { id: 'l3', name: 'French',   proficiency: 'Intermediate' },
  ],
  awards: [
    {
      id: 'a1',
      title: 'Engineer of the Year',
      issuer: 'Stripe',
      date: '2023',
      description: 'Recognized for outstanding technical leadership and impact on the Payments team.',
    },
    {
      id: 'a2',
      title: 'Hackathon Winner — Best Developer Tool',
      issuer: 'Airbnb Internal Hackathon',
      date: '2020',
      description: 'First place for DevPulse prototype among 45 participating teams.',
    },
  ],
  references: [
    {
      id: 'r1',
      name: 'Jordan Lee',
      position: 'Engineering Manager',
      company: 'Stripe',
      email: 'jordan.lee@stripe.com',
      phone: '+1 (415) 555-0101',
    },
    {
      id: 'r2',
      name: 'Priya Sharma',
      position: 'Senior Staff Engineer',
      company: 'Airbnb',
      email: 'priya.sharma@airbnb.com',
      phone: '+1 (415) 555-0202',
    },
  ],
});

interface ResumeState {
  resumes: ResumeData[];
  activeResume: ResumeData | null;
  isLoading: boolean;
  _hasHydrated: boolean;
  setHasHydrated: (v: boolean) => void;
  setResumes: (resumes: ResumeData[]) => void;
  setActiveResume: (resume: ResumeData | null) => void;
  addResume: (title: string) => ResumeData;
  addSampleResume: () => ResumeData;
  updateResume: (id: string, updates: Partial<ResumeData>) => void;
  deleteResume: (id: string) => void;
  resetResume: (id: string) => void;
  duplicateResume: (id: string) => ResumeData | null;
  setLoading: (loading: boolean) => void;
}

export const useResumeStore = create<ResumeState>()(
  persist(
    (set, get) => ({
      resumes: [],
      activeResume: null,
      isLoading: false,
      _hasHydrated: false,
      setHasHydrated: (v) => set({ _hasHydrated: v }),

      setResumes: (resumes) => set({ resumes }),

      setActiveResume: (activeResume) => set({ activeResume }),

      addResume: (title) => {
        const resume = createEmptyResume(Date.now().toString(), title);
        set(state => ({ resumes: [resume, ...state.resumes], activeResume: resume }));
        return resume;
      },

      addSampleResume: () => {
        const resume = createSampleResume(Date.now().toString());
        set(state => ({ resumes: [resume, ...state.resumes], activeResume: resume }));
        return resume;
      },

      updateResume: (id, updates) => {
        set(state => ({
          resumes: state.resumes.map(r =>
            r.id === id ? { ...r, ...updates, updatedAt: new Date().toISOString() } : r,
          ),
          activeResume:
            state.activeResume?.id === id
              ? { ...state.activeResume, ...updates, updatedAt: new Date().toISOString() }
              : state.activeResume,
        }));
      },

      deleteResume: (id) => {
        set(state => ({
          resumes: state.resumes.filter(r => r.id !== id),
          activeResume: state.activeResume?.id === id ? null : state.activeResume,
        }));
      },

      resetResume: (id) => {
        const { resumes } = get();
        const existing = resumes.find(r => r.id === id);
        if (!existing) { return; }
        const blank = createEmptyResume(id, existing.title);
        blank.templateId = existing.templateId;
        blank.createdAt = existing.createdAt;
        set(state => ({
          resumes: state.resumes.map(r => r.id === id ? blank : r),
          activeResume: state.activeResume?.id === id ? blank : state.activeResume,
        }));
      },

      duplicateResume: (id) => {
        const { resumes } = get();
        const original = resumes.find(r => r.id === id);
        if (!original) { return null; }
        const copy: ResumeData = {
          ...original,
          id: Date.now().toString(),
          title: `${original.title} (Copy)`,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        set(state => ({ resumes: [copy, ...state.resumes] }));
        return copy;
      },

      setLoading: (isLoading) => set({ isLoading }),
    }),
    {
      name: 'resume_store',
      storage: createJSONStorage(() => AsyncStorage),
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      },
    },
  ),
);
