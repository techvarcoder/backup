import { create } from 'zustand';
import { User } from '../types';

interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isGuest: boolean;
  hasOnboarded: boolean;
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  setHasOnboarded: (value: boolean) => void;
  continueAsGuest: () => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>(set => ({
  user: null,
  isLoading: true,
  isAuthenticated: false,
  isGuest: false,
  hasOnboarded: false,

  setUser: (user) => set({ user, isAuthenticated: !!user, isGuest: false, isLoading: false }),
  setLoading: (isLoading) => set({ isLoading }),
  setHasOnboarded: (hasOnboarded) => set({ hasOnboarded }),
  continueAsGuest: () => set({ isGuest: true, isAuthenticated: false, user: null, isLoading: false }),
  logout: () => set({ user: null, isAuthenticated: false, isGuest: false }),
}));
