import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AIToolsStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { isProLocked } from '../../constants';

type Props = NativeStackScreenProps<AIToolsStackParamList, 'AIToolsHub'>;

interface Tool {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  route: keyof AIToolsStackParamList;
  isPremium?: boolean;
}

const TOOLS: Tool[] = [
  {
    id: '1',
    title: 'AI Resume Writer',
    description: 'Generate a complete resume using AI from your job role and skills.',
    icon: '✍️',
    color: '#2563EB',
    route: 'AIResumeWriter',
  },
  {
    id: '2',
    title: 'Improve Resume',
    description: 'Get AI suggestions to enhance your resume content and wording.',
    icon: '⚡',
    color: '#7C3AED',
    route: 'AIResumeReview',
  },
  {
    id: '3',
    title: 'ATS Score Checker',
    description: 'Check how well your resume performs against ATS systems.',
    icon: '🎯',
    color: '#16A34A',
    route: 'ATSScore',
  },
  {
    id: '4',
    title: 'Cover Letter Generator',
    description: 'Create a personalized cover letter for any job application.',
    icon: '📝',
    color: '#EA580C',
    route: 'CoverLetter',
    isPremium: true,
  },
  {
    id: '5',
    title: 'Salary Calculator',
    description: 'Estimate your market salary',
    icon: '💰',
    color: '#16A34A',
    route: 'SalaryCalculator',
  },
  {
    id: '6',
    title: 'Notice Period Calculator',
    description: 'Find your last working day',
    icon: '📋',
    color: '#F59E0B',
    route: 'NoticePeriodCalculator',
  },
];

export default function AIToolsHubScreen({ navigation }: Props) {
  const { colors } = useThemeStore();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>AI Tools</Text>
        <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
          Supercharge your job search with AI
        </Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {TOOLS.map(tool => (
          <TouchableOpacity
            key={tool.id}
            style={[styles.toolCard, { backgroundColor: colors.surface }, shadow.md]}
            onPress={() => !isProLocked(!!tool.isPremium) && navigation.navigate(tool.route as any)}
            accessibilityRole="button"
            accessibilityLabel={tool.title}>
            <View style={[styles.toolIcon, { backgroundColor: tool.color + '15' }]}>
              <Text style={styles.toolIconText}>{tool.icon}</Text>
            </View>
            <View style={styles.toolInfo}>
              <View style={styles.toolTitleRow}>
                <Text style={[styles.toolTitle, { color: colors.text }]}>{tool.title}</Text>
                {isProLocked(!!tool.isPremium) ? (
                  <View style={styles.proBadge}>
                    <Text style={styles.proBadgeText}>PRO</Text>
                  </View>
                ) : null}
              </View>
              <Text style={[styles.toolDescription, { color: colors.textSecondary }]}>
                {tool.description}
              </Text>
            </View>
            <Text style={[styles.arrow, { color: colors.textMuted }]}>→</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { padding: spacing.xxl, paddingBottom: spacing.lg },
  title: { fontSize: fontSize.xxl, fontFamily: fontFamily.bold },
  subtitle: { fontSize: fontSize.base, fontFamily: fontFamily.regular, marginTop: spacing.xs },
  content: { padding: spacing.xxl, paddingTop: 0 },
  toolCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.xl,
    padding: spacing.lg,
    marginBottom: spacing.md,
  },
  toolIcon: {
    width: 52,
    height: 52,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.lg,
  },
  toolIconText: { fontSize: 26 },
  toolInfo: { flex: 1 },
  toolTitleRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.xs },
  toolTitle: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold },
  toolDescription: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, lineHeight: 18 },
  proBadge: {
    backgroundColor: '#F59E0B',
    borderRadius: radius.full,
    paddingHorizontal: spacing.sm,
    paddingVertical: 2,
  },
  proBadgeText: { fontSize: 9, fontFamily: fontFamily.bold, color: '#FFF' },
  arrow: { fontSize: 18, marginLeft: spacing.sm },
});
