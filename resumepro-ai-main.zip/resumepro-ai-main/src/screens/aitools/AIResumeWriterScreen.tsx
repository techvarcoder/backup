import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  KeyboardAvoidingView, Platform, Clipboard,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import LinearGradient from 'react-native-linear-gradient';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AIToolsStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useResumeStore } from '../../store/useResumeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { gradients } from '../../theme/colors';
import { TextField } from '../../components/inputs/TextField';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { Snackbar } from '../../components/common/Snackbar';
import { generateResumeSummary, AINotConfiguredError } from '../../services/aiService';

type Props = NativeStackScreenProps<AIToolsStackParamList, 'AIResumeWriter'>;

export default function AIResumeWriterScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const { resumes, updateResume } = useResumeStore();
  const [jobRole, setJobRole] = useState('');
  const [skills, setSkills] = useState('');
  const [experience, setExperience] = useState('');
  const [loading, setLoading] = useState(false);
  const [summary, setSummary] = useState('');
  const [bullets, setBullets] = useState<string[]>([]);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '', type: 'success' as 'success' | 'error' });

  const showMsg = (msg: string, type: 'success' | 'error' = 'success') =>
    setSnackbar({ visible: true, message: msg, type });

  const handleGenerate = async () => {
    if (!jobRole.trim()) { showMsg('Please enter a job role', 'error'); return; }
    setLoading(true);
    try {
      const result = await generateResumeSummary(jobRole.trim(), skills, experience);
      setSummary(result.summary);
      setBullets(result.bullets);
    } catch (err) {
      const message = err instanceof AINotConfiguredError
        ? err.message
        : 'Failed to generate — please try again';
      showMsg(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleApplyToResume = () => {
    const latest = resumes[0];
    if (!latest) { showMsg('Create a resume first', 'error'); return; }
    updateResume(latest.id, {
      personalInfo: { ...latest.personalInfo, jobTitle: jobRole.trim(), summary },
    });
    showMsg(`Applied to "${latest.title}"`, 'success');
  };

  const handleCopy = () => {
    const content = [summary, '', 'Key Achievements:', ...bullets.map(b => `• ${b}`)].join('\n');
    Clipboard.setString(content);
    showMsg('Copied to clipboard');
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
            <Text style={[styles.backText, { color: colors.text }]}>←</Text>
          </TouchableOpacity>
          <Text style={[styles.title, { color: colors.text }]}>AI Resume Writer</Text>
        </View>

        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <LinearGradient colors={gradients.primary} style={styles.heroBanner}>
            <Text style={styles.heroIcon}>✍️</Text>
            <Text style={styles.heroTitle}>Generate Resume Content</Text>
            <Text style={styles.heroSubtitle}>Fill in your details and get a professional summary with bullet points</Text>
          </LinearGradient>

          <View style={[styles.card, { backgroundColor: colors.surface }, shadow.sm]}>
            <TextField label="Job Role *" value={jobRole} onChangeText={setJobRole} placeholder="e.g. React Native Developer" />
            <TextField label="Key Skills" value={skills} onChangeText={setSkills} placeholder="e.g. React Native, TypeScript, Firebase" hint="Separate with commas" />
            <TextField label="Years of Experience" value={experience} onChangeText={setExperience} placeholder="e.g. 4" keyboardType="numeric" />
            <PrimaryButton label="Generate with AI" onPress={handleGenerate} loading={loading} />
          </View>

          {summary ? (
            <View style={[styles.outputCard, { backgroundColor: colors.surface }, shadow.md]}>
              <View style={styles.outputHeader}>
                <Text style={[styles.outputTitle, { color: colors.text }]}>Professional Summary</Text>
                <View style={[styles.aiBadge, { backgroundColor: colors.primary + '20' }]}>
                  <Text style={[styles.aiBadgeText, { color: colors.primary }]}>AI</Text>
                </View>
              </View>
              <Text style={[styles.outputText, { color: colors.textSecondary }]}>{summary}</Text>

              {bullets.length > 0 && (
                <>
                  <Text style={[styles.outputTitle, { color: colors.text, marginBottom: spacing.sm }]}>Key Achievements</Text>
                  {bullets.map((b, i) => (
                    <View key={i} style={styles.bulletRow}>
                      <Text style={[styles.bulletDot, { color: colors.primary }]}>•</Text>
                      <Text style={[styles.bulletText, { color: colors.textSecondary }]}>{b}</Text>
                    </View>
                  ))}
                </>
              )}

              <View style={styles.outputActions}>
                <TouchableOpacity style={[styles.actionBtn, { backgroundColor: colors.primary }]} onPress={handleApplyToResume}>
                  <Text style={styles.actionBtnText}>Apply to Resume</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.actionBtn, { backgroundColor: colors.surfaceVariant }]} onPress={handleCopy}>
                  <Text style={[styles.actionBtnText, { color: colors.primary }]}>Copy</Text>
                </TouchableOpacity>
              </View>
              <TouchableOpacity onPress={handleGenerate} style={styles.regenBtn}>
                <Text style={[styles.regenText, { color: colors.textSecondary }]}>↻  Regenerate</Text>
              </TouchableOpacity>
            </View>
          ) : null}
        </ScrollView>
      </KeyboardAvoidingView>

      <Snackbar message={snackbar.message} visible={snackbar.visible} type={snackbar.type} onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  heroBanner: { borderRadius: radius.xl, padding: spacing.xxl, alignItems: 'center', marginBottom: spacing.xxl },
  heroIcon: { fontSize: 40, marginBottom: spacing.md },
  heroTitle: { fontSize: fontSize.lg, fontFamily: fontFamily.bold, color: '#FFF', marginBottom: spacing.xs },
  heroSubtitle: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, color: 'rgba(255,255,255,0.85)', textAlign: 'center' },
  card: { borderRadius: radius.xl, padding: spacing.xxl, marginBottom: spacing.xxl },
  outputCard: { borderRadius: radius.xl, padding: spacing.xxl },
  outputHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: spacing.md },
  outputTitle: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold },
  aiBadge: { borderRadius: radius.full, paddingHorizontal: spacing.md, paddingVertical: 4 },
  aiBadgeText: { fontSize: fontSize.xs, fontFamily: fontFamily.bold },
  outputText: { fontSize: fontSize.base, fontFamily: fontFamily.regular, lineHeight: 24, marginBottom: spacing.xl },
  bulletRow: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.sm, alignItems: 'flex-start' },
  bulletDot: { fontSize: 16, lineHeight: 22 },
  bulletText: { flex: 1, fontSize: fontSize.sm, fontFamily: fontFamily.regular, lineHeight: 20 },
  outputActions: { flexDirection: 'row', gap: spacing.md, marginTop: spacing.xl },
  actionBtn: { flex: 1, borderRadius: radius.lg, padding: spacing.md, alignItems: 'center' },
  actionBtnText: { color: '#FFF', fontSize: fontSize.sm, fontFamily: fontFamily.semiBold },
  regenBtn: { alignItems: 'center', marginTop: spacing.lg },
  regenText: { fontSize: fontSize.sm, fontFamily: fontFamily.medium },
});
