import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AIToolsStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useResumeStore } from '../../store/useResumeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { TextField } from '../../components/inputs/TextField';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { Snackbar } from '../../components/common/Snackbar';
import { ResumePickerModal } from '../../components/resume/ResumePickerModal';
import { checkATSScore, ATSScoreResult, AINotConfiguredError } from '../../services/aiService';
import { ResumeData } from '../../types';

type Props = NativeStackScreenProps<AIToolsStackParamList, 'ATSScore'>;

export default function ATSScoreScreen({ navigation, route }: Props) {
  const { colors } = useThemeStore();
  const { resumes, updateResume } = useResumeStore();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ATSScoreResult | null>(null);
  const [resumeTitle, setResumeTitle] = useState('');
  const [snackbar, setSnackbar] = useState({ visible: false, message: '', type: 'error' as 'success' | 'error' });
  const [pickerVisible, setPickerVisible] = useState(false);
  const [jobRole, setJobRole] = useState('');
  const [jobDescription, setJobDescription] = useState('');

  const resumeId = route.params?.resumeId;
  const [resume, setResume] = useState<ResumeData | undefined>(() =>
    resumeId ? resumes.find(r => r.id === resumeId) : undefined,
  );

  const handleCheck = async (target?: ResumeData) => {
    const subject = target ?? resume;
    if (!subject) { return; }
    setLoading(true);
    try {
      const res = await checkATSScore(subject, jobRole.trim(), jobDescription.trim());
      setResult(res);
      setResumeTitle(subject.title);
      updateResume(subject.id, { atsScore: res.overall });
    } catch (err) {
      const message = err instanceof AINotConfiguredError
        ? err.message
        : 'Failed to check score — please try again';
      setSnackbar({ visible: true, message, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const handlePickResume = (picked: ResumeData) => {
    setResume(picked);
    setPickerVisible(false);
    handleCheck(picked);
  };

  const getScoreColor = (score: number) => {
    if (score >= 75) { return colors.success; }
    if (score >= 50) { return colors.warning; }
    return colors.error;
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) { return 'Excellent'; }
    if (score >= 65) { return 'Good'; }
    if (score >= 50) { return 'Fair'; }
    return 'Needs Work';
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>ATS Score Checker</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {!result ? (
          <View style={[styles.ctaCard, { backgroundColor: colors.surface }, shadow.md]}>
            <Text style={styles.ctaIcon}>🎯</Text>
            <Text style={[styles.ctaTitle, { color: colors.text }]}>Check Your ATS Score</Text>
            <Text style={[styles.ctaSubtitle, { color: colors.textSecondary }]}>
              {resume
                ? `Analyze "${resume.title}" against ATS criteria`
                : 'Choose which resume you’d like to check'}
            </Text>
            <TextField
              label="Job Role (optional)"
              value={jobRole}
              onChangeText={setJobRole}
              placeholder="e.g. Senior Backend Engineer"
              containerStyle={styles.fullWidthField}
            />
            <TextField
              label="Job Description (optional)"
              value={jobDescription}
              onChangeText={setJobDescription}
              placeholder="Paste the job description to score your match against it..."
              hint="Leave blank for a general ATS-friendliness check"
              multiline
              numberOfLines={4}
              style={styles.jobDescInput}
              containerStyle={styles.fullWidthField}
            />
            {resume ? (
              <>
                <PrimaryButton label="Check ATS Score" onPress={() => handleCheck()} loading={loading} />
                <TouchableOpacity onPress={() => setPickerVisible(true)} style={styles.changeBtn}>
                  <Text style={[styles.changeText, { color: colors.textSecondary }]}>Change resume</Text>
                </TouchableOpacity>
              </>
            ) : (
              <PrimaryButton label="Choose Resume" onPress={() => setPickerVisible(true)} />
            )}
          </View>
        ) : (
          <>
            <Text style={[styles.resumeLabel, { color: colors.textSecondary }]}>Results for: {resumeTitle}</Text>

            <View style={[styles.scoreCard, { backgroundColor: colors.surface }, shadow.md]}>
              <View style={[styles.scoreCircleOuter, { borderColor: getScoreColor(result.overall) + '30' }]}>
                <View style={[styles.scoreCircleInner, { borderColor: getScoreColor(result.overall) }]}>
                  <Text style={[styles.scoreValue, { color: getScoreColor(result.overall) }]}>{result.overall}</Text>
                  <Text style={[styles.scoreMax, { color: colors.textSecondary }]}>/100</Text>
                </View>
              </View>
              <Text style={[styles.scoreLabel, { color: getScoreColor(result.overall) }]}>{getScoreLabel(result.overall)}</Text>
              <Text style={[styles.scoreDesc, { color: colors.textSecondary }]}>
                {result.overall >= 75
                  ? 'Your resume is ATS-friendly and should pass most filters.'
                  : result.overall >= 50
                  ? 'Your resume may pass some ATS filters. Apply the suggestions below.'
                  : 'Your resume needs improvements to pass ATS filters.'}
              </Text>
            </View>

            <View style={[styles.criteriaCard, { backgroundColor: colors.surface }, shadow.sm]}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>Score Breakdown</Text>
              {result.criteria.map(c => (
                <View key={c.label} style={styles.criteriaRow}>
                  <View style={styles.criteriaLeft}>
                    <Text style={[styles.criteriaLabel, { color: colors.text }]}>{c.label}</Text>
                    <Text style={[styles.criteriaDetail, { color: colors.textSecondary }]}>{c.detail}</Text>
                  </View>
                  <View style={[styles.criteriaBar, { backgroundColor: colors.border }]}>
                    <View style={[styles.criteriaFill, { width: `${c.score}%` as any, backgroundColor: getScoreColor(c.score) }]} />
                  </View>
                  <Text style={[styles.criteriaScore, { color: getScoreColor(c.score) }]}>{c.score}</Text>
                </View>
              ))}
            </View>

            {result.suggestions.length > 0 && (
              <View style={[styles.suggestionsCard, { backgroundColor: colors.surface }, shadow.sm]}>
                <Text style={[styles.sectionTitle, { color: colors.text }]}>Suggestions to Improve</Text>
                {result.suggestions.map((s, i) => (
                  <View key={i} style={styles.suggestion}>
                    <Text style={[styles.suggestionBullet, { color: colors.warning }]}>⚠</Text>
                    <Text style={[styles.suggestionText, { color: colors.textSecondary }]}>{s}</Text>
                  </View>
                ))}
              </View>
            )}

            <View style={styles.regenRow}>
              <TouchableOpacity onPress={() => handleCheck()}>
                <Text style={[styles.regenText, { color: colors.textSecondary }]}>↻  Re-check</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setResult(null)}>
                <Text style={[styles.regenText, { color: colors.textSecondary }]}>✏️  Edit details</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </ScrollView>

      <Snackbar message={snackbar.message} visible={snackbar.visible} type={snackbar.type} onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))} />
      <ResumePickerModal
        visible={pickerVisible}
        title="Select a resume to check"
        onClose={() => setPickerVisible(false)}
        onSelect={handlePickResume}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  ctaCard: { borderRadius: radius.xl, padding: spacing.xxl, alignItems: 'center' },
  ctaIcon: { fontSize: 56, marginBottom: spacing.lg },
  ctaTitle: { fontSize: fontSize.xl, fontFamily: fontFamily.bold, marginBottom: spacing.sm, textAlign: 'center' },
  ctaSubtitle: { fontSize: fontSize.base, fontFamily: fontFamily.regular, textAlign: 'center', lineHeight: 24, marginBottom: spacing.xxl },
  changeBtn: { alignItems: 'center', marginTop: spacing.lg },
  changeText: { fontSize: fontSize.sm, fontFamily: fontFamily.medium },
  fullWidthField: { width: '100%', alignSelf: 'stretch' },
  jobDescInput: { textAlignVertical: 'top', minHeight: 90 },
  resumeLabel: { fontSize: fontSize.sm, fontFamily: fontFamily.medium, marginBottom: spacing.lg, textAlign: 'center' },
  scoreCard: { borderRadius: radius.xl, padding: spacing.xxl, alignItems: 'center', marginBottom: spacing.lg },
  scoreCircleOuter: { width: 150, height: 150, borderRadius: 75, borderWidth: 12, alignItems: 'center', justifyContent: 'center', marginBottom: spacing.lg },
  scoreCircleInner: { width: 120, height: 120, borderRadius: 60, borderWidth: 6, alignItems: 'center', justifyContent: 'center' },
  scoreValue: { fontSize: 40, fontFamily: fontFamily.bold },
  scoreMax: { fontSize: fontSize.sm, fontFamily: fontFamily.regular },
  scoreLabel: { fontSize: fontSize.lg, fontFamily: fontFamily.bold, marginBottom: spacing.xs },
  scoreDesc: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, textAlign: 'center', lineHeight: 20 },
  criteriaCard: { borderRadius: radius.xl, padding: spacing.xxl, marginBottom: spacing.lg },
  sectionTitle: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, marginBottom: spacing.lg },
  criteriaRow: { flexDirection: 'row', alignItems: 'center', marginBottom: spacing.md, gap: spacing.sm },
  criteriaLeft: { width: 90 },
  criteriaLabel: { fontSize: fontSize.sm, fontFamily: fontFamily.semiBold },
  criteriaDetail: { fontSize: 10, fontFamily: fontFamily.regular },
  criteriaBar: { flex: 1, height: 8, borderRadius: 4, overflow: 'hidden' },
  criteriaFill: { height: '100%', borderRadius: 4 },
  criteriaScore: { fontSize: fontSize.sm, fontFamily: fontFamily.bold, width: 28, textAlign: 'right' },
  suggestionsCard: { borderRadius: radius.xl, padding: spacing.xxl },
  suggestion: { flexDirection: 'row', gap: spacing.sm, marginBottom: spacing.md, alignItems: 'flex-start' },
  suggestionBullet: { fontSize: 14, marginTop: 1 },
  suggestionText: { flex: 1, fontSize: fontSize.sm, fontFamily: fontFamily.regular, lineHeight: 20 },
  regenRow: { flexDirection: 'row', justifyContent: 'center', gap: spacing.xl, marginTop: spacing.xl },
  regenText: { fontSize: fontSize.sm, fontFamily: fontFamily.medium },
});
