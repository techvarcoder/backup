import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AIToolsStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useResumeStore } from '../../store/useResumeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { Snackbar } from '../../components/common/Snackbar';
import { ResumePickerModal } from '../../components/resume/ResumePickerModal';
import { reviewResume, ReviewSuggestion, AINotConfiguredError } from '../../services/aiService';
import { ResumeData } from '../../types';

type Props = NativeStackScreenProps<AIToolsStackParamList, 'AIResumeReview'>;

export default function AIResumeReviewScreen({ navigation, route }: Props) {
  const { colors } = useThemeStore();
  const { resumes } = useResumeStore();
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<ReviewSuggestion[] | null>(null);
  const [resumeTitle, setResumeTitle] = useState('');
  const [snackbar, setSnackbar] = useState({ visible: false, message: '', type: 'error' as 'success' | 'error' });
  const [pickerVisible, setPickerVisible] = useState(false);

  const resumeId = route.params?.resumeId;
  const [resume, setResume] = useState<ResumeData | undefined>(() =>
    resumeId ? resumes.find(r => r.id === resumeId) : undefined,
  );

  const handleReview = async (target?: ResumeData) => {
    const subject = target ?? resume;
    if (!subject) { return; }
    setLoading(true);
    try {
      const result = await reviewResume(subject);
      setSuggestions(result.suggestions);
      setResumeTitle(subject.title);
    } catch (err) {
      const message = err instanceof AINotConfiguredError
        ? err.message
        : 'Failed to analyze — please try again';
      setSnackbar({ visible: true, message, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const handlePickResume = (picked: ResumeData) => {
    setResume(picked);
    setPickerVisible(false);
    handleReview(picked);
  };

  const good = suggestions?.filter(s => s.type === 'good').length ?? 0;
  const warn = suggestions?.filter(s => s.type === 'warn').length ?? 0;
  const errors = suggestions?.filter(s => s.type === 'error').length ?? 0;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Improve Resume</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {!suggestions ? (
          <View style={[styles.ctaCard, { backgroundColor: colors.surface }, shadow.md]}>
            <Text style={styles.ctaIcon}>⚡</Text>
            <Text style={[styles.ctaTitle, { color: colors.text }]}>Analyze Your Resume</Text>
            <Text style={[styles.ctaSubtitle, { color: colors.textSecondary }]}>
              {resume
                ? `Get personalized suggestions for "${resume.title}"`
                : 'Choose which resume you’d like AI to review'}
            </Text>
            {resume ? (
              <>
                <PrimaryButton label="Analyze with AI" onPress={() => handleReview()} loading={loading} />
                <TouchableOpacity onPress={() => setPickerVisible(true)} style={styles.changeBtn}>
                  <Text style={[styles.changeText, { color: colors.textSecondary }]}>Change resume</Text>
                </TouchableOpacity>
              </>
            ) : (
              <PrimaryButton label="Choose Resume" onPress={() => setPickerVisible(true)} />
            )}
          </View>
        ) : (
          <>
            <Text style={[styles.resumeLabel, { color: colors.textSecondary }]}>Analyzing: {resumeTitle}</Text>

            <View style={[styles.summaryRow, { gap: spacing.md }]}>
              {[
                { label: 'Good', count: good, color: colors.success },
                { label: 'Improve', count: warn, color: colors.warning },
                { label: 'Fix', count: errors, color: colors.error },
              ].map(s => (
                <View key={s.label} style={[styles.summaryCard, { backgroundColor: colors.surface, flex: 1 }, shadow.sm]}>
                  <Text style={[styles.summaryCount, { color: s.color }]}>{s.count}</Text>
                  <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>{s.label}</Text>
                </View>
              ))}
            </View>

            <View style={[styles.improvementsCard, { backgroundColor: colors.surface }, shadow.sm]}>
              <Text style={[styles.sectionTitle, { color: colors.text }]}>AI Suggestions</Text>
              {suggestions.map((item, idx) => (
                <View key={idx} style={[styles.suggestion, { borderBottomColor: colors.border }]}>
                  <Text style={styles.suggestionIcon}>{item.icon}</Text>
                  <Text style={[styles.suggestionText, { color: colors.textSecondary }]}>{item.text}</Text>
                </View>
              ))}
            </View>

            <TouchableOpacity onPress={() => handleReview()} style={styles.regenBtn}>
              <Text style={[styles.regenText, { color: colors.textSecondary }]}>↻  Re-analyze</Text>
            </TouchableOpacity>
          </>
        )}
      </ScrollView>

      <Snackbar message={snackbar.message} visible={snackbar.visible} type={snackbar.type} onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))} />
      <ResumePickerModal
        visible={pickerVisible}
        title="Select a resume to analyze"
        onClose={() => setPickerVisible(false)}
        onSelect={handlePickResume}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  ctaCard: { borderRadius: radius.xl, padding: spacing.xxl, alignItems: 'center' },
  ctaIcon: { fontSize: 56, marginBottom: spacing.lg },
  ctaTitle: { fontSize: fontSize.xl, fontFamily: fontFamily.bold, marginBottom: spacing.sm, textAlign: 'center' },
  ctaSubtitle: { fontSize: fontSize.base, fontFamily: fontFamily.regular, textAlign: 'center', lineHeight: 24, marginBottom: spacing.xxl },
  changeBtn: { alignItems: 'center', marginTop: spacing.lg },
  changeText: { fontSize: fontSize.sm, fontFamily: fontFamily.medium },
  resumeLabel: { fontSize: fontSize.sm, fontFamily: fontFamily.medium, marginBottom: spacing.md, textAlign: 'center' },
  summaryRow: { flexDirection: 'row', marginBottom: spacing.lg },
  summaryCard: { borderRadius: radius.lg, padding: spacing.lg, alignItems: 'center' },
  summaryCount: { fontSize: fontSize.xxl, fontFamily: fontFamily.bold },
  summaryLabel: { fontSize: fontSize.xs, fontFamily: fontFamily.regular },
  improvementsCard: { borderRadius: radius.xl, padding: spacing.xxl },
  sectionTitle: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, marginBottom: spacing.lg },
  suggestion: { flexDirection: 'row', gap: spacing.md, paddingBottom: spacing.md, marginBottom: spacing.md, borderBottomWidth: 1, alignItems: 'flex-start' },
  suggestionIcon: { fontSize: 16 },
  suggestionText: { flex: 1, fontSize: fontSize.sm, fontFamily: fontFamily.regular, lineHeight: 20 },
  regenBtn: { alignItems: 'center', marginTop: spacing.xl },
  regenText: { fontSize: fontSize.sm, fontFamily: fontFamily.medium },
});
