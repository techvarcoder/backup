import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  KeyboardAvoidingView, Platform, Clipboard,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AIToolsStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useResumeStore } from '../../store/useResumeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { TextField } from '../../components/inputs/TextField';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { Snackbar } from '../../components/common/Snackbar';
import { generateCoverLetter, AINotConfiguredError } from '../../services/aiService';

type Props = NativeStackScreenProps<AIToolsStackParamList, 'CoverLetter'>;

export default function CoverLetterScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const { resumes } = useResumeStore();
  const activeResume = resumes[0];

  const [jobTitle, setJobTitle] = useState('');
  const [company, setCompany] = useState('');
  const [yourName, setYourName] = useState(activeResume?.personalInfo.fullName ?? '');
  const [experience, setExperience] = useState('');
  const [loading, setLoading] = useState(false);
  const [generated, setGenerated] = useState('');
  const [snackbar, setSnackbar] = useState({ visible: false, message: '', type: 'success' as 'success' | 'error' });

  const showMsg = (msg: string, type: 'success' | 'error' = 'success') =>
    setSnackbar({ visible: true, message: msg, type });

  const handleGenerate = async () => {
    if (!jobTitle.trim() || !company.trim()) {
      showMsg('Please enter job title and company', 'error');
      return;
    }
    setLoading(true);
    try {
      const skills = activeResume
        ? activeResume.skills.slice(0, 4).map(s => s.name).join(', ')
        : '';
      const summary = activeResume?.personalInfo.summary ?? '';
      const result = await generateCoverLetter(
        jobTitle.trim(), company.trim(), yourName.trim(), experience, skills, summary,
      );
      setGenerated(result.letter);
    } catch (err) {
      const message = err instanceof AINotConfiguredError
        ? err.message
        : 'Failed to generate — please try again';
      showMsg(message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!generated) { return; }
    Clipboard.setString(generated);
    showMsg('Cover letter copied to clipboard');
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
            <Text style={[styles.backText, { color: colors.text }]}>←</Text>
          </TouchableOpacity>
          <Text style={[styles.title, { color: colors.text }]}>Cover Letter Generator</Text>
        </View>

        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={[styles.card, { backgroundColor: colors.surface }, shadow.sm]}>
            <TextField label="Job Title *" value={jobTitle} onChangeText={setJobTitle} placeholder="React Native Developer" />
            <TextField label="Company *" value={company} onChangeText={setCompany} placeholder="Google" />
            <TextField label="Your Name" value={yourName} onChangeText={setYourName} placeholder="John Doe" />
            <TextField label="Years of Experience" value={experience} onChangeText={setExperience} placeholder="4" keyboardType="numeric" />
            {activeResume && (
              <Text style={[styles.autoNote, { color: colors.textSecondary }]}>
                ✓ Skills & summary auto-filled from "{activeResume.title}"
              </Text>
            )}
            <PrimaryButton label="Generate Cover Letter" onPress={handleGenerate} loading={loading} style={{ marginTop: spacing.md }} />
          </View>

          {generated ? (
            <View style={[styles.outputCard, { backgroundColor: colors.surface }, shadow.md]}>
              <Text style={[styles.outputTitle, { color: colors.text }]}>Cover Letter Preview</Text>
              <View style={[styles.letterContainer, { borderColor: colors.border }]}>
                <Text style={[styles.letterText, { color: colors.text }]}>{generated}</Text>
              </View>
              <View style={styles.actions}>
                <TouchableOpacity style={[styles.actionBtn, { backgroundColor: colors.primary }]} onPress={handleCopy}>
                  <Text style={styles.actionBtnText}>Copy</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.actionBtn, { backgroundColor: colors.surfaceVariant }]} onPress={handleGenerate}>
                  <Text style={[styles.actionBtnText, { color: colors.primary }]}>Regenerate</Text>
                </TouchableOpacity>
              </View>
            </View>
          ) : null}
        </ScrollView>
      </KeyboardAvoidingView>

      <Snackbar message={snackbar.message} visible={snackbar.visible} type={snackbar.type} onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  card: { borderRadius: radius.xl, padding: spacing.xxl, marginBottom: spacing.xl },
  autoNote: { fontSize: fontSize.xs, fontFamily: fontFamily.regular, marginBottom: spacing.sm },
  outputCard: { borderRadius: radius.xl, padding: spacing.xxl },
  outputTitle: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, marginBottom: spacing.lg },
  letterContainer: { borderWidth: 1, borderRadius: radius.md, padding: spacing.lg, marginBottom: spacing.lg },
  letterText: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, lineHeight: 22 },
  actions: { flexDirection: 'row', gap: spacing.md },
  actionBtn: { flex: 1, borderRadius: radius.lg, padding: spacing.md, alignItems: 'center' },
  actionBtnText: { color: '#FFF', fontSize: fontSize.sm, fontFamily: fontFamily.semiBold },
});
