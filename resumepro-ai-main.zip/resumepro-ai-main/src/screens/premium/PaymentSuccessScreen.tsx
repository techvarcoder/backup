import React, { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Animated, { useSharedValue, useAnimatedStyle, withSpring, withDelay } from 'react-native-reanimated';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/types';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius } from '../../theme/spacing';
import { gradients } from '../../theme/colors';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';

type Props = NativeStackScreenProps<ProfileStackParamList, 'PaymentSuccess'>;

const FEATURES = ['All Premium Templates', 'AI Writing Assistant', 'Unlimited PDF Exports', 'ATS Score Checker'];

export default function PaymentSuccessScreen({ navigation }: Props) {
  const scale = useSharedValue(0);
  const opacity = useSharedValue(0);

  const iconStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const contentStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }));

  useEffect(() => {
    scale.value = withSpring(1, { damping: 10, stiffness: 100 });
    opacity.value = withDelay(400, withSpring(1));
  }, [scale, opacity]);

  return (
    <LinearGradient colors={gradients.success} style={styles.container}>
      <Animated.View style={[styles.iconWrapper, iconStyle]}>
        <Text style={styles.checkIcon}>✓</Text>
      </Animated.View>

      <Animated.View style={[styles.content, contentStyle]}>
        <Text style={styles.title}>Payment Successful!</Text>
        <Text style={styles.subtitle}>
          Welcome to ResumePro AI Pro! You now have access to all premium features.
        </Text>

        <View style={styles.featureList}>
          {FEATURES.map(f => (
            <View key={f} style={styles.featureRow}>
              <Text style={styles.featureCheck}>✓</Text>
              <Text style={styles.featureText}>{f}</Text>
            </View>
          ))}
        </View>

        <PrimaryButton
          label="Start Building Resumes"
          onPress={() => navigation.navigate('Profile')}
          style={styles.ctaBtn}
        />
      </Animated.View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xxxl,
  },
  iconWrapper: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(255,255,255,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xxl,
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.5)',
  },
  checkIcon: { fontSize: 48, color: '#FFFFFF' },
  content: { alignItems: 'center', width: '100%' },
  title: { fontSize: fontSize.xxl, fontFamily: fontFamily.bold, color: '#FFFFFF', marginBottom: spacing.md, textAlign: 'center' },
  subtitle: { fontSize: fontSize.base, fontFamily: fontFamily.regular, color: 'rgba(255,255,255,0.85)', textAlign: 'center', lineHeight: 24, marginBottom: spacing.xxl },
  featureList: { width: '100%', backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: radius.xl, padding: spacing.xxl, marginBottom: spacing.xxl },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.sm },
  featureCheck: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold' },
  featureText: { color: '#FFFFFF', fontSize: fontSize.base, fontFamily: fontFamily.medium },
  ctaBtn: {},
});
