import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';

type Props = NativeStackScreenProps<ProfileStackParamList, 'PaymentScreen'>;

type PaymentMethod = 'card' | 'netbanking' | 'googlepay' | 'phonepe';

const PLAN_MAP: Record<string, { name: string; price: string }> = {
  monthly: { name: 'Monthly Plan', price: '₹99.00' },
  yearly: { name: 'Annual Plan', price: '₹489.00' },
  lifetime: { name: 'Lifetime Plan', price: '₹1,299.00' },
};

const PAYMENT_METHODS: Array<{ id: PaymentMethod; icon: string; label: string }> = [
  { id: 'card', icon: '💳', label: 'Credit / Debit Card' },
  { id: 'netbanking', icon: '🏦', label: 'Net Banking' },
  { id: 'googlepay', icon: 'G', label: 'Google Pay' },
  { id: 'phonepe', icon: '📱', label: 'PhonePe' },
];

export default function PaymentScreen({ navigation, route }: Props) {
  const { planId } = route.params;
  const { colors } = useThemeStore();
  const [method, setMethod] = useState<PaymentMethod>('card');
  const [loading, setLoading] = useState(false);
  const plan = PLAN_MAP[planId] ?? { name: 'Plan', price: '₹99.00' };

  const handlePay = async () => {
    setLoading(true);
    await new Promise<void>(resolve => setTimeout(() => resolve(), 2000));
    setLoading(false);
    navigation.replace('PaymentSuccess');
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Payment</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Order Summary */}
        <View style={[styles.summaryCard, { backgroundColor: colors.surface }, shadow.sm]}>
          <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>ResumePro AI Pro</Text>
          <Text style={[styles.planName, { color: colors.text }]}>{plan.name}</Text>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <View style={styles.totalRow}>
            <Text style={[styles.totalLabel, { color: colors.textSecondary }]}>Total</Text>
            <Text style={[styles.totalValue, { color: colors.primary }]}>{plan.price}</Text>
          </View>
        </View>

        {/* Payment Methods */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Payment Methods</Text>
        {PAYMENT_METHODS.map(m => (
          <TouchableOpacity
            key={m.id}
            onPress={() => setMethod(m.id)}
            style={[
              styles.methodCard,
              { backgroundColor: colors.surface },
              shadow.sm,
              method === m.id && { borderColor: colors.primary, borderWidth: 2 },
            ]}
            accessibilityRole="radio"
            accessibilityState={{ selected: method === m.id }}>
            <View style={[styles.methodIcon, { backgroundColor: colors.primary + '15' }]}>
              <Text style={{ fontSize: 18 }}>{m.icon}</Text>
            </View>
            <Text style={[styles.methodLabel, { color: colors.text }]}>{m.label}</Text>
            <View style={[styles.radio, { borderColor: method === m.id ? colors.primary : colors.border }]}>
              {method === m.id ? (
                <View style={[styles.radioFill, { backgroundColor: colors.primary }]} />
              ) : null}
            </View>
          </TouchableOpacity>
        ))}

        <View style={styles.secureRow}>
          <Text style={[styles.secureText, { color: colors.textMuted }]}>🔒 Secure Payment</Text>
        </View>

        <PrimaryButton
          label={`Pay ${plan.price}`}
          onPress={handlePay}
          loading={loading}
        />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  summaryCard: { borderRadius: radius.xl, padding: spacing.xxl, marginBottom: spacing.xxl },
  summaryLabel: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, marginBottom: spacing.xs },
  planName: { fontSize: fontSize.lg, fontFamily: fontFamily.semiBold, marginBottom: spacing.lg },
  divider: { height: 1, marginBottom: spacing.lg },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  totalLabel: { fontSize: fontSize.base, fontFamily: fontFamily.medium },
  totalValue: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  sectionTitle: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, marginBottom: spacing.lg },
  methodCard: { flexDirection: 'row', alignItems: 'center', borderRadius: radius.xl, padding: spacing.lg, marginBottom: spacing.md, borderWidth: 1.5, borderColor: 'transparent', gap: spacing.lg },
  methodIcon: { width: 44, height: 44, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center' },
  methodLabel: { flex: 1, fontSize: fontSize.base, fontFamily: fontFamily.medium },
  radio: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  radioFill: { width: 10, height: 10, borderRadius: 5 },
  secureRow: { alignItems: 'center', marginVertical: spacing.lg },
  secureText: { fontSize: fontSize.sm, fontFamily: fontFamily.regular },
});
