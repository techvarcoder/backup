import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AIToolsStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { TextField } from '../../components/inputs/TextField';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { Snackbar } from '../../components/common/Snackbar';

type Props = NativeStackScreenProps<AIToolsStackParamList, 'NoticePeriodCalculator'>;

const parseDDMMYYYY = (input: string): Date | null => {
  const match = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(input.trim());
  if (!match) { return null; }
  const day = parseInt(match[1], 10);
  const month = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  const date = new Date(year, month - 1, day);
  if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) {
    return null;
  }
  return date;
};

export default function NoticePeriodCalculatorScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const [resignDate, setResignDate] = useState('');
  const [noticeDays, setNoticeDays] = useState('');
  const [result, setResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '' });

  const handleCalculate = async () => {
    const startDate = parseDDMMYYYY(resignDate);
    if (!startDate) {
      setSnackbar({ visible: true, message: 'Enter a valid resignation date in dd/mm/yyyy format' });
      return;
    }
    setLoading(true);
    await new Promise<void>(resolve => setTimeout(() => resolve(), 600));
    const days = parseInt(noticeDays, 10) || 60;
    const d = new Date(startDate);
    d.setDate(d.getDate() + days);
    const lastDay = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' });
    setResult(lastDay);
    setLoading(false);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Notice Period Calculator</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={[styles.card, { backgroundColor: colors.surface }, shadow.sm]}>
          <TextField
            label="Resignation Date"
            value={resignDate}
            onChangeText={setResignDate}
            placeholder="dd/mm/yyyy"
          />
          <TextField
            label="Notice Period (days)"
            value={noticeDays}
            onChangeText={setNoticeDays}
            placeholder="e.g. 60 (2 Months)"
            keyboardType="numeric"
          />
          <PrimaryButton label="Calculate" onPress={handleCalculate} loading={loading} />
        </View>

        {result ? (
          <View style={[styles.resultCard, { backgroundColor: colors.surface }, shadow.md]}>
            <Text style={[styles.resultLabel, { color: colors.textSecondary }]}>Last Working Day</Text>
            <Text style={[styles.resultValue, { color: colors.primary }]}>{result}</Text>
            <Text style={[styles.noticeDaysText, { color: colors.textSecondary }]}>
              Notice period: {noticeDays || '60'} Days ({Math.ceil((parseInt(noticeDays, 10) || 60) / 30)} Months)
            </Text>
          </View>
        ) : null}
      </ScrollView>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type="error"
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  card: { borderRadius: radius.xl, padding: spacing.xxl, marginBottom: spacing.xl },
  resultCard: { borderRadius: radius.xl, padding: spacing.xxl, alignItems: 'center' },
  resultLabel: { fontSize: fontSize.sm, fontFamily: fontFamily.medium, marginBottom: spacing.sm },
  resultValue: { fontSize: fontSize.xxxl, fontFamily: fontFamily.bold, marginBottom: spacing.sm, textAlign: 'center' },
  noticeDaysText: { fontSize: fontSize.sm, fontFamily: fontFamily.regular },
});
