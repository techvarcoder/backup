import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AIToolsStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { TextField } from '../../components/inputs/TextField';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { Snackbar } from '../../components/common/Snackbar';
import { estimateSalaryRange, getOfferVerdict, SalaryEstimateResult, AINotConfiguredError } from '../../services/aiService';

type Props = NativeStackScreenProps<AIToolsStackParamList, 'SalaryCalculator'>;

const formatLPA = (n: number) => `₹${n.toFixed(1)} LPA`;

export default function SalaryCalculatorScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const [role, setRole] = useState('');
  const [experience, setExperience] = useState('');
  const [location, setLocation] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [skills, setSkills] = useState('');
  const [offer, setOffer] = useState('');
  const [result, setResult] = useState<SalaryEstimateResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '' });

  const handleCalculate = async () => {
    if (!role.trim()) { setSnackbar({ visible: true, message: 'Please enter a job role' }); return; }
    setLoading(true);
    try {
      const res = await estimateSalaryRange(role.trim(), experience, location, companyName.trim(), skills);
      setResult(res);
    } catch (err) {
      const message = err instanceof AINotConfiguredError
        ? err.message
        : 'Failed to calculate — please try again';
      setSnackbar({ visible: true, message });
    } finally {
      setLoading(false);
    }
  };

  const offerLPA = parseFloat(offer);
  const verdict = result && offer.trim() && !isNaN(offerLPA) && offerLPA > 0
    ? getOfferVerdict(offerLPA, result)
    : null;
  const verdictColor = verdict
    ? verdict.tone === 'error' ? colors.error : verdict.tone === 'success' ? colors.success : colors.warning
    : colors.text;
  const verdictBgColor = verdict
    ? verdict.tone === 'error' ? colors.errorLight : verdict.tone === 'success' ? colors.successLight : colors.warningLight
    : colors.surface;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Salary Calculator</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={[styles.card, { backgroundColor: colors.surface }, shadow.sm]}>
          <TextField label="Job Role *" value={role} onChangeText={setRole} placeholder="Software Engineer" />
          <TextField label="Company Name" value={companyName} onChangeText={setCompanyName} placeholder="e.g. Google" />
          <TextField label="Years of Experience" value={experience} onChangeText={setExperience} placeholder="4" keyboardType="numeric" />
          <TextField label="Location" value={location} onChangeText={setLocation} placeholder="Bangalore" />
          <TextField label="Skills" value={skills} onChangeText={setSkills} placeholder="e.g. React Native, TypeScript, AWS" hint="Separate with commas" />
          <TextField label="Do you have an offer? (LPA)" value={offer} onChangeText={setOffer} placeholder="e.g. 12" keyboardType="numeric" hint="Optional — we'll compare it to the market range" />
          <PrimaryButton label="Calculate" onPress={handleCalculate} loading={loading} />
        </View>

        {result ? (
          <View style={[styles.resultCard, { backgroundColor: colors.surface }, shadow.md]}>
            <Text style={[styles.resultTitle, { color: colors.text }]}>Salary Range</Text>
            <Text style={[styles.resultSubtitle, { color: colors.textSecondary }]}>
              {result.note}
            </Text>
            <View style={styles.rangeRow}>
              <View style={[styles.rangeItem, { backgroundColor: colors.errorLight }]}>
                <Text style={[styles.rangeLabel, { color: colors.error }]}>Min</Text>
                <Text style={[styles.rangeValue, { color: colors.error }]}>{formatLPA(result.min)}</Text>
              </View>
              <View style={[styles.rangeItem, { backgroundColor: colors.primary + '15' }]}>
                <Text style={[styles.rangeLabel, { color: colors.primary }]}>Average</Text>
                <Text style={[styles.rangeValue, { color: colors.primary }]}>{formatLPA(result.avg)}</Text>
              </View>
              <View style={[styles.rangeItem, { backgroundColor: colors.successLight }]}>
                <Text style={[styles.rangeLabel, { color: colors.success }]}>Max</Text>
                <Text style={[styles.rangeValue, { color: colors.success }]}>{formatLPA(result.max)}</Text>
              </View>
            </View>
          </View>
        ) : null}

        {verdict ? (
          <View style={[styles.verdictCard, { backgroundColor: verdictBgColor }, shadow.sm]}>
            <Text style={[styles.verdictLabel, { color: verdictColor }]}>{verdict.label}</Text>
            <Text style={[styles.verdictDetail, { color: verdictColor }]}>{verdict.detail}</Text>
          </View>
        ) : null}
      </ScrollView>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type="error"
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  card: { borderRadius: radius.xl, padding: spacing.xxl, marginBottom: spacing.xl },
  resultCard: { borderRadius: radius.xl, padding: spacing.xxl },
  resultTitle: { fontSize: fontSize.lg, fontFamily: fontFamily.bold, marginBottom: spacing.xs },
  resultSubtitle: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, marginBottom: spacing.xl },
  rangeRow: { flexDirection: 'row', gap: spacing.sm },
  rangeItem: { flex: 1, borderRadius: radius.lg, padding: spacing.lg, alignItems: 'center' },
  rangeLabel: { fontSize: fontSize.xs, fontFamily: fontFamily.medium, marginBottom: spacing.xs },
  rangeValue: { fontSize: fontSize.base, fontFamily: fontFamily.bold },
  verdictCard: { borderRadius: radius.xl, padding: spacing.xxl, marginTop: spacing.xl },
  verdictLabel: { fontSize: fontSize.lg, fontFamily: fontFamily.bold, marginBottom: spacing.xs },
  verdictDetail: { fontSize: fontSize.sm, fontFamily: fontFamily.regular },
});
