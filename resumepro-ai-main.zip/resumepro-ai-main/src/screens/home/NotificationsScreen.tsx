import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { HomeStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { EmptyState } from '../../components/common/EmptyState';

type Props = NativeStackScreenProps<HomeStackParamList, 'Notifications'>;

interface Notification {
  id: string;
  icon: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
}

const MOCK_NOTIFICATIONS: Notification[] = [
  { id: '1', icon: '🎯', title: 'ATS Score Improved!', message: 'Your resume score improved to 85/100 after recent edits.', time: '2h ago', read: false },
  { id: '2', icon: '👑', title: 'Premium Feature Available', message: 'Try Cover Letter Generator - available with Pro plan.', time: '1d ago', read: false },
  { id: '3', icon: '💡', title: 'Resume Tip', message: 'Add measurable achievements to increase your interview calls.', time: '2d ago', read: true },
];

export default function NotificationsScreen({ navigation }: Props) {
  const { colors } = useThemeStore();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Notifications</Text>
      </View>

      {MOCK_NOTIFICATIONS.length === 0 ? (
        <EmptyState title="No Notifications" description="You're all caught up!" />
      ) : (
        <FlatList
          data={MOCK_NOTIFICATIONS}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[
                styles.notifCard,
                { backgroundColor: item.read ? colors.surface : colors.primary + '08' },
                shadow.sm,
              ]}>
              <View style={[styles.notifIcon, { backgroundColor: colors.primary + '15' }]}>
                <Text style={{ fontSize: 22 }}>{item.icon}</Text>
              </View>
              <View style={styles.notifInfo}>
                <Text style={[styles.notifTitle, { color: colors.text }]}>{item.title}</Text>
                <Text style={[styles.notifMessage, { color: colors.textSecondary }]} numberOfLines={2}>
                  {item.message}
                </Text>
                <Text style={[styles.notifTime, { color: colors.textMuted }]}>{item.time}</Text>
              </View>
              {!item.read ? (
                <View style={[styles.unreadDot, { backgroundColor: colors.primary }]} />
              ) : null}
            </TouchableOpacity>
          )}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  list: { padding: spacing.xxl, paddingTop: 0 },
  notifCard: { flexDirection: 'row', alignItems: 'flex-start', borderRadius: radius.xl, padding: spacing.lg, marginBottom: spacing.md, gap: spacing.md },
  notifIcon: { width: 48, height: 48, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  notifInfo: { flex: 1 },
  notifTitle: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, marginBottom: 2 },
  notifMessage: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, lineHeight: 18, marginBottom: spacing.xs },
  notifTime: { fontSize: fontSize.xs, fontFamily: fontFamily.regular },
  unreadDot: { width: 8, height: 8, borderRadius: 4, marginTop: 6, flexShrink: 0 },
});
