import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import LinearGradient from 'react-native-linear-gradient';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { CompositeScreenProps } from '@react-navigation/native';
import { BottomTabScreenProps } from '@react-navigation/bottom-tabs';
import { HomeStackParamList, MainTabParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useAuthStore } from '../../store/useAuthStore';
import { useResumeStore } from '../../store/useResumeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { gradients } from '../../theme/colors';
import {
  SectionHeader,
  ResumeCard,
  AIFeatureCard,
  StatCard,
} from '../../components';

type Props = CompositeScreenProps<
  NativeStackScreenProps<HomeStackParamList, 'Home'>,
  BottomTabScreenProps<MainTabParamList>
>;

const AI_FEATURES = [
  { id: '1', title: 'AI Resume Writer', description: 'Generate a full resume with AI', icon: '✍️', gradient: ['#2563EB', '#1D4ED8'], screen: 'AIResumeWriter' },
  { id: '2', title: 'Improve Resume', description: 'Enhance your existing content', icon: '⚡', gradient: ['#7C3AED', '#5B21B6'], screen: 'AIResumeReview' },
  { id: '3', title: 'ATS Score', description: 'Check ATS compatibility score', icon: '🎯', gradient: ['#16A34A', '#15803D'], screen: 'ATSScore' },
  { id: '4', title: 'Cover Letter', description: 'Generate a professional letter', icon: '📝', gradient: ['#EA580C', '#C2410C'], screen: 'CoverLetter' },
];

const QUICK_ACTIONS = [
  { id: '1', icon: '📋', label: 'New Resume', color: '#2563EB', tab: 'ResumesTab', screen: 'CreateResume' },
  { id: '2', icon: '📑', label: 'Templates', color: '#7C3AED', tab: 'ResumesTab', screen: 'ResumeTemplates' },
  { id: '3', icon: '🤖', label: 'AI Tools', color: '#16A34A', tab: 'AIToolsTab', screen: 'AIToolsHub' },
  { id: '4', icon: '💰', label: 'Salary Calc', color: '#F59E0B', tab: 'AIToolsTab', screen: 'SalaryCalculator' },
] as const;

export default function HomeScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const { user } = useAuthStore();
  const { resumes } = useResumeStore();

  const firstName = user?.displayName?.split(' ')[0] ?? 'there';
  const recentResumes = resumes.slice(0, 3);

  const totalSkills = resumes.reduce((sum, r) => sum + r.skills.length, 0);
  const scoredResumes = resumes.filter(r => r.atsScore != null);
  const avgATS = scoredResumes.length > 0
    ? Math.round(scoredResumes.reduce((s, r) => s + (r.atsScore ?? 0), 0) / scoredResumes.length)
    : null;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <LinearGradient colors={gradients.primary} style={styles.headerGradient}>
          <View style={styles.headerRow}>
            <View>
              <Text style={styles.greeting}>Hi, {firstName} 👋</Text>
              <Text style={styles.greetingSubtitle}>Build your career!</Text>
            </View>
            <TouchableOpacity
              style={styles.notifBtn}
              onPress={() => navigation.navigate('Notifications')}
              accessibilityLabel="Notifications">
              <Text style={styles.notifIcon}>🔔</Text>
            </TouchableOpacity>
          </View>

          {/* Stats Row */}
          <View style={styles.statsRow}>
            <StatCard
              label="Resumes"
              value={String(resumes.length)}
              icon="📄"
              color="#2563EB"
              style={styles.statCard}
            />
            <View style={styles.statGap} />
            <StatCard
              label="Skill Sets"
              value={String(totalSkills)}
              icon="💡"
              color="#7C3AED"
              style={styles.statCard}
            />
            <View style={styles.statGap} />
            <StatCard
              label="Avg ATS"
              value={avgATS != null ? `${avgATS}%` : '--'}
              icon="🎯"
              color="#16A34A"
              style={styles.statCard}
            />
          </View>
        </LinearGradient>

        <View style={styles.body}>
          {/* Create Resume CTA */}
          <TouchableOpacity
            style={[styles.ctaCard, { backgroundColor: colors.surface }, shadow.md]}
            onPress={() => navigation.navigate('ResumesTab')}
            accessibilityRole="button">
            <Text style={[styles.ctaTitle, { color: colors.text }]}>Create New Resume</Text>
            <Text style={[styles.ctaSubtitle, { color: colors.textSecondary }]}>
              Choose from 40+ professional templates
            </Text>
            <View style={[styles.ctaButton, { backgroundColor: colors.primary }]}>
              <Text style={styles.ctaButtonText}>+ Create Resume</Text>
            </View>
          </TouchableOpacity>

          {/* Quick Actions */}
          <SectionHeader title="Quick Actions" />
          <View style={styles.quickActions}>
            {QUICK_ACTIONS.map(action => (
              <TouchableOpacity
                key={action.id}
                style={[styles.quickAction, { backgroundColor: colors.surface }, shadow.sm]}
                onPress={() => navigation.navigate(action.tab, { screen: action.screen } as any)}
                accessibilityRole="button"
                accessibilityLabel={action.label}>
                <View style={[styles.quickIcon, { backgroundColor: action.color + '15' }]}>
                  <Text style={styles.quickIconText}>{action.icon}</Text>
                </View>
                <Text style={[styles.quickLabel, { color: colors.text }]}>{action.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* AI Tools */}
          <SectionHeader
            title="AI Tools"
            actionLabel="See All"
            onAction={() => navigation.navigate('AIToolsTab')}
          />
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.hScroll}>
            {AI_FEATURES.map(feature => (
              <AIFeatureCard
                key={feature.id}
                title={feature.title}
                description={feature.description}
                icon={feature.icon}
                gradient={feature.gradient}
                onPress={() => navigation.navigate('AIToolsTab', { screen: feature.screen } as any)}
              />
            ))}
          </ScrollView>

          {/* Recent Resumes */}
          <SectionHeader
            title="Recent Resumes"
            actionLabel="See All"
            onAction={() => navigation.navigate('ResumesTab')}
          />
          {recentResumes.length === 0 ? (
            <View style={[styles.emptyResumes, { backgroundColor: colors.surface }, shadow.sm]}>
              <Text style={styles.emptyIcon}>📄</Text>
              <Text style={[styles.emptyTitle, { color: colors.text }]}>No resumes yet</Text>
              <Text style={[styles.emptySubtitle, { color: colors.textSecondary }]}>
                Create your first resume to get started
              </Text>
            </View>
          ) : (
            recentResumes.map(resume => (
              <ResumeCard
                key={resume.id}
                resume={resume}
                onPress={() => navigation.navigate('ResumesTab')}
              />
            ))
          )}

          {/* Premium Banner */}
          <LinearGradient colors={gradients.premium} style={styles.premiumBanner}>
            <Text style={styles.premiumTitle}>ResumePro AI Pro</Text>
            <Text style={styles.premiumSubtitle}>
              Unlock all premium features
            </Text>
            <View style={styles.premiumFeatures}>
              {['All Premium Templates', 'AI Writing Assistant', 'ATS Score Checker', 'Cover Letter Generator'].map(f => (
                <Text key={f} style={styles.premiumFeatureItem}>✓ {f}</Text>
              ))}
            </View>
            <TouchableOpacity
              style={styles.premiumCTA}
              onPress={() => navigation.navigate('ProfileTab')}
              accessibilityRole="button">
              <Text style={styles.premiumCTAText}>Upgrade Now</Text>
            </TouchableOpacity>
          </LinearGradient>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerGradient: {
    paddingTop: spacing.lg,
    paddingHorizontal: spacing.xxl,
    paddingBottom: spacing.xxxl + spacing.xxl,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: spacing.xxl,
  },
  greeting: {
    fontSize: fontSize.xxl,
    fontFamily: fontFamily.bold,
    color: '#FFFFFF',
  },
  greetingSubtitle: {
    fontSize: fontSize.base,
    fontFamily: fontFamily.regular,
    color: 'rgba(255,255,255,0.8)',
    marginTop: 2,
  },
  notifBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  notifIcon: { fontSize: 18 },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  statGap: { width: spacing.md },
  body: {
    marginTop: -spacing.xxl,
    padding: spacing.xxl,
  },
  ctaCard: {
    borderRadius: radius.xl,
    padding: spacing.xxl,
    marginBottom: spacing.xxl,
  },
  ctaTitle: {
    fontSize: fontSize.lg,
    fontFamily: fontFamily.bold,
    marginBottom: spacing.xs,
  },
  ctaSubtitle: {
    fontSize: fontSize.sm,
    fontFamily: fontFamily.regular,
    marginBottom: spacing.lg,
  },
  ctaButton: {
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
    paddingHorizontal: spacing.xxl,
    alignSelf: 'flex-start',
  },
  ctaButtonText: {
    color: '#FFFFFF',
    fontSize: fontSize.sm,
    fontFamily: fontFamily.semiBold,
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: spacing.xxl,
  },
  quickAction: {
    alignItems: 'center',
    flex: 1,
    marginHorizontal: 4,
    borderRadius: radius.lg,
    padding: spacing.md,
  },
  quickIcon: {
    width: 48,
    height: 48,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xs,
  },
  quickIconText: { fontSize: 22 },
  quickLabel: {
    fontSize: 11,
    fontFamily: fontFamily.medium,
    textAlign: 'center',
  },
  hScroll: { marginBottom: spacing.xxl },
  emptyResumes: {
    borderRadius: radius.xl,
    padding: spacing.xxl,
    alignItems: 'center',
    marginBottom: spacing.xxl,
  },
  emptyIcon: { fontSize: 40, marginBottom: spacing.md },
  emptyTitle: {
    fontSize: fontSize.md,
    fontFamily: fontFamily.semiBold,
    marginBottom: spacing.xs,
  },
  emptySubtitle: {
    fontSize: fontSize.sm,
    fontFamily: fontFamily.regular,
    textAlign: 'center',
  },
  premiumBanner: {
    borderRadius: radius.xl,
    padding: spacing.xxl,
    marginBottom: spacing.xxl,
  },
  premiumTitle: {
    fontSize: fontSize.lg,
    fontFamily: fontFamily.bold,
    color: '#FFFFFF',
    marginBottom: spacing.xs,
  },
  premiumSubtitle: {
    fontSize: fontSize.sm,
    fontFamily: fontFamily.regular,
    color: 'rgba(255,255,255,0.8)',
    marginBottom: spacing.lg,
  },
  premiumFeatures: { marginBottom: spacing.lg },
  premiumFeatureItem: {
    fontSize: fontSize.sm,
    fontFamily: fontFamily.regular,
    color: 'rgba(255,255,255,0.9)',
    marginBottom: spacing.xs,
  },
  premiumCTA: {
    backgroundColor: '#FFFFFF',
    borderRadius: radius.lg,
    paddingVertical: spacing.md,
    alignItems: 'center',
  },
  premiumCTAText: {
    color: '#7C3AED',
    fontSize: fontSize.base,
    fontFamily: fontFamily.bold,
  },
});
