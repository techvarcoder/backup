import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { APP_NAME, APP_VERSION } from '../../constants';

type Props = NativeStackScreenProps<ProfileStackParamList, 'About'>;

export default function AboutScreen({ navigation }: Props) {
  const { colors } = useThemeStore();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>About App</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={[styles.logoCard, { backgroundColor: colors.surface }, shadow.md]}>
          <View style={[styles.logoBox, { backgroundColor: colors.primary + '15' }]}>
            <Text style={styles.logoIcon}>📋</Text>
          </View>
          <Text style={[styles.appName, { color: colors.text }]}>{APP_NAME}</Text>
          <Text style={[styles.appTagline, { color: colors.textSecondary }]}>
            AI Powered Resume Builder
          </Text>
          <View style={[styles.versionBadge, { backgroundColor: colors.surfaceVariant }]}>
            <Text style={[styles.versionText, { color: colors.textSecondary }]}>
              Version {APP_VERSION}
            </Text>
          </View>
        </View>

        <View style={[styles.infoCard, { backgroundColor: colors.surface }, shadow.sm]}>
          <Text style={[styles.description, { color: colors.textSecondary }]}>
            ResumePro AI helps you build professional resumes using the power of AI. Create ATS-optimized resumes, generate cover letters, and track your job applications — all in one place.
          </Text>
        </View>

        <View style={[styles.linksCard, { backgroundColor: colors.surface }, shadow.sm]}>
          {[
            { icon: '🌐', label: 'Website', value: 'www.resumeproai.com' },
            { icon: '📧', label: 'Support', value: 'support@resumeproai.com' },
            { icon: '📱', label: 'Social Media', value: '@resumeproai' },
          ].map(link => (
            <View key={link.label} style={styles.linkRow}>
              <Text style={styles.linkIcon}>{link.icon}</Text>
              <View>
                <Text style={[styles.linkLabel, { color: colors.textSecondary }]}>{link.label}</Text>
                <Text style={[styles.linkValue, { color: colors.primary }]}>{link.value}</Text>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  logoCard: { borderRadius: radius.xl, padding: spacing.xxl, alignItems: 'center', marginBottom: spacing.xl },
  logoBox: { width: 80, height: 80, borderRadius: 20, alignItems: 'center', justifyContent: 'center', marginBottom: spacing.lg },
  logoIcon: { fontSize: 40 },
  appName: { fontSize: fontSize.xl, fontFamily: fontFamily.bold, marginBottom: spacing.xs },
  appTagline: { fontSize: fontSize.base, fontFamily: fontFamily.regular, marginBottom: spacing.lg },
  versionBadge: { borderRadius: radius.full, paddingHorizontal: spacing.lg, paddingVertical: spacing.xs },
  versionText: { fontSize: fontSize.xs, fontFamily: fontFamily.medium },
  infoCard: { borderRadius: radius.xl, padding: spacing.xxl, marginBottom: spacing.xl },
  description: { fontSize: fontSize.base, fontFamily: fontFamily.regular, lineHeight: 24 },
  linksCard: { borderRadius: radius.xl, padding: spacing.xxl },
  linkRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg, marginBottom: spacing.lg },
  linkIcon: { fontSize: 22 },
  linkLabel: { fontSize: fontSize.xs, fontFamily: fontFamily.regular },
  linkValue: { fontSize: fontSize.base, fontFamily: fontFamily.medium },
});
