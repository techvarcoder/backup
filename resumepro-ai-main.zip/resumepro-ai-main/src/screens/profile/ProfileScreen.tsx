import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useAuthStore } from '../../store/useAuthStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { ConfirmationDialog } from '../../components/common/ConfirmationDialog';
import LinearGradient from 'react-native-linear-gradient';
import { gradients } from '../../theme/colors';

type Props = NativeStackScreenProps<ProfileStackParamList, 'Profile'>;

interface MenuItem {
  id: string;
  icon: string;
  label: string;
  route?: keyof ProfileStackParamList;
  isDestructive?: boolean;
  badge?: string;
}

const MENU_SECTIONS: Array<{ title: string; items: MenuItem[] }> = [
  {
    title: 'Account',
    items: [
      { id: 'edit', icon: '✏️', label: 'Edit Profile', route: 'EditProfile' },
      { id: 'plan', icon: '👑', label: 'My Plan', route: 'Subscription' },
      { id: 'premium', icon: '⭐', label: 'Upgrade to Premium', route: 'Premium', badge: 'PRO' },
    ],
  },
  {
    title: 'Preferences',
    items: [
      { id: 'settings', icon: '⚙️', label: 'App Settings', route: 'Settings' },
      { id: 'notifications', icon: '🔔', label: 'Notification Settings', route: 'Settings' },
    ],
  },
  {
    title: 'Legal',
    items: [
      { id: 'privacy', icon: '🔒', label: 'Privacy Policy', route: 'PrivacyPolicy' },
      { id: 'terms', icon: '📋', label: 'Terms & Conditions', route: 'TermsAndConditions' },
    ],
  },
  {
    title: 'Support',
    items: [
      { id: 'help', icon: '❓', label: 'Help & Support', route: 'Help' },
      { id: 'feedback', icon: '💬', label: 'Send Feedback', route: 'Feedback' },
      { id: 'about', icon: 'ℹ️', label: 'About App', route: 'About' },
      { id: 'rate', icon: '⭐', label: 'Rate Us', route: undefined },
    ],
  },
  {
    title: 'Danger Zone',
    items: [
      { id: 'delete', icon: '🗑️', label: 'Delete Account', route: 'DeleteAccount', isDestructive: true },
    ],
  },
];

export default function ProfileScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const { user, isGuest, logout } = useAuthStore();
  const [logoutDialog, setLogoutDialog] = React.useState(false);

  const handleMenuPress = (item: MenuItem) => {
    if (item.route) {
      navigation.navigate(item.route as any);
    }
  };

  const handleLogout = () => {
    logout();
    setLogoutDialog(false);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={[styles.title, { color: colors.text }]}>Profile</Text>
        </View>

        {/* Guest Banner */}
        {isGuest ? (
          <LinearGradient colors={gradients.primary} style={[styles.guestBanner, { borderRadius: radius.xl }]}>
            <Text style={styles.guestIcon}>👤</Text>
            <Text style={styles.guestTitle}>You're browsing as Guest</Text>
            <Text style={styles.guestSubtitle}>
              Your resumes are saved locally. Create an account to sync across devices and unlock all features.
            </Text>
            <View style={styles.guestActions}>
              <TouchableOpacity
                style={styles.guestSignInBtn}
                onPress={() => logout()}
                accessibilityRole="button">
                <Text style={styles.guestSignInText}>Sign In</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.guestCreateBtn, { backgroundColor: 'rgba(255,255,255,0.2)' }]}
                onPress={() => logout()}
                accessibilityRole="button">
                <Text style={styles.guestCreateText}>Create Account</Text>
              </TouchableOpacity>
            </View>
          </LinearGradient>
        ) : (
          /* User Card */
          <View style={[styles.userCard, { backgroundColor: colors.surface }, shadow.md]}>
            <View style={[styles.avatar, { backgroundColor: colors.primary + '20' }]}>
              <Text style={styles.avatarText}>
                {(user?.displayName ?? 'U').charAt(0).toUpperCase()}
              </Text>
            </View>
            <View style={styles.userInfo}>
              <Text style={[styles.userName, { color: colors.text }]}>
                {user?.displayName ?? 'User'}
              </Text>
              <Text style={[styles.userEmail, { color: colors.textSecondary }]}>
                {user?.email ?? 'user@example.com'}
              </Text>
              {user?.isPremium ? (
                <View style={[styles.proBadge, { backgroundColor: colors.gold + '20' }]}>
                  <Text style={[styles.proBadgeText, { color: colors.gold }]}>⭐ PRO</Text>
                </View>
              ) : null}
            </View>
          </View>
        )}

        {/* Menu Sections */}
        {MENU_SECTIONS.filter(s => !isGuest || !['Account', 'Danger Zone'].includes(s.title)).map(section => (
          <View key={section.title} style={styles.section}>
            <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>
              {section.title}
            </Text>
            <View style={[styles.sectionCard, { backgroundColor: colors.surface }, shadow.sm]}>
              {section.items.map((item, idx) => (
                <React.Fragment key={item.id}>
                  <TouchableOpacity
                    style={styles.menuItem}
                    onPress={() => handleMenuPress(item)}
                    accessibilityRole="button"
                    accessibilityLabel={item.label}>
                    <Text style={styles.menuIcon}>{item.icon}</Text>
                    <Text
                      style={[
                        styles.menuLabel,
                        { color: item.isDestructive ? colors.error : colors.text },
                      ]}>
                      {item.label}
                    </Text>
                    {item.badge ? (
                      <View style={[styles.badge, { backgroundColor: colors.gold + '20' }]}>
                        <Text style={[styles.badgeText, { color: colors.gold }]}>{item.badge}</Text>
                      </View>
                    ) : null}
                    <Text style={[styles.menuArrow, { color: colors.textMuted }]}>→</Text>
                  </TouchableOpacity>
                  {idx < section.items.length - 1 ? (
                    <View style={[styles.separator, { backgroundColor: colors.border }]} />
                  ) : null}
                </React.Fragment>
              ))}
            </View>
          </View>
        ))}

        {/* Logout / Sign In */}
        {isGuest ? (
          <TouchableOpacity
            style={[styles.logoutBtn, { borderColor: colors.primary }]}
            onPress={() => logout()}
            accessibilityRole="button">
            <Text style={[styles.logoutText, { color: colors.primary }]}>🔑 Sign In / Create Account</Text>
          </TouchableOpacity>
        ) : (
          <TouchableOpacity
            style={[styles.logoutBtn, { borderColor: colors.error }]}
            onPress={() => setLogoutDialog(true)}
            accessibilityRole="button">
            <Text style={[styles.logoutText, { color: colors.error }]}>🚪 Sign Out</Text>
          </TouchableOpacity>
        )}
      </ScrollView>

      <ConfirmationDialog
        visible={logoutDialog}
        title="Sign Out"
        message="Are you sure you want to sign out of your account?"
        confirmLabel="Sign Out"
        cancelLabel="Cancel"
        onConfirm={handleLogout}
        onCancel={() => setLogoutDialog(false)}
        destructive
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { padding: spacing.xxl, paddingBottom: 40 },
  header: { marginBottom: spacing.xl },
  title: { fontSize: fontSize.xxl, fontFamily: fontFamily.bold },
  userCard: { flexDirection: 'row', alignItems: 'center', borderRadius: radius.xl, padding: spacing.lg, marginBottom: spacing.xxl, gap: spacing.lg },
  avatar: { width: 64, height: 64, borderRadius: 32, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 28, fontFamily: fontFamily.bold, color: '#2563EB' },
  userInfo: { flex: 1 },
  userName: { fontSize: fontSize.lg, fontFamily: fontFamily.bold, marginBottom: 2 },
  userEmail: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, marginBottom: spacing.xs },
  proBadge: { alignSelf: 'flex-start', borderRadius: radius.full, paddingHorizontal: spacing.sm, paddingVertical: 2 },
  proBadgeText: { fontSize: 10, fontFamily: fontFamily.bold },
  section: { marginBottom: spacing.xl },
  sectionTitle: { fontSize: fontSize.xs, fontFamily: fontFamily.semiBold, marginBottom: spacing.sm, letterSpacing: 0.8, textTransform: 'uppercase' },
  sectionCard: { borderRadius: radius.xl, overflow: 'hidden' },
  menuItem: { flexDirection: 'row', alignItems: 'center', padding: spacing.lg, gap: spacing.md },
  menuIcon: { fontSize: 20, width: 28 },
  menuLabel: { flex: 1, fontSize: fontSize.base, fontFamily: fontFamily.medium },
  badge: { borderRadius: radius.full, paddingHorizontal: spacing.sm, paddingVertical: 2, marginRight: spacing.sm },
  badgeText: { fontSize: 9, fontFamily: fontFamily.bold },
  menuArrow: { fontSize: 16 },
  separator: { height: 1, marginLeft: 64 },
  logoutBtn: { borderWidth: 1.5, borderRadius: radius.xl, padding: spacing.lg, alignItems: 'center', marginTop: spacing.xl },
  logoutText: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold },
  guestBanner: { padding: spacing.xxl, marginBottom: spacing.xxl, alignItems: 'center' },
  guestIcon: { fontSize: 48, marginBottom: spacing.md },
  guestTitle: { fontSize: fontSize.lg, fontFamily: fontFamily.bold, color: '#FFF', marginBottom: spacing.sm, textAlign: 'center' },
  guestSubtitle: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, color: 'rgba(255,255,255,0.85)', textAlign: 'center', lineHeight: 20, marginBottom: spacing.xl },
  guestActions: { flexDirection: 'row', gap: spacing.md, width: '100%' },
  guestSignInBtn: { flex: 1, backgroundColor: '#FFF', borderRadius: radius.lg, paddingVertical: spacing.md, alignItems: 'center' },
  guestSignInText: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, color: '#2563EB' },
  guestCreateBtn: { flex: 1, borderRadius: radius.lg, paddingVertical: spacing.md, alignItems: 'center', borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.5)' },
  guestCreateText: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, color: '#FFF' },
});
