import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { TextField } from '../../components/inputs/TextField';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { Snackbar } from '../../components/common/Snackbar';

type Props = NativeStackScreenProps<ProfileStackParamList, 'Feedback'>;

export default function FeedbackScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const [rating, setRating] = useState(0);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '' });

  const handleSubmit = async () => {
    if (!message.trim()) {
      setSnackbar({ visible: true, message: 'Please write your feedback' });
      return;
    }
    setLoading(true);
    await new Promise<void>(resolve => setTimeout(() => resolve(), 1000));
    setLoading(false);
    setSnackbar({ visible: true, message: 'Thank you for your feedback!' });
    setTimeout(() => navigation.goBack(), 1500);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
            <Text style={[styles.backText, { color: colors.text }]}>←</Text>
          </TouchableOpacity>
          <Text style={[styles.title, { color: colors.text }]}>Send Feedback</Text>
        </View>

        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={[styles.card, { backgroundColor: colors.surface }, shadow.sm]}>
            <Text style={[styles.ratingLabel, { color: colors.text }]}>How would you rate the app?</Text>
            <View style={styles.stars}>
              {[1, 2, 3, 4, 5].map(star => (
                <TouchableOpacity
                  key={star}
                  onPress={() => setRating(star)}
                  accessibilityRole="button"
                  accessibilityLabel={`Rate ${star} stars`}>
                  <Text style={[styles.star, { color: star <= rating ? '#F59E0B' : colors.border }]}>
                    ★
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <TextField
              label="Your Feedback"
              value={message}
              onChangeText={setMessage}
              placeholder="Tell us what you think..."
              multiline
              numberOfLines={5}
              style={{ minHeight: 120, textAlignVertical: 'top' }}
            />

            <PrimaryButton label="Submit Feedback" onPress={handleSubmit} loading={loading} />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type="success"
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  card: { borderRadius: radius.xl, padding: spacing.xxl },
  ratingLabel: { fontSize: fontSize.base, fontFamily: fontFamily.medium, marginBottom: spacing.lg, textAlign: 'center' },
  stars: { flexDirection: 'row', justifyContent: 'center', gap: spacing.md, marginBottom: spacing.xxl },
  star: { fontSize: 40 },
});
