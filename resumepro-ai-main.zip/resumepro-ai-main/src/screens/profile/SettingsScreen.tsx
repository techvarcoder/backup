import React from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useSettingsStore } from '../../store/useSettingsStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { ThemeMode } from '../../types';

type Props = NativeStackScreenProps<ProfileStackParamList, 'Settings'>;

export default function SettingsScreen({ navigation }: Props) {
  const { colors, mode, setMode } = useThemeStore();
  const { settings, updateSettings } = useSettingsStore();

  const THEMES: Array<{ id: ThemeMode; label: string }> = [
    { id: 'light', label: '☀️ Light' },
    { id: 'dark', label: '🌙 Dark' },
    { id: 'system', label: '⚙️ System' },
  ];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>App Settings</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Theme */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>APPEARANCE</Text>
          <View style={[styles.card, { backgroundColor: colors.surface }, shadow.sm]}>
            <Text style={[styles.label, { color: colors.text }]}>Theme</Text>
            <View style={styles.themeRow}>
              {THEMES.map(t => (
                <TouchableOpacity
                  key={t.id}
                  onPress={() => {
                    setMode(t.id);
                    updateSettings({ theme: t.id });
                  }}
                  style={[
                    styles.themeBtn,
                    {
                      backgroundColor: mode === t.id ? colors.primary : colors.surfaceVariant,
                      borderColor: mode === t.id ? colors.primary : colors.border,
                    },
                  ]}>
                  <Text style={[styles.themeBtnText, { color: mode === t.id ? '#FFF' : colors.text }]}>
                    {t.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>

        {/* Notifications */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>NOTIFICATIONS</Text>
          <View style={[styles.card, { backgroundColor: colors.surface }, shadow.sm]}>
            <View style={styles.toggleRow}>
              <Text style={[styles.toggleLabel, { color: colors.text }]}>Enable Notifications</Text>
              <Switch
                value={settings.notificationsEnabled}
                onValueChange={v => updateSettings({ notificationsEnabled: v })}
                trackColor={{ false: colors.border, true: colors.primary + '80' }}
                thumbColor={settings.notificationsEnabled ? colors.primary : colors.textMuted}
                accessibilityLabel="Enable notifications"
              />
            </View>
          </View>
        </View>

        {/* Backup */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>BACKUP</Text>
          <View style={[styles.card, { backgroundColor: colors.surface }, shadow.sm]}>
            <View style={styles.toggleRow}>
              <View>
                <Text style={[styles.toggleLabel, { color: colors.text }]}>Auto Backup</Text>
                <Text style={[styles.toggleSubtitle, { color: colors.textSecondary }]}>
                  Sync resumes to cloud
                </Text>
              </View>
              <Switch
                value={settings.autoBackup}
                onValueChange={v => updateSettings({ autoBackup: v })}
                trackColor={{ false: colors.border, true: colors.primary + '80' }}
                thumbColor={settings.autoBackup ? colors.primary : colors.textMuted}
                accessibilityLabel="Auto backup"
              />
            </View>
          </View>
        </View>

        {/* Export Format */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.textSecondary }]}>EXPORT</Text>
          <View style={[styles.card, { backgroundColor: colors.surface }, shadow.sm]}>
            <Text style={[styles.label, { color: colors.text }]}>Default Export Format</Text>
            <View style={styles.formatRow}>
              {(['pdf', 'docx'] as const).map(f => (
                <TouchableOpacity
                  key={f}
                  onPress={() => updateSettings({ exportFormat: f })}
                  style={[
                    styles.formatBtn,
                    {
                      backgroundColor: settings.exportFormat === f ? colors.primary : colors.surfaceVariant,
                      borderColor: settings.exportFormat === f ? colors.primary : colors.border,
                    },
                  ]}>
                  <Text style={[styles.formatBtnText, { color: settings.exportFormat === f ? '#FFF' : colors.text }]}>
                    {f.toUpperCase()}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  section: { marginBottom: spacing.xl },
  sectionTitle: { fontSize: 10, fontFamily: fontFamily.semiBold, letterSpacing: 0.8, textTransform: 'uppercase', marginBottom: spacing.sm },
  card: { borderRadius: radius.xl, padding: spacing.lg },
  label: { fontSize: fontSize.base, fontFamily: fontFamily.medium, marginBottom: spacing.md },
  themeRow: { flexDirection: 'row', gap: spacing.sm },
  themeBtn: { flex: 1, borderRadius: radius.lg, borderWidth: 1, padding: spacing.sm, alignItems: 'center' },
  themeBtnText: { fontSize: fontSize.sm, fontFamily: fontFamily.medium },
  toggleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  toggleLabel: { fontSize: fontSize.base, fontFamily: fontFamily.medium },
  toggleSubtitle: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, marginTop: 2 },
  formatRow: { flexDirection: 'row', gap: spacing.sm },
  formatBtn: { flex: 1, borderRadius: radius.lg, borderWidth: 1, padding: spacing.sm, alignItems: 'center' },
  formatBtnText: { fontSize: fontSize.sm, fontFamily: fontFamily.semiBold },
});
