import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';

type Props = NativeStackScreenProps<ProfileStackParamList, 'PrivacyPolicy'>;

const SECTIONS = [
  { title: 'Data Collection', content: 'We collect information you provide directly to us, such as your name, email address, and resume content. We do not sell your personal data to third parties.' },
  { title: 'How We Use Your Data', content: 'Your data is used to provide and improve our services, personalize your experience, and send important notifications about your account.' },
  { title: 'Data Storage', content: 'Your resume data is stored securely on our servers. We use industry-standard encryption to protect your information.' },
  { title: 'Your Rights', content: 'You have the right to access, update, or delete your personal data at any time through your profile settings or by contacting our support team.' },
  { title: 'Contact Us', content: 'If you have any questions about our privacy policy, please contact us at privacy@resumeproai.com.' },
];

export default function PrivacyPolicyScreen({ navigation }: Props) {
  const { colors } = useThemeStore();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Privacy Policy</Text>
      </View>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={[styles.updated, { color: colors.textMuted }]}>Last updated: January 2025</Text>
        {SECTIONS.map(section => (
          <View key={section.title} style={[styles.section, { backgroundColor: colors.surface }, shadow.sm]}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>{section.title}</Text>
            <Text style={[styles.sectionContent, { color: colors.textSecondary }]}>{section.content}</Text>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  updated: { fontSize: fontSize.xs, fontFamily: fontFamily.regular, marginBottom: spacing.lg },
  section: { borderRadius: radius.xl, padding: spacing.xxl, marginBottom: spacing.md },
  sectionTitle: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, marginBottom: spacing.sm },
  sectionContent: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, lineHeight: 22 },
});
