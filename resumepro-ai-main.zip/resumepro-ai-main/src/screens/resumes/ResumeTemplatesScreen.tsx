import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ResumeStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useResumeStore } from '../../store/useResumeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius } from '../../theme/spacing';
import { TemplateCard } from '../../components/cards/TemplateCard';
import { TEMPLATES } from '../../data/templates';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { isProLocked } from '../../constants';
import { Snackbar } from '../../components/common/Snackbar';

type Props = NativeStackScreenProps<ResumeStackParamList, 'ResumeTemplates'>;


const CATEGORIES = ['All', 'Professional', 'Modern', 'Minimal', 'Creative', 'ATS'] as const;

export default function ResumeTemplatesScreen({ navigation, route }: Props) {
  const { colors } = useThemeStore();
  const { activeResume, updateResume, addResume } = useResumeStore();
  const { resumeId } = route.params ?? {};
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [selected, setSelected] = useState(
    resumeId
      ? (activeResume?.templateId ?? 'professional-1')
      : 'professional-1',
  );
  const [snackbar, setSnackbar] = useState({ visible: false, message: '' });

  const filtered = activeCategory === 'All'
    ? TEMPLATES
    : TEMPLATES.filter(t => t.category === activeCategory);

  const handleApply = () => {
    if (resumeId) {
      updateResume(resumeId, { templateId: selected });
      setSnackbar({ visible: true, message: 'Template applied!' });
      setTimeout(() => navigation.goBack(), 1200);
    } else {
      const resume = addResume('My Resume');
      updateResume(resume.id, { templateId: selected });
      navigation.replace('ResumeEditor', { resumeId: resume.id });
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Choose Template</Text>
      </View>

      {/* Category Filters */}
      <FlatList
        data={CATEGORIES as unknown as string[]}
        horizontal
        showsHorizontalScrollIndicator={false}
        keyExtractor={item => item}
        contentContainerStyle={styles.categories}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => setActiveCategory(item)}
            style={[
              styles.categoryBtn,
              {
                backgroundColor: activeCategory === item ? colors.primary : colors.surfaceVariant,
                borderColor: activeCategory === item ? colors.primary : colors.border,
              },
            ]}>
            <Text
              style={[
                styles.categoryText,
                { color: activeCategory === item ? '#FFF' : colors.text },
              ]}>
              {item}
            </Text>
          </TouchableOpacity>
        )}
      />

      <FlatList
        data={filtered}
        numColumns={2}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.grid}
        renderItem={({ item }) => (
          <TemplateCard
            template={item}
            selected={selected === item.id}
            onPress={() => !isProLocked(item.isPremium) && setSelected(item.id)}
          />
        )}
        showsVerticalScrollIndicator={false}
      />

      <View style={[styles.applyBar, { backgroundColor: colors.surface }]}>
        <PrimaryButton
          label={resumeId ? 'Use This Template' : 'Create Resume with This Template'}
          onPress={handleApply}
        />
      </View>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type="success"
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.xxl,
    paddingBottom: spacing.md,
    gap: spacing.lg,
  },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  categories: {
    paddingHorizontal: spacing.xxl,
    gap: spacing.sm,
    marginBottom: spacing.lg,
  },
  categoryBtn: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: radius.full,
    borderWidth: 1,
  },
  categoryText: { fontSize: fontSize.sm, fontFamily: fontFamily.medium },
  grid: {
    paddingHorizontal: spacing.xxl,
    paddingBottom: 100,
  },
  applyBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: spacing.xxl,
    paddingBottom: spacing.xxxl,
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
  },
});
