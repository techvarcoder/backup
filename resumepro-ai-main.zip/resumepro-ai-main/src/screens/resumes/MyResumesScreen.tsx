import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActionSheetIOS,
  Platform,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ResumeStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useResumeStore } from '../../store/useResumeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { ResumeData } from '../../types';
import {
  SearchBar,
  ResumeCard,
  EmptyState,
  ConfirmationDialog,
  Snackbar,
} from '../../components';

type Props = NativeStackScreenProps<ResumeStackParamList, 'MyResumes'>;

export default function MyResumesScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const { resumes, deleteResume, duplicateResume, addSampleResume } = useResumeStore();
  const [search, setSearch] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '', type: 'success' as 'success' | 'error' });

  const filtered = resumes.filter(r =>
    r.title.toLowerCase().includes(search.toLowerCase()) ||
    r.personalInfo.jobTitle?.toLowerCase().includes(search.toLowerCase()),
  );

  const handleMenu = (resume: ResumeData) => {
    const options = ['Open', 'Duplicate', 'Delete', 'Cancel'];
    if (Platform.OS === 'ios') {
      ActionSheetIOS.showActionSheetWithOptions(
        { options, cancelButtonIndex: 3, destructiveButtonIndex: 2 },
        buttonIndex => {
          if (buttonIndex === 0) { navigation.navigate('ResumeEditor', { resumeId: resume.id }); }
          if (buttonIndex === 1) { handleDuplicate(resume.id); }
          if (buttonIndex === 2) { setDeleteTarget(resume.id); }
        },
      );
    } else {
      Alert.alert(resume.title, undefined, [
        { text: 'Open', onPress: () => navigation.navigate('ResumeEditor', { resumeId: resume.id }) },
        { text: 'Duplicate', onPress: () => handleDuplicate(resume.id) },
        { text: 'Delete', style: 'destructive', onPress: () => setDeleteTarget(resume.id) },
        { text: 'Cancel', style: 'cancel' },
      ]);
    }
  };

  const handleDuplicate = (id: string) => {
    duplicateResume(id);
    setSnackbar({ visible: true, message: 'Resume duplicated', type: 'success' });
  };

  const handleDelete = () => {
    if (deleteTarget) {
      deleteResume(deleteTarget);
      setDeleteTarget(null);
      setSnackbar({ visible: true, message: 'Resume deleted', type: 'success' });
    }
  };

  const handleLoadSample = () => {
    const sample = addSampleResume();
    setSnackbar({ visible: true, message: 'Sample resume loaded!', type: 'success' });
    navigation.navigate('ResumeEditor', { resumeId: sample.id });
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <Text style={[styles.title, { color: colors.text }]}>My Resumes</Text>
        <View style={styles.headerBtns}>
          <TouchableOpacity
            style={[styles.sampleBtn, { backgroundColor: colors.surfaceVariant, borderColor: colors.primary }]}
            onPress={handleLoadSample}
            accessibilityRole="button"
            accessibilityLabel="Load sample resume">
            <Text style={[styles.sampleBtnText, { color: colors.primary }]}>Sample</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.addBtn, { backgroundColor: colors.primary }]}
            onPress={() => navigation.navigate('CreateResume')}
            accessibilityRole="button"
            accessibilityLabel="Create new resume">
            <Text style={styles.addBtnText}>+ New</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.searchWrapper}>
        <SearchBar
          value={search}
          onChangeText={setSearch}
          placeholder="Search resumes..."
        />
      </View>

      {filtered.length === 0 && search === '' ? (
        <EmptyState
          title="No Resumes Yet"
          description="Create your first resume or load a sample to see how it looks."
          actionLabel="Load Sample Resume"
          onAction={handleLoadSample}
        />
      ) : filtered.length === 0 ? (
        <EmptyState
          title="No Results Found"
          description={`No resumes match "${search}"`}
        />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <ResumeCard
              resume={item}
              onPress={() => navigation.navigate('ResumeEditor', { resumeId: item.id })}
              onMenu={() => handleMenu(item)}
            />
          )}
          showsVerticalScrollIndicator={false}
        />
      )}

      <ConfirmationDialog
        visible={!!deleteTarget}
        title="Delete Resume"
        message="Are you sure you want to delete this resume? This action cannot be undone."
        confirmLabel="Delete"
        onConfirm={handleDelete}
        onCancel={() => setDeleteTarget(null)}
        destructive
      />

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type={snackbar.type}
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />

      <TouchableOpacity
        style={[styles.fab, { backgroundColor: colors.primary }, shadow.lg]}
        onPress={() => navigation.navigate('CreateResume')}
        accessibilityRole="button"
        accessibilityLabel="Create new resume">
        <Text style={styles.fabIcon}>+</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: spacing.xxl,
    paddingBottom: spacing.md,
  },
  title: { fontSize: fontSize.xxl, fontFamily: fontFamily.bold },
  headerBtns: { flexDirection: 'row', gap: spacing.sm, alignItems: 'center' },
  sampleBtn: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    borderRadius: radius.lg,
    borderWidth: 1.5,
  },
  sampleBtnText: { fontSize: fontSize.sm, fontFamily: fontFamily.semiBold },
  addBtn: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.sm,
    borderRadius: radius.lg,
  },
  addBtnText: { color: '#FFF', fontSize: fontSize.sm, fontFamily: fontFamily.semiBold },
  searchWrapper: { paddingHorizontal: spacing.xxl, marginBottom: spacing.lg },
  list: { paddingHorizontal: spacing.xxl, paddingBottom: 100 },
  fab: {
    position: 'absolute',
    bottom: 24,
    right: 24,
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
  },
  fabIcon: { color: '#FFF', fontSize: 28, fontWeight: 'bold' },
});
