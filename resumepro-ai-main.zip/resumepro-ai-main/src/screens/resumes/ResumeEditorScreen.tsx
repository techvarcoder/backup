import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
} from 'react-native-reanimated';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ResumeStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useResumeStore } from '../../store/useResumeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { Colors } from '../../theme/colors';
import { ResumeData, WorkExperience, Education, Skill, Project, Certificate, Language, Award, Reference } from '../../types';
import { SkillChip } from '../../components/common/SkillChip';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { TextField } from '../../components/inputs/TextField';
import { Snackbar } from '../../components/common/Snackbar';

type Props = NativeStackScreenProps<ResumeStackParamList, 'ResumeEditor'>;

interface AccordionProps {
  title: string;
  icon: string;
  completed?: boolean;
  children: React.ReactNode;
  colors: Colors;
}

const Accordion: React.FC<AccordionProps> = ({ title, icon, completed, children, colors }) => {
  const [open, setOpen] = useState(false);
  const height = useSharedValue(0);
  const opacity = useSharedValue(0);

  const toggle = useCallback(() => {
    if (open) {
      height.value = withTiming(0, { duration: 250 });
      opacity.value = withTiming(0, { duration: 200 });
    } else {
      height.value = withTiming(1, { duration: 250 });
      opacity.value = withTiming(1, { duration: 250 });
    }
    setOpen(v => !v);
  }, [open, height, opacity]);

  const contentStyle = useAnimatedStyle(() => ({
    display: height.value > 0 ? 'flex' : 'none',
    opacity: opacity.value,
  }));

  return (
    <View style={[styles.accordion, { backgroundColor: colors.surface }, shadow.sm]}>
      <TouchableOpacity
        onPress={toggle}
        style={styles.accordionHeader}
        accessibilityRole="button"
        accessibilityState={{ expanded: open }}>
        <View style={[styles.accordionIcon, { backgroundColor: colors.primary + '15' }]}>
          <Text style={{ fontSize: 18 }}>{icon}</Text>
        </View>
        <Text style={[styles.accordionTitle, { color: colors.text }]}>{title}</Text>
        <View style={styles.accordionRight}>
          {completed ? (
            <View style={[styles.completedDot, { backgroundColor: colors.success }]} />
          ) : null}
          <Text style={[styles.chevron, { color: colors.textMuted }]}>{open ? '▲' : '▼'}</Text>
        </View>
      </TouchableOpacity>
      <Animated.View style={[styles.accordionContent, contentStyle]}>
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        {children}
      </Animated.View>
    </View>
  );
};

export default function ResumeEditorScreen({ navigation, route }: Props) {
  const { resumeId } = route.params;
  const { colors } = useThemeStore();
  const { resumes, updateResume, setActiveResume, resetResume, _hasHydrated } = useResumeStore();
  const resume = resumes.find(r => r.id === resumeId);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '' });
  const [newSkill, setNewSkill] = useState('');

  if (!_hasHydrated) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.loadingContainer}>
          <Text style={[styles.loadingText, { color: colors.textSecondary }]}>Loading resume...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!resume) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.loadingContainer}>
          <Text style={[styles.errorText, { color: colors.error }]}>Resume not found</Text>
          <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginTop: 16 }}>
            <Text style={{ color: colors.primary, fontSize: 16 }}>← Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const update = (changes: Partial<ResumeData>) => {
    updateResume(resumeId, changes);
  };

  const updatePersonal = (field: string, value: string) => {
    update({ personalInfo: { ...resume.personalInfo, [field]: value } });
  };

  const addExperience = () => {
    const exp: WorkExperience = {
      id: Date.now().toString(),
      jobTitle: '',
      company: '',
      startDate: '',
      endDate: '',
      isPresent: false,
    };
    update({ workExperience: [...resume.workExperience, exp] });
  };

  const updateExperience = (id: string, field: string, value: string | boolean) => {
    update({
      workExperience: resume.workExperience.map(e =>
        e.id === id ? { ...e, [field]: value } : e,
      ),
    });
  };

  const removeExperience = (id: string) => {
    update({ workExperience: resume.workExperience.filter(e => e.id !== id) });
  };

  const addEducation = () => {
    const edu: Education = {
      id: Date.now().toString(),
      degree: '',
      institution: '',
      startYear: '',
    };
    update({ education: [...resume.education, edu] });
  };

  const updateEducation = (id: string, field: string, value: string) => {
    update({
      education: resume.education.map(e => (e.id === id ? { ...e, [field]: value } : e)),
    });
  };

  const removeEducation = (id: string) => {
    update({ education: resume.education.filter(e => e.id !== id) });
  };

  const addSkill = (name: string) => {
    if (!name.trim()) { return; }
    const skill: Skill = { id: Date.now().toString(), name: name.trim() };
    update({ skills: [...resume.skills, skill] });
  };

  const removeSkill = (id: string) => {
    update({ skills: resume.skills.filter(s => s.id !== id) });
  };

  const addProject = () => {
    const p: Project = { id: Date.now().toString(), name: '' };
    update({ projects: [...resume.projects, p] });
  };
  const updateProject = (id: string, field: string, value: string) => {
    update({ projects: resume.projects.map(p => p.id === id ? { ...p, [field]: value } : p) });
  };
  const removeProject = (id: string) => {
    update({ projects: resume.projects.filter(p => p.id !== id) });
  };

  const addCertificate = () => {
    const c: Certificate = { id: Date.now().toString(), name: '', issuer: '' };
    update({ certificates: [...resume.certificates, c] });
  };
  const updateCertificate = (id: string, field: string, value: string) => {
    update({ certificates: resume.certificates.map(c => c.id === id ? { ...c, [field]: value } : c) });
  };
  const removeCertificate = (id: string) => {
    update({ certificates: resume.certificates.filter(c => c.id !== id) });
  };

  const addLanguage = () => {
    const l: Language = { id: Date.now().toString(), name: '', proficiency: 'Intermediate' };
    update({ languages: [...resume.languages, l] });
  };
  const updateLanguage = (id: string, field: string, value: string) => {
    update({ languages: resume.languages.map(l => l.id === id ? { ...l, [field]: value } : l) });
  };
  const removeLanguage = (id: string) => {
    update({ languages: resume.languages.filter(l => l.id !== id) });
  };

  const addAward = () => {
    const a: Award = { id: Date.now().toString(), title: '' };
    update({ awards: [...resume.awards, a] });
  };
  const updateAward = (id: string, field: string, value: string) => {
    update({ awards: resume.awards.map(a => a.id === id ? { ...a, [field]: value } : a) });
  };
  const removeAward = (id: string) => {
    update({ awards: resume.awards.filter(a => a.id !== id) });
  };

  const addReference = () => {
    const r: Reference = { id: Date.now().toString(), name: '' };
    update({ references: [...resume.references, r] });
  };
  const updateReference = (id: string, field: string, value: string) => {
    update({ references: resume.references.map(r => r.id === id ? { ...r, [field]: value } : r) });
  };
  const removeReference = (id: string) => {
    update({ references: resume.references.filter(r => r.id !== id) });
  };

  const handleSave = () => {
    setActiveResume(resume);
    setSnackbar({ visible: true, message: 'Resume saved successfully' });
  };

  const handleReset = () => {
    Alert.alert(
      'Reset Resume',
      'This will clear all data in this resume. This cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reset',
          style: 'destructive',
          onPress: () => {
            resetResume(resumeId);
            setSnackbar({ visible: true, message: 'Resume has been reset' });
          },
        },
      ],
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity
          onPress={() => navigation.goBack()}
          accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: colors.text }]} numberOfLines={1}>
          {resume.title}
        </Text>
        <View style={styles.headerActions}>
          <TouchableOpacity
            onPress={handleReset}
            style={[styles.previewBtn, { borderColor: colors.error }]}
            accessibilityLabel="Reset resume">
            <Text style={[styles.previewBtnText, { color: colors.error }]}>Reset</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => navigation.navigate('ResumePreview', { resumeId })}
            style={[styles.previewBtn, { borderColor: colors.primary }]}
            accessibilityLabel="Preview resume">
            <Text style={[styles.previewBtnText, { color: colors.primary }]}>Preview</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Progress Bar */}
      <View style={styles.progressRow}>
        <Text style={[styles.progressLabel, { color: colors.textSecondary }]}>
          Profile Completion
        </Text>
        <Text style={[styles.progressValue, { color: colors.primary }]}>
          {Math.round(([resume.personalInfo.fullName, resume.personalInfo.email, resume.workExperience.length > 0, resume.education.length > 0, resume.skills.length > 0].filter(Boolean).length / 5) * 100)}%
        </Text>
      </View>
      <View style={[styles.progressBar, { backgroundColor: colors.border }]}>
        <View
          style={[
            styles.progressFill,
            {
              width: `${Math.round(([resume.personalInfo.fullName, resume.personalInfo.email, resume.workExperience.length > 0, resume.education.length > 0, resume.skills.length > 0].filter(Boolean).length / 5) * 100)}%` as any,
              backgroundColor: colors.primary,
            },
          ]}
        />
      </View>

      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}>

        {/* Personal Info */}
        <Accordion
          title="Personal Details"
          icon="👤"
          completed={!!resume.personalInfo.fullName && !!resume.personalInfo.email}
          colors={colors}>
          <TextField label="Full Name" value={resume.personalInfo.fullName} onChangeText={v => updatePersonal('fullName', v)} placeholder="John Doe" />
          <TextField label="Job Title" value={resume.personalInfo.jobTitle} onChangeText={v => updatePersonal('jobTitle', v)} placeholder="Senior Software Engineer" />
          <TextField label="Email" value={resume.personalInfo.email} onChangeText={v => updatePersonal('email', v)} placeholder="john@example.com" keyboardType="email-address" />
          <TextField label="Phone" value={resume.personalInfo.phone} onChangeText={v => updatePersonal('phone', v)} placeholder="+91 9876543210" keyboardType="phone-pad" />
          <TextField label="Location" value={resume.personalInfo.location} onChangeText={v => updatePersonal('location', v)} placeholder="Bangalore, India" />
          <TextField label="LinkedIn (optional)" value={resume.personalInfo.linkedin ?? ''} onChangeText={v => updatePersonal('linkedin', v)} placeholder="linkedin.com/in/johndoe" />
        </Accordion>

        {/* Professional Summary */}
        <Accordion
          title="Professional Summary"
          icon="📝"
          completed={!!resume.personalInfo.summary}
          colors={colors}>
          <TextField
            label="Summary"
            value={resume.personalInfo.summary ?? ''}
            onChangeText={v => updatePersonal('summary', v)}
            placeholder="Motivated professional with 4+ years of experience..."
            multiline
            numberOfLines={4}
            style={{ minHeight: 100, textAlignVertical: 'top' }}
          />
        </Accordion>

        {/* Work Experience */}
        <Accordion
          title="Work Experience"
          icon="💼"
          completed={resume.workExperience.length > 0}
          colors={colors}>
          {resume.workExperience.map((exp, idx) => (
            <View key={exp.id} style={[styles.entryCard, { backgroundColor: colors.surfaceVariant }]}>
              <View style={styles.entryHeader}>
                <Text style={[styles.entryIndex, { color: colors.textSecondary }]}>
                  Experience {idx + 1}
                </Text>
                <TouchableOpacity onPress={() => removeExperience(exp.id)}>
                  <Text style={{ color: colors.error, fontSize: 18 }}>✕</Text>
                </TouchableOpacity>
              </View>
              <TextField label="Job Title" value={exp.jobTitle} onChangeText={v => updateExperience(exp.id, 'jobTitle', v)} placeholder="Senior Software Engineer" />
              <TextField label="Company" value={exp.company} onChangeText={v => updateExperience(exp.id, 'company', v)} placeholder="Google" />
              <View style={styles.dateRow}>
                <TextField label="Start Date" value={exp.startDate} onChangeText={v => updateExperience(exp.id, 'startDate', v)} placeholder="Jan 2022" containerStyle={styles.dateField} />
                <TextField label="End Date" value={exp.endDate ?? ''} onChangeText={v => updateExperience(exp.id, 'endDate', v)} placeholder="Present" containerStyle={styles.dateField} />
              </View>
              <TextField label="Description" value={exp.description ?? ''} onChangeText={v => updateExperience(exp.id, 'description', v)} placeholder="Describe your role and achievements..." multiline numberOfLines={3} style={{ textAlignVertical: 'top', minHeight: 80 }} />
            </View>
          ))}
          <TouchableOpacity
            style={[styles.addItemBtn, { borderColor: colors.primary }]}
            onPress={addExperience}>
            <Text style={[styles.addItemText, { color: colors.primary }]}>+ Add Experience</Text>
          </TouchableOpacity>
        </Accordion>

        {/* Education */}
        <Accordion
          title="Education"
          icon="🎓"
          completed={resume.education.length > 0}
          colors={colors}>
          {resume.education.map((edu, idx) => (
            <View key={edu.id} style={[styles.entryCard, { backgroundColor: colors.surfaceVariant }]}>
              <View style={styles.entryHeader}>
                <Text style={[styles.entryIndex, { color: colors.textSecondary }]}>
                  Education {idx + 1}
                </Text>
                <TouchableOpacity onPress={() => removeEducation(edu.id)}>
                  <Text style={{ color: colors.error, fontSize: 18 }}>✕</Text>
                </TouchableOpacity>
              </View>
              <TextField label="Degree" value={edu.degree} onChangeText={v => updateEducation(edu.id, 'degree', v)} placeholder="Bachelor of Technology" />
              <TextField label="Institution" value={edu.institution} onChangeText={v => updateEducation(edu.id, 'institution', v)} placeholder="Anna University" />
              <TextField label="Field of Study" value={edu.fieldOfStudy ?? ''} onChangeText={v => updateEducation(edu.id, 'fieldOfStudy', v)} placeholder="Computer Science" />
              <View style={styles.dateRow}>
                <TextField label="Start Year" value={edu.startYear} onChangeText={v => updateEducation(edu.id, 'startYear', v)} placeholder="2016" containerStyle={styles.dateField} keyboardType="numeric" />
                <TextField label="End Year" value={edu.endYear ?? ''} onChangeText={v => updateEducation(edu.id, 'endYear', v)} placeholder="2020" containerStyle={styles.dateField} keyboardType="numeric" />
              </View>
            </View>
          ))}
          <TouchableOpacity
            style={[styles.addItemBtn, { borderColor: colors.primary }]}
            onPress={addEducation}>
            <Text style={[styles.addItemText, { color: colors.primary }]}>+ Add Education</Text>
          </TouchableOpacity>
        </Accordion>

        {/* Skills */}
        <Accordion
          title="Skills"
          icon="⚡"
          completed={resume.skills.length > 0}
          colors={colors}>
          <View style={styles.skillsWrap}>
            {resume.skills.map(skill => (
              <SkillChip
                key={skill.id}
                label={skill.name}
                selected
                removable
                onRemove={() => removeSkill(skill.id)}
              />
            ))}
          </View>
          <View style={styles.skillInputRow}>
            <TextInput
              value={newSkill}
              onChangeText={setNewSkill}
              placeholder="Add a skill..."
              placeholderTextColor={colors.textMuted}
              style={[
                styles.skillInput,
                { color: colors.text, borderColor: colors.border, backgroundColor: colors.surface },
              ]}
              onSubmitEditing={() => {
                addSkill(newSkill);
                setNewSkill('');
              }}
            />
            <TouchableOpacity
              style={[styles.skillAddBtn, { backgroundColor: colors.primary }]}
              onPress={() => { addSkill(newSkill); setNewSkill(''); }}>
              <Text style={{ color: '#FFF', fontWeight: 'bold' }}>+</Text>
            </TouchableOpacity>
          </View>
        </Accordion>

        {/* Projects */}
        <Accordion title="Projects" icon="🚀" completed={resume.projects.length > 0} colors={colors}>
          {resume.projects.map((proj, idx) => (
            <View key={proj.id} style={[styles.entryCard, { backgroundColor: colors.surfaceVariant }]}>
              <View style={styles.entryHeader}>
                <Text style={[styles.entryIndex, { color: colors.textSecondary }]}>Project {idx + 1}</Text>
                <TouchableOpacity onPress={() => removeProject(proj.id)}>
                  <Text style={{ color: colors.error, fontSize: 18 }}>✕</Text>
                </TouchableOpacity>
              </View>
              <TextField label="Project Name" value={proj.name} onChangeText={v => updateProject(proj.id, 'name', v)} placeholder="My Awesome App" />
              <TextField label="Description" value={proj.description ?? ''} onChangeText={v => updateProject(proj.id, 'description', v)} placeholder="Brief description of the project..." multiline numberOfLines={3} style={{ textAlignVertical: 'top', minHeight: 80 }} />
              <TextField label="Technologies" value={proj.technologies ?? ''} onChangeText={v => updateProject(proj.id, 'technologies', v)} placeholder="React Native, TypeScript, Firebase" />
              <TextField label="Link (optional)" value={proj.link ?? ''} onChangeText={v => updateProject(proj.id, 'link', v)} placeholder="https://github.com/..." keyboardType="url" />
              <View style={styles.dateRow}>
                <TextField label="Start Date" value={proj.startDate ?? ''} onChangeText={v => updateProject(proj.id, 'startDate', v)} placeholder="Jan 2024" containerStyle={styles.dateField} />
                <TextField label="End Date" value={proj.endDate ?? ''} onChangeText={v => updateProject(proj.id, 'endDate', v)} placeholder="Present" containerStyle={styles.dateField} />
              </View>
            </View>
          ))}
          <TouchableOpacity style={[styles.addItemBtn, { borderColor: colors.primary }]} onPress={addProject}>
            <Text style={[styles.addItemText, { color: colors.primary }]}>+ Add Project</Text>
          </TouchableOpacity>
        </Accordion>

        {/* Certificates */}
        <Accordion title="Certificates" icon="🏆" completed={resume.certificates.length > 0} colors={colors}>
          {resume.certificates.map((cert, idx) => (
            <View key={cert.id} style={[styles.entryCard, { backgroundColor: colors.surfaceVariant }]}>
              <View style={styles.entryHeader}>
                <Text style={[styles.entryIndex, { color: colors.textSecondary }]}>Certificate {idx + 1}</Text>
                <TouchableOpacity onPress={() => removeCertificate(cert.id)}>
                  <Text style={{ color: colors.error, fontSize: 18 }}>✕</Text>
                </TouchableOpacity>
              </View>
              <TextField label="Certificate Name" value={cert.name} onChangeText={v => updateCertificate(cert.id, 'name', v)} placeholder="AWS Certified Developer" />
              <TextField label="Issuing Organization" value={cert.issuer} onChangeText={v => updateCertificate(cert.id, 'issuer', v)} placeholder="Amazon Web Services" />
              <TextField label="Date" value={cert.date ?? ''} onChangeText={v => updateCertificate(cert.id, 'date', v)} placeholder="Mar 2024" />
              <TextField label="Credential Link (optional)" value={cert.link ?? ''} onChangeText={v => updateCertificate(cert.id, 'link', v)} placeholder="https://..." keyboardType="url" />
            </View>
          ))}
          <TouchableOpacity style={[styles.addItemBtn, { borderColor: colors.primary }]} onPress={addCertificate}>
            <Text style={[styles.addItemText, { color: colors.primary }]}>+ Add Certificate</Text>
          </TouchableOpacity>
        </Accordion>

        {/* Languages */}
        <Accordion title="Languages" icon="🌐" completed={resume.languages.length > 0} colors={colors}>
          {resume.languages.map((lang, idx) => (
            <View key={lang.id} style={[styles.entryCard, { backgroundColor: colors.surfaceVariant }]}>
              <View style={styles.entryHeader}>
                <Text style={[styles.entryIndex, { color: colors.textSecondary }]}>Language {idx + 1}</Text>
                <TouchableOpacity onPress={() => removeLanguage(lang.id)}>
                  <Text style={{ color: colors.error, fontSize: 18 }}>✕</Text>
                </TouchableOpacity>
              </View>
              <TextField label="Language" value={lang.name} onChangeText={v => updateLanguage(lang.id, 'name', v)} placeholder="English" />
              <View style={styles.proficiencyRow}>
                <Text style={[styles.proficiencyLabel, { color: colors.textSecondary }]}>Proficiency</Text>
                <View style={styles.proficiencyChips}>
                  {(['Beginner', 'Elementary', 'Intermediate', 'Professional', 'Native'] as Language['proficiency'][]).map(level => (
                    <TouchableOpacity
                      key={level}
                      style={[
                        styles.proficiencyChip,
                        { borderColor: lang.proficiency === level ? colors.primary : colors.border },
                        lang.proficiency === level && { backgroundColor: colors.primary + '15' },
                      ]}
                      onPress={() => updateLanguage(lang.id, 'proficiency', level)}>
                      <Text style={[styles.proficiencyChipText, { color: lang.proficiency === level ? colors.primary : colors.textSecondary }]}>
                        {level}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            </View>
          ))}
          <TouchableOpacity style={[styles.addItemBtn, { borderColor: colors.primary }]} onPress={addLanguage}>
            <Text style={[styles.addItemText, { color: colors.primary }]}>+ Add Language</Text>
          </TouchableOpacity>
        </Accordion>

        {/* Awards */}
        <Accordion title="Awards" icon="🥇" completed={resume.awards.length > 0} colors={colors}>
          {resume.awards.map((award, idx) => (
            <View key={award.id} style={[styles.entryCard, { backgroundColor: colors.surfaceVariant }]}>
              <View style={styles.entryHeader}>
                <Text style={[styles.entryIndex, { color: colors.textSecondary }]}>Award {idx + 1}</Text>
                <TouchableOpacity onPress={() => removeAward(award.id)}>
                  <Text style={{ color: colors.error, fontSize: 18 }}>✕</Text>
                </TouchableOpacity>
              </View>
              <TextField label="Award Title" value={award.title} onChangeText={v => updateAward(award.id, 'title', v)} placeholder="Best Employee of the Year" />
              <TextField label="Issuing Organization" value={award.issuer ?? ''} onChangeText={v => updateAward(award.id, 'issuer', v)} placeholder="Company / Organization" />
              <TextField label="Date" value={award.date ?? ''} onChangeText={v => updateAward(award.id, 'date', v)} placeholder="Dec 2023" />
              <TextField label="Description (optional)" value={award.description ?? ''} onChangeText={v => updateAward(award.id, 'description', v)} placeholder="Brief description..." multiline numberOfLines={2} style={{ textAlignVertical: 'top', minHeight: 60 }} />
            </View>
          ))}
          <TouchableOpacity style={[styles.addItemBtn, { borderColor: colors.primary }]} onPress={addAward}>
            <Text style={[styles.addItemText, { color: colors.primary }]}>+ Add Award</Text>
          </TouchableOpacity>
        </Accordion>

        {/* References */}
        <Accordion title="References" icon="👥" completed={resume.references.length > 0} colors={colors}>
          {resume.references.map((ref, idx) => (
            <View key={ref.id} style={[styles.entryCard, { backgroundColor: colors.surfaceVariant }]}>
              <View style={styles.entryHeader}>
                <Text style={[styles.entryIndex, { color: colors.textSecondary }]}>Reference {idx + 1}</Text>
                <TouchableOpacity onPress={() => removeReference(ref.id)}>
                  <Text style={{ color: colors.error, fontSize: 18 }}>✕</Text>
                </TouchableOpacity>
              </View>
              <TextField label="Full Name" value={ref.name} onChangeText={v => updateReference(ref.id, 'name', v)} placeholder="John Smith" />
              <TextField label="Position" value={ref.position ?? ''} onChangeText={v => updateReference(ref.id, 'position', v)} placeholder="Engineering Manager" />
              <TextField label="Company" value={ref.company ?? ''} onChangeText={v => updateReference(ref.id, 'company', v)} placeholder="Google" />
              <TextField label="Email" value={ref.email ?? ''} onChangeText={v => updateReference(ref.id, 'email', v)} placeholder="john@example.com" keyboardType="email-address" />
              <TextField label="Phone" value={ref.phone ?? ''} onChangeText={v => updateReference(ref.id, 'phone', v)} placeholder="+91 9876543210" keyboardType="phone-pad" />
            </View>
          ))}
          <TouchableOpacity style={[styles.addItemBtn, { borderColor: colors.primary }]} onPress={addReference}>
            <Text style={[styles.addItemText, { color: colors.primary }]}>+ Add Reference</Text>
          </TouchableOpacity>
        </Accordion>

        <PrimaryButton label="Save Resume" onPress={handleSave} style={styles.saveBtn} />
      </ScrollView>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type="success"
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  loadingText: { fontSize: 16, fontFamily: fontFamily.regular },
  errorText: { fontSize: 16, fontFamily: fontFamily.medium },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.xxl,
    paddingBottom: spacing.md,
    gap: spacing.md,
  },
  backText: { fontSize: 24, paddingRight: spacing.xs },
  headerTitle: { flex: 1, fontSize: fontSize.lg, fontFamily: fontFamily.semiBold },
  headerActions: { flexDirection: 'row', gap: spacing.sm },
  previewBtn: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.xs,
    borderRadius: radius.lg,
    borderWidth: 1.5,
  },
  previewBtnText: { fontSize: fontSize.sm, fontFamily: fontFamily.semiBold },
  progressRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.xxl,
    marginBottom: spacing.xs,
  },
  progressLabel: { fontSize: fontSize.xs, fontFamily: fontFamily.regular },
  progressValue: { fontSize: fontSize.xs, fontFamily: fontFamily.semiBold },
  progressBar: {
    height: 4,
    marginHorizontal: spacing.xxl,
    borderRadius: 2,
    overflow: 'hidden',
    marginBottom: spacing.lg,
  },
  progressFill: { height: '100%', borderRadius: 2 },
  scrollContent: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  accordion: {
    borderRadius: radius.lg,
    marginBottom: spacing.md,
    overflow: 'hidden',
  },
  accordionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.lg,
  },
  accordionIcon: {
    width: 40,
    height: 40,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.md,
  },
  accordionTitle: { flex: 1, fontSize: fontSize.base, fontFamily: fontFamily.semiBold },
  accordionRight: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  completedDot: { width: 8, height: 8, borderRadius: 4 },
  chevron: { fontSize: 12 },
  accordionContent: { paddingHorizontal: spacing.lg, paddingBottom: spacing.lg },
  divider: { height: 1, marginBottom: spacing.lg },
  entryCard: {
    borderRadius: radius.md,
    padding: spacing.md,
    marginBottom: spacing.md,
  },
  entryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  entryIndex: { fontSize: fontSize.sm, fontFamily: fontFamily.semiBold },
  dateRow: { flexDirection: 'row', gap: spacing.md },
  dateField: { flex: 1 },
  addItemBtn: {
    borderRadius: radius.md,
    borderWidth: 1.5,
    borderStyle: 'dashed',
    padding: spacing.md,
    alignItems: 'center',
    marginTop: spacing.sm,
  },
  addItemText: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold },
  skillsWrap: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: spacing.md },
  skillInputRow: {
    flexDirection: 'row',
    gap: spacing.sm,
    alignItems: 'center',
  },
  skillInput: {
    flex: 1,
    height: 44,
    borderRadius: radius.md,
    borderWidth: 1.5,
    paddingHorizontal: spacing.md,
    fontSize: fontSize.base,
    fontFamily: fontFamily.regular,
  },
  skillAddBtn: {
    width: 44,
    height: 44,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  proficiencyRow: { marginTop: spacing.xs, marginBottom: spacing.sm },
  proficiencyLabel: { fontSize: fontSize.xs, fontFamily: fontFamily.semiBold, marginBottom: spacing.sm, textTransform: 'uppercase', letterSpacing: 0.5 },
  proficiencyChips: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  proficiencyChip: { paddingHorizontal: spacing.md, paddingVertical: spacing.xs, borderRadius: radius.full, borderWidth: 1.5 },
  proficiencyChipText: { fontSize: fontSize.xs, fontFamily: fontFamily.medium },
  saveBtn: { marginTop: spacing.xxl },
});
