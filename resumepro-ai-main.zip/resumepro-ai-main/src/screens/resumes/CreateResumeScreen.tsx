import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ResumeStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useResumeStore } from '../../store/useResumeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { TextField } from '../../components/inputs/TextField';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { Snackbar } from '../../components/common/Snackbar';
import { importResumeFile } from '../../utils/importResumeFile';
import { generateResumeSummary, AINotConfiguredError } from '../../services/aiService';
import { Skill } from '../../types';

type Props = NativeStackScreenProps<ResumeStackParamList, 'CreateResume'>;

interface Option {
  id: string;
  icon: string;
  title: string;
  subtitle: string;
}

const OPTIONS: Option[] = [
  { id: 'scratch', icon: '📄', title: 'Start from Scratch', subtitle: 'Create a new resume from a blank template.' },
  { id: 'ai', icon: '🤖', title: 'Use AI Assistant', subtitle: 'Let AI help you build your resume fast.' },
  { id: 'import', icon: '📤', title: 'Import Resume', subtitle: 'Upload your existing resume (PDF/DOCX).' },
];

export default function CreateResumeScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const { addResume, updateResume } = useResumeStore();
  const [title, setTitle] = useState('');
  const [selected, setSelected] = useState('scratch');
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(false);
  const [jobRole, setJobRole] = useState('');
  const [skills, setSkills] = useState('');
  const [experience, setExperience] = useState('');
  const [aiGenerating, setAiGenerating] = useState(false);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '', type: 'error' as 'success' | 'error' });

  const showError = (message: string) => setSnackbar({ visible: true, message, type: 'error' });

  const parseSkillsInput = (raw: string): Skill[] =>
    raw.split(',').map(s => s.trim()).filter(Boolean).map((name, i) => ({ id: `sk-${Date.now()}-${i}`, name }));

  const handleNext = () => {
    if (selected === 'import') { handleImportResume(); return; }
    if (selected === 'ai') { handleGenerateWithAI(); return; }
    const resumeTitle = title.trim() || 'My Resume';
    setLoading(true);
    const resume = addResume(resumeTitle);
    setLoading(false);
    navigation.replace('ResumeEditor', { resumeId: resume.id });
  };

  const handleGenerateWithAI = async () => {
    if (!jobRole.trim()) { showError('Please enter a job role'); return; }
    setAiGenerating(true);
    try {
      const result = await generateResumeSummary(jobRole.trim(), skills, experience);
      const resume = addResume(title.trim() || jobRole.trim());
      updateResume(resume.id, {
        personalInfo: { ...resume.personalInfo, jobTitle: jobRole.trim(), summary: result.summary },
        skills: parseSkillsInput(skills),
        workExperience: [{
          id: `we-${Date.now()}`,
          jobTitle: jobRole.trim(),
          company: '',
          location: '',
          startDate: '',
          endDate: '',
          isPresent: true,
          description: result.bullets.map(b => `- ${b}`).join('\n'),
        }],
      });
      navigation.replace('ResumeEditor', { resumeId: resume.id });
    } catch (err) {
      const message = err instanceof AINotConfiguredError
        ? err.message
        : 'Failed to generate — please try again';
      showError(message);
    } finally {
      setAiGenerating(false);
    }
  };

  const handleImportResume = async () => {
    setImporting(true);
    try {
      const result = await importResumeFile();
      if (result.status === 'cancelled') { return; }
      if (result.status === 'error') { showError(result.message); return; }

      const resumeTitle = title.trim() || result.suggestedTitle;
      const resume = addResume(resumeTitle);
      updateResume(resume.id, result.data);
      navigation.replace('ResumeEditor', { resumeId: resume.id });
    } finally {
      setImporting(false);
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <View style={styles.header}>
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={styles.backBtn}
            accessibilityLabel="Go back">
            <Text style={[styles.backText, { color: colors.text }]}>←</Text>
          </TouchableOpacity>
          <Text style={[styles.title, { color: colors.text }]}>Create New Resume</Text>
        </View>

        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
          pointerEvents={importing || aiGenerating ? 'none' : 'auto'}>
          <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>
            Choose how you want to start
          </Text>

          {OPTIONS.map(opt => (
            <TouchableOpacity
              key={opt.id}
              onPress={() => setSelected(opt.id)}
              style={[
                styles.optionCard,
                { backgroundColor: colors.surface },
                shadow.sm,
                selected === opt.id && {
                  borderColor: colors.primary,
                  borderWidth: 2,
                },
              ]}
              accessibilityRole="radio"
              accessibilityState={{ selected: selected === opt.id }}>
              <View style={[styles.optionIcon, { backgroundColor: colors.primary + '15' }]}>
                <Text style={styles.optionIconText}>{opt.icon}</Text>
              </View>
              <View style={styles.optionInfo}>
                <Text style={[styles.optionTitle, { color: colors.text }]}>{opt.title}</Text>
                <Text style={[styles.optionSubtitle, { color: colors.textSecondary }]}>
                  {opt.subtitle}
                </Text>
              </View>
              <View
                style={[
                  styles.radio,
                  { borderColor: selected === opt.id ? colors.primary : colors.border },
                ]}>
                {selected === opt.id ? (
                  <View style={[styles.radioFill, { backgroundColor: colors.primary }]} />
                ) : null}
              </View>
            </TouchableOpacity>
          ))}

          <View style={[styles.titleCard, { backgroundColor: colors.surface }, shadow.sm]}>
            <TextField
              label="Resume Title"
              value={title}
              onChangeText={setTitle}
              placeholder="e.g. Senior Software Engineer"
              hint="Give your resume a name to identify it easily"
            />
          </View>

          {selected === 'ai' ? (
            <View style={[styles.titleCard, { backgroundColor: colors.surface }, shadow.sm]}>
              <TextField label="Job Role *" value={jobRole} onChangeText={setJobRole} placeholder="e.g. React Native Developer" />
              <TextField label="Key Skills" value={skills} onChangeText={setSkills} placeholder="e.g. React Native, TypeScript, Firebase" hint="Separate with commas" />
              <TextField label="Years of Experience" value={experience} onChangeText={setExperience} placeholder="e.g. 4" keyboardType="numeric" />
            </View>
          ) : null}

          <PrimaryButton label="Next" onPress={handleNext} loading={loading || importing || aiGenerating} />
        </ScrollView>
      </KeyboardAvoidingView>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type={snackbar.type}
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: spacing.xxl,
    paddingBottom: spacing.lg,
    gap: spacing.lg,
  },
  backBtn: { padding: spacing.xs },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0 },
  sectionLabel: {
    fontSize: fontSize.base,
    fontFamily: fontFamily.medium,
    marginBottom: spacing.lg,
  },
  optionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.md,
    borderWidth: 1.5,
    borderColor: 'transparent',
  },
  optionIcon: {
    width: 48,
    height: 48,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.md,
  },
  optionIconText: { fontSize: 24 },
  optionInfo: { flex: 1 },
  optionTitle: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, marginBottom: 2 },
  optionSubtitle: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, lineHeight: 18 },
  radio: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioFill: { width: 10, height: 10, borderRadius: 5 },
  titleCard: {
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginTop: spacing.lg,
    marginBottom: spacing.xxl,
  },
});
