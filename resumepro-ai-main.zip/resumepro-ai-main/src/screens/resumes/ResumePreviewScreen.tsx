import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { WebView } from 'react-native-webview';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ResumeStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useResumeStore } from '../../store/useResumeStore';
import { getTemplate } from '../../data/templates';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius } from '../../theme/spacing';
import { buildResumeHtml } from '../../utils/resumeHtmlTemplate';
import { Snackbar } from '../../components/common/Snackbar';

type Props = NativeStackScreenProps<ResumeStackParamList, 'ResumePreview'>;

export default function ResumePreviewScreen({ navigation, route }: Props) {
  const { resumeId } = route.params;
  const { colors } = useThemeStore();
  const { resumes, _hasHydrated } = useResumeStore();
  const [snackbar, setSnackbar] = React.useState({ visible: false, message: '' });
  const [webLoading, setWebLoading] = React.useState(true);
  const resume = resumes.find(r => r.id === resumeId);

  if (!_hasHydrated) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} />
        </View>
      </SafeAreaView>
    );
  }

  if (!resume) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={styles.center}>
          <Text style={{ color: colors.error, fontSize: 16 }}>Resume not found</Text>
          <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginTop: 16 }}>
            <Text style={{ color: colors.primary, fontSize: 16 }}>← Go Back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const template = getTemplate(resume.templateId);
  const html = buildResumeHtml(resume, template.accentColor, resume.templateId);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.toolbar}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <View style={styles.toolbarCenter}>
          <Text style={[styles.toolbarTitle, { color: colors.text }]} numberOfLines={1}>{resume.title}</Text>
          <Text style={[styles.toolbarTemplate, { color: colors.textSecondary }]}>{template.name}</Text>
        </View>
        <View style={styles.toolbarActions}>
          <TouchableOpacity
            style={[styles.toolbarBtn, { backgroundColor: colors.surfaceVariant }]}
            onPress={() => navigation.navigate('ResumeEditor', { resumeId })}
            accessibilityLabel="Edit resume">
            <Text style={styles.toolbarBtnText}>✏️</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.toolbarBtn, { backgroundColor: colors.surfaceVariant }]}
            onPress={() => navigation.navigate('ResumeTemplates', { resumeId })}
            accessibilityLabel="Change template">
            <Text style={styles.toolbarBtnText}>🎨</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.toolbarBtn, { backgroundColor: colors.surfaceVariant }]}
            onPress={() => navigation.navigate('ExportResume', { resumeId })}
            accessibilityLabel="Export resume">
            <Text style={styles.toolbarBtnText}>⬇️</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.webContainer}>
        {webLoading && (
          <View style={[styles.webLoader, { backgroundColor: colors.background }]}>
            <ActivityIndicator size="large" color={colors.primary} />
            <Text style={[styles.webLoaderText, { color: colors.textSecondary }]}>Rendering template...</Text>
          </View>
        )}
        <WebView
          source={{ html }}
          style={styles.webView}
          originWhitelist={['*']}
          scrollEnabled
          showsVerticalScrollIndicator={false}
          onLoadEnd={() => setWebLoading(false)}
        />
      </View>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type="success"
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  toolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.xxl,
    paddingVertical: spacing.md,
    gap: spacing.md,
  },
  backText: { fontSize: 24, paddingRight: spacing.xs },
  toolbarCenter: { flex: 1 },
  toolbarTitle: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold },
  toolbarTemplate: { fontSize: fontSize.xs, fontFamily: fontFamily.regular },
  toolbarActions: { flexDirection: 'row', gap: spacing.sm },
  toolbarBtn: {
    width: 36,
    height: 36,
    borderRadius: radius.sm,
    alignItems: 'center',
    justifyContent: 'center',
  },
  toolbarBtnText: { fontSize: 16 },
  webContainer: { flex: 1, position: 'relative' },
  webLoader: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10,
  },
  webLoaderText: { marginTop: 12, fontSize: fontSize.sm, fontFamily: fontFamily.regular },
  webView: { flex: 1, backgroundColor: '#fff' },
});
