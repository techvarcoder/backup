import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  PermissionsAndroid,
  Platform,
  Share,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { generatePDF } from 'react-native-html-to-pdf';
import RNFS from 'react-native-fs';
import { ResumeStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useResumeStore } from '../../store/useResumeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { isProLocked } from '../../constants';
import { Snackbar } from '../../components/common/Snackbar';
import { buildResumeHtml } from '../../utils/resumeHtmlTemplate';
import { buildDocx } from '../../utils/resumeDocxBuilder';
import { getTemplate } from '../../data/templates';

type Props = NativeStackScreenProps<ResumeStackParamList, 'ExportResume'>;

interface ExportOption {
  id: string;
  icon: string;
  format: string;
  description: string;
  isPremium: boolean;
}

const EXPORT_OPTIONS: ExportOption[] = [
  { id: 'pdf',   icon: '📄', format: 'Download PDF',  description: 'Export as PDF to your device',      isPremium: false },
  { id: 'share', icon: '📤', format: 'Share PDF',      description: 'Share via WhatsApp, Gmail, etc.',   isPremium: false },
  { id: 'docx',  icon: '📝', format: 'Save as Word',   description: 'Export as .docx format',            isPremium: true  },
];

async function requestStoragePermission(): Promise<boolean> {
  if (Platform.OS !== 'android') { return true; }
  if (Platform.Version >= 29) { return true; }
  const granted = await PermissionsAndroid.request(
    PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
    {
      title: 'Storage Permission',
      message: 'ResumePro needs storage access to save your file.',
      buttonPositive: 'Allow',
      buttonNegative: 'Deny',
    },
  );
  return granted === PermissionsAndroid.RESULTS.GRANTED;
}

/** Sanitize user-entered name → safe file name without extension */
function sanitize(name: string): string {
  return name.trim().replace(/[^a-zA-Z0-9 _-]/g, '').replace(/\s+/g, '_') || 'Resume';
}

export default function ExportResumeScreen({ navigation, route }: Props) {
  const { resumeId } = route.params;
  const { colors } = useThemeStore();
  const { resumes } = useResumeStore();
  const resume = resumes.find(r => r.id === resumeId);

  const defaultName = resume?.title ?? 'Resume';
  const [selectedFormat, setSelectedFormat] = useState('pdf');
  const [fileName, setFileName] = useState(defaultName);
  const [loading, setLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '', type: 'success' as 'success' | 'error' });

  const showMsg = (message: string, type: 'success' | 'error') =>
    setSnackbar({ visible: true, message, type });

  const generatePdf = async (name: string): Promise<string | null> => {
    if (!resume) { return null; }
    const html = buildResumeHtml(resume, getTemplate(resume.templateId).accentColor);
    const result = await generatePDF({ html, fileName: name, directory: 'Downloads', base64: false });
    return result.filePath ?? null;
  };

  const handleDownload = async () => {
    if (!resume) { showMsg('Resume not found', 'error'); return; }
    const hasPermission = await requestStoragePermission();
    if (!hasPermission) { showMsg('Storage permission denied', 'error'); return; }
    setLoading(true);
    try {
      const name = sanitize(fileName);
      const tempPath = await generatePdf(name);
      if (!tempPath) { showMsg('Failed to generate PDF', 'error'); return; }
      const destPath = `${RNFS.DownloadDirectoryPath}/${name}.pdf`;
      await RNFS.copyFile(tempPath, destPath);
      if (Platform.OS === 'android') { await RNFS.scanFile(destPath).catch(() => {}); }
      showMsg(`Saved: ${name}.pdf`, 'success');
    } catch {
      showMsg('Error saving PDF', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleShare = async () => {
    if (!resume) { showMsg('Resume not found', 'error'); return; }
    setLoading(true);
    try {
      const name = sanitize(fileName);
      const tempPath = await generatePdf(name);
      if (!tempPath) { showMsg('Failed to generate PDF', 'error'); return; }
      // Use the temp path directly — avoids FileUriExposedException on Android 7+
      await Share.share({ title: `${name}.pdf`, url: `file://${tempPath}`, message: `My resume: ${resume.title}` });
    } catch {
      showMsg('Error sharing PDF', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleWordExport = async () => {
    if (!resume) { showMsg('Resume not found', 'error'); return; }
    const hasPermission = await requestStoragePermission();
    if (!hasPermission) { showMsg('Storage permission denied', 'error'); return; }
    setLoading(true);
    try {
      const name = sanitize(fileName);
      const accent = getTemplate(resume.templateId).accentColor;
      await buildDocx(resume, accent, name);
      showMsg(`Saved: ${name}.docx to Downloads`, 'success');
    } catch {
      showMsg('Error generating Word file', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleExport = () => {
    if (selectedFormat === 'pdf')   { handleDownload(); }
    else if (selectedFormat === 'share') { handleShare(); }
    else if (selectedFormat === 'docx')  { handleWordExport(); }
  };

  const exportLabel = selectedFormat === 'share' ? 'Share PDF' : selectedFormat === 'docx' ? 'Save as Word' : 'Download PDF';

  if (!resume) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
        <Text style={{ padding: 24, color: colors.error }}>Resume not found</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Export Resume</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <View style={[styles.resumeInfo, { backgroundColor: colors.surface }, shadow.sm]}>
          <Text style={styles.resumeIcon}>📋</Text>
          <View style={styles.resumeInfoText}>
            <Text style={[styles.resumeName, { color: colors.text }]} numberOfLines={1}>{resume.title}</Text>
            <Text style={[styles.resumeMeta, { color: colors.textSecondary }]}>
              {[
                resume.workExperience.length > 0 && 'Experience',
                resume.education.length > 0 && 'Education',
                resume.skills.length > 0 && `${resume.skills.length} Skills`,
              ].filter(Boolean).join(' · ')}
            </Text>
          </View>
        </View>

        {/* File name input */}
        <Text style={[styles.sectionLabel, { color: colors.textSecondary }]}>File Name</Text>
        <View style={[styles.fileNameRow, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <TextInput
            style={[styles.fileNameInput, { color: colors.text }]}
            value={fileName}
            onChangeText={setFileName}
            placeholder="Enter file name"
            placeholderTextColor={colors.textSecondary}
            autoCapitalize="none"
            autoCorrect={false}
            returnKeyType="done"
          />
          <Text style={[styles.extBadge, { color: colors.textSecondary, backgroundColor: colors.background }]}>
            {selectedFormat === 'docx' ? '.docx' : '.pdf'}
          </Text>
        </View>

        <Text style={[styles.sectionLabel, { color: colors.textSecondary, marginTop: spacing.lg }]}>Export As</Text>

        {EXPORT_OPTIONS.map(opt => (
          <TouchableOpacity
            key={opt.id}
            onPress={() => !isProLocked(opt.isPremium) && setSelectedFormat(opt.id)}
            style={[
              styles.optionCard,
              { backgroundColor: colors.surface },
              shadow.sm,
              selectedFormat === opt.id && { borderColor: colors.primary, borderWidth: 2 },
              isProLocked(opt.isPremium) && { opacity: 0.6 },
            ]}
            accessibilityRole="radio"
            accessibilityState={{ selected: selectedFormat === opt.id }}>
            <Text style={styles.optionIcon}>{opt.icon}</Text>
            <View style={styles.optionInfo}>
              <Text style={[styles.optionFormat, { color: colors.text }]}>{opt.format}</Text>
              <Text style={[styles.optionDesc, { color: colors.textSecondary }]}>{opt.description}</Text>
            </View>
            {isProLocked(opt.isPremium) ? (
              <View style={styles.proBadge}><Text style={styles.proBadgeText}>PRO</Text></View>
            ) : (
              <View style={[styles.radio, { borderColor: selectedFormat === opt.id ? colors.primary : colors.border }]}>
                {selectedFormat === opt.id && <View style={[styles.radioFill, { backgroundColor: colors.primary }]} />}
              </View>
            )}
          </TouchableOpacity>
        ))}

        <PrimaryButton label={exportLabel} onPress={handleExport} loading={loading} style={styles.exportBtn} />
      </ScrollView>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type={snackbar.type}
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: spacing.md, paddingBottom: 48 },
  resumeInfo: { flexDirection: 'row', alignItems: 'center', borderRadius: radius.lg, padding: spacing.lg, marginBottom: spacing.xl, gap: spacing.md },
  resumeIcon: { fontSize: 32 },
  resumeInfoText: { flex: 1 },
  resumeName: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, marginBottom: 2 },
  resumeMeta: { fontSize: fontSize.xs, fontFamily: fontFamily.regular },
  sectionLabel: { fontSize: fontSize.sm, fontFamily: fontFamily.medium, marginBottom: spacing.md, textTransform: 'uppercase', letterSpacing: 0.5 },
  fileNameRow: { flexDirection: 'row', alignItems: 'center', borderWidth: 1.5, borderRadius: radius.md, paddingLeft: spacing.lg, marginBottom: spacing.xs, overflow: 'hidden' },
  fileNameInput: { flex: 1, fontSize: fontSize.base, fontFamily: fontFamily.regular, paddingVertical: spacing.md },
  extBadge: { paddingHorizontal: spacing.md, paddingVertical: spacing.md, fontSize: fontSize.sm, fontFamily: fontFamily.medium },
  optionCard: { flexDirection: 'row', alignItems: 'center', borderRadius: radius.lg, padding: spacing.lg, marginBottom: spacing.md, borderWidth: 1.5, borderColor: 'transparent' },
  optionIcon: { fontSize: 28, marginRight: spacing.lg },
  optionInfo: { flex: 1 },
  optionFormat: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, marginBottom: 2 },
  optionDesc: { fontSize: fontSize.sm, fontFamily: fontFamily.regular },
  proBadge: { backgroundColor: '#F59E0B', borderRadius: radius.full, paddingHorizontal: spacing.sm, paddingVertical: 2 },
  proBadgeText: { fontSize: 10, fontFamily: fontFamily.bold, color: '#FFF' },
  radio: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  radioFill: { width: 10, height: 10, borderRadius: 5 },
  exportBtn: { marginTop: spacing.xl },
});
