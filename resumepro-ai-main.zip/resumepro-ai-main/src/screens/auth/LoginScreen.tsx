import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useAuthStore } from '../../store/useAuthStore';
import { authService } from '../../services/firebase/auth';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { OutlinedButton } from '../../components/buttons/OutlinedButton';
import { TextField } from '../../components/inputs/TextField';
import { Snackbar } from '../../components/common/Snackbar';

type Props = NativeStackScreenProps<AuthStackParamList, 'Login'>;

export default function LoginScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const { setUser, continueAsGuest } = useAuthStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '', type: 'error' as 'error' | 'success' });

  const showError = (msg: string) =>
    setSnackbar({ visible: true, message: msg, type: 'error' });

  const handleLogin = async () => {
    if (!email.trim()) { showError('Please enter your email'); return; }
    if (!password) { showError('Please enter your password'); return; }
    setLoading(true);
    try {
      const result = await authService.signIn({ email: email.trim(), password });
      if (result.error) { showError(result.error); }
      else if (result.user) { setUser(result.user); }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setGoogleLoading(true);
    try {
      const result = await authService.signInWithGoogle();
      if (result.error) { showError(result.error); }
      else if (result.user) { setUser(result.user); }
    } finally {
      setGoogleLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <View style={[styles.logoBox, { backgroundColor: colors.primary + '15' }]}>
            <Text style={styles.logoIcon}>📋</Text>
          </View>
          <Text style={[styles.title, { color: colors.text }]}>Welcome Back 👋</Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
            Login to continue
          </Text>
        </View>

        <View style={[styles.card, { backgroundColor: colors.surface }, shadow.md]}>
          <TextField
            label="Email Address"
            value={email}
            onChangeText={setEmail}
            placeholder="john@example.com"
            keyboardType="email-address"
            autoCapitalize="none"
            autoComplete="email"
          />
          <TextField
            label="Password"
            value={password}
            onChangeText={setPassword}
            placeholder="Enter your password"
            isPassword
          />

          <TouchableOpacity
            onPress={() => navigation.navigate('ForgotPassword')}
            style={styles.forgotBtn}
            accessibilityRole="button">
            <Text style={[styles.forgotText, { color: colors.primary }]}>
              Forgot Password?
            </Text>
          </TouchableOpacity>

          <PrimaryButton label="Login" onPress={handleLogin} loading={loading} />

          <View style={styles.divider}>
            <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
            <Text style={[styles.dividerText, { color: colors.textMuted }]}>or</Text>
            <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
          </View>

          <OutlinedButton
            label="Continue with Google"
            onPress={handleGoogleLogin}
            loading={googleLoading}
          />
        </View>

        <View style={styles.footer}>
          <Text style={[styles.footerText, { color: colors.textSecondary }]}>
            Don't have an account?{' '}
          </Text>
          <TouchableOpacity
            onPress={() => navigation.navigate('Register')}
            accessibilityRole="button">
            <Text style={[styles.signupLink, { color: colors.primary }]}>Sign up</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.divider}>
          <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
          <Text style={[styles.dividerText, { color: colors.textMuted }]}>or</Text>
          <View style={[styles.dividerLine, { backgroundColor: colors.border }]} />
        </View>

        <TouchableOpacity
          style={[styles.guestBtn, { borderColor: colors.border }]}
          onPress={continueAsGuest}
          accessibilityRole="button"
          accessibilityLabel="Continue as guest">
          <Text style={styles.guestIcon}>👤</Text>
          <Text style={[styles.guestText, { color: colors.textSecondary }]}>Continue as Guest</Text>
        </TouchableOpacity>
        <Text style={[styles.guestNote, { color: colors.textMuted }]}>
          Your data will be saved locally. You can create an account anytime.
        </Text>
      </ScrollView>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type={snackbar.type}
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: {
    flexGrow: 1,
    padding: spacing.xxl,
    justifyContent: 'center',
  },
  header: { alignItems: 'center', marginBottom: spacing.xxl },
  logoBox: {
    width: 80,
    height: 80,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.lg,
  },
  logoIcon: { fontSize: 40 },
  title: {
    fontSize: fontSize.xxl,
    fontFamily: fontFamily.bold,
    marginBottom: spacing.xs,
  },
  subtitle: {
    fontSize: fontSize.base,
    fontFamily: fontFamily.regular,
  },
  card: {
    borderRadius: radius.xl,
    padding: spacing.xxl,
    marginBottom: spacing.xxl,
  },
  forgotBtn: { alignSelf: 'flex-end', marginBottom: spacing.lg },
  forgotText: { fontSize: fontSize.sm, fontFamily: fontFamily.medium },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: spacing.lg,
    gap: spacing.md,
  },
  dividerLine: { flex: 1, height: 1 },
  dividerText: { fontSize: fontSize.sm, fontFamily: fontFamily.regular },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  footerText: { fontSize: fontSize.base, fontFamily: fontFamily.regular },
  signupLink: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold },
  guestBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderRadius: radius.lg,
    paddingVertical: spacing.lg,
    gap: spacing.sm,
    marginBottom: spacing.md,
  },
  guestIcon: { fontSize: 18 },
  guestText: { fontSize: fontSize.base, fontFamily: fontFamily.medium },
  guestNote: {
    fontSize: fontSize.xs,
    fontFamily: fontFamily.regular,
    textAlign: 'center',
    lineHeight: 18,
    paddingBottom: spacing.xl,
  },
});
