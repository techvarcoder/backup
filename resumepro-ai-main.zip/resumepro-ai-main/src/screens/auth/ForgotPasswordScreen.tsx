import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { authService } from '../../services/firebase/auth';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { TextField } from '../../components/inputs/TextField';
import { Snackbar } from '../../components/common/Snackbar';

type Props = NativeStackScreenProps<AuthStackParamList, 'ForgotPassword'>;

export default function ForgotPasswordScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '', type: 'error' as 'error' | 'success' });

  const handleSend = async () => {
    if (!email.trim()) {
      setSnackbar({ visible: true, message: 'Please enter your email', type: 'error' });
      return;
    }
    setLoading(true);
    try {
      const result = await authService.sendPasswordResetEmail(email.trim());
      if (result.error) {
        setSnackbar({ visible: true, message: result.error, type: 'error' });
      } else {
        setSent(true);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={styles.content}>
        {sent ? (
          <View style={styles.successState}>
            <Text style={styles.successIcon}>📧</Text>
            <Text style={[styles.title, { color: colors.text }]}>Check Your Email</Text>
            <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
              We've sent a password reset link to{' '}
              <Text style={{ fontFamily: fontFamily.semiBold, color: colors.text }}>{email}</Text>
            </Text>
            <PrimaryButton
              label="Back to Login"
              onPress={() => navigation.navigate('Login')}
              style={styles.backBtn}
            />
          </View>
        ) : (
          <>
            <TouchableOpacity
              onPress={() => navigation.goBack()}
              style={styles.backArrow}
              accessibilityRole="button"
              accessibilityLabel="Go back">
              <Text style={[styles.backArrowText, { color: colors.text }]}>←</Text>
            </TouchableOpacity>

            <View style={styles.header}>
              <Text style={styles.headerIcon}>🔐</Text>
              <Text style={[styles.title, { color: colors.text }]}>Forgot Password?</Text>
              <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
                No worries, we'll send you reset instructions.
              </Text>
            </View>

            <View style={[styles.card, { backgroundColor: colors.surface }, shadow.md]}>
              <TextField
                label="Email Address"
                value={email}
                onChangeText={setEmail}
                placeholder="john@example.com"
                keyboardType="email-address"
                autoCapitalize="none"
                autoComplete="email"
              />
              <PrimaryButton label="Send Reset Link" onPress={handleSend} loading={loading} />
            </View>

            <TouchableOpacity
              onPress={() => navigation.navigate('Login')}
              style={styles.loginLink}
              accessibilityRole="button">
              <Text style={[styles.loginLinkText, { color: colors.primary }]}>
                Back to Login
              </Text>
            </TouchableOpacity>
          </>
        )}
      </View>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type={snackbar.type}
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: {
    flex: 1,
    padding: spacing.xxl,
    justifyContent: 'center',
  },
  backArrow: { position: 'absolute', top: 60, left: spacing.xxl },
  backArrowText: { fontSize: 24 },
  header: { alignItems: 'center', marginBottom: spacing.xxl },
  headerIcon: { fontSize: 56, marginBottom: spacing.lg },
  title: {
    fontSize: fontSize.xxl,
    fontFamily: fontFamily.bold,
    textAlign: 'center',
    marginBottom: spacing.sm,
  },
  subtitle: {
    fontSize: fontSize.base,
    fontFamily: fontFamily.regular,
    textAlign: 'center',
    lineHeight: 24,
  },
  card: {
    borderRadius: radius.xl,
    padding: spacing.xxl,
    marginBottom: spacing.xxl,
  },
  loginLink: { alignItems: 'center' },
  loginLinkText: { fontSize: fontSize.base, fontFamily: fontFamily.medium },
  successState: { alignItems: 'center', padding: spacing.lg },
  successIcon: { fontSize: 64, marginBottom: spacing.lg },
  backBtn: { marginTop: spacing.xxl, width: 200 },
});
