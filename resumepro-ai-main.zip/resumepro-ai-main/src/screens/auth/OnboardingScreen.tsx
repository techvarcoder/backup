import React, { useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Dimensions,
  TouchableOpacity,
  NativeScrollEvent,
  NativeSyntheticEvent,
  ListRenderItem,
} from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../navigation/types';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing } from '../../theme/spacing';
import { lightColors } from '../../theme/colors';
import { useAuthStore } from '../../store/useAuthStore';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';

const { width } = Dimensions.get('window');

interface Slide {
  id: string;
  icon: string;
  title: string;
  subtitle: string;
  gradient: string[];
}

const slides: Slide[] = [
  {
    id: '1',
    icon: '🤖',
    title: 'Create Impressive Resumes',
    subtitle: 'Professional templates designed to get you hired. Stand out from the crowd.',
    gradient: ['#1E3A8A', '#2563EB'],
  },
  {
    id: '2',
    icon: '✨',
    title: 'AI Powered Writing Assistant',
    subtitle: 'Get AI suggestions to write your best resume. Smart, fast, and tailored for you.',
    gradient: ['#1D4ED8', '#3B82F6'],
  },
  {
    id: '3',
    icon: '🎯',
    title: 'ATS Friendly & Professional',
    subtitle: 'Build ATS-optimized resumes that make it past automated screening every time.',
    gradient: ['#2563EB', '#60A5FA'],
  },
];

type Props = NativeStackScreenProps<AuthStackParamList, 'Onboarding'>;

export default function OnboardingScreen({ navigation }: Props) {
  const [activeIndex, setActiveIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);
  const { setHasOnboarded } = useAuthStore();

  const handleScroll = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const index = Math.round(e.nativeEvent.contentOffset.x / width);
    setActiveIndex(index);
  };

  const handleNext = () => {
    if (activeIndex < slides.length - 1) {
      flatListRef.current?.scrollToIndex({ index: activeIndex + 1, animated: true });
    } else {
      handleGetStarted();
    }
  };

  const handleGetStarted = () => {
    setHasOnboarded(true);
    navigation.replace('Login');
  };

  const renderSlide: ListRenderItem<Slide> = ({ item }) => (
    <LinearGradient colors={item.gradient} style={styles.slide}>
      <View style={styles.slideContent}>
        <View style={styles.iconWrapper}>
          <Text style={styles.slideIcon}>{item.icon}</Text>
        </View>
        <Text style={styles.slideTitle}>{item.title}</Text>
        <Text style={styles.slideSubtitle}>{item.subtitle}</Text>
      </View>
    </LinearGradient>
  );

  return (
    <View style={styles.container}>
      <FlatList
        ref={flatListRef}
        data={slides}
        renderItem={renderSlide}
        keyExtractor={item => item.id}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
      />

      <View style={styles.bottom}>
        <View style={styles.dots}>
          {slides.map((_, i) => (
            <View
              key={i}
              style={[
                styles.dot,
                i === activeIndex ? styles.activeDot : styles.inactiveDot,
              ]}
            />
          ))}
        </View>

        <PrimaryButton
          label={activeIndex === slides.length - 1 ? 'Get Started' : 'Next'}
          onPress={handleNext}
        />

        <TouchableOpacity
          onPress={handleGetStarted}
          style={styles.skipBtn}
          accessibilityRole="button"
          accessibilityLabel="Skip onboarding">
          <Text style={[styles.skipText, { color: lightColors.textSecondary }]}>
            Skip for now
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFFFFF' },
  slide: {
    width,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  slideContent: {
    alignItems: 'center',
    padding: spacing.xxxl,
  },
  iconWrapper: {
    width: 120,
    height: 120,
    borderRadius: 32,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.xxxl,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  slideIcon: { fontSize: 56 },
  slideTitle: {
    fontSize: fontSize.xxl,
    fontFamily: fontFamily.bold,
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: spacing.lg,
    lineHeight: 34,
  },
  slideSubtitle: {
    fontSize: fontSize.md,
    fontFamily: fontFamily.regular,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    lineHeight: 26,
  },
  bottom: {
    backgroundColor: '#FFFFFF',
    padding: spacing.xxl,
    paddingBottom: spacing.xxxl,
  },
  dots: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: spacing.xxl,
    gap: spacing.sm,
  },
  dot: { height: 8, borderRadius: 4 },
  activeDot: { width: 24, backgroundColor: '#2563EB' },
  inactiveDot: { width: 8, backgroundColor: '#E5E7EB' },
  skipBtn: { alignItems: 'center', marginTop: spacing.lg },
  skipText: { fontSize: fontSize.base, fontFamily: fontFamily.medium },
});
