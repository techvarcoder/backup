import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useAuthStore } from '../../store/useAuthStore';
import { authService } from '../../services/firebase/auth';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { TextField } from '../../components/inputs/TextField';
import { Snackbar } from '../../components/common/Snackbar';

type Props = NativeStackScreenProps<AuthStackParamList, 'Register'>;

export default function RegisterScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const { setUser } = useAuthStore();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [loading, setLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '', type: 'error' as 'error' | 'success' });

  const showError = (msg: string) =>
    setSnackbar({ visible: true, message: msg, type: 'error' });

  const handleRegister = async () => {
    if (!name.trim()) { showError('Please enter your name'); return; }
    if (!email.trim()) { showError('Please enter your email'); return; }
    if (password.length < 6) { showError('Password must be at least 6 characters'); return; }
    if (password !== confirmPassword) { showError('Passwords do not match'); return; }
    if (!agreedToTerms) { showError('Please agree to the Terms & Conditions'); return; }

    setLoading(true);
    try {
      const result = await authService.signUp({
        email: email.trim(),
        password,
        displayName: name.trim(),
      });
      if (result.error) { showError(result.error); }
      else if (result.user) { setUser(result.user); }
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <Text style={[styles.title, { color: colors.text }]}>Create Account</Text>
          <Text style={[styles.subtitle, { color: colors.textSecondary }]}>
            Let's get you started
          </Text>
        </View>

        <View style={[styles.card, { backgroundColor: colors.surface }, shadow.md]}>
          <TextField
            label="Full Name"
            value={name}
            onChangeText={setName}
            placeholder="John Doe"
            autoCapitalize="words"
          />
          <TextField
            label="Email Address"
            value={email}
            onChangeText={setEmail}
            placeholder="john@example.com"
            keyboardType="email-address"
            autoCapitalize="none"
          />
          <TextField
            label="Password"
            value={password}
            onChangeText={setPassword}
            placeholder="Min. 6 characters"
            isPassword
          />
          <TextField
            label="Confirm Password"
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            placeholder="Re-enter password"
            isPassword
          />

          <TouchableOpacity
            style={styles.termsRow}
            onPress={() => setAgreedToTerms(v => !v)}
            accessibilityRole="checkbox"
            accessibilityState={{ checked: agreedToTerms }}>
            <View
              style={[
                styles.checkbox,
                {
                  backgroundColor: agreedToTerms ? colors.primary : 'transparent',
                  borderColor: agreedToTerms ? colors.primary : colors.border,
                },
              ]}>
              {agreedToTerms ? <Text style={styles.checkmark}>✓</Text> : null}
            </View>
            <View style={styles.termsTextWrap}>
              <Text style={[styles.termsText, { color: colors.textSecondary }]}>
                I agree to the{' '}
              </Text>
              <TouchableOpacity>
                <Text style={[styles.termsLink, { color: colors.primary }]}>
                  Terms & Conditions
                </Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>

          <PrimaryButton label="Create Account" onPress={handleRegister} loading={loading} />
        </View>

        <View style={styles.footer}>
          <Text style={[styles.footerText, { color: colors.textSecondary }]}>
            Already have an account?{' '}
          </Text>
          <TouchableOpacity
            onPress={() => navigation.navigate('Login')}
            accessibilityRole="button">
            <Text style={[styles.loginLink, { color: colors.primary }]}>Sign in</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type={snackbar.type}
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: {
    flexGrow: 1,
    padding: spacing.xxl,
    justifyContent: 'center',
  },
  header: { marginBottom: spacing.xxl },
  title: {
    fontSize: fontSize.xxl,
    fontFamily: fontFamily.bold,
    marginBottom: spacing.xs,
  },
  subtitle: {
    fontSize: fontSize.base,
    fontFamily: fontFamily.regular,
  },
  card: {
    borderRadius: radius.xl,
    padding: spacing.xxl,
    marginBottom: spacing.xxl,
  },
  termsRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: spacing.xl,
    gap: spacing.md,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 4,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
  },
  checkmark: { color: '#FFF', fontSize: 12, fontWeight: 'bold' },
  termsTextWrap: { flex: 1, flexDirection: 'row', flexWrap: 'wrap' },
  termsText: { fontSize: fontSize.sm, fontFamily: fontFamily.regular },
  termsLink: { fontSize: fontSize.sm, fontFamily: fontFamily.semiBold },
  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  footerText: { fontSize: fontSize.base, fontFamily: fontFamily.regular },
  loginLink: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold },
});
