import { ResumeTemplate } from '../types';

export const TEMPLATES: ResumeTemplate[] = [
  // ── Original 8 ──────────────────────────────────────────────────────────────
  { id: 'professional-1', name: 'Professional',    category: 'Professional', isPremium: false, accentColor: '#2563EB' },
  { id: 'modern-1',       name: 'Modern Blue',     category: 'Modern',       isPremium: false, accentColor: '#3B82F6' },
  { id: 'minimal-1',      name: 'Minimal',         category: 'Minimal',      isPremium: false, accentColor: '#374151' },
  { id: 'creative-1',     name: 'Creative',        category: 'Creative',     isPremium: true,  accentColor: '#7C3AED' },
  { id: 'ats-1',          name: 'ATS Optimized',   category: 'ATS',          isPremium: false, accentColor: '#16A34A' },
  { id: 'professional-2', name: 'Executive',       category: 'Professional', isPremium: true,  accentColor: '#1E40AF' },
  { id: 'modern-2',       name: 'Tech Pro',        category: 'Modern',       isPremium: true,  accentColor: '#0891B2' },
  { id: 'minimal-2',      name: 'Clean Slate',     category: 'Minimal',      isPremium: false, accentColor: '#6B7280' },
  // ── New 12 ──────────────────────────────────────────────────────────────────
  { id: 'bold-1',         name: 'Bold Impact',     category: 'Modern',       isPremium: false, accentColor: '#DC2626' },
  { id: 'gradient-1',     name: 'Gradient',        category: 'Creative',     isPremium: true,  accentColor: '#8B5CF6' },
  { id: 'accent-1',       name: 'Side Accent',     category: 'Professional', isPremium: false, accentColor: '#0F766E' },
  { id: 'academic-1',     name: 'Academic CV',     category: 'Professional', isPremium: false, accentColor: '#1E3A5F' },
  { id: 'compact-1',      name: 'Compact',         category: 'Minimal',      isPremium: false, accentColor: '#374151' },
  { id: 'magazine-1',     name: 'Magazine',        category: 'Creative',     isPremium: true,  accentColor: '#BE185D' },
  { id: 'timeline-1',     name: 'Timeline',        category: 'Creative',     isPremium: true,  accentColor: '#7C3AED' },
  { id: 'finance-1',      name: 'Finance',         category: 'Professional', isPremium: true,  accentColor: '#92400E' },
  { id: 'startup-1',      name: 'Startup',         category: 'Modern',       isPremium: false, accentColor: '#2563EB' },
  { id: 'healthcare-1',   name: 'Healthcare',      category: 'Professional', isPremium: false, accentColor: '#0D9488' },
  { id: 'euro-1',         name: 'Euro CV',         category: 'Professional', isPremium: false, accentColor: '#1D4ED8' },
  { id: 'infographic-1',  name: 'Infographic',     category: 'Creative',     isPremium: true,  accentColor: '#D97706' },
  // ── New 20 ──────────────────────────────────────────────────────────────────
  { id: 'twocol-1',       name: 'Two-Column Grid', category: 'Modern',       isPremium: true,  accentColor: '#4F46E5' },
  { id: 'newspaper-1',    name: 'Newspaper',       category: 'Creative',     isPremium: false, accentColor: '#111827' },
  { id: 'dashboard-1',    name: 'Dashboard Stats', category: 'Modern',       isPremium: true,  accentColor: '#059669' },
  { id: 'boxed-1',        name: 'Boxed Frame',     category: 'Minimal',      isPremium: false, accentColor: '#1F2937' },
  { id: 'typewriter-1',   name: 'Typewriter',      category: 'Creative',     isPremium: false, accentColor: '#78350F' },
  { id: 'swiss-1',        name: 'Swiss Grid',      category: 'Modern',       isPremium: true,  accentColor: '#DC2626' },
  { id: 'kanban-1',       name: 'Kanban Board',    category: 'Creative',     isPremium: true,  accentColor: '#2563EB' },
  { id: 'ribbon-1',       name: 'Ribbon Header',   category: 'Creative',     isPremium: true,  accentColor: '#B91C1C' },
  { id: 'diagonal-1',     name: 'Split Diagonal',  category: 'Modern',       isPremium: true,  accentColor: '#0EA5E9' },
  { id: 'letterpress-1',  name: 'Letterpress',     category: 'Minimal',      isPremium: false, accentColor: '#57534E' },
  { id: 'blueprint-1',    name: 'Blueprint',       category: 'Modern',       isPremium: true,  accentColor: '#1D4ED8' },
  { id: 'chatbubble-1',   name: 'Chat Bubble',     category: 'Creative',     isPremium: true,  accentColor: '#10B981' },
  { id: 'vtabs-1',        name: 'Vertical Tabs',   category: 'Modern',       isPremium: true,  accentColor: '#7E22CE' },
  { id: 'foldertab-1',    name: 'Folder Tab',      category: 'Professional', isPremium: false, accentColor: '#B45309' },
  { id: 'stackedcards-1', name: 'Stacked Cards',   category: 'Creative',     isPremium: true,  accentColor: '#DB2777' },
  { id: 'halftone-1',     name: 'Halftone Pop',    category: 'Creative',     isPremium: true,  accentColor: '#F59E0B' },
  { id: 'wave-1',         name: 'Wave Curve',      category: 'Professional', isPremium: false, accentColor: '#0284C7' },
  { id: 'ledger-1',       name: 'Ledger',          category: 'ATS',          isPremium: false, accentColor: '#065F46' },
  { id: 'neon-1',         name: 'Neon Dark',       category: 'Modern',       isPremium: true,  accentColor: '#22D3EE' },
  { id: 'scrapbook-1',    name: 'Scrapbook',       category: 'Creative',     isPremium: true,  accentColor: '#EA580C' },
];

export const getTemplate = (templateId: string): ResumeTemplate =>
  TEMPLATES.find(t => t.id === templateId) ?? TEMPLATES[0];
