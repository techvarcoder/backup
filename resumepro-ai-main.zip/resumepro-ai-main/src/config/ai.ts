// ─────────────────────────────────────────────────────────────────────────────
// AI Configuration — Google Gemini
//
// Steps to activate:
//   1. Go to https://aistudio.google.com → Get API Key
//   2. Replace the empty string below with your key
//   3. (Recommended) Restrict the key to package "com.medianest" in
//      Google Cloud Console → APIs & Services → Credentials
//
// When GEMINI_API_KEY is empty, the app falls back to rule-based logic
// so it still works without any key during development.
// ─────────────────────────────────────────────────────────────────────────────

export const AI_CONFIG = {
  GEMINI_API_KEY: '', // TODO: paste your key here

  GEMINI_MODEL: 'gemini-2.0-flash',
  TIMEOUT_MS: 30000,
};
