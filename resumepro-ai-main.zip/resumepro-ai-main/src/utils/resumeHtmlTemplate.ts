import { ResumeData } from '../types';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function esc(s: string) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function contactLine(p: ResumeData['personalInfo']): string {
  return [p.email, p.phone, p.location, p.linkedin, p.website]
    .filter(Boolean).map(v => esc(v!)).join(' &nbsp;|&nbsp; ');
}

/** Convert newline-separated text into <ul><li> list or plain paragraphs */
function descHtml(text: string): string {
  if (!text) { return ''; }
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  if (lines.length <= 1) { return `<p>${esc(text)}</p>`; }
  return `<ul>${lines.map(l => {
    const clean = l.replace(/^[-•*]\s*/, '');
    return `<li>${esc(clean)}</li>`;
  }).join('')}</ul>`;
}

// Shared page & print CSS added to every template
const PAGE_CSS = `
  @page { size: letter; margin: 0.6in 0.75in; }
  @media print { body { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
  * { margin:0; padding:0; box-sizing:border-box; }
  ul { padding-left: 16px; }
  li { margin-bottom: 2px; }
`;

// ─── Template 1: Professional ─────────────────────────────────────────────────
function buildProfessional(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;

  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div class="entry">
      <div class="row"><span class="etitle">${title}</span><span class="date">${date}</span></div>
      ${sub ? `<div class="esub">${sub}</div>` : ''}
      ${desc ? `<div class="edesc">${desc}</div>` : ''}
    </div>`;

  const section = (title: string, body: string) => `
    <div class="section">
      <div class="sec-head"><span class="sec-bar"></span>${title}</div>
      ${body}
    </div>`;

  const expItems = resume.workExperience.map(e => entry(
    esc(e.jobTitle),
    esc(e.company) + (e.location ? ` &mdash; ${esc(e.location)}` : ''),
    `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`,
    descHtml(e.description ?? ''),
  )).join('');

  const eduItems = resume.education.map(e => entry(
    esc(e.degree) + (e.fieldOfStudy ? ` &mdash; ${esc(e.fieldOfStudy)}` : ''),
    esc(e.institution),
    `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? 'Present')}`,
    e.grade ? `GPA / Grade: ${esc(e.grade)}` : '',
  )).join('');

  const projItems = resume.projects.map(pr => entry(
    esc(pr.name),
    pr.technologies ? esc(pr.technologies) : '',
    pr.startDate ? `${esc(pr.startDate)}${pr.endDate ? ` &ndash; ${esc(pr.endDate)}` : ''}` : '',
    descHtml(pr.description ?? ''),
  )).join('');

  const certItems = resume.certificates.map(c => entry(
    esc(c.name), esc(c.issuer), esc(c.date ?? ''), '',
  )).join('');

  const refItems = resume.references.map(r => entry(
    esc(r.name),
    [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '),
    '',
    [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '),
  )).join('');

  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: Arial, 'Helvetica Neue', sans-serif; font-size: 13px; color: #1F2937; background: #fff; }
    .header { background: ${accent}; color: #fff; padding: 28px 36px 22px; }
    .name { font-size: 28px; font-weight: 700; letter-spacing: 0.5px; }
    .jobtitle { font-size: 14px; opacity: .88; margin: 4px 0 10px; }
    .contact { font-size: 12px; opacity: .82; }
    .body { padding: 24px 36px; }
    .section { margin-bottom: 18px; }
    .sec-head { display: flex; align-items: center; font-size: 10px; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; color: #374151; margin-bottom: 10px; }
    .sec-bar { width: 4px; height: 14px; background: ${accent}; border-radius: 2px; margin-right: 9px; flex-shrink: 0; }
    .entry { margin-bottom: 12px; }
    .row { display: flex; justify-content: space-between; align-items: baseline; }
    .etitle { font-weight: 700; font-size: 14px; color: #111827; }
    .date { font-size: 11px; color: #6B7280; white-space: nowrap; margin-left: 8px; flex-shrink: 0; }
    .esub { font-size: 13px; color: ${accent}; font-weight: 600; margin: 3px 0 4px; }
    .edesc { font-size: 12px; color: #4B5563; line-height: 1.65; margin-top: 3px; }
    .edesc p { margin: 0; }
    .summary { font-size: 13px; color: #374151; line-height: 1.75; }
    .skills { display: flex; flex-wrap: wrap; gap: 6px; }
    .skill { border: 1.5px solid ${accent}; color: ${accent}; font-size: 12px; padding: 3px 12px; border-radius: 20px; }
    .twocol { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
  </style></head><body>
  <div class="header">
    <div class="name">${esc(p.fullName || 'Your Name')}</div>
    <div class="jobtitle">${esc(p.jobTitle || '')}</div>
    <div class="contact">${contactLine(p)}</div>
  </div>
  <div class="body">
    ${p.summary ? section('Professional Summary', `<div class="summary">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Work Experience', expItems) : ''}
    ${resume.education.length ? section('Education', eduItems) : ''}
    ${resume.skills.length ? section('Skills', `<div class="skills">${resume.skills.map(s => `<span class="skill">${esc(s.name)}</span>`).join('')}</div>`) : ''}
    ${resume.projects.length ? section('Projects', projItems) : ''}
    ${resume.certificates.length ? section('Certifications', certItems) : ''}
    ${resume.languages.length ? section('Languages', `<div class="twocol">${resume.languages.map(l => `<div><b>${esc(l.name)}</b> &mdash; <span style="color:#6B7280">${l.proficiency}</span></div>`).join('')}</div>`) : ''}
    ${resume.awards.length ? section('Awards & Honors', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('References', refItems) : ''}
  </div></body></html>`;
}

// ─── Template 2: Modern Two-Column ────────────────────────────────────────────
function buildModern(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;

  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <b style="font-size:14px;color:#111827">${title}</b>
        <span style="font-size:11px;color:#9CA3AF;white-space:nowrap;margin-left:8px;flex-shrink:0">${date}</span>
      </div>
      ${sub ? `<div style="color:${accent};font-size:12px;font-weight:600;margin:3px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:3px">${desc}</div>` : ''}
    </div>`;

  const sideSection = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:9px;font-weight:700;letter-spacing:1.5px;color:rgba(255,255,255,0.65);text-transform:uppercase;margin-bottom:8px;border-bottom:1px solid rgba(255,255,255,0.2);padding-bottom:4px">${title}</div>
      ${body}
    </div>`;

  const mainSection = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:${accent};margin-bottom:10px;padding-bottom:4px;border-bottom:2px solid ${accent}">${title}</div>
      ${body}
    </div>`;

  const contactInfo = [
    p.email    ? `<div style="margin-bottom:6px;font-size:12px">&#9993; ${esc(p.email)}</div>` : '',
    p.phone    ? `<div style="margin-bottom:6px;font-size:12px">&#128222; ${esc(p.phone)}</div>` : '',
    p.location ? `<div style="margin-bottom:6px;font-size:12px">&#128205; ${esc(p.location)}</div>` : '',
    p.linkedin ? `<div style="margin-bottom:6px;font-size:12px">&#128279; ${esc(p.linkedin)}</div>` : '',
  ].filter(Boolean).join('');

  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; }
    .edesc p { margin: 0; } ul { color: #4B5563; }
  </style>
  </head><body>
  <div style="display:flex;min-height:100vh">
    <div style="width:230px;min-width:230px;background:${accent};color:#fff;padding:32px 22px">
      <div style="font-size:22px;font-weight:700;line-height:1.25;margin-bottom:4px">${esc(p.fullName || 'Your Name')}</div>
      <div style="font-size:13px;opacity:.82;margin-bottom:26px">${esc(p.jobTitle || '')}</div>
      ${sideSection('Contact', contactInfo)}
      ${resume.skills.length ? sideSection('Skills', resume.skills.map(s => `<div style="font-size:12px;background:rgba(255,255,255,0.15);border-radius:4px;padding:4px 9px;margin-bottom:5px">${esc(s.name)}</div>`).join('')) : ''}
      ${resume.languages.length ? sideSection('Languages', resume.languages.map(l => `<div style="margin-bottom:5px;font-size:12px"><b>${esc(l.name)}</b><span style="opacity:.75"> &middot; ${l.proficiency}</span></div>`).join('')) : ''}
      ${resume.awards.length ? sideSection('Awards', resume.awards.map(a => `<div style="font-size:11px;margin-bottom:6px"><b>${esc(a.title)}</b>${a.issuer ? `<br/><span style="opacity:.7">${esc(a.issuer)}</span>` : ''}</div>`).join('')) : ''}
    </div>
    <div style="flex:1;padding:32px 30px">
      ${p.summary ? mainSection('Profile', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
      ${resume.workExperience.length ? mainSection('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company) + (e.location ? ` &mdash; ${esc(e.location)}` : ''), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
      ${resume.education.length ? mainSection('Education', resume.education.map(e => entry(esc(e.degree) + (e.fieldOfStudy ? ` &mdash; ${esc(e.fieldOfStudy)}` : ''), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? 'Present')}`, e.grade ? `GPA: ${esc(e.grade)}` : '')).join('')) : ''}
      ${resume.projects.length ? mainSection('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
      ${resume.certificates.length ? mainSection('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
      ${resume.references.length ? mainSection('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
    </div>
  </div></body></html>`;
}

// ─── Template 3: Minimal Serif ────────────────────────────────────────────────
function buildMinimal(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;

  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px;display:flex;gap:18px">
      <div style="width:95px;min-width:95px;text-align:right;padding-top:2px">
        <span style="font-size:11px;color:#9CA3AF;line-height:1.5">${date}</span>
      </div>
      <div style="flex:1;border-left:2px solid #E5E7EB;padding-left:16px">
        <div style="font-weight:700;font-size:14px;color:#111827">${title}</div>
        ${sub ? `<div style="font-size:12px;color:#6B7280;margin:2px 0">${sub}</div>` : ''}
        ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
      </div>
    </div>`;

  const section = (title: string, body: string) => `
    <div style="margin-bottom:24px">
      <div style="font-size:10px;letter-spacing:2px;text-transform:uppercase;color:#9CA3AF;font-weight:700;margin-bottom:14px">${title}</div>
      ${body}
    </div>`;

  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: Georgia, 'Times New Roman', serif; font-size: 13px; color: #1F2937; background: #fff; padding: 44px 52px; }
    ul { color: #4B5563; } p { margin: 0; }
  </style>
  </head><body>
    <div style="text-align:center;margin-bottom:36px;padding-bottom:26px;border-bottom:1px solid #E5E7EB">
      <div style="font-size:30px;font-weight:700;letter-spacing:2px;color:#111827;margin-bottom:7px">${esc((p.fullName || 'YOUR NAME').toUpperCase())}</div>
      <div style="font-size:14px;color:#6B7280;margin-bottom:11px">${esc(p.jobTitle || '')}</div>
      <div style="font-size:12px;color:#9CA3AF">${contactLine(p)}</div>
    </div>
    ${p.summary ? section('Summary', `<div style="font-size:13px;color:#374151;line-height:1.8;font-style:italic">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle) + ' &mdash; ' + esc(e.company), e.location ? esc(e.location) : '', `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? 'Present')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
    ${resume.skills.length ? section('Skills', `<div style="font-size:13px;color:#374151;line-height:2">${resume.skills.map(s => esc(s.name)).join(' &nbsp;&middot;&nbsp; ')}</div>`) : ''}
    ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} <span style="color:#9CA3AF">(${l.proficiency})</span></span>`).join('')}</div>`) : ''}
    ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 4: Creative Sidebar ────────────────────────────────────────────
function buildCreative(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const initials = (p.fullName || 'YN').split(' ').map((w: string) => w[0]).join('').toUpperCase().slice(0, 2);

  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:16px;padding-left:14px;border-left:3px solid ${accent}30">
      <div style="font-weight:700;font-size:14px;color:#111827">${title}</div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:3px 0">${sub}</div>` : ''}
      ${date ? `<div style="font-size:11px;color:#9CA3AF;margin-bottom:4px">${date}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65">${desc}</div>` : ''}
    </div>`;

  const mainSec = (title: string, body: string) => `
    <div style="margin-bottom:22px">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:11px">
        <div style="width:28px;height:28px;background:${accent};border-radius:6px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
          <span style="color:#fff;font-size:14px;font-weight:700">=</span>
        </div>
        <span style="font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#374151">${title}</span>
      </div>
      ${body}
    </div>`;

  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; }
    ul { color: #4B5563; } p { margin: 0; }
  </style>
  </head><body>
  <div style="display:flex;min-height:100vh">
    <div style="width:210px;min-width:210px;background:${accent};color:#fff;padding:34px 22px">
      <div style="width:72px;height:72px;border-radius:50%;background:rgba(255,255,255,0.25);display:flex;align-items:center;justify-content:center;margin:0 auto 18px;font-size:26px;font-weight:700">${initials}</div>
      <div style="font-size:17px;font-weight:700;text-align:center;margin-bottom:4px;line-height:1.3">${esc(p.fullName || 'Your Name')}</div>
      <div style="font-size:12px;opacity:.78;text-align:center;margin-bottom:26px">${esc(p.jobTitle || '')}</div>
      <div style="margin-bottom:18px">
        <div style="font-size:8px;letter-spacing:1.5px;text-transform:uppercase;opacity:.62;margin-bottom:9px;border-bottom:1px solid rgba(255,255,255,.2);padding-bottom:4px">Contact</div>
        ${[p.email, p.phone, p.location, p.linkedin].filter(Boolean).map(v => `<div style="font-size:11px;margin-bottom:7px;opacity:.9;word-break:break-all">${esc(v!)}</div>`).join('')}
      </div>
      ${resume.skills.length ? `<div style="margin-bottom:18px"><div style="font-size:8px;letter-spacing:1.5px;text-transform:uppercase;opacity:.62;margin-bottom:9px;border-bottom:1px solid rgba(255,255,255,.2);padding-bottom:4px">Skills</div>${resume.skills.map(s => `<div style="font-size:11px;background:rgba(255,255,255,.18);border-radius:4px;padding:4px 9px;margin-bottom:5px">${esc(s.name)}</div>`).join('')}</div>` : ''}
      ${resume.languages.length ? `<div style="margin-bottom:18px"><div style="font-size:8px;letter-spacing:1.5px;text-transform:uppercase;opacity:.62;margin-bottom:9px;border-bottom:1px solid rgba(255,255,255,.2);padding-bottom:4px">Languages</div>${resume.languages.map(l => `<div style="font-size:11px;margin-bottom:5px;opacity:.9">${esc(l.name)} &middot; ${l.proficiency}</div>`).join('')}</div>` : ''}
      ${resume.awards.length ? `<div><div style="font-size:8px;letter-spacing:1.5px;text-transform:uppercase;opacity:.62;margin-bottom:9px;border-bottom:1px solid rgba(255,255,255,.2);padding-bottom:4px">Awards</div>${resume.awards.map(a => `<div style="font-size:11px;margin-bottom:7px;opacity:.9"><b>${esc(a.title)}</b>${a.issuer ? `<br/>${esc(a.issuer)}` : ''}</div>`).join('')}</div>` : ''}
    </div>
    <div style="flex:1;padding:34px 30px;background:#FAFAFA">
      ${p.summary ? mainSec('About Me', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
      ${resume.workExperience.length ? mainSec('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
      ${resume.education.length ? mainSec('Education', resume.education.map(e => entry(esc(e.degree) + (e.fieldOfStudy ? ` &mdash; ${esc(e.fieldOfStudy)}` : ''), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? 'Present')}`, e.grade ? `GPA: ${esc(e.grade)}` : '')).join('')) : ''}
      ${resume.projects.length ? mainSec('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
      ${resume.certificates.length ? mainSec('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
      ${resume.references.length ? mainSec('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
    </div>
  </div></body></html>`;
}

// ─── Template 5: ATS Optimized ───────────────────────────────────────────────
function buildATS(resume: ResumeData): string {
  const p = resume.personalInfo;

  const section = (title: string, body: string) => `
    <div style="margin-bottom:18px">
      <div style="font-size:13px;font-weight:700;text-transform:uppercase;border-bottom:1.5px solid #000;padding-bottom:3px;margin-bottom:10px">${title}</div>
      ${body}
    </div>`;

  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:12px">
      <div style="display:flex;justify-content:space-between;align-items:baseline"><b style="font-size:13px">${title}</b><span style="font-size:12px">${date}</span></div>
      ${sub ? `<div style="font-size:12px">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;margin-top:4px;line-height:1.65">${desc}</div>` : ''}
    </div>`;

  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: Arial, sans-serif; font-size: 13px; color: #000; background: #fff; padding: 36px 44px; line-height: 1.55; }
    ul { color: #000; } p { margin: 0; }
  </style>
  </head><body>
    <div style="text-align:center;margin-bottom:22px">
      <div style="font-size:24px;font-weight:700">${esc(p.fullName || 'Your Name')}</div>
      ${p.jobTitle ? `<div style="font-size:14px;margin:5px 0">${esc(p.jobTitle)}</div>` : ''}
      <div style="font-size:12px">${contactLine(p)}</div>
    </div>
    ${p.summary ? section('Summary', `<div style="font-size:13px">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Work Experience', resume.workExperience.map(e => entry(`${esc(e.jobTitle)} | ${esc(e.company)}`, e.location ? esc(e.location) : '', `${esc(e.startDate)} - ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} - ${esc(e.endYear ?? 'Present')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
    ${resume.skills.length ? section('Skills', `<div style="font-size:13px">${resume.skills.map(s => esc(s.name)).join(', ')}</div>`) : ''}
    ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="font-size:13px">${resume.languages.map(l => `${esc(l.name)} (${l.proficiency})`).join(', ')}</div>`) : ''}
    ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 6: Executive ───────────────────────────────────────────────────
function buildExecutive(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;

  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:16px">
      <div style="display:flex;justify-content:space-between;border-bottom:1px dotted #D1D5DB;padding-bottom:5px;margin-bottom:5px;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:12px;color:#6B7280;font-style:italic;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:13px;color:${accent};font-weight:600;margin-bottom:4px">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#374151;line-height:1.75">${desc}</div>` : ''}
    </div>`;

  const section = (title: string, body: string) => `
    <div style="margin-bottom:22px">
      <div style="text-align:center;margin-bottom:11px">
        <span style="font-size:10px;letter-spacing:3px;text-transform:uppercase;color:${accent};font-weight:700">${title}</span>
      </div>
      <div style="height:1px;background:${accent};margin-bottom:13px;opacity:.35"></div>
      ${body}
    </div>`;

  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: Georgia, 'Times New Roman', serif; font-size: 13px; color: #1F2937; background: #fff; padding: 40px 48px; }
    ul { color: #374151; } p { margin: 0; }
  </style>
  </head><body>
    <div style="text-align:center;margin-bottom:30px">
      <div style="height:2px;background:${accent};margin-bottom:16px"></div>
      <div style="font-size:30px;font-weight:700;letter-spacing:3px;color:#111827;margin-bottom:7px">${esc((p.fullName || 'Your Name').toUpperCase())}</div>
      <div style="font-size:14px;color:#6B7280;letter-spacing:1px;margin-bottom:11px">${esc(p.jobTitle || '')}</div>
      <div style="font-size:12px;color:#9CA3AF">${contactLine(p)}</div>
      <div style="height:2px;background:${accent};margin-top:16px"></div>
    </div>
    ${p.summary ? section('Executive Summary', `<div style="font-size:13px;color:#374151;line-height:1.8;text-align:justify">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Professional Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree) + (e.fieldOfStudy ? ` &mdash; ${esc(e.fieldOfStudy)}` : ''), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? 'Present')}`, e.grade ? `Grade: ${esc(e.grade)}` : '')).join('')) : ''}
    ${resume.skills.length ? section('Core Competencies', `<div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center">${resume.skills.map(s => `<span style="border:1px solid ${accent};color:${accent};font-size:12px;padding:3px 13px;font-family:Arial,sans-serif">${esc(s.name)}</span>`).join('')}</div>`) : ''}
    ${resume.projects.length ? section('Notable Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:16px;justify-content:center">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} &mdash; <span style="color:#6B7280">${l.proficiency}</span></span>`).join('')}</div>`) : ''}
    ${resume.awards.length ? section('Awards & Recognition', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 7: Tech Pro ────────────────────────────────────────────────────
function buildTechPro(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const dark = '#0F172A';

  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:14px;font-weight:700;color:#F1F5F9">${title}</span>
        ${date ? `<span style="font-size:11px;color:${accent};font-family:monospace;background:${accent}25;padding:2px 9px;border-radius:4px;flex-shrink:0;margin-left:8px">${date}</span>` : ''}
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};margin:3px 0 5px;font-weight:600">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#94A3B8;line-height:1.65">${desc}</div>` : ''}
    </div>`;

  const section = (icon: string, title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="display:flex;align-items:center;gap:9px;margin-bottom:11px">
        <span style="color:${accent};font-family:monospace;font-size:15px;font-weight:700">${icon}</span>
        <span style="font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#CBD5E1">${title}</span>
        <div style="flex:1;height:1px;background:${accent}40;margin-left:8px"></div>
      </div>
      ${body}
    </div>`;

  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; background: ${dark}; color: #E2E8F0; }
    ul { color: #94A3B8; padding-left: 18px; } p { margin: 0; }
  </style>
  </head><body>
  <div style="background:linear-gradient(135deg,${dark} 0%,#1E293B 100%);padding:30px 34px;border-bottom:3px solid ${accent}">
    <div style="font-size:27px;font-weight:700;color:#F8FAFC;letter-spacing:1px">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:14px;color:${accent};font-weight:600;margin:5px 0 11px;font-family:monospace">&gt; ${esc(p.jobTitle || 'Developer')}</div>
    <div style="font-size:12px;color:#94A3B8;font-family:monospace">${[p.email, p.phone, p.location].filter(Boolean).map(v => esc(v!)).join(' &nbsp;&middot;&nbsp; ')}</div>
  </div>
  <div style="padding:26px 34px">
    ${p.summary ? section('//', 'About', `<div style="font-size:13px;color:#94A3B8;line-height:1.75;border-left:3px solid ${accent};padding-left:14px">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('&#9654;', 'Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &rarr; ${e.isPresent ? 'Now' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.skills.length ? section('#', 'Tech Stack', `<div style="display:flex;flex-wrap:wrap;gap:7px">${resume.skills.map(s => `<span style="background:${accent}22;color:${accent};font-size:12px;padding:4px 11px;border-radius:4px;border:1px solid ${accent}50;font-family:monospace">${esc(s.name)}</span>`).join('')}</div>`) : ''}
    ${resume.education.length ? section('*', 'Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? 'Present')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
    ${resume.projects.length ? section('&rarr;', 'Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? section('&#10003;', 'Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? section('@', 'Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="color:#94A3B8;font-size:12px">${esc(l.name)} <span style="color:${accent}">[${l.proficiency}]</span></span>`).join('')}</div>`) : ''}
    ${resume.awards.length ? section('&#9733;', 'Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('~', 'References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </div></body></html>`;
}

// ─── Template 8: Clean Slate ─────────────────────────────────────────────────
function buildCleanSlate(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;

  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="display:flex;gap:22px;margin-bottom:16px">
      <div style="min-width:86px;max-width:86px;text-align:right;padding-top:2px;font-size:11px;color:#9CA3AF;line-height:1.5">${date}</div>
      <div style="flex:1">
        <div style="font-size:14px;font-weight:600;color:#111827">${title}</div>
        ${sub ? `<div style="font-size:12px;color:#6B7280;margin:3px 0">${sub}</div>` : ''}
        ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:5px">${desc}</div>` : ''}
      </div>
    </div>`;

  const section = (title: string, body: string) => `
    <div style="margin-bottom:26px">
      <div style="display:flex;align-items:center;gap:13px;margin-bottom:16px">
        <div style="width:7px;height:7px;border-radius:50%;background:${accent};flex-shrink:0"></div>
        <span style="font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#374151">${title}</span>
        <div style="flex:1;height:1px;background:#E5E7EB"></div>
      </div>
      ${body}
    </div>`;

  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Helvetica Neue', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; padding: 44px 52px; }
    ul { color: #4B5563; } p { margin: 0; }
  </style>
  </head><body>
    <div style="margin-bottom:38px">
      <div style="font-size:30px;font-weight:300;letter-spacing:4px;color:#111827;margin-bottom:7px">${esc((p.fullName || 'Your Name').toUpperCase())}</div>
      <div style="font-size:14px;color:${accent};font-weight:500;letter-spacing:1px;margin-bottom:15px">${esc(p.jobTitle || '')}</div>
      <div style="display:flex;flex-wrap:wrap;gap:18px;font-size:12px;color:#9CA3AF">
        ${[p.email, p.phone, p.location, p.linkedin].filter(Boolean).map(v => `<span>${esc(v!)}</span>`).join('')}
      </div>
      <div style="height:2px;background:linear-gradient(to right,${accent},transparent);margin-top:22px"></div>
    </div>
    ${p.summary ? section('Profile', `<div style="font-size:13px;color:#374151;line-height:1.8">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree) + (e.fieldOfStudy ? ` &middot; ${esc(e.fieldOfStudy)}` : ''), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? 'Present')}`, e.grade ? `GPA: ${esc(e.grade)}` : '')).join('')) : ''}
    ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:9px">${resume.skills.map(s => `<span style="background:#F3F4F6;color:#374151;font-size:12px;padding:4px 13px;border-radius:20px">${esc(s.name)}</span>`).join('')}</div>`) : ''}
    ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:18px">${resume.languages.map(l => `<span style="font-size:13px;color:#374151">${esc(l.name)} <span style="color:#9CA3AF">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
    ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 9: Bold Impact ─────────────────────────────────────────────────
// Giant oversized name, strong typographic hierarchy, no sidebar
function buildBoldImpact(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:800;color:#111827;text-transform:uppercase;letter-spacing:0.5px">${title}</span>
        <span style="font-size:11px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:13px;color:${accent};font-weight:700;margin:3px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:22px">
      <div style="font-size:10px;font-weight:900;letter-spacing:3px;text-transform:uppercase;color:${accent};margin-bottom:10px;display:flex;align-items:center;gap:10px">
        ${title}<div style="flex:1;height:2px;background:${accent}"></div>
      </div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Arial Black', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="padding:36px 40px 20px;border-bottom:4px solid ${accent}">
    <div style="font-size:42px;font-weight:900;color:#111827;letter-spacing:-1px;line-height:1;text-transform:uppercase;margin-bottom:6px">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:16px;font-weight:700;color:${accent};letter-spacing:2px;text-transform:uppercase;margin-bottom:12px">${esc(p.jobTitle || '')}</div>
    <div style="font-size:12px;color:#6B7280;display:flex;flex-wrap:wrap;gap:16px">${[p.email, p.phone, p.location, p.linkedin].filter(Boolean).map(v => `<span>${esc(v!)}</span>`).join('')}</div>
  </div>
  <div style="padding:24px 40px">
    ${p.summary ? section('Profile', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
    ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:8px">${resume.skills.map(s => `<span style="background:${accent};color:#fff;font-size:12px;font-weight:700;padding:4px 14px;border-radius:4px">${esc(s.name)}</span>`).join('')}</div>`) : ''}
    ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px;font-weight:700;color:#111827">${esc(l.name)} <span style="font-weight:400;color:#6B7280">&mdash; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
    ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </div></body></html>`;
}

// ─── Template 10: Gradient Header ────────────────────────────────────────────
// Diagonal gradient header, white cards for sections
function buildGradient(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const accent2 = accent + 'CC';
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="background:#fff;border-radius:8px;padding:12px 14px;margin-bottom:10px;border-left:4px solid ${accent};box-shadow:0 1px 4px rgba(0,0,0,0.07)">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:11px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:3px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#374151;margin-bottom:8px;padding-left:2px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #F8FAFC; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="background:linear-gradient(135deg,${accent} 0%,${accent2} 50%,#6D28D9 100%);padding:36px 40px 28px;color:#fff">
    <div style="font-size:30px;font-weight:800;letter-spacing:0.5px;margin-bottom:6px">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:15px;opacity:.9;margin-bottom:14px;font-weight:500">${esc(p.jobTitle || '')}</div>
    <div style="display:flex;flex-wrap:wrap;gap:16px;font-size:12px;opacity:.85">${[p.email, p.phone, p.location, p.linkedin].filter(Boolean).map(v => `<span>${esc(v!)}</span>`).join('')}</div>
  </div>
  <div style="padding:24px 40px">
    ${p.summary ? section('About Me', `<div style="background:#fff;border-radius:8px;padding:12px 14px;font-size:13px;color:#374151;line-height:1.75;border-left:4px solid ${accent};box-shadow:0 1px 4px rgba(0,0,0,0.07)">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Work Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree) + (e.fieldOfStudy ? ` &mdash; ${esc(e.fieldOfStudy)}` : ''), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.grade ? `GPA: ${esc(e.grade)}` : '')).join('')) : ''}
    ${resume.skills.length ? section('Skills', `<div style="background:#fff;border-radius:8px;padding:12px 14px;display:flex;flex-wrap:wrap;gap:8px;box-shadow:0 1px 4px rgba(0,0,0,0.07)">${resume.skills.map(s => `<span style="background:${accent}18;color:${accent};font-size:12px;padding:4px 12px;border-radius:20px;font-weight:600;border:1px solid ${accent}40">${esc(s.name)}</span>`).join('')}</div>`) : ''}
    ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="background:#fff;border-radius:8px;padding:12px 14px;display:flex;flex-wrap:wrap;gap:14px;box-shadow:0 1px 4px rgba(0,0,0,0.07)">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} <span style="color:#9CA3AF">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
    ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </div></body></html>`;
}

// ─── Template 11: Side Accent ────────────────────────────────────────────────
// Thick left color bar (not a sidebar), single column, clean
function buildSideAccent(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:13px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:11px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:3px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="display:flex;gap:0;margin-bottom:20px">
      <div style="width:5px;background:${accent};border-radius:3px;flex-shrink:0;margin-right:16px"></div>
      <div style="flex:1">
        <div style="font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#374151;margin-bottom:10px">${title}</div>
        ${body}
      </div>
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; padding: 36px 40px; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="display:flex;gap:0;margin-bottom:28px;padding-bottom:20px;border-bottom:1px solid #E5E7EB">
    <div style="width:6px;background:${accent};border-radius:3px;flex-shrink:0;margin-right:18px"></div>
    <div>
      <div style="font-size:30px;font-weight:800;color:#111827;margin-bottom:5px">${esc(p.fullName || 'Your Name')}</div>
      <div style="font-size:14px;color:${accent};font-weight:600;margin-bottom:10px">${esc(p.jobTitle || '')}</div>
      <div style="font-size:12px;color:#6B7280;display:flex;flex-wrap:wrap;gap:14px">${[p.email, p.phone, p.location, p.linkedin].filter(Boolean).map(v => `<span>${esc(v!)}</span>`).join('')}</div>
    </div>
  </div>
  ${p.summary ? section('Profile', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
  ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree) + (e.fieldOfStudy ? ` &mdash; ${esc(e.fieldOfStudy)}` : ''), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.grade ? `GPA: ${esc(e.grade)}` : '')).join('')) : ''}
  ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:7px">${resume.skills.map(s => `<span style="background:#F3F4F6;color:#374151;font-size:12px;padding:4px 12px;border-radius:4px;border:1px solid #E5E7EB">${esc(s.name)}</span>`).join('')}</div>`) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
  ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
  ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} <span style="color:#9CA3AF">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 12: Academic CV ─────────────────────────────────────────────────
// Traditional formal CV, serif, ruled section headers
function buildAcademic(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between">
        <span style="font-size:13px;font-weight:700;color:#1E3A5F;font-style:italic">${title}</span>
        <span style="font-size:12px;color:#6B7280;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:13px;color:#374151;font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.7;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:${accent};padding-bottom:5px;border-bottom:2px solid ${accent};margin-bottom:12px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Times New Roman', Georgia, serif; font-size: 13px; color: #1F2937; background: #fff; padding: 40px 52px; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="text-align:center;margin-bottom:28px;padding-bottom:20px;border-bottom:3px double ${accent}">
    <div style="font-size:26px;font-weight:700;color:#1E3A5F;letter-spacing:1px;margin-bottom:5px">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:14px;color:#374151;margin-bottom:10px;font-style:italic">${esc(p.jobTitle || '')}</div>
    <div style="font-size:12px;color:#6B7280">${contactLine(p)}</div>
  </div>
  ${p.summary ? section('Research / Professional Interest', `<div style="font-size:13px;color:#374151;line-height:1.8;text-align:justify">${esc(p.summary)}</div>`) : ''}
  ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree) + (e.fieldOfStudy ? `, ${esc(e.fieldOfStudy)}` : ''), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? 'Present')}`, e.grade ? `Grade: ${esc(e.grade)}` : '')).join('')) : ''}
  ${resume.workExperience.length ? section('Professional Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company) + (e.location ? `, ${esc(e.location)}` : ''), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
  ${resume.projects.length ? section('Research & Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
  ${resume.certificates.length ? section('Certifications & Training', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
  ${resume.awards.length ? section('Honours & Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
  ${resume.skills.length ? section('Skills & Competencies', `<div style="font-size:13px;color:#374151;line-height:2">${resume.skills.map(s => esc(s.name)).join(' &nbsp;&bull;&nbsp; ')}</div>`) : ''}
  ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span>${esc(l.name)} <span style="color:#9CA3AF">(${l.proficiency})</span></span>`).join('')}</div>`) : ''}
  ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 13: Compact ─────────────────────────────────────────────────────
// Dense single-column, tight spacing, fits everything on one page
function buildCompact(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:7px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:12px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:10px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:11px;color:${accent};font-weight:600">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:11px;color:#4B5563;line-height:1.5;margin-top:2px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:10px">
      <div style="font-size:9px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:${accent};background:${accent}12;padding:2px 6px;display:inline-block;border-radius:2px;margin-bottom:6px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: Arial, sans-serif; font-size: 12px; color: #1F2937; background: #fff; padding: 24px 32px; }
    ul { color: #4B5563; padding-left: 14px; } li { margin-bottom: 1px; } p { margin: 0; }
  </style></head><body>
  <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px;padding-bottom:10px;border-bottom:2px solid ${accent}">
    <div>
      <div style="font-size:22px;font-weight:800;color:#111827;line-height:1">${esc(p.fullName || 'Your Name')}</div>
      <div style="font-size:12px;color:${accent};font-weight:600;margin-top:3px">${esc(p.jobTitle || '')}</div>
    </div>
    <div style="font-size:11px;color:#6B7280;text-align:right;line-height:1.8">
      ${[p.email, p.phone, p.location].filter(Boolean).map(v => `<div>${esc(v!)}</div>`).join('')}
    </div>
  </div>
  ${p.summary ? section('Summary', `<div style="font-size:11px;color:#374151;line-height:1.6">${esc(p.summary)}</div>`) : ''}
  ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle) + ' — ' + esc(e.company), e.location ? esc(e.location) : '', `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
  ${resume.skills.length ? section('Skills', `<div style="font-size:11px;color:#374151;line-height:1.8">${resume.skills.map(s => esc(s.name)).join(' &middot; ')}</div>`) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
  ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => `<div style="font-size:11px;margin-bottom:3px"><b>${esc(c.name)}</b> &mdash; ${esc(c.issuer)}${c.date ? ` (${esc(c.date)})` : ''}</div>`).join('')) : ''}
  ${resume.languages.length ? section('Languages', `<div style="font-size:11px;color:#374151">${resume.languages.map(l => `${esc(l.name)} (${l.proficiency})`).join(' &middot; ')}</div>`) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map(a => `<div style="font-size:11px;margin-bottom:3px"><b>${esc(a.title)}</b>${a.issuer ? ` &mdash; ${esc(a.issuer)}` : ''}${a.date ? ` (${esc(a.date)})` : ''}</div>`).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map(r => `<div style="font-size:11px;margin-bottom:4px"><b>${esc(r.name)}</b>${r.position ? `, ${esc(r.position)}` : ''}${r.company ? ` &mdash; ${esc(r.company)}` : ''}<br/>${[r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | ')}</div>`).join('')) : ''}
  </body></html>`;
}

// ─── Template 14: Magazine ────────────────────────────────────────────────────
// Editorial large name, pink/bold accent, column layout feel
function buildMagazine(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px;padding-bottom:12px;border-bottom:1px solid #F3F4F6">
      <div style="font-size:14px;font-weight:700;color:#111827">${title}</div>
      <div style="display:flex;justify-content:space-between;align-items:center;margin:3px 0">
        ${sub ? `<span style="font-size:12px;color:${accent};font-weight:600">${sub}</span>` : '<span></span>'}
        <span style="font-size:11px;color:#9CA3AF">${date}</span>
      </div>
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:22px">
      <div style="font-size:20px;font-weight:900;color:#111827;border-left:5px solid ${accent};padding-left:10px;margin-bottom:12px;line-height:1">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="background:#111827;padding:36px 40px 28px;color:#fff;position:relative">
    <div style="font-size:48px;font-weight:900;line-height:0.9;letter-spacing:-2px;color:#fff;margin-bottom:10px">${esc((p.fullName || 'YOUR NAME').toUpperCase())}</div>
    <div style="font-size:15px;color:${accent};font-weight:700;letter-spacing:3px;text-transform:uppercase;margin-bottom:16px">${esc(p.jobTitle || '')}</div>
    <div style="font-size:12px;color:#9CA3AF;display:flex;flex-wrap:wrap;gap:16px">${[p.email, p.phone, p.location, p.linkedin].filter(Boolean).map(v => `<span>${esc(v!)}</span>`).join('')}</div>
    <div style="position:absolute;top:0;right:0;width:8px;height:100%;background:${accent}"></div>
  </div>
  <div style="padding:28px 40px">
    ${p.summary ? section('About', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree) + (e.fieldOfStudy ? ` &mdash; ${esc(e.fieldOfStudy)}` : ''), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.grade ? `Grade: ${esc(e.grade)}` : '')).join('')) : ''}
    ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:8px">${resume.skills.map(s => `<span style="background:#111827;color:#fff;font-size:12px;padding:4px 14px;border-radius:3px;font-weight:600">${esc(s.name)}</span>`).join('')}</div>`) : ''}
    ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px;font-weight:700">${esc(l.name)} <span style="font-weight:400;color:#9CA3AF">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
    ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </div></body></html>`;
}

// ─── Template 15: Timeline ────────────────────────────────────────────────────
// Vertical center timeline, alternating left/right entries
function buildTimeline(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const timelineEntry = (title: string, sub: string, date: string, desc: string, idx: number) => {
    const left = idx % 2 === 0;
    return `<div style="display:flex;align-items:flex-start;margin-bottom:18px;gap:0">
      <div style="flex:1;text-align:${left ? 'right' : 'left'};padding-${left ? 'right' : 'left'}:16px;${left ? '' : 'order:2'}">
        <div style="font-size:13px;font-weight:700;color:#111827">${title}</div>
        ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
        ${desc ? `<div style="font-size:11px;color:#4B5563;line-height:1.6;margin-top:3px">${desc}</div>` : ''}
      </div>
      <div style="display:flex;flex-direction:column;align-items:center;flex-shrink:0;width:32px">
        <div style="width:12px;height:12px;border-radius:50%;background:${accent};border:3px solid #fff;box-shadow:0 0 0 2px ${accent};flex-shrink:0"></div>
        <div style="width:2px;flex:1;background:${accent}40;min-height:20px"></div>
      </div>
      <div style="flex:1;padding-${left ? 'left' : 'right'}:16px;${left ? 'order:2' : ''}">
        <div style="font-size:11px;color:#9CA3AF;font-style:italic;padding-top:2px">${date}</div>
      </div>
    </div>`;
  };
  const section = (title: string, body: string) => `
    <div style="margin-bottom:22px">
      <div style="text-align:center;font-size:10px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:${accent};margin-bottom:14px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="background:${accent};color:#fff;padding:32px 40px;text-align:center">
    <div style="font-size:28px;font-weight:800;letter-spacing:0.5px;margin-bottom:5px">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:14px;opacity:.88;margin-bottom:12px">${esc(p.jobTitle || '')}</div>
    <div style="font-size:12px;opacity:.78;display:flex;flex-wrap:wrap;gap:14px;justify-content:center">${[p.email, p.phone, p.location].filter(Boolean).map(v => `<span>${esc(v!)}</span>`).join('')}</div>
  </div>
  <div style="padding:28px 32px">
    ${p.summary ? `<div style="text-align:center;font-size:13px;color:#374151;line-height:1.75;max-width:520px;margin:0 auto 24px;padding-bottom:18px;border-bottom:1px solid #E5E7EB">${esc(p.summary)}</div>` : ''}
    ${resume.workExperience.length ? section('Experience', resume.workExperience.map((e, i) => timelineEntry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''), i)).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map((e, i) => timelineEntry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '', i)).join('')) : ''}
    ${resume.skills.length ? `<div style="text-align:center;margin-bottom:22px"><div style="font-size:10px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:${accent};margin-bottom:12px">Skills</div><div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center">${resume.skills.map(s => `<span style="background:${accent}18;color:${accent};font-size:12px;padding:4px 12px;border-radius:20px;border:1px solid ${accent}40">${esc(s.name)}</span>`).join('')}</div></div>` : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map((c, i) => timelineEntry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '', i)).join('')) : ''}
    ${resume.languages.length ? `<div style="text-align:center;margin-bottom:20px"><div style="font-size:10px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:${accent};margin-bottom:10px">Languages</div><div style="display:flex;flex-wrap:wrap;gap:12px;justify-content:center">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} <span style="color:#9CA3AF">&middot; ${l.proficiency}</span></span>`).join('')}</div></div>` : ''}
    ${resume.awards.length ? section('Awards', resume.awards.map((a, i) => timelineEntry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''), i)).join('')) : ''}
  </div></body></html>`;
}

// ─── Template 16: Finance ─────────────────────────────────────────────────────
// Dark navy + gold, conservative, formal banking/finance look
function buildFinance(resume: ResumeData, accent: string): string {
  const navy = '#1E2B4A';
  const gold = accent;
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline;border-bottom:1px solid #E8E4D8;padding-bottom:4px;margin-bottom:4px">
        <span style="font-size:13px;font-weight:700;color:${navy}">${title}</span>
        <span style="font-size:11px;color:#92400E;flex-shrink:0;margin-left:8px;font-style:italic">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${gold};font-weight:700;margin-bottom:3px">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B4B3A;line-height:1.7">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="background:${navy};color:${gold};font-size:10px;font-weight:700;letter-spacing:2px;text-transform:uppercase;padding:5px 12px;margin-bottom:12px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: Georgia, serif; font-size: 13px; color: #1F2937; background: #FAFAF7; }
    ul { color: #4B4B3A; } p { margin: 0; }
  </style></head><body>
  <div style="background:${navy};padding:32px 40px 24px;color:#fff;border-bottom:4px solid ${gold}">
    <div style="font-size:28px;font-weight:700;letter-spacing:2px;color:#fff;margin-bottom:5px;font-variant:small-caps">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:14px;color:${gold};font-weight:600;letter-spacing:1px;margin-bottom:12px">${esc(p.jobTitle || '')}</div>
    <div style="font-size:12px;color:#B8B09A;display:flex;flex-wrap:wrap;gap:16px">${[p.email, p.phone, p.location, p.linkedin].filter(Boolean).map(v => `<span>${esc(v!)}</span>`).join('')}</div>
  </div>
  <div style="padding:24px 40px">
    ${p.summary ? section('Executive Profile', `<div style="font-size:13px;color:#374151;line-height:1.8;text-align:justify">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Professional Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree) + (e.fieldOfStudy ? `, ${esc(e.fieldOfStudy)}` : ''), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.grade ? `Grade: ${esc(e.grade)}` : '')).join('')) : ''}
    ${resume.skills.length ? section('Areas of Expertise', `<div style="display:flex;flex-wrap:wrap;gap:8px">${resume.skills.map(s => `<span style="border:1px solid ${gold};color:${navy};font-size:12px;padding:3px 12px;font-family:Arial,sans-serif">${esc(s.name)}</span>`).join('')}</div>`) : ''}
    ${resume.certificates.length ? section('Licences & Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.awards.length ? section('Awards & Recognition', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px;color:${navy};font-weight:600">${esc(l.name)} <span style="font-weight:400;color:#6B7280">(${l.proficiency})</span></span>`).join('')}</div>`) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </div></body></html>`;
}

// ─── Template 17: Startup ────────────────────────────────────────────────────
// Clean white with vibrant accent, pill chips, very modern
function buildStartup(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px;padding:12px 14px;border-radius:10px;background:#F9FAFB;border:1px solid #F3F4F6">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:8px">
        <div style="font-size:14px;font-weight:700;color:#111827">${title}</div>
        <span style="font-size:10px;color:#fff;background:${accent};padding:2px 9px;border-radius:20px;white-space:nowrap;flex-shrink:0;font-weight:600">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:3px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
        <div style="width:32px;height:3px;background:${accent};border-radius:2px"></div>
        <span style="font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#111827">${title}</span>
      </div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', -apple-system, Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; padding: 36px 40px; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="margin-bottom:28px">
    <div style="font-size:32px;font-weight:800;color:#111827;margin-bottom:5px;letter-spacing:-0.5px">${esc(p.fullName || 'Your Name')}</div>
    <div style="display:inline-block;background:${accent};color:#fff;font-size:13px;font-weight:600;padding:4px 16px;border-radius:20px;margin-bottom:13px">${esc(p.jobTitle || '')}</div>
    <div style="display:flex;flex-wrap:wrap;gap:10px;font-size:12px">
      ${[p.email, p.phone, p.location, p.linkedin].filter(Boolean).map(v => `<span style="background:#F3F4F6;color:#374151;padding:3px 10px;border-radius:20px">${esc(v!)}</span>`).join('')}
    </div>
  </div>
  ${p.summary ? section('About', `<div style="font-size:13px;color:#374151;line-height:1.75;padding:12px 14px;border-radius:10px;background:#F9FAFB;border:1px solid #F3F4F6">${esc(p.summary)}</div>`) : ''}
  ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Now' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree) + (e.fieldOfStudy ? ` &mdash; ${esc(e.fieldOfStudy)}` : ''), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.grade ? `GPA: ${esc(e.grade)}` : '')).join('')) : ''}
  ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:8px">${resume.skills.map(s => `<span style="background:${accent}15;color:${accent};font-size:12px;padding:5px 14px;border-radius:20px;font-weight:600;border:1.5px solid ${accent}40">${esc(s.name)}</span>`).join('')}</div>`) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
  ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
  ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:8px">${resume.languages.map(l => `<span style="background:#F3F4F6;color:#374151;font-size:12px;padding:4px 12px;border-radius:20px">${esc(l.name)} &middot; ${l.proficiency}</span>`).join('')}</div>`) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 18: Healthcare ──────────────────────────────────────────────────
// Teal/green, clinical clean, two-tone header
function buildHealthcare(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:13px;padding-left:12px;border-left:3px solid ${accent}">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#134E4A">${title}</span>
        <span style="font-size:11px;color:#6B7280;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#374151;line-height:1.65;margin-top:3px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="background:${accent}15;border-left:4px solid ${accent};padding:5px 12px;font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#134E4A;margin-bottom:10px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: Arial, 'Helvetica Neue', sans-serif; font-size: 13px; color: #1F2937; background: #fff; }
    ul { color: #374151; } p { margin: 0; }
  </style></head><body>
  <div style="background:${accent};padding:28px 36px 0;color:#fff">
    <div style="font-size:28px;font-weight:700;margin-bottom:4px">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:14px;opacity:.9;margin-bottom:0;font-weight:500">${esc(p.jobTitle || '')}</div>
  </div>
  <div style="background:${accent}20;padding:10px 36px;margin-bottom:22px">
    <div style="font-size:12px;color:#134E4A;display:flex;flex-wrap:wrap;gap:16px">${[p.email, p.phone, p.location, p.linkedin].filter(Boolean).map(v => `<span>${esc(v!)}</span>`).join('')}</div>
  </div>
  <div style="padding:0 36px 28px">
    ${p.summary ? section('Professional Profile', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Clinical / Work Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education & Training', resume.education.map(e => entry(esc(e.degree) + (e.fieldOfStudy ? ` &mdash; ${esc(e.fieldOfStudy)}` : ''), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.grade ? `Grade: ${esc(e.grade)}` : '')).join('')) : ''}
    ${resume.skills.length ? section('Clinical Skills', `<div style="display:flex;flex-wrap:wrap;gap:7px">${resume.skills.map(s => `<span style="background:${accent}18;color:#134E4A;font-size:12px;padding:4px 12px;border-radius:4px;border:1px solid ${accent}50;font-weight:600">${esc(s.name)}</span>`).join('')}</div>`) : ''}
    ${resume.certificates.length ? section('Licences & Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.projects.length ? section('Research & Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.awards.length ? section('Awards & Recognition', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} <span style="color:#6B7280">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </div></body></html>`;
}

// ─── Template 19: Euro CV ─────────────────────────────────────────────────────
// Europass-inspired: photo placeholder, structured table layout
function buildEuroCV(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const row = (label: string, value: string) => value ? `
    <tr>
      <td style="width:160px;padding:5px 12px 5px 0;font-size:11px;font-weight:700;color:${accent};text-transform:uppercase;letter-spacing:0.5px;vertical-align:top;white-space:nowrap">${label}</td>
      <td style="padding:5px 0;font-size:13px;color:#1F2937;vertical-align:top">${value}</td>
    </tr>` : '';
  const section = (title: string, body: string) => `
    <div style="margin-bottom:18px">
      <div style="background:${accent};color:#fff;font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;padding:5px 14px;margin-bottom:10px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; }
    ul { color: #4B5563; } p { margin: 0; } table { width: 100%; border-collapse: collapse; }
  </style></head><body>
  <div style="background:${accent};padding:24px 36px;color:#fff;display:flex;align-items:center;gap:20px">
    <div style="width:72px;height:90px;background:rgba(255,255,255,0.25);border-radius:4px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:700">
      ${(p.fullName || 'YN').split(' ').map((w: string) => w[0]).join('').toUpperCase().slice(0, 2)}
    </div>
    <div>
      <div style="font-size:24px;font-weight:700;margin-bottom:4px">${esc(p.fullName || 'Your Name')}</div>
      <div style="font-size:13px;opacity:.88">${esc(p.jobTitle || '')}</div>
    </div>
  </div>
  <div style="padding:22px 36px">
    ${section('Personal Information', `<table>${row('Email', p.email ? esc(p.email) : '')}${row('Phone', p.phone ? esc(p.phone) : '')}${row('Location', p.location ? esc(p.location) : '')}${row('LinkedIn', p.linkedin ? esc(p.linkedin) : '')}${row('Website', p.website ? esc(p.website) : '')}</table>`)}
    ${p.summary ? section('Profile', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Work Experience', resume.workExperience.map(e => `
      <table style="margin-bottom:12px">${row('Dates', `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`)}${row('Position', `<b>${esc(e.jobTitle)}</b>`)}${row('Employer', esc(e.company) + (e.location ? `, ${esc(e.location)}` : ''))}${e.description ? row('Activities', descHtml(e.description)) : ''}</table>`).join('<hr style="border:0;border-top:1px solid #E5E7EB;margin:8px 0"/>')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => `
      <table style="margin-bottom:12px">${row('Dates', `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? 'Present')}`)}${row('Qualification', `<b>${esc(e.degree)}</b>${e.fieldOfStudy ? ` &mdash; ${esc(e.fieldOfStudy)}` : ''}`)}${row('Institution', esc(e.institution))}${e.grade ? row('Grade', esc(e.grade)) : ''}</table>`).join('<hr style="border:0;border-top:1px solid #E5E7EB;margin:8px 0"/>')) : ''}
    ${resume.skills.length ? section('Skills', `<div style="font-size:13px;color:#374151;line-height:2">${resume.skills.map(s => esc(s.name)).join(' &nbsp;&bull;&nbsp; ')}</div>`) : ''}
    ${resume.languages.length ? section('Languages', `<table>${resume.languages.map(l => row(esc(l.name), l.proficiency)).join('')}</table>`) : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => `<table style="margin-bottom:8px">${row('Date', c.date ? esc(c.date) : '')}${row('Certificate', `<b>${esc(c.name)}</b>`)}${row('Issued by', esc(c.issuer))}</table>`).join('<hr style="border:0;border-top:1px solid #E5E7EB;margin:6px 0"/>')) : ''}
    ${resume.awards.length ? section('Awards', resume.awards.map(a => `<table style="margin-bottom:8px">${row('Date', a.date ? esc(a.date) : '')}${row('Award', `<b>${esc(a.title)}</b>`)}${row('Issuer', a.issuer ? esc(a.issuer) : '')}${a.description ? row('Details', esc(a.description)) : ''}</table>`).join('')) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => `<table style="margin-bottom:8px">${row('Name', `<b>${esc(r.name)}</b>`)}${row('Title', [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '))}${row('Contact', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))}</table>`).join('<hr style="border:0;border-top:1px solid #E5E7EB;margin:6px 0"/>')) : ''}
  </div></body></html>`;
}

// ─── Template 20: Infographic ────────────────────────────────────────────────
// Progress bars for skills, visual icons, colorful but still readable
function buildInfographic(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const levelMap: Record<string, number> = { Expert: 95, Advanced: 80, Intermediate: 60, Beginner: 35 };
  const profMap: Record<string, number> = { Native: 100, Professional: 85, Intermediate: 65, Elementary: 40, Beginner: 25 };
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:13px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:10px;background:${accent}18;color:${accent};padding:2px 8px;border-radius:10px;font-weight:600;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:3px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">
        <div style="width:4px;height:18px;background:${accent};border-radius:2px"></div>
        <span style="font-size:12px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#111827">${title}</span>
      </div>
      ${body}
    </div>`;
  const skillBar = (name: string, level: number) => `
    <div style="margin-bottom:8px">
      <div style="display:flex;justify-content:space-between;margin-bottom:3px">
        <span style="font-size:12px;color:#374151;font-weight:600">${esc(name)}</span>
        <span style="font-size:11px;color:#9CA3AF">${level}%</span>
      </div>
      <div style="background:#F3F4F6;border-radius:4px;height:7px;overflow:hidden">
        <div style="width:${level}%;height:100%;background:linear-gradient(to right,${accent},${accent}CC);border-radius:4px"></div>
      </div>
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="display:flex;min-height:100vh">
    <div style="width:220px;min-width:220px;background:${accent}10;padding:28px 18px;border-right:2px solid ${accent}20">
      <div style="font-size:20px;font-weight:800;color:#111827;margin-bottom:3px;line-height:1.2">${esc(p.fullName || 'Your Name')}</div>
      <div style="font-size:12px;color:${accent};font-weight:700;margin-bottom:18px">${esc(p.jobTitle || '')}</div>
      <div style="margin-bottom:18px">
        <div style="font-size:9px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:${accent};margin-bottom:8px">Contact</div>
        ${[p.email, p.phone, p.location, p.linkedin].filter(Boolean).map(v => `<div style="font-size:11px;color:#374151;margin-bottom:5px;word-break:break-all">${esc(v!)}</div>`).join('')}
      </div>
      ${resume.skills.length ? `<div style="margin-bottom:18px"><div style="font-size:9px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:${accent};margin-bottom:10px">Skills</div>${resume.skills.map(s => skillBar(s.name, s.level ? levelMap[s.level] ?? 65 : 65)).join('')}</div>` : ''}
      ${resume.languages.length ? `<div><div style="font-size:9px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:${accent};margin-bottom:10px">Languages</div>${resume.languages.map(l => skillBar(l.name, profMap[l.proficiency] ?? 60)).join('')}</div>` : ''}
    </div>
    <div style="flex:1;padding:28px 24px">
      ${p.summary ? section('Profile', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
      ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
      ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree) + (e.fieldOfStudy ? ` &mdash; ${esc(e.fieldOfStudy)}` : ''), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.grade ? `GPA: ${esc(e.grade)}` : '')).join('')) : ''}
      ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
      ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
      ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
      ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
    </div>
  </div></body></html>`;
}

// ─── Template 21: Two-Column Grid ────────────────────────────────────────────
// Symmetric two columns (not a sidebar): wide left column + narrower right column
function buildTwoColumn(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:11px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const small = (title: string, sub: string, date: string) => `
    <div style="margin-bottom:10px">
      <div style="font-size:12px;font-weight:700;color:#111827">${title}</div>
      ${sub ? `<div style="font-size:11px;color:#6B7280">${sub}</div>` : ''}
      ${date ? `<div style="font-size:10px;color:#9CA3AF">${date}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:${accent};border-bottom:2px solid ${accent}30;padding-bottom:6px;margin-bottom:12px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; padding: 36px 40px; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="margin-bottom:24px;padding-bottom:18px;border-bottom:1px solid #E5E7EB">
    <div style="font-size:28px;font-weight:800;color:#111827">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:14px;color:${accent};font-weight:600;margin:5px 0 10px">${esc(p.jobTitle || '')}</div>
    <div style="font-size:12px;color:#6B7280">${contactLine(p)}</div>
  </div>
  <div style="display:flex;gap:28px">
    <div style="flex:1.7">
      ${p.summary ? section('Profile', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
      ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
      ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    </div>
    <div style="flex:1;border-left:1px solid #E5E7EB;padding-left:22px">
      ${resume.education.length ? section('Education', resume.education.map(e => small(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`)).join('')) : ''}
      ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:6px">${resume.skills.map(s => `<span style="background:#F3F4F6;color:#374151;font-size:11px;padding:3px 10px;border-radius:4px">${esc(s.name)}</span>`).join('')}</div>`) : ''}
      ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => small(esc(c.name), esc(c.issuer), esc(c.date ?? ''))).join('')) : ''}
      ${resume.languages.length ? section('Languages', resume.languages.map(l => `<div style="font-size:12px;margin-bottom:5px">${esc(l.name)} <span style="color:#9CA3AF">&middot; ${l.proficiency}</span></div>`).join('')) : ''}
      ${resume.awards.length ? section('Awards', resume.awards.map(a => small(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''))).join('')) : ''}
      ${resume.references.length ? section('References', resume.references.map(r => small(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
    </div>
  </div>
  </body></html>`;
}

// ─── Template 22: Newspaper ───────────────────────────────────────────────────
// Masthead-style name, rule lines, two-column skill "column" like newsprint
function buildNewspaper(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:11px;color:#6B7280;flex-shrink:0;margin-left:8px;font-style:italic">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#374151;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:13px;font-weight:700;text-transform:uppercase;letter-spacing:1px;border-bottom:2px solid #111827;padding-bottom:5px;margin-bottom:12px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: Georgia, 'Times New Roman', serif; font-size: 13px; color: #1F2937; background: #fff; padding: 34px 44px; }
    ul { color: #374151; } p { margin: 0; }
  </style></head><body>
  <div style="text-align:center;border-top:3px solid #111827;border-bottom:1px solid #111827;padding:14px 0;margin-bottom:6px">
    <div style="font-size:38px;font-weight:900;letter-spacing:1px;color:#111827;font-family:Georgia,serif">${esc((p.fullName || 'Your Name').toUpperCase())}</div>
  </div>
  <div style="text-align:center;border-bottom:3px solid #111827;padding-bottom:10px;margin-bottom:24px">
    <div style="font-size:13px;font-style:italic;color:${accent};font-weight:700;letter-spacing:2px;text-transform:uppercase">${esc(p.jobTitle || '')}</div>
    <div style="font-size:11px;color:#6B7280;margin-top:4px">${contactLine(p)}</div>
  </div>
  ${p.summary ? `<div style="margin-bottom:24px;font-size:13px;line-height:1.85;text-align:justify;column-count:2;column-gap:24px">${esc(p.summary)}</div>` : ''}
  ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree) + (e.fieldOfStudy ? ` &mdash; ${esc(e.fieldOfStudy)}` : ''), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, '')).join('')) : ''}
  ${resume.skills.length || resume.languages.length ? section('Skills &amp; Languages', `<div style="column-count:2;column-gap:24px;font-size:12px;line-height:2;color:#374151">${[...resume.skills.map(s => esc(s.name)), ...resume.languages.map(l => `${esc(l.name)} (${l.proficiency})`)].join('<br/>')}</div>`) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
  ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 23: Dashboard Stats ────────────────────────────────────────────
// Stat tiles computed from resume data, dashboard-card aesthetic
function buildDashboard(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:11px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#374151;margin-bottom:10px">${title}</div>
      ${body}
    </div>`;
  const stat = (n: number, label: string) => `
    <div style="flex:1;background:#F9FAFB;border-radius:10px;padding:14px;text-align:center;border:1px solid #F3F4F6">
      <div style="font-size:24px;font-weight:800;color:${accent}">${n}</div>
      <div style="font-size:10px;color:#6B7280;text-transform:uppercase;letter-spacing:0.5px;margin-top:2px">${label}</div>
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; padding: 32px 38px; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="margin-bottom:20px">
    <div style="font-size:27px;font-weight:800;color:#111827">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:14px;color:${accent};font-weight:600;margin:4px 0 10px">${esc(p.jobTitle || '')}</div>
    <div style="font-size:12px;color:#6B7280">${contactLine(p)}</div>
  </div>
  <div style="display:flex;gap:10px;margin-bottom:24px">
    ${stat(resume.workExperience.length, 'Roles')}
    ${stat(resume.skills.length, 'Skills')}
    ${stat(resume.projects.length, 'Projects')}
    ${stat(resume.certificates.length, 'Certs')}
  </div>
  ${p.summary ? section('Summary', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
  ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
  ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:7px">${resume.skills.map(s => `<span style="background:${accent}15;color:${accent};font-size:12px;padding:4px 12px;border-radius:6px;font-weight:600">${esc(s.name)}</span>`).join('')}</div>`) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
  ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
  ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} <span style="color:#9CA3AF">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 24: Boxed Frame ─────────────────────────────────────────────────
// Whole resume wrapped in a thin double-line border frame, thin-weight serif
function buildBoxedFrame(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:600;color:#111827">${title}</span>
        <span style="font-size:11px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:#4B5563;font-style:italic;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.7;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:11px;letter-spacing:2px;text-transform:uppercase;color:${accent};margin-bottom:10px;border-bottom:1px solid #E5E7EB;padding-bottom:5px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: Georgia, 'Times New Roman', serif; font-size: 13px; color: #1F2937; background: #fff; padding: 20px; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="border:3px double ${accent};padding:36px 42px;min-height:calc(100vh - 40px)">
    <div style="text-align:center;margin-bottom:28px">
      <div style="font-size:26px;font-weight:300;letter-spacing:3px;color:#111827">${esc((p.fullName || 'Your Name').toUpperCase())}</div>
      <div style="font-size:13px;color:${accent};margin:8px 0">${esc(p.jobTitle || '')}</div>
      <div style="font-size:11px;color:#9CA3AF">${contactLine(p)}</div>
    </div>
    ${p.summary ? section('Profile', `<div style="font-size:13px;color:#374151;line-height:1.8">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
    ${resume.skills.length ? section('Skills', `<div style="font-size:13px;color:#374151;line-height:2">${resume.skills.map(s => esc(s.name)).join(' &nbsp;&middot;&nbsp; ')}</div>`) : ''}
    ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} <span style="color:#9CA3AF">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
    ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </div>
  </body></html>`;
}

// ─── Template 25: Typewriter ──────────────────────────────────────────────────
// Monospace Courier, dashed borders, cream paper, retro typed look
function buildTypewriter(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:12px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:13px;font-weight:700;color:#292524">${title}</span>
        <span style="font-size:11px;color:#78716C;flex-shrink:0;margin-left:8px">[${date}]</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#44403C;line-height:1.7;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:18px;border:1px dashed #A8A29E;padding:12px 16px">
      <div style="font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:${accent};margin-bottom:10px">&gt;&gt; ${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Courier New', Courier, monospace; font-size: 13px; color: #292524; background: #FBF7EE; padding: 34px 40px; }
    ul { color: #44403C; } p { margin: 0; }
  </style></head><body>
  <div style="text-align:center;margin-bottom:22px">
    <div style="font-size:13px;color:#78716C">===================================</div>
    <div style="font-size:24px;font-weight:700;letter-spacing:1px;margin:8px 0;color:#292524">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:13px;color:${accent}">${esc(p.jobTitle || '')}</div>
    <div style="font-size:11px;color:#78716C;margin-top:6px">${contactLine(p)}</div>
    <div style="font-size:13px;color:#78716C;margin-top:6px">===================================</div>
  </div>
  ${p.summary ? section('Summary', `<div style="font-size:12px;color:#44403C;line-height:1.75">${esc(p.summary)}</div>`) : ''}
  ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} - ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} - ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
  ${resume.skills.length ? section('Skills', `<div style="font-size:12px;color:#44403C">${resume.skills.map(s => esc(s.name)).join(' | ')}</div>`) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
  ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
  ${resume.languages.length ? section('Languages', `<div style="font-size:12px">${resume.languages.map(l => `${esc(l.name)} (${l.proficiency})`).join(' | ')}</div>`) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 26: Swiss Grid ──────────────────────────────────────────────────
// Huge numbered labels beside each section, asymmetric Helvetica grid
function buildSwissGrid(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  let idx = 0;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:13px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:11px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:700;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#374151;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => {
    idx += 1;
    return `
    <div style="display:flex;gap:20px;margin-bottom:26px;border-top:1px solid #111827;padding-top:14px">
      <div style="width:64px;flex-shrink:0;font-size:34px;font-weight:900;color:${accent};line-height:1">${String(idx).padStart(2, '0')}</div>
      <div style="flex:1">
        <div style="font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:#111827;margin-bottom:12px">${title}</div>
        ${body}
      </div>
    </div>`;
  };
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Helvetica Neue', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; padding: 40px 44px; }
    ul { color: #374151; } p { margin: 0; }
  </style></head><body>
  <div style="margin-bottom:8px">
    <div style="font-size:44px;font-weight:900;letter-spacing:-1px;color:#111827;line-height:1;text-transform:uppercase">${esc(p.fullName || 'Your Name')}</div>
    <div style="width:60px;height:6px;background:${accent};margin:10px 0"></div>
    <div style="font-size:14px;font-weight:700;color:#111827;text-transform:uppercase;letter-spacing:1px">${esc(p.jobTitle || '')}</div>
    <div style="font-size:11px;color:#6B7280;margin-top:8px">${contactLine(p)}</div>
  </div>
  ${p.summary ? section('Profile', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
  ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
  ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:8px">${resume.skills.map(s => `<span style="background:#111827;color:#fff;font-size:11px;padding:4px 12px;font-weight:700">${esc(s.name)}</span>`).join('')}</div>`) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
  ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
  ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px;font-weight:700">${esc(l.name)} <span style="font-weight:400;color:#6B7280">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 27: Kanban Board ────────────────────────────────────────────────
// Skills/Languages/Certs as horizontal Trello-style board columns
function buildKanban(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:11px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#374151;margin-bottom:10px">${title}</div>
      ${body}
    </div>`;
  const board = (title: string, items: string[]) => items.length ? `
    <div style="flex:1;background:#F3F4F6;border-radius:8px;padding:10px;min-width:0">
      <div style="font-size:10px;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:#6B7280;margin-bottom:8px">${title}</div>
      ${items.map(it => `<div style="background:#fff;border-radius:6px;padding:7px 10px;margin-bottom:6px;font-size:11px;color:#374151;box-shadow:0 1px 2px rgba(0,0,0,0.06)">${it}</div>`).join('')}
    </div>` : '';
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; padding: 34px 38px; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="margin-bottom:20px">
    <div style="font-size:27px;font-weight:800;color:#111827">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:14px;color:${accent};font-weight:600;margin:4px 0 10px">${esc(p.jobTitle || '')}</div>
    <div style="font-size:12px;color:#6B7280">${contactLine(p)}</div>
  </div>
  <div style="display:flex;gap:10px;margin-bottom:24px">
    ${board('Skills', resume.skills.map(s => esc(s.name)))}
    ${board('Languages', resume.languages.map(l => `${esc(l.name)} &middot; ${l.proficiency}`))}
    ${board('Certifications', resume.certificates.map(c => `<b>${esc(c.name)}</b>${c.issuer ? `<br/><span style="color:#9CA3AF">${esc(c.issuer)}</span>` : ''}`))}
  </div>
  ${p.summary ? section('Summary', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
  ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 28: Ribbon Header ───────────────────────────────────────────────
// Name shown inside a ribbon-banner shape with triangle notches
function buildRibbon(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:11px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:${accent};margin-bottom:10px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: Georgia, serif; font-size: 13px; color: #1F2937; background: #fff; padding: 40px 44px; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="text-align:center;margin-bottom:26px">
    <div style="display:inline-flex;align-items:stretch">
      <div style="width:0;height:0;border-top:20px solid transparent;border-bottom:20px solid transparent;border-right:14px solid ${accent}CC"></div>
      <div style="background:${accent};color:#fff;padding:14px 40px;font-size:26px;font-weight:700;letter-spacing:1px">${esc(p.fullName || 'Your Name')}</div>
      <div style="width:0;height:0;border-top:20px solid transparent;border-bottom:20px solid transparent;border-left:14px solid ${accent}CC"></div>
    </div>
    <div style="font-size:14px;color:${accent};font-weight:600;font-style:italic;margin-top:14px">${esc(p.jobTitle || '')}</div>
    <div style="font-size:11px;color:#9CA3AF;margin-top:6px">${contactLine(p)}</div>
  </div>
  ${p.summary ? section('Profile', `<div style="font-size:13px;color:#374151;line-height:1.8;text-align:center">${esc(p.summary)}</div>`) : ''}
  ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
  ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center">${resume.skills.map(s => `<span style="border:1px solid ${accent};color:${accent};font-size:12px;padding:3px 13px;border-radius:20px">${esc(s.name)}</span>`).join('')}</div>`) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
  ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
  ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px;justify-content:center">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} <span style="color:#9CA3AF">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 29: Split Diagonal ──────────────────────────────────────────────
// Header split into two skewed diagonal color blocks
function buildDiagonalSplit(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:11px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#374151;margin-bottom:10px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="position:relative;height:150px;overflow:hidden;background:#F3F4F6">
    <div style="position:absolute;top:0;left:-15%;width:65%;height:200%;top:-30%;background:#111827;transform:skewX(-10deg)"></div>
    <div style="position:relative;z-index:2;display:flex;height:150px;align-items:center;padding:0 44px">
      <div style="flex:1;color:#fff">
        <div style="font-size:26px;font-weight:800">${esc(p.fullName || 'Your Name')}</div>
        <div style="font-size:13px;color:${accent};font-weight:600;margin-top:4px">${esc(p.jobTitle || '')}</div>
      </div>
      <div style="flex:1;text-align:right;font-size:12px;color:#374151">
        ${[p.email, p.phone, p.location, p.linkedin].filter(Boolean).map(v => `<div style="margin-bottom:3px">${esc(v!)}</div>`).join('')}
      </div>
    </div>
  </div>
  <div style="padding:26px 44px">
    ${p.summary ? section('Profile', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
    ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:8px">${resume.skills.map(s => `<span style="background:${accent}18;color:${accent};font-size:12px;padding:4px 12px;border-radius:4px;font-weight:600">${esc(s.name)}</span>`).join('')}</div>`) : ''}
    ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} <span style="color:#9CA3AF">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
    ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </div>
  </body></html>`;
}

// ─── Template 30: Letterpress ─────────────────────────────────────────────────
// Warm cream, embossed name, thin hairline rules, elegant minimalism
function buildLetterpress(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:15px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:13px;font-weight:600;color:#3F3A34">${title}</span>
        <span style="font-size:11px;color:#A39E93;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#57534E;line-height:1.75;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:24px">
      <div style="font-size:10px;letter-spacing:3px;text-transform:uppercase;color:#A39E93;margin-bottom:12px;border-bottom:1px solid #E7E2D8;padding-bottom:8px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: Georgia, 'Times New Roman', serif; font-size: 13px; color: #3F3A34; background: #FAF7F0; padding: 46px 56px; }
    ul { color: #57534E; } p { margin: 0; }
  </style></head><body>
    <div style="text-align:center;margin-bottom:34px">
      <div style="font-size:32px;letter-spacing:2px;color:#3F3A34;text-shadow:1px 1px 0 rgba(255,255,255,0.9),-1px -1px 1px rgba(0,0,0,0.06)">${esc(p.fullName || 'Your Name')}</div>
      <div style="font-size:13px;color:${accent};letter-spacing:1px;margin-top:8px">${esc(p.jobTitle || '')}</div>
      <div style="font-size:11px;color:#A39E93;margin-top:10px">${contactLine(p)}</div>
    </div>
    ${p.summary ? section('Profile', `<div style="font-size:13px;color:#57534E;line-height:1.85;font-style:italic;text-align:center">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
    ${resume.skills.length ? section('Skills', `<div style="font-size:13px;color:#57534E;line-height:2;text-align:center">${resume.skills.map(s => esc(s.name)).join(' &nbsp;&middot;&nbsp; ')}</div>`) : ''}
    ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:16px;justify-content:center">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} <span style="color:#A39E93">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
    ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 31: Blueprint ───────────────────────────────────────────────────
// Technical drafting grid background, corner-bracket accents, monospace labels
function buildBlueprint(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:13px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:13px;font-weight:700;color:#1E293B">${title}</span>
        <span style="font-size:10px;color:#64748B;font-family:monospace;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#475569;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="position:relative;border:1px solid ${accent}40;padding:14px 16px;margin-bottom:18px">
      <div style="position:absolute;top:-1px;left:-1px;width:10px;height:10px;border-top:2px solid ${accent};border-left:2px solid ${accent}"></div>
      <div style="position:absolute;top:-1px;right:-1px;width:10px;height:10px;border-top:2px solid ${accent};border-right:2px solid ${accent}"></div>
      <div style="position:absolute;bottom:-1px;left:-1px;width:10px;height:10px;border-bottom:2px solid ${accent};border-left:2px solid ${accent}"></div>
      <div style="position:absolute;bottom:-1px;right:-1px;width:10px;height:10px;border-bottom:2px solid ${accent};border-right:2px solid ${accent}"></div>
      <div style="font-size:10px;font-family:monospace;letter-spacing:1.5px;color:${accent};margin-bottom:10px">[ ${title} ]</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1E293B; background-color: #fff;
      background-image: linear-gradient(${accent}18 1px, transparent 1px), linear-gradient(90deg, ${accent}18 1px, transparent 1px);
      background-size: 22px 22px; padding: 34px 40px; }
    ul { color: #475569; } p { margin: 0; }
  </style></head><body>
  <div style="margin-bottom:22px">
    <div style="font-size:26px;font-weight:800;color:#1E293B;font-family:monospace">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:13px;color:${accent};font-weight:600;margin:4px 0;font-family:monospace">${esc(p.jobTitle || '')}</div>
    <div style="font-size:11px;color:#64748B;font-family:monospace">${contactLine(p)}</div>
  </div>
  ${p.summary ? section('ABOUT', `<div style="font-size:13px;color:#475569;line-height:1.75">${esc(p.summary)}</div>`) : ''}
  ${resume.workExperience.length ? section('EXPERIENCE', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} - ${e.isPresent ? 'PRESENT' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
  ${resume.education.length ? section('EDUCATION', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} - ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
  ${resume.skills.length ? section('SKILLS', `<div style="display:flex;flex-wrap:wrap;gap:7px">${resume.skills.map(s => `<span style="border:1px solid ${accent};color:${accent};font-size:11px;padding:3px 10px;font-family:monospace">${esc(s.name)}</span>`).join('')}</div>`) : ''}
  ${resume.projects.length ? section('PROJECTS', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
  ${resume.certificates.length ? section('CERTIFICATIONS', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
  ${resume.languages.length ? section('LANGUAGES', `<div style="font-size:12px;font-family:monospace">${resume.languages.map(l => `${esc(l.name)}[${l.proficiency}]`).join(' &nbsp; ')}</div>`) : ''}
  ${resume.awards.length ? section('AWARDS', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
  ${resume.references.length ? section('REFERENCES', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 32: Chat Bubble ─────────────────────────────────────────────────
// Experience entries as alternating rounded chat-bubble cards
function buildChatBubble(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const bubble = (title: string, sub: string, date: string, desc: string, i: number) => {
    const right = i % 2 === 1;
    return `
    <div style="display:flex;justify-content:${right ? 'flex-end' : 'flex-start'};margin-bottom:12px">
      <div style="max-width:78%;background:${right ? accent + '15' : '#F3F4F6'};border-radius:${right ? '16px 16px 4px 16px' : '16px 16px 16px 4px'};padding:12px 15px">
        <div style="display:flex;justify-content:space-between;gap:10px">
          <span style="font-size:13px;font-weight:700;color:#111827">${title}</span>
          <span style="font-size:10px;color:#9CA3AF;flex-shrink:0">${date}</span>
        </div>
        ${sub ? `<div style="font-size:11px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
        ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.6;margin-top:3px">${desc}</div>` : ''}
      </div>
    </div>`;
  };
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:#374151;margin-bottom:12px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; padding: 34px 38px; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="text-align:center;margin-bottom:24px">
    <div style="width:60px;height:60px;border-radius:50%;background:${accent};color:#fff;display:flex;align-items:center;justify-content:center;font-size:22px;font-weight:700;margin:0 auto 10px">${(p.fullName || 'YN').split(' ').map((w: string) => w[0]).join('').toUpperCase().slice(0, 2)}</div>
    <div style="font-size:24px;font-weight:800;color:#111827">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:13px;color:${accent};font-weight:600;margin:4px 0 8px">${esc(p.jobTitle || '')}</div>
    <div style="font-size:11px;color:#9CA3AF">${contactLine(p)}</div>
  </div>
  ${p.summary ? section('About', `<div style="background:#F3F4F6;border-radius:16px;padding:12px 16px;font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
  ${resume.workExperience.length ? section('Experience', resume.workExperience.map((e, i) => bubble(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)}&ndash;${e.isPresent ? 'Now' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''), i)).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map((e, i) => bubble(esc(e.degree), esc(e.institution), `${esc(e.startYear)}&ndash;${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '', i)).join('')) : ''}
  ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:7px">${resume.skills.map(s => `<span style="background:${accent}18;color:${accent};font-size:12px;padding:5px 13px;border-radius:20px;font-weight:600">${esc(s.name)}</span>`).join('')}</div>`) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map((pr, i) => bubble(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''), i)).join('')) : ''}
  ${resume.certificates.length ? section('Certifications', resume.certificates.map((c, i) => bubble(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '', i)).join('')) : ''}
  ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:8px">${resume.languages.map(l => `<span style="background:#F3F4F6;color:#374151;font-size:12px;padding:4px 12px;border-radius:20px">${esc(l.name)} &middot; ${l.proficiency}</span>`).join('')}</div>`) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map((a, i) => bubble(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''), i)).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map((r, i) => bubble(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '), i)).join('')) : ''}
  </body></html>`;
}

// ─── Template 33: Vertical Tabs ───────────────────────────────────────────────
// Narrow rotated tab-label strip on the far left, content to the right
function buildVerticalTabs(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:11px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:${accent};margin-bottom:10px">${title}</div>
      ${body}
    </div>`;
  const tabLabels = [
    resume.workExperience.length && 'Experience', resume.education.length && 'Education',
    resume.skills.length && 'Skills', resume.projects.length && 'Projects',
  ].filter(Boolean) as string[];
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="display:flex;min-height:100vh">
    <div style="width:44px;min-width:44px;background:${accent};display:flex;flex-direction:column">
      ${(tabLabels.length ? tabLabels : ['Resume']).map(label => `
        <div style="flex:1;display:flex;align-items:center;justify-content:center;border-bottom:1px solid rgba(255,255,255,0.25)">
          <span style="writing-mode:vertical-rl;transform:rotate(180deg);color:#fff;font-size:10px;font-weight:700;letter-spacing:2px;text-transform:uppercase">${label}</span>
        </div>`).join('')}
    </div>
    <div style="flex:1;padding:32px 36px">
      <div style="margin-bottom:22px">
        <div style="font-size:26px;font-weight:800;color:#111827">${esc(p.fullName || 'Your Name')}</div>
        <div style="font-size:13px;color:${accent};font-weight:600;margin:4px 0 8px">${esc(p.jobTitle || '')}</div>
        <div style="font-size:11px;color:#6B7280">${contactLine(p)}</div>
      </div>
      ${p.summary ? section('Profile', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
      ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
      ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
      ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:8px">${resume.skills.map(s => `<span style="background:${accent}15;color:${accent};font-size:12px;padding:4px 12px;border-radius:4px;font-weight:600">${esc(s.name)}</span>`).join('')}</div>`) : ''}
      ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
      ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
      ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} <span style="color:#9CA3AF">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
      ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
      ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
    </div>
  </div>
  </body></html>`;
}

// ─── Template 34: Folder Tab ──────────────────────────────────────────────────
// Manila-folder tab peeking above the content page
function buildFolderTab(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#292524">${title}</span>
        <span style="font-size:11px;color:#A8A29E;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#57534E;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:${accent};border-bottom:1px solid #E7E2D8;padding-bottom:6px;margin-bottom:12px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #292524; background: #FEF9F0; padding: 46px 34px 34px; }
    ul { color: #57534E; } p { margin: 0; }
  </style></head><body>
  <div style="position:relative;background:#fff;border-radius:8px;padding:34px 36px;box-shadow:0 2px 10px rgba(0,0,0,0.06)">
    <div style="position:absolute;top:-24px;left:28px;background:${accent};color:#fff;padding:9px 24px;border-radius:6px 6px 0 0;font-size:16px;font-weight:700">${esc(p.fullName || 'Your Name')}</div>
    <div style="padding-top:8px;margin-bottom:22px">
      <div style="font-size:13px;color:${accent};font-weight:600">${esc(p.jobTitle || '')}</div>
      <div style="font-size:11px;color:#A8A29E;margin-top:6px">${contactLine(p)}</div>
    </div>
    ${p.summary ? section('Profile', `<div style="font-size:13px;color:#57534E;line-height:1.75">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
    ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:7px">${resume.skills.map(s => `<span style="background:#FEF3E2;color:#92400E;font-size:12px;padding:4px 12px;border-radius:4px">${esc(s.name)}</span>`).join('')}</div>`) : ''}
    ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} <span style="color:#A8A29E">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
    ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </div>
  </body></html>`;
}

// ─── Template 35: Stacked Cards ───────────────────────────────────────────────
// Masonry-style 2-column card grid, every section is its own card
function buildStackedCards(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:10px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:13px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:10px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:11px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:11px;color:#4B5563;line-height:1.6;margin-top:3px">${desc}</div>` : ''}
    </div>`;
  const card = (title: string, body: string) => `
    <div style="display:inline-block;width:100%;break-inside:avoid;background:#F9FAFB;border-radius:10px;padding:14px 16px;margin-bottom:14px;border:1px solid #F3F4F6">
      <div style="font-size:10px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:${accent};margin-bottom:10px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; padding: 34px 38px; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="margin-bottom:22px">
    <div style="font-size:27px;font-weight:800;color:#111827">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:14px;color:${accent};font-weight:600;margin:4px 0 8px">${esc(p.jobTitle || '')}</div>
    <div style="font-size:11px;color:#6B7280">${contactLine(p)}</div>
  </div>
  <div style="column-count:2;column-gap:16px">
    ${p.summary ? card('Profile', `<div style="font-size:12px;color:#374151;line-height:1.7">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? card('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)}&ndash;${e.isPresent ? 'Now' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? card('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)}&ndash;${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
    ${resume.skills.length ? card('Skills', `<div style="display:flex;flex-wrap:wrap;gap:6px">${resume.skills.map(s => `<span style="background:#fff;color:#374151;font-size:11px;padding:3px 9px;border-radius:4px;border:1px solid #E5E7EB">${esc(s.name)}</span>`).join('')}</div>`) : ''}
    ${resume.projects.length ? card('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? card('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? card('Languages', resume.languages.map(l => `<div style="font-size:11px;margin-bottom:4px">${esc(l.name)} <span style="color:#9CA3AF">&middot; ${l.proficiency}</span></div>`).join('')) : ''}
    ${resume.awards.length ? card('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? card('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </div>
  </body></html>`;
}

// ─── Template 36: Halftone Pop ────────────────────────────────────────────────
// Comic/pop-art look — thick borders, dot-pattern background, bright blocks
function buildHalftone(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:13px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:800;color:#111827">${title}</span>
        <span style="font-size:10px;color:#fff;background:#111827;padding:2px 8px;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:700;margin:3px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#374151;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="display:inline-block;background:${accent};color:#111827;font-size:12px;font-weight:800;letter-spacing:1px;text-transform:uppercase;padding:4px 14px;border:2.5px solid #111827;margin-bottom:12px;transform:rotate(-1deg)">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background-color: #fff;
      background-image: radial-gradient(circle, #00000014 1.4px, transparent 1.4px); background-size: 11px 11px; padding: 32px 36px; }
    ul { color: #374151; } p { margin: 0; }
  </style></head><body>
  <div style="border:3px solid #111827;background:${accent};padding:20px 24px;margin-bottom:24px;transform:rotate(-0.6deg)">
    <div style="font-size:32px;font-weight:900;color:#111827;letter-spacing:-0.5px">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:14px;font-weight:700;color:#111827;margin:5px 0">${esc(p.jobTitle || '')}</div>
    <div style="font-size:11px;color:#111827;opacity:.8">${contactLine(p)}</div>
  </div>
  ${p.summary ? section('Bio', `<div style="font-size:13px;color:#374151;line-height:1.75;border:2px solid #111827;padding:10px 14px;background:#fff">${esc(p.summary)}</div>`) : ''}
  ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)}&ndash;${e.isPresent ? 'Now' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)}&ndash;${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
  ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:8px">${resume.skills.map(s => `<span style="background:#fff;color:#111827;font-size:12px;font-weight:700;padding:4px 12px;border:2px solid #111827">${esc(s.name)}</span>`).join('')}</div>`) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
  ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
  ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px;font-weight:700">${esc(l.name)} <span style="font-weight:400;color:#6B7280">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 37: Wave Curve ──────────────────────────────────────────────────
// Header with a smooth curved bottom edge blending into the content below
function buildWaveCurve(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#111827">${title}</span>
        <span style="font-size:11px;color:#9CA3AF;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#4B5563;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:20px">
      <div style="font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:${accent};margin-bottom:10px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #1F2937; background: #fff; }
    ul { color: #4B5563; } p { margin: 0; }
  </style></head><body>
  <div style="position:relative;background:${accent};padding:40px 44px 64px;color:#fff;overflow:hidden">
    <div style="font-size:28px;font-weight:800">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:14px;opacity:.9;margin:5px 0 12px">${esc(p.jobTitle || '')}</div>
    <div style="font-size:12px;opacity:.82;display:flex;flex-wrap:wrap;gap:14px">${[p.email, p.phone, p.location, p.linkedin].filter(Boolean).map(v => `<span>${esc(v!)}</span>`).join('')}</div>
    <div style="position:absolute;bottom:-46px;left:-12%;width:124%;height:90px;background:#fff;border-radius:50%"></div>
  </div>
  <div style="padding:8px 44px 26px">
    ${p.summary ? section('Profile', `<div style="font-size:13px;color:#374151;line-height:1.75">${esc(p.summary)}</div>`) : ''}
    ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &ndash; ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
    ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
    ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:8px">${resume.skills.map(s => `<span style="background:${accent}15;color:${accent};font-size:12px;padding:4px 13px;border-radius:20px;font-weight:600">${esc(s.name)}</span>`).join('')}</div>`) : ''}
    ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
    ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
    ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="font-size:13px">${esc(l.name)} <span style="color:#9CA3AF">&middot; ${l.proficiency}</span></span>`).join('')}</div>`) : ''}
    ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
    ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </div>
  </body></html>`;
}

// ─── Template 38: Ledger ──────────────────────────────────────────────────────
// Entire resume as a bordered table/ledger grid — plain, scanner-friendly
function buildLedger(resume: ResumeData): string {
  const p = resume.personalInfo;
  const cellStyle = 'border:1px solid #999;padding:6px 10px;font-size:12px;vertical-align:top';
  const row = (label: string, value: string) => value ? `<tr><td style="${cellStyle};width:150px;font-weight:700;background:#F3F4F6">${label}</td><td style="${cellStyle}">${value}</td></tr>` : '';
  const section = (title: string, rowsHtml: string) => `
    <table style="width:100%;border-collapse:collapse;margin-bottom:14px">
      <tr><td colspan="2" style="${cellStyle};background:#111827;color:#fff;font-weight:700;text-transform:uppercase;letter-spacing:1px;font-size:11px">${title}</td></tr>
      ${rowsHtml}
    </table>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: Arial, sans-serif; font-size: 12px; color: #111827; background: #fff; padding: 30px 36px; }
    table { border-collapse: collapse; } ul { color: #111827; } p { margin: 0; }
  </style></head><body>
  ${section('Personal Information', `${row('Name', esc(p.fullName || 'Your Name'))}${row('Job Title', esc(p.jobTitle || ''))}${row('Email', p.email ? esc(p.email) : '')}${row('Phone', p.phone ? esc(p.phone) : '')}${row('Location', p.location ? esc(p.location) : '')}${row('LinkedIn', p.linkedin ? esc(p.linkedin) : '')}`)}
  ${p.summary ? section('Summary', row('Profile', esc(p.summary))) : ''}
  ${resume.workExperience.length ? section('Work Experience', resume.workExperience.map(e => `${row('Position', `${esc(e.jobTitle)} at ${esc(e.company)}`)}${row('Dates', `${esc(e.startDate)} - ${e.isPresent ? 'Present' : esc(e.endDate ?? '')}`)}${e.description ? row('Details', descHtml(e.description)) : ''}`).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map(e => `${row('Degree', esc(e.degree) + (e.fieldOfStudy ? `, ${esc(e.fieldOfStudy)}` : ''))}${row('Institution', esc(e.institution))}${row('Years', `${esc(e.startYear)} - ${esc(e.endYear ?? '')}`)}`).join('')) : ''}
  ${resume.skills.length ? section('Skills', row('Skills', resume.skills.map(s => esc(s.name)).join(', '))) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map(pr => `${row('Project', esc(pr.name))}${pr.technologies ? row('Tech', esc(pr.technologies)) : ''}${pr.description ? row('Details', descHtml(pr.description)) : ''}`).join('')) : ''}
  ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => row('Certificate', `${esc(c.name)} &mdash; ${esc(c.issuer)}${c.date ? ` (${esc(c.date)})` : ''}`)).join('')) : ''}
  ${resume.languages.length ? section('Languages', row('Languages', resume.languages.map(l => `${esc(l.name)} (${l.proficiency})`).join(', '))) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map(a => row('Award', `${esc(a.title)}${a.issuer ? ` &mdash; ${esc(a.issuer)}` : ''}${a.date ? ` (${esc(a.date)})` : ''}`)).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map(r => row('Reference', `${esc(r.name)}${r.position ? `, ${esc(r.position)}` : ''}${r.company ? ` &mdash; ${esc(r.company)}` : ''} &nbsp; ${[r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | ')}`)).join('')) : ''}
  </body></html>`;
}

// ─── Template 39: Neon Dark ───────────────────────────────────────────────────
// Near-black background with glowing neon text-shadow accents, centered header
function buildNeonDark(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string) => `
    <div style="margin-bottom:14px">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:14px;font-weight:700;color:#F1F5F9">${title}</span>
        <span style="font-size:11px;color:${accent};flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:#94A3B8;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#94A3B8;line-height:1.65;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="border:1px solid ${accent}40;box-shadow:0 0 14px ${accent}25;border-radius:10px;padding:14px 16px;margin-bottom:16px;background:#12121A">
      <div style="font-size:11px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:${accent};margin-bottom:10px;text-shadow:0 0 8px ${accent}80">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; background: #0B0B12; color: #E2E8F0; padding: 36px 40px; }
    ul { color: #94A3B8; padding-left: 18px; } p { margin: 0; }
  </style></head><body>
  <div style="text-align:center;margin-bottom:28px">
    <div style="font-size:32px;font-weight:800;color:#fff;text-shadow:0 0 10px ${accent},0 0 24px ${accent}70;letter-spacing:1px">${esc(p.fullName || 'Your Name')}</div>
    <div style="font-size:14px;color:${accent};font-weight:600;margin:6px 0;text-shadow:0 0 8px ${accent}60">${esc(p.jobTitle || '')}</div>
    <div style="font-size:12px;color:#64748B">${[p.email, p.phone, p.location].filter(Boolean).map(v => esc(v!)).join(' &nbsp;&middot;&nbsp; ')}</div>
  </div>
  ${p.summary ? section('About', `<div style="font-size:13px;color:#94A3B8;line-height:1.75">${esc(p.summary)}</div>`) : ''}
  ${resume.workExperience.length ? section('Experience', resume.workExperience.map(e => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)} &rarr; ${e.isPresent ? 'Now' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''))).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map(e => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)} &ndash; ${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '')).join('')) : ''}
  ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:8px">${resume.skills.map(s => `<span style="background:${accent}18;color:${accent};font-size:12px;padding:4px 12px;border-radius:20px;border:1px solid ${accent}60">${esc(s.name)}</span>`).join('')}</div>`) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map(pr => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''))).join('')) : ''}
  ${resume.certificates.length ? section('Certifications', resume.certificates.map(c => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '')).join('')) : ''}
  ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:14px">${resume.languages.map(l => `<span style="color:#94A3B8;font-size:12px">${esc(l.name)} <span style="color:${accent}">[${l.proficiency}]</span></span>`).join('')}</div>`) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map(a => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''))).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map(r => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '))).join('')) : ''}
  </body></html>`;
}

// ─── Template 40: Scrapbook ───────────────────────────────────────────────────
// Washi-tape section headers at slight rotation, warm scrapbook aesthetic
function buildScrapbook(resume: ResumeData, accent: string): string {
  const p = resume.personalInfo;
  const entry = (title: string, sub: string, date: string, desc: string, i: number) => `
    <div style="margin-bottom:12px;background:#fff;border-radius:6px;padding:11px 14px;box-shadow:0 2px 6px rgba(0,0,0,0.08);transform:rotate(${i % 2 === 0 ? '-0.6deg' : '0.6deg'})">
      <div style="display:flex;justify-content:space-between;align-items:baseline">
        <span style="font-size:13px;font-weight:700;color:#78350F">${title}</span>
        <span style="font-size:10px;color:#B45309;flex-shrink:0;margin-left:8px">${date}</span>
      </div>
      ${sub ? `<div style="font-size:12px;color:${accent};font-weight:600;margin:2px 0">${sub}</div>` : ''}
      ${desc ? `<div style="font-size:12px;color:#57534E;line-height:1.6;margin-top:4px">${desc}</div>` : ''}
    </div>`;
  const section = (title: string, body: string) => `
    <div style="margin-bottom:22px">
      <div style="display:inline-block;background:${accent}30;border:1px dashed ${accent};padding:5px 16px;transform:rotate(-2deg);font-weight:700;color:#78350F;font-size:11px;letter-spacing:1px;text-transform:uppercase;margin-bottom:12px">${title}</div>
      ${body}
    </div>`;
  return `<!DOCTYPE html><html><head><meta charset="utf-8"/>
  <style>
    ${PAGE_CSS}
    body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 13px; color: #57534E; background: #FFFBF0; padding: 36px 40px; }
    ul { color: #57534E; } p { margin: 0; }
  </style></head><body>
  <div style="text-align:center;margin-bottom:26px">
    <div style="display:inline-block;background:#fff;padding:16px 32px;border-radius:8px;box-shadow:0 3px 8px rgba(0,0,0,0.1);transform:rotate(-1deg)">
      <div style="font-size:26px;font-weight:800;color:#78350F">${esc(p.fullName || 'Your Name')}</div>
      <div style="font-size:13px;color:${accent};font-weight:700;margin:4px 0">${esc(p.jobTitle || '')}</div>
      <div style="font-size:11px;color:#A8A29E">${contactLine(p)}</div>
    </div>
  </div>
  ${p.summary ? section('About Me', entry(esc(p.summary), '', '', '', 0)) : ''}
  ${resume.workExperience.length ? section('Experience', resume.workExperience.map((e, i) => entry(esc(e.jobTitle), esc(e.company), `${esc(e.startDate)}&ndash;${e.isPresent ? 'Now' : esc(e.endDate ?? '')}`, descHtml(e.description ?? ''), i)).join('')) : ''}
  ${resume.education.length ? section('Education', resume.education.map((e, i) => entry(esc(e.degree), esc(e.institution), `${esc(e.startYear)}&ndash;${esc(e.endYear ?? '')}`, e.fieldOfStudy ? esc(e.fieldOfStudy) : '', i)).join('')) : ''}
  ${resume.skills.length ? section('Skills', `<div style="display:flex;flex-wrap:wrap;gap:8px">${resume.skills.map((s, i) => `<span style="background:#fff;color:#78350F;font-size:12px;padding:4px 13px;border-radius:6px;box-shadow:0 2px 4px rgba(0,0,0,0.08);transform:rotate(${i % 2 === 0 ? '-2deg' : '2deg'})">${esc(s.name)}</span>`).join('')}</div>`) : ''}
  ${resume.projects.length ? section('Projects', resume.projects.map((pr, i) => entry(esc(pr.name), esc(pr.technologies ?? ''), pr.startDate ? esc(pr.startDate) : '', descHtml(pr.description ?? ''), i)).join('')) : ''}
  ${resume.certificates.length ? section('Certifications', resume.certificates.map((c, i) => entry(esc(c.name), esc(c.issuer), esc(c.date ?? ''), '', i)).join('')) : ''}
  ${resume.languages.length ? section('Languages', `<div style="display:flex;flex-wrap:wrap;gap:10px">${resume.languages.map(l => `<span style="font-size:12px;color:#57534E">${esc(l.name)} &middot; ${l.proficiency}</span>`).join('')}</div>`) : ''}
  ${resume.awards.length ? section('Awards', resume.awards.map((a, i) => entry(esc(a.title), esc(a.issuer ?? ''), esc(a.date ?? ''), esc(a.description ?? ''), i)).join('')) : ''}
  ${resume.references.length ? section('References', resume.references.map((r, i) => entry(esc(r.name), [r.position, r.company].filter(Boolean).map(v => esc(v!)).join(', '), '', [r.email, r.phone].filter(Boolean).map(v => esc(v!)).join(' | '), i)).join('')) : ''}
  </body></html>`;
}

// ─── Public entry point ───────────────────────────────────────────────────────

export function buildResumeHtml(resume: ResumeData, accentColor: string = '#2563EB', templateId?: string): string {
  const id = templateId ?? resume.templateId ?? 'professional-1';
  switch (id) {
    case 'modern-1':       return buildModern(resume, accentColor);
    case 'minimal-1':      return buildMinimal(resume, accentColor);
    case 'creative-1':     return buildCreative(resume, accentColor);
    case 'ats-1':          return buildATS(resume);
    case 'professional-2': return buildExecutive(resume, accentColor);
    case 'modern-2':       return buildTechPro(resume, accentColor);
    case 'minimal-2':      return buildCleanSlate(resume, accentColor);
    case 'bold-1':         return buildBoldImpact(resume, accentColor);
    case 'gradient-1':     return buildGradient(resume, accentColor);
    case 'accent-1':       return buildSideAccent(resume, accentColor);
    case 'academic-1':     return buildAcademic(resume, accentColor);
    case 'compact-1':      return buildCompact(resume, accentColor);
    case 'magazine-1':     return buildMagazine(resume, accentColor);
    case 'timeline-1':     return buildTimeline(resume, accentColor);
    case 'finance-1':      return buildFinance(resume, accentColor);
    case 'startup-1':      return buildStartup(resume, accentColor);
    case 'healthcare-1':   return buildHealthcare(resume, accentColor);
    case 'euro-1':         return buildEuroCV(resume, accentColor);
    case 'infographic-1':  return buildInfographic(resume, accentColor);
    case 'twocol-1':       return buildTwoColumn(resume, accentColor);
    case 'newspaper-1':    return buildNewspaper(resume, accentColor);
    case 'dashboard-1':    return buildDashboard(resume, accentColor);
    case 'boxed-1':        return buildBoxedFrame(resume, accentColor);
    case 'typewriter-1':   return buildTypewriter(resume, accentColor);
    case 'swiss-1':        return buildSwissGrid(resume, accentColor);
    case 'kanban-1':       return buildKanban(resume, accentColor);
    case 'ribbon-1':       return buildRibbon(resume, accentColor);
    case 'diagonal-1':     return buildDiagonalSplit(resume, accentColor);
    case 'letterpress-1':  return buildLetterpress(resume, accentColor);
    case 'blueprint-1':    return buildBlueprint(resume, accentColor);
    case 'chatbubble-1':   return buildChatBubble(resume, accentColor);
    case 'vtabs-1':        return buildVerticalTabs(resume, accentColor);
    case 'foldertab-1':    return buildFolderTab(resume, accentColor);
    case 'stackedcards-1': return buildStackedCards(resume, accentColor);
    case 'halftone-1':     return buildHalftone(resume, accentColor);
    case 'wave-1':         return buildWaveCurve(resume, accentColor);
    case 'ledger-1':       return buildLedger(resume);
    case 'neon-1':         return buildNeonDark(resume, accentColor);
    case 'scrapbook-1':    return buildScrapbook(resume, accentColor);
    default:               return buildProfessional(resume, accentColor);
  }
}
