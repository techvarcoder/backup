import JSZip from 'jszip';
import RNFS from 'react-native-fs';
import { ResumeData } from '../types';

// Convert hex #RRGGBB → RRGGBB (no #) for OOXML
const hex = (color: string) => color.replace('#', '').toUpperCase();

function esc(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function para(text: string, opts?: {
  bold?: boolean;
  size?: number; // half-points
  color?: string;
  spacing?: number; // twips after
  italic?: boolean;
}): string {
  const { bold, size = 20, color, spacing, italic } = opts ?? {};
  const rPr = [
    bold ? '<w:b/>' : '',
    italic ? '<w:i/>' : '',
    `<w:sz w:val="${size}"/>`,
    `<w:szCs w:val="${size}"/>`,
    color ? `<w:color w:val="${hex(color)}"/>` : '',
  ].join('');
  const pPr = spacing
    ? `<w:pPr><w:spacing w:after="${spacing}"/></w:pPr>`
    : '';
  return `<w:p>${pPr}<w:r><w:rPr>${rPr}</w:rPr><w:t xml:space="preserve">${esc(text)}</w:t></w:r></w:p>`;
}

function hRule(color: string): string {
  return `<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="${hex(color)}"/></w:pBdr><w:spacing w:after="80"/></w:pPr></w:p>`;
}

function sectionHead(title: string, accent: string): string {
  return [
    para(title, { bold: true, size: 18, color: '#374151', spacing: 0 }),
    hRule(accent),
  ].join('');
}

function entryBlock(
  title: string,
  sub: string,
  date: string,
  desc: string,
  accent: string,
): string {
  return [
    `<w:p>
      <w:r><w:rPr><w:b/><w:sz w:val="22"/><w:szCs w:val="22"/></w:rPr><w:t xml:space="preserve">${esc(title)}</w:t></w:r>
      <w:r><w:rPr><w:sz w:val="20"/><w:color w:val="6B7280"/></w:rPr><w:t xml:space="preserve">   ${esc(date)}</w:t></w:r>
    </w:p>`,
    sub ? para(sub, { bold: true, size: 20, color: accent, spacing: 40 }) : '',
    desc ? para(desc, { size: 18, color: '#4B5563', spacing: 80 }) : '',
  ].join('');
}

export async function buildDocx(resume: ResumeData, accent: string, customFileName?: string): Promise<string> {
  const p = resume.personalInfo;

  const contactLine = [p.email, p.phone, p.location, p.linkedin]
    .filter(Boolean).join('  |  ');

  const bodyXml: string[] = [];

  // Header
  bodyXml.push(para(p.fullName || 'Your Name', { bold: true, size: 44, color: accent }));
  bodyXml.push(para(p.jobTitle || '', { size: 24, color: '#6B7280', spacing: 60 }));
  bodyXml.push(para(contactLine, { size: 18, color: '#6B7280', spacing: 160 }));

  // Summary
  if (p.summary) {
    bodyXml.push(sectionHead('PROFESSIONAL SUMMARY', accent));
    bodyXml.push(para(p.summary, { size: 20, color: '#374151', spacing: 160 }));
  }

  // Experience
  if (resume.workExperience.length > 0) {
    bodyXml.push(sectionHead('WORK EXPERIENCE', accent));
    resume.workExperience.forEach(exp => {
      const date = `${exp.startDate} – ${exp.isPresent ? 'Present' : (exp.endDate ?? '')}`;
      bodyXml.push(entryBlock(exp.jobTitle, exp.company, date, exp.description ?? '', accent));
    });
  }

  // Education
  if (resume.education.length > 0) {
    bodyXml.push(sectionHead('EDUCATION', accent));
    resume.education.forEach(edu => {
      const date = `${edu.startYear} – ${edu.endYear ?? ''}`;
      const sub = edu.institution + (edu.fieldOfStudy ? ` · ${edu.fieldOfStudy}` : '');
      bodyXml.push(entryBlock(edu.degree, sub, date, edu.grade ? `Grade: ${edu.grade}` : '', accent));
    });
  }

  // Skills
  if (resume.skills.length > 0) {
    bodyXml.push(sectionHead('SKILLS', accent));
    bodyXml.push(para(resume.skills.map(s => s.name).join('  ·  '), { size: 20, color: '#374151', spacing: 160 }));
  }

  // Projects
  if (resume.projects.length > 0) {
    bodyXml.push(sectionHead('PROJECTS', accent));
    resume.projects.forEach(proj => {
      const date = proj.startDate ? `${proj.startDate}${proj.endDate ? ` – ${proj.endDate}` : ''}` : '';
      bodyXml.push(entryBlock(proj.name, proj.technologies ?? '', date, proj.description ?? '', accent));
    });
  }

  // Certificates
  if (resume.certificates.length > 0) {
    bodyXml.push(sectionHead('CERTIFICATIONS', accent));
    resume.certificates.forEach(cert => {
      bodyXml.push(entryBlock(cert.name, cert.issuer, cert.date ?? '', '', accent));
    });
  }

  // Languages
  if (resume.languages.length > 0) {
    bodyXml.push(sectionHead('LANGUAGES', accent));
    bodyXml.push(para(
      resume.languages.map(l => `${l.name} (${l.proficiency})`).join('  ·  '),
      { size: 20, color: '#374151', spacing: 160 },
    ));
  }

  // Awards
  if (resume.awards.length > 0) {
    bodyXml.push(sectionHead('AWARDS & RECOGNITION', accent));
    resume.awards.forEach(award => {
      bodyXml.push(entryBlock(award.title, award.issuer ?? '', award.date ?? '', award.description ?? '', accent));
    });
  }

  // References
  if (resume.references.length > 0) {
    bodyXml.push(sectionHead('REFERENCES', accent));
    resume.references.forEach(ref => {
      const sub = [ref.position, ref.company].filter(Boolean).join(' · ');
      const desc = [ref.email, ref.phone].filter(Boolean).join('  |  ');
      bodyXml.push(entryBlock(ref.name, sub, '', desc, accent));
    });
  }

  const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
  xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
  xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <w:body>
    ${bodyXml.join('\n')}
    <w:sectPr>
      <w:pgSz w:w="12240" w:h="15840"/>
      <w:pgMar w:top="1080" w:right="1080" w:bottom="1080" w:left="1080"/>
    </w:sectPr>
  </w:body>
</w:document>`;

  const zip = new JSZip();
  zip.file('[Content_Types].xml', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`);

  zip.file('_rels/.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`);

  zip.file('word/document.xml', documentXml);

  zip.file('word/_rels/document.xml.rels', `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
</Relationships>`);

  const base64 = await zip.generateAsync({ type: 'base64' });

  const fileName = (customFileName || resume.title || 'Resume').replace(/[^a-zA-Z0-9_-]/g, '_') + '.docx';
  const destPath = `${RNFS.DownloadDirectoryPath}/${fileName}`;
  await RNFS.writeFile(destPath, base64, 'base64');

  if (RNFS.scanFile) {
    await RNFS.scanFile(destPath).catch(() => {});
  }

  return destPath;
}
