import { pick, types, isErrorWithCode, errorCodes } from '@react-native-documents/picker';
import RNFS from 'react-native-fs';
import { ResumeData } from '../types';
import { isConfigured as isAiConfigured, extractResumeFromPdf, extractResumeFromText } from '../services/aiService';
import { extractTextFromDocx } from './docxTextExtractor';

const MAX_IMPORT_FILE_SIZE_BYTES = 8 * 1024 * 1024;

export type ImportResumeFileResult =
  | { status: 'success'; data: Partial<ResumeData>; suggestedTitle: string }
  | { status: 'cancelled' }
  | { status: 'error'; message: string };

export async function importResumeFile(): Promise<ImportResumeFileResult> {
  if (!isAiConfigured()) {
    return { status: 'error', message: 'Import Resume needs a Gemini API key. Add your key in src/config/ai.ts, then try again.' };
  }

  let picked;
  try {
    [picked] = await pick({ type: [types.pdf, types.docx] });
  } catch (err) {
    if (isErrorWithCode(err) && err.code === errorCodes.OPERATION_CANCELED) { return { status: 'cancelled' }; }
    return { status: 'error', message: 'Could not open the file picker.' };
  }
  if (!picked) { return { status: 'cancelled' }; }

  const nameLower = (picked.name ?? '').toLowerCase();
  const isPdf = picked.type === 'application/pdf' || nameLower.endsWith('.pdf');
  const isDocx = picked.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || nameLower.endsWith('.docx');
  if (!isPdf && !isDocx) {
    return { status: 'error', message: 'Unsupported file type — please choose a PDF or DOCX file.' };
  }

  if (picked.size != null && picked.size > MAX_IMPORT_FILE_SIZE_BYTES) {
    return { status: 'error', message: 'This file is too large (max 8MB). Please choose a smaller file.' };
  }

  try {
    const base64 = await RNFS.readFile(picked.uri, 'base64');

    let extracted: Partial<ResumeData> | null;
    if (isPdf) {
      extracted = await extractResumeFromPdf(base64);
    } else {
      const text = await extractTextFromDocx(base64);
      if (!text.trim()) {
        return { status: 'error', message: "Couldn't read any text from this DOCX file." };
      }
      extracted = await extractResumeFromText(text);
    }

    if (!extracted) {
      return { status: 'error', message: "Couldn't extract resume data from this file. Try a different file, or check your Gemini API key." };
    }

    const suggestedTitle = (picked.name ?? '').replace(/\.(pdf|docx)$/i, '') || 'My Resume';
    return { status: 'success', data: extracted, suggestedTitle };
  } catch {
    return { status: 'error', message: 'Something went wrong while importing this file.' };
  }
}
