import JSZip from 'jszip';

// Only handles the standard `w:` namespace prefix used by Word/Google Docs/LibreOffice exports.
const RUN_CONTENT_RE = /<w:t[^>]*>([\s\S]*?)<\/w:t>|<w:tab\b[^/]*\/>|<w:(?:br|cr)\b[^/]*\/>/g;
const PARAGRAPH_RE = /<w:p\b[\s\S]*?<\/w:p>/g;

function decodeXmlEntities(s: string): string {
  return s
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');
}

function extractParagraphText(paragraphXml: string): string {
  let out = '';
  let match: RegExpExecArray | null;
  RUN_CONTENT_RE.lastIndex = 0;
  while ((match = RUN_CONTENT_RE.exec(paragraphXml)) !== null) {
    if (match[1] !== undefined) {
      out += decodeXmlEntities(match[1]);
    } else if (match[0].startsWith('<w:tab')) {
      out += '\t';
    } else {
      out += '\n';
    }
  }
  return out;
}

export async function extractTextFromDocx(base64: string): Promise<string> {
  const zip = await JSZip.loadAsync(base64, { base64: true });
  const entry = zip.file('word/document.xml');
  if (!entry) {
    throw new Error('Invalid DOCX: missing word/document.xml');
  }
  const xml = await entry.async('string');
  const paragraphs = xml.match(PARAGRAPH_RE) ?? [];
  return paragraphs
    .map(extractParagraphText)
    .join('\n')
    .trim();
}
