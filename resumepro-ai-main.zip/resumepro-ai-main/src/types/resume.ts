export interface PersonalInfo {
  fullName: string;
  jobTitle: string;
  email: string;
  phone: string;
  location: string;
  linkedin?: string;
  website?: string;
  github?: string;
  summary?: string;
  photoUrl?: string;
}

export interface WorkExperience {
  id: string;
  jobTitle: string;
  company: string;
  location?: string;
  startDate: string;
  endDate?: string;
  isPresent: boolean;
  description?: string;
}

export interface Education {
  id: string;
  degree: string;
  institution: string;
  fieldOfStudy?: string;
  startYear: string;
  endYear?: string;
  grade?: string;
}

export interface Skill {
  id: string;
  name: string;
  level?: 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert';
}

export interface Project {
  id: string;
  name: string;
  description?: string;
  technologies?: string;
  link?: string;
  startDate?: string;
  endDate?: string;
}

export interface Certificate {
  id: string;
  name: string;
  issuer: string;
  date?: string;
  link?: string;
}

export interface Language {
  id: string;
  name: string;
  proficiency: 'Beginner' | 'Elementary' | 'Intermediate' | 'Professional' | 'Native';
}

export interface Award {
  id: string;
  title: string;
  issuer?: string;
  date?: string;
  description?: string;
}

export interface Reference {
  id: string;
  name: string;
  position?: string;
  company?: string;
  email?: string;
  phone?: string;
}

export interface ResumeData {
  id: string;
  title: string;
  templateId: string;
  createdAt: string;
  updatedAt: string;
  personalInfo: PersonalInfo;
  workExperience: WorkExperience[];
  education: Education[];
  skills: Skill[];
  projects: Project[];
  certificates: Certificate[];
  languages: Language[];
  awards: Award[];
  references: Reference[];
  atsScore?: number;
}

export interface ResumeTemplate {
  id: string;
  name: string;
  category: 'Professional' | 'Creative' | 'Modern' | 'Minimal' | 'ATS';
  isPremium: boolean;
  thumbnail?: string;
  accentColor: string;
}
