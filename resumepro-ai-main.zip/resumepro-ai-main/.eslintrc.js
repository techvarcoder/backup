module.exports = {
  root: true,
  extends: '@react-native',
  rules: {
    'react-native/no-inline-styles': 'warn',
    'no-console': 'warn',
    'react/no-unstable-nested-components': ['error', { allowAsProps: true }],
  },
};
