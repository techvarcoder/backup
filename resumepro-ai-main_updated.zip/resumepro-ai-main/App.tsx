import 'react-native-gesture-handler';
import React, { useEffect } from 'react';
import { StatusBar } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { AppNavigator } from './src/navigation/AppNavigator';
import { useThemeStore } from './src/store/useThemeStore';
import { useAuthStore } from './src/store/useAuthStore';
import { authService } from './src/services/firebase/auth';

function Root() {
  const { isDark } = useThemeStore();
  const { setUser, logout } = useAuthStore();

  useEffect(() => {
    const unsubscribe = authService.onAuthStateChanged(fbUser => {
      if (fbUser) {
        setUser(fbUser);
      } else if (useAuthStore.getState().isAuthenticated) {
        logout();
      }
    });
    return unsubscribe;
  }, [setUser, logout]);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar
          barStyle={isDark ? 'light-content' : 'dark-content'}
          backgroundColor="transparent"
          translucent
        />
        <AppNavigator />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}

export default Root;
