import {
  initConnection,
  endConnection,
  getProducts,
  requestPurchase,
  purchaseUpdatedListener,
  purchaseErrorListener,
  finishTransaction,
  getAvailablePurchases,
  Purchase,
  Product,
  PurchaseError,
} from 'react-native-iap';
import { usePremiumStore } from '../store/usePremiumStore';

export class BillingNotAvailableError extends Error {}

export const PRODUCT_IDS = {
  monthly: 'resumepro_pro_monthly',
  yearly: 'resumepro_pro_yearly',
  lifetime: 'resumepro_pro_lifetime',
} as const;

export type PlanId = keyof typeof PRODUCT_IDS;

let connected = false;

async function ensureConnection(): Promise<void> {
  if (connected) { return; }
  try {
    await initConnection();
    connected = true;
  } catch {
    throw new BillingNotAvailableError('Google Play Billing is not available on this device.');
  }
}

function planIdFromProductId(productId: string): PlanId | null {
  const entry = (Object.entries(PRODUCT_IDS) as [PlanId, string][]).find(([, id]) => id === productId);
  return entry ? entry[0] : null;
}

function computeExpiry(planId: PlanId): string | null {
  if (planId === 'lifetime') { return null; }
  const expiry = new Date();
  if (planId === 'monthly') { expiry.setMonth(expiry.getMonth() + 1); }
  if (planId === 'yearly') { expiry.setFullYear(expiry.getFullYear() + 1); }
  return expiry.toISOString();
}

export const billing = {
  initBilling: async (): Promise<void> => {
    await ensureConnection();
  },

  teardown: (): void => {
    if (connected) {
      endConnection();
      connected = false;
    }
  },

  getAvailableProducts: async (): Promise<Product[]> => {
    await ensureConnection();
    return getProducts({ skus: Object.values(PRODUCT_IDS) });
  },

  purchasePlan: (planId: PlanId): Promise<void> => {
    const sku = PRODUCT_IDS[planId];
    return new Promise((resolve, reject) => {
      let updateSub: { remove: () => void } | null = null;
      let errorSub: { remove: () => void } | null = null;
      const cleanup = () => {
        updateSub?.remove();
        errorSub?.remove();
      };

      updateSub = purchaseUpdatedListener(async (purchase: Purchase) => {
        if (purchase.productId !== sku) { return; }
        try {
          usePremiumStore.getState().setPremium(purchase.productId, computeExpiry(planId));
          await finishTransaction({ purchase, isConsumable: false });
          cleanup();
          resolve();
        } catch (err) {
          cleanup();
          reject(err);
        }
      });

      errorSub = purchaseErrorListener((error: PurchaseError) => {
        cleanup();
        reject(new Error(error.message || 'Purchase failed or was cancelled.'));
      });

      ensureConnection()
        .then(() => requestPurchase({ sku }))
        .catch(err => {
          cleanup();
          reject(err);
        });
    });
  },

  restorePurchases: async (): Promise<boolean> => {
    await ensureConnection();
    const purchases = await getAvailablePurchases();
    const active = purchases.find((p: Purchase) => planIdFromProductId(p.productId) !== null);
    if (!active) { return false; }
    const planId = planIdFromProductId(active.productId);
    if (!planId) { return false; }
    usePremiumStore.getState().setPremium(active.productId, computeExpiry(planId));
    return true;
  },
};
