import auth, { FirebaseAuthTypes } from '@react-native-firebase/auth';
import { GoogleSignin, isSuccessResponse } from '@react-native-google-signin/google-signin';
import { FIREBASE_CONFIG, isFirebaseConfigured } from '../../config/firebase';
import { User } from '../../types';

export class AuthNotConfiguredError extends Error {}

export interface AuthCredentials {
  email: string;
  password: string;
}

export interface AuthResult {
  user: User | null;
  error: string | null;
}

let googleConfigured = false;
function ensureGoogleConfigured(): void {
  if (googleConfigured) { return; }
  if (!isFirebaseConfigured()) {
    throw new AuthNotConfiguredError('Add a Firebase Web Client ID in src/config/firebase.ts to use Google Sign-In.');
  }
  GoogleSignin.configure({ webClientId: FIREBASE_CONFIG.GOOGLE_WEB_CLIENT_ID });
  googleConfigured = true;
}

function mapFirebaseUser(fbUser: FirebaseAuthTypes.User): User {
  return {
    uid: fbUser.uid,
    email: fbUser.email ?? '',
    displayName: fbUser.displayName ?? undefined,
    photoURL: fbUser.photoURL ?? undefined,
    createdAt: fbUser.metadata.creationTime ?? new Date().toISOString(),
  };
}

function mapAuthError(err: unknown): string {
  const code = (err as { code?: string })?.code ?? '';
  switch (code) {
    case 'auth/invalid-email': return 'Please enter a valid email address';
    case 'auth/user-disabled': return 'This account has been disabled';
    case 'auth/user-not-found': return 'No account found with this email';
    case 'auth/wrong-password': return 'Incorrect password';
    case 'auth/invalid-credential': return 'Invalid email or password';
    case 'auth/email-already-in-use': return 'An account already exists with this email';
    case 'auth/weak-password': return 'Password is too weak';
    case 'auth/network-request-failed': return 'Network error — please check your connection';
    case 'auth/too-many-requests': return 'Too many attempts — please try again later';
    default: return (err as Error)?.message || 'Something went wrong. Please try again.';
  }
}

export const authService = {
  signIn: async ({ email, password }: AuthCredentials): Promise<AuthResult> => {
    try {
      const cred = await auth().signInWithEmailAndPassword(email, password);
      return { user: mapFirebaseUser(cred.user), error: null };
    } catch (err) {
      return { user: null, error: mapAuthError(err) };
    }
  },

  signUp: async ({ email, password, displayName }: AuthCredentials & { displayName: string }): Promise<AuthResult> => {
    try {
      const cred = await auth().createUserWithEmailAndPassword(email, password);
      await cred.user.updateProfile({ displayName });
      return { user: { ...mapFirebaseUser(cred.user), displayName }, error: null };
    } catch (err) {
      return { user: null, error: mapAuthError(err) };
    }
  },

  signInWithGoogle: async (): Promise<AuthResult> => {
    try {
      ensureGoogleConfigured();
      await GoogleSignin.hasPlayServices();
      const response = await GoogleSignin.signIn();
      if (!isSuccessResponse(response)) {
        return { user: null, error: 'Google Sign-In was cancelled' };
      }
      const idToken = response.data.idToken;
      if (!idToken) {
        return { user: null, error: 'Google Sign-In did not return a valid token' };
      }
      const googleCredential = auth.GoogleAuthProvider.credential(idToken);
      const cred = await auth().signInWithCredential(googleCredential);
      return { user: mapFirebaseUser(cred.user), error: null };
    } catch (err) {
      if (err instanceof AuthNotConfiguredError) {
        return { user: null, error: err.message };
      }
      return { user: null, error: mapAuthError(err) };
    }
  },

  signOut: async (): Promise<void> => {
    if (googleConfigured) {
      const isSignedIn = await GoogleSignin.hasPreviousSignIn();
      if (isSignedIn) { await GoogleSignin.signOut(); }
    }
    await auth().signOut();
  },

  sendPasswordResetEmail: async (email: string): Promise<{ error: string | null }> => {
    try {
      await auth().sendPasswordResetEmail(email);
      return { error: null };
    } catch (err) {
      return { error: mapAuthError(err) };
    }
  },

  getCurrentUser: (): User | null => {
    const fbUser = auth().currentUser;
    return fbUser ? mapFirebaseUser(fbUser) : null;
  },

  onAuthStateChanged: (callback: (user: User | null) => void): (() => void) => {
    return auth().onAuthStateChanged((fbUser: FirebaseAuthTypes.User | null) => {
      callback(fbUser ? mapFirebaseUser(fbUser) : null);
    });
  },

  deleteAccount: async (): Promise<{ error: string | null; requiresRecentLogin?: boolean }> => {
    const fbUser = auth().currentUser;
    if (!fbUser) { return { error: 'No signed-in user to delete' }; }
    try {
      await fbUser.delete();
      return { error: null };
    } catch (err) {
      const code = (err as { code?: string })?.code ?? '';
      if (code === 'auth/requires-recent-login') {
        return { error: 'For your security, please sign in again before deleting your account.', requiresRecentLogin: true };
      }
      return { error: mapAuthError(err) };
    }
  },
};
