export { authService, AuthNotConfiguredError } from './auth';
export type { AuthCredentials, AuthResult } from './auth';
