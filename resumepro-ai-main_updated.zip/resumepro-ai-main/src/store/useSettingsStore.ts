import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppSettings } from '../types';
import { STORAGE_KEYS } from '../constants';

const defaultSettings: AppSettings = {
  theme: 'light',
  language: 'en',
  notificationsEnabled: true,
  autoBackup: true,
  exportFormat: 'pdf',
};

interface SettingsState {
  settings: AppSettings;
  _hasHydrated: boolean;
  setHasHydrated: (v: boolean) => void;
  updateSettings: (updates: Partial<AppSettings>) => void;
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    set => ({
      settings: defaultSettings,
      _hasHydrated: false,
      setHasHydrated: (v) => set({ _hasHydrated: v }),

      updateSettings: (updates) =>
        set(state => ({ settings: { ...state.settings, ...updates } })),
    }),
    {
      name: STORAGE_KEYS.SETTINGS,
      storage: createJSONStorage(() => AsyncStorage),
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      },
    },
  ),
);
