import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User } from '../types';

interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isGuest: boolean;
  hasOnboarded: boolean;
  _hasHydrated: boolean;
  setHasHydrated: (v: boolean) => void;
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  setHasOnboarded: (value: boolean) => void;
  continueAsGuest: () => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    set => ({
      user: null,
      isLoading: true,
      isAuthenticated: false,
      isGuest: false,
      hasOnboarded: false,
      _hasHydrated: false,
      setHasHydrated: (v) => set({ _hasHydrated: v }),

      setUser: (user) => set({ user, isAuthenticated: !!user, isGuest: false, isLoading: false }),
      setLoading: (isLoading) => set({ isLoading }),
      setHasOnboarded: (hasOnboarded) => set({ hasOnboarded }),
      continueAsGuest: () => set({ isGuest: true, isAuthenticated: false, user: null, isLoading: false }),
      logout: () => set({ user: null, isAuthenticated: false, isGuest: false }),
    }),
    {
      name: 'auth_store',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        isGuest: state.isGuest,
        hasOnboarded: state.hasOnboarded,
      }),
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      },
    },
  ),
);
