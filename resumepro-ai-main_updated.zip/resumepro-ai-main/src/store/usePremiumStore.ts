import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface PremiumState {
  isPremium: boolean;
  activeProductId: string | null;
  expiryDate: string | null;
  _hasHydrated: boolean;
  setHasHydrated: (v: boolean) => void;
  setPremium: (productId: string, expiryDate: string | null) => void;
  clearPremium: () => void;
}

export const usePremiumStore = create<PremiumState>()(
  persist(
    set => ({
      isPremium: false,
      activeProductId: null,
      expiryDate: null,
      _hasHydrated: false,
      setHasHydrated: (v) => set({ _hasHydrated: v }),

      setPremium: (activeProductId, expiryDate) =>
        set({ isPremium: true, activeProductId, expiryDate }),

      clearPremium: () => set({ isPremium: false, activeProductId: null, expiryDate: null }),
    }),
    {
      name: 'premium_store',
      storage: createJSONStorage(() => AsyncStorage),
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      },
    },
  ),
);
