import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import { Appearance } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { lightColors, darkColors, Colors } from '../theme/colors';
import { ThemeMode } from '../types';
import { STORAGE_KEYS } from '../constants';

interface ThemeState {
  mode: ThemeMode;
  isDark: boolean;
  colors: Colors;
  _hasHydrated: boolean;
  setHasHydrated: (v: boolean) => void;
  setMode: (mode: ThemeMode) => void;
}

const getIsDark = (mode: ThemeMode): boolean => {
  if (mode === 'system') {
    return Appearance.getColorScheme() === 'dark';
  }
  return mode === 'dark';
};

export const useThemeStore = create<ThemeState>()(
  persist(
    set => ({
      mode: 'light',
      isDark: false,
      colors: lightColors,
      _hasHydrated: false,
      setHasHydrated: (v) => set({ _hasHydrated: v }),

      setMode: (mode) => {
        const isDark = getIsDark(mode);
        set({ mode, isDark, colors: isDark ? darkColors : lightColors });
      },
    }),
    {
      name: STORAGE_KEYS.THEME,
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({ mode: state.mode }),
      onRehydrateStorage: () => (state) => {
        if (state) {
          state.setMode(state.mode);
          state.setHasHydrated(true);
        }
      },
    },
  ),
);
