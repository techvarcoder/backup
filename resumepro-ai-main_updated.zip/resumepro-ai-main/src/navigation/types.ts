export type RootStackParamList = {
  Splash: undefined;
  Auth: undefined;
  Main: undefined;
};

export type AuthStackParamList = {
  Onboarding: undefined;
  Login: undefined;
  Register: undefined;
  ForgotPassword: undefined;
  ChooseRole: undefined;
  TermsAndConditions: undefined;
};

export type MainTabParamList = {
  HomeTab: undefined;
  ResumesTab: undefined;
  AIToolsTab: undefined;
  ProfileTab: undefined;
};

export type HomeStackParamList = {
  Home: undefined;
  Notifications: undefined;
};

export type ResumeStackParamList = {
  MyResumes: undefined;
  CreateResume: undefined;
  ResumeEditor: { resumeId: string };
  ResumeTemplates: { resumeId?: string };
  ResumePreview: { resumeId: string };
  ExportResume: { resumeId: string };
};

export type AIToolsStackParamList = {
  AIToolsHub: undefined;
  AIResumeWriter: undefined;
  AIResumeReview: { resumeId?: string };
  ATSScore: { resumeId?: string };
  CoverLetter: undefined;
  SalaryCalculator: undefined;
  NoticePeriodCalculator: undefined;
};

export type ProfileStackParamList = {
  Profile: undefined;
  Settings: undefined;
  Premium: undefined;
  Subscription: undefined;
  PaymentScreen: { planId: string };
  PaymentSuccess: undefined;
  EditProfile: undefined;
  Help: undefined;
  About: undefined;
  Feedback: undefined;
  PrivacyPolicy: undefined;
  TermsAndConditions: undefined;
  DeleteAccount: undefined;
};
