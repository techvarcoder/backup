import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { Snackbar } from '../../components/common/Snackbar';
import { billing, PlanId, PRODUCT_IDS } from '../../services/billing';

type Props = NativeStackScreenProps<ProfileStackParamList, 'PaymentScreen'>;

const PLAN_MAP: Record<string, { name: string; price: string }> = {
  monthly: { name: 'Monthly Plan', price: '₹99.00' },
  yearly: { name: 'Annual Plan', price: '₹489.00' },
  lifetime: { name: 'Lifetime Plan', price: '₹1,299.00' },
};

export default function PaymentScreen({ navigation, route }: Props) {
  const { planId } = route.params;
  const { colors } = useThemeStore();
  const [loading, setLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '' });
  const plan = PLAN_MAP[planId] ?? { name: 'Plan', price: '₹99.00' };
  const isKnownPlan = planId in PRODUCT_IDS;

  const handlePay = async () => {
    if (!isKnownPlan) {
      setSnackbar({ visible: true, message: 'Unknown plan selected.' });
      return;
    }
    setLoading(true);
    try {
      await billing.purchasePlan(planId as PlanId);
      navigation.replace('PaymentSuccess');
    } catch (err) {
      setSnackbar({ visible: true, message: (err as Error).message || 'Purchase could not be completed.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Payment</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Order Summary */}
        <View style={[styles.summaryCard, { backgroundColor: colors.surface }, shadow.sm]}>
          <Text style={[styles.summaryLabel, { color: colors.textSecondary }]}>ResumePro AI Pro</Text>
          <Text style={[styles.planName, { color: colors.text }]}>{plan.name}</Text>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <View style={styles.totalRow}>
            <Text style={[styles.totalLabel, { color: colors.textSecondary }]}>Total</Text>
            <Text style={[styles.totalValue, { color: colors.primary }]}>{plan.price}</Text>
          </View>
        </View>

        <View style={styles.secureRow}>
          <Text style={[styles.secureText, { color: colors.textMuted }]}>🔒 Secured by Google Play Billing</Text>
        </View>

        <PrimaryButton
          label={`Pay ${plan.price}`}
          onPress={handlePay}
          loading={loading}
        />
      </ScrollView>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type="error"
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  summaryCard: { borderRadius: radius.xl, padding: spacing.xxl, marginBottom: spacing.xxl },
  summaryLabel: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, marginBottom: spacing.xs },
  planName: { fontSize: fontSize.lg, fontFamily: fontFamily.semiBold, marginBottom: spacing.lg },
  divider: { height: 1, marginBottom: spacing.lg },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  totalLabel: { fontSize: fontSize.base, fontFamily: fontFamily.medium },
  totalValue: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  secureRow: { alignItems: 'center', marginVertical: spacing.lg },
  secureText: { fontSize: fontSize.sm, fontFamily: fontFamily.regular },
});
