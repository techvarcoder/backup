import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import LinearGradient from 'react-native-linear-gradient';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { gradients } from '../../theme/colors';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { Snackbar } from '../../components/common/Snackbar';
import { billing } from '../../services/billing';

type Props = NativeStackScreenProps<ProfileStackParamList, 'Premium'>;

interface Plan {
  id: string;
  name: string;
  price: string;
  period: string;
  tag?: string;
}

const PLANS: Plan[] = [
  { id: 'monthly', name: 'Monthly Plan', price: '₹99', period: '/month' },
  { id: 'yearly', name: 'Annual Plan', price: '₹489', period: '/year', tag: 'Save 60%' },
  { id: 'lifetime', name: 'Lifetime Plan', price: '₹1,299', period: 'One-time payment, lifetime access.' },
];

const FEATURES = [
  '📑 All Premium Templates',
  '✍️ AI Writing Assistant',
  '🎯 ATS Score Checker',
  '📝 Cover Letter Generator',
  '⬇️ Unlimited PDF Exports',
  '🚀 Ad Free Experience',
];

export default function PremiumScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const [selectedPlan, setSelectedPlan] = useState('yearly');
  const [restoring, setRestoring] = useState(false);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '', type: 'error' as 'error' | 'success' });

  const handleSubscribe = () => {
    navigation.navigate('PaymentScreen', { planId: selectedPlan });
  };

  const handleRestore = async () => {
    setRestoring(true);
    try {
      const restored = await billing.restorePurchases();
      setSnackbar({
        visible: true,
        type: restored ? 'success' : 'error',
        message: restored ? 'Your purchase has been restored.' : 'No previous purchase was found.',
      });
    } catch (err) {
      setSnackbar({ visible: true, type: 'error', message: (err as Error).message || 'Could not restore purchases.' });
    } finally {
      setRestoring(false);
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Premium Plans</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <LinearGradient colors={gradients.premium} style={styles.heroBanner}>
          <Text style={styles.heroIcon}>👑</Text>
          <Text style={styles.heroTitle}>ResumePro AI Pro</Text>
          <Text style={styles.heroSubtitle}>Unlock all premium features</Text>
        </LinearGradient>

        {/* Features */}
        <View style={[styles.featuresCard, { backgroundColor: colors.surface }, shadow.sm]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>What's included</Text>
          <View style={styles.featureList}>
            {FEATURES.map(f => (
              <View key={f} style={styles.featureRow}>
                <Text style={[styles.featureText, { color: colors.textSecondary }]}>{f}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Plans */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>Choose Your Plan</Text>
        {PLANS.map(plan => (
          <TouchableOpacity
            key={plan.id}
            onPress={() => setSelectedPlan(plan.id)}
            style={[
              styles.planCard,
              { backgroundColor: colors.surface },
              shadow.sm,
              selectedPlan === plan.id && { borderColor: colors.primary, borderWidth: 2 },
            ]}
            accessibilityRole="radio"
            accessibilityState={{ selected: selectedPlan === plan.id }}>
            <View style={styles.planLeft}>
              <View style={[styles.radio, { borderColor: selectedPlan === plan.id ? colors.primary : colors.border }]}>
                {selectedPlan === plan.id ? (
                  <View style={[styles.radioFill, { backgroundColor: colors.primary }]} />
                ) : null}
              </View>
              <View>
                <Text style={[styles.planName, { color: colors.text }]}>{plan.name}</Text>
                <Text style={[styles.planPeriod, { color: colors.textSecondary }]}>{plan.period}</Text>
              </View>
            </View>
            <View style={styles.planRight}>
              {plan.tag ? (
                <View style={[styles.tag, { backgroundColor: colors.success + '15' }]}>
                  <Text style={[styles.tagText, { color: colors.success }]}>{plan.tag}</Text>
                </View>
              ) : null}
              <Text style={[styles.planPrice, { color: selectedPlan === plan.id ? colors.primary : colors.text }]}>
                {plan.price}
              </Text>
            </View>
          </TouchableOpacity>
        ))}

        <PrimaryButton
          label="Continue"
          onPress={handleSubscribe}
          style={styles.subscribeBtn}
        />

        <TouchableOpacity style={styles.restoreBtn} onPress={handleRestore} disabled={restoring}>
          <Text style={[styles.restoreText, { color: colors.primary }]}>
            {restoring ? 'Restoring…' : 'Restore Purchase'}
          </Text>
        </TouchableOpacity>
      </ScrollView>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type={snackbar.type}
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  heroBanner: { borderRadius: radius.xl, padding: spacing.xxl, alignItems: 'center', marginBottom: spacing.xxl },
  heroIcon: { fontSize: 48, marginBottom: spacing.md },
  heroTitle: { fontSize: fontSize.xl, fontFamily: fontFamily.bold, color: '#FFF', marginBottom: spacing.xs },
  heroSubtitle: { fontSize: fontSize.base, fontFamily: fontFamily.regular, color: 'rgba(255,255,255,0.8)' },
  featuresCard: { borderRadius: radius.xl, padding: spacing.xxl, marginBottom: spacing.xxl },
  sectionTitle: { fontSize: fontSize.lg, fontFamily: fontFamily.semiBold, marginBottom: spacing.lg },
  featureList: {},
  featureRow: { marginBottom: spacing.sm },
  featureText: { fontSize: fontSize.base, fontFamily: fontFamily.regular },
  planCard: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderRadius: radius.xl, padding: spacing.lg, marginBottom: spacing.md, borderWidth: 1.5, borderColor: 'transparent' },
  planLeft: { flexDirection: 'row', alignItems: 'center', gap: spacing.lg },
  radio: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  radioFill: { width: 10, height: 10, borderRadius: 5 },
  planName: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, marginBottom: 2 },
  planPeriod: { fontSize: fontSize.xs, fontFamily: fontFamily.regular },
  planRight: { alignItems: 'flex-end', gap: spacing.xs },
  planPrice: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  tag: { borderRadius: radius.full, paddingHorizontal: spacing.sm, paddingVertical: 2 },
  tagText: { fontSize: 10, fontFamily: fontFamily.semiBold },
  subscribeBtn: { marginTop: spacing.xl },
  restoreBtn: { alignItems: 'center', marginTop: spacing.lg },
  restoreText: { fontSize: fontSize.sm, fontFamily: fontFamily.medium },
});
