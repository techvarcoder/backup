import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';

type Props = NativeStackScreenProps<ProfileStackParamList, 'PrivacyPolicy'>;

const SECTIONS = [
  { title: 'Data Collection', content: 'We collect information you provide directly to us, such as your name, email address, profile photo, and resume content. If you sign in with Google, we receive your name, email address, and profile photo from your Google account. We do not sell your personal data to third parties.' },
  { title: 'How We Use Your Data', content: 'Your data is used to provide and improve our services, personalize your experience, and send important notifications about your account.' },
  { title: 'AI Features (Google Gemini)', content: 'When you use AI-powered tools, the relevant resume text is sent to the Google Gemini API to generate suggestions. This content is processed by Google to return a response and is not stored by ResumePro AI beyond what is needed to display the result to you.' },
  { title: 'Authentication (Firebase & Google Sign-In)', content: 'We use Google Firebase Authentication to manage sign-in, including Google Sign-In. Firebase stores your authentication identifiers securely; you may also continue as a guest without creating an account.' },
  { title: 'Subscriptions (Google Play Billing)', content: 'Premium purchases and subscriptions are processed by Google Play Billing. We do not receive or store your payment card details — Google handles all payment information.' },
  { title: 'Data Storage', content: 'Your resume data is stored securely on your device and, where applicable, on our servers. We use industry-standard encryption to protect your information.' },
  { title: 'Your Rights', content: 'You have the right to access, update, or delete your personal data at any time through your profile settings or by contacting our support team.' },
  { title: 'Contact Us', content: 'If you have any questions about our privacy policy, please contact us at privacy@resumeproai.com.' },
];

export default function PrivacyPolicyScreen({ navigation }: Props) {
  const { colors } = useThemeStore();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Privacy Policy</Text>
      </View>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={[styles.updated, { color: colors.textMuted }]}>Last updated: July 2026</Text>
        {SECTIONS.map(section => (
          <View key={section.title} style={[styles.section, { backgroundColor: colors.surface }, shadow.sm]}>
            <Text style={[styles.sectionTitle, { color: colors.text }]}>{section.title}</Text>
            <Text style={[styles.sectionContent, { color: colors.textSecondary }]}>{section.content}</Text>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  updated: { fontSize: fontSize.xs, fontFamily: fontFamily.regular, marginBottom: spacing.lg },
  section: { borderRadius: radius.xl, padding: spacing.xxl, marginBottom: spacing.md },
  sectionTitle: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, marginBottom: spacing.sm },
  sectionContent: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, lineHeight: 22 },
});
