import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useAuthStore } from '../../store/useAuthStore';
import { useResumeStore } from '../../store/useResumeStore';
import { usePremiumStore } from '../../store/usePremiumStore';
import { authService } from '../../services/firebase/auth';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius } from '../../theme/spacing';
import { OutlinedButton } from '../../components/buttons/OutlinedButton';
import { ConfirmationDialog } from '../../components/common/ConfirmationDialog';
import { Snackbar } from '../../components/common/Snackbar';

type Props = NativeStackScreenProps<ProfileStackParamList, 'DeleteAccount'>;

const CONSEQUENCES = [
  '🗑️ All your resumes will be permanently deleted',
  '❌ Your account and data cannot be recovered',
  '👑 Premium subscription will be cancelled',
  '📄 All exported resumes will remain on your device',
];

export default function DeleteAccountScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const { logout } = useAuthStore();
  const [dialog, setDialog] = useState(false);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '' });

  const handleDelete = async () => {
    setDialog(false);
    const { error, requiresRecentLogin } = await authService.deleteAccount();
    if (error) {
      setSnackbar({ visible: true, message: error });
      if (requiresRecentLogin) {
        logout();
      }
      return;
    }
    useResumeStore.getState().setResumes([]);
    useResumeStore.getState().setActiveResume(null);
    usePremiumStore.getState().clearPremium();
    logout();
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Delete Account</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.warningIcon}>
          <Text style={styles.warningEmoji}>⚠️</Text>
        </View>
        <Text style={[styles.heading, { color: colors.text }]}>Are you sure?</Text>
        <Text style={[styles.description, { color: colors.textSecondary }]}>
          Deleting your account is permanent and cannot be undone. The following will happen:
        </Text>

        <View style={[styles.consequencesCard, { backgroundColor: colors.errorLight, borderColor: colors.error }]}>
          {CONSEQUENCES.map(c => (
            <Text key={c} style={[styles.consequence, { color: colors.error }]}>{c}</Text>
          ))}
        </View>

        <OutlinedButton
          label="Delete My Account"
          onPress={() => setDialog(true)}
          color={colors.error}
          style={styles.deleteBtn}
        />

        <TouchableOpacity
          onPress={() => navigation.goBack()}
          style={styles.cancelBtn}
          accessibilityRole="button">
          <Text style={[styles.cancelText, { color: colors.primary }]}>Keep My Account</Text>
        </TouchableOpacity>
      </ScrollView>

      <ConfirmationDialog
        visible={dialog}
        title="Delete Account"
        message="This action is irreversible. All your data will be permanently deleted. Are you absolutely sure?"
        confirmLabel="Yes, Delete"
        cancelLabel="Cancel"
        onConfirm={handleDelete}
        onCancel={() => setDialog(false)}
        destructive
      />

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type="error"
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, alignItems: 'center' },
  warningIcon: { marginBottom: spacing.lg, marginTop: spacing.xl },
  warningEmoji: { fontSize: 64 },
  heading: { fontSize: fontSize.xxl, fontFamily: fontFamily.bold, marginBottom: spacing.md, textAlign: 'center' },
  description: { fontSize: fontSize.base, fontFamily: fontFamily.regular, textAlign: 'center', lineHeight: 24, marginBottom: spacing.xxl },
  consequencesCard: { width: '100%', borderRadius: radius.xl, borderWidth: 1, padding: spacing.xxl, marginBottom: spacing.xxl },
  consequence: { fontSize: fontSize.sm, fontFamily: fontFamily.medium, marginBottom: spacing.sm, lineHeight: 20 },
  deleteBtn: { width: '100%', marginBottom: spacing.lg },
  cancelBtn: { alignItems: 'center', padding: spacing.md },
  cancelText: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold },
});
