import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, KeyboardAvoidingView, Platform, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { launchImageLibrary } from 'react-native-image-picker';
import { ProfileStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { useAuthStore } from '../../store/useAuthStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { TextField } from '../../components/inputs/TextField';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';
import { Snackbar } from '../../components/common/Snackbar';

type Props = NativeStackScreenProps<ProfileStackParamList, 'EditProfile'>;

export default function EditProfileScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const { user, setUser } = useAuthStore();
  const [name, setName] = useState(user?.displayName ?? '');
  const [email] = useState(user?.email ?? '');
  const [photoURL, setPhotoURL] = useState(user?.photoURL);
  const [loading, setLoading] = useState(false);
  const [snackbar, setSnackbar] = useState({ visible: false, message: '' });

  const handlePickAvatar = async () => {
    const result = await launchImageLibrary({ mediaType: 'photo', quality: 0.8 });
    const uri = result.assets?.[0]?.uri;
    if (uri) {
      setPhotoURL(uri);
    }
  };

  const handleSave = async () => {
    if (!name.trim()) {
      setSnackbar({ visible: true, message: 'Name cannot be empty' });
      return;
    }
    setLoading(true);
    if (user) {
      setUser({ ...user, displayName: name.trim(), photoURL });
    }
    setLoading(false);
    setSnackbar({ visible: true, message: 'Profile updated!' });
    setTimeout(() => navigation.goBack(), 1200);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
            <Text style={[styles.backText, { color: colors.text }]}>←</Text>
          </TouchableOpacity>
          <Text style={[styles.title, { color: colors.text }]}>Edit Profile</Text>
        </View>

        <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
          <View style={styles.avatarWrapper}>
            <View style={[styles.avatar, { backgroundColor: colors.primary + '20' }]}>
              {photoURL ? (
                <Image source={{ uri: photoURL }} style={styles.avatarImage} />
              ) : (
                <Text style={[styles.avatarText, { color: colors.primary }]}>
                  {(name || 'U').charAt(0).toUpperCase()}
                </Text>
              )}
            </View>
            <TouchableOpacity
              style={[styles.editAvatarBtn, { backgroundColor: colors.primary }]}
              onPress={handlePickAvatar}
              accessibilityRole="button"
              accessibilityLabel="Change profile photo">
              <Text style={styles.editAvatarIcon}>✏️</Text>
            </TouchableOpacity>
          </View>

          <View style={[styles.card, { backgroundColor: colors.surface }, shadow.sm]}>
            <TextField label="Full Name" value={name} onChangeText={setName} placeholder="John Doe" autoCapitalize="words" />
            <TextField label="Email Address" value={email} onChangeText={() => {}} placeholder="john@example.com" editable={false} />
            <PrimaryButton label="Save Changes" onPress={handleSave} loading={loading} />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>

      <Snackbar
        message={snackbar.message}
        visible={snackbar.visible}
        type="success"
        onDismiss={() => setSnackbar(s => ({ ...s, visible: false }))}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  avatarWrapper: { alignItems: 'center', marginBottom: spacing.xxl, position: 'relative' },
  avatar: { width: 96, height: 96, borderRadius: 48, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  avatarImage: { width: 96, height: 96 },
  avatarText: { fontSize: 40, fontFamily: fontFamily.bold },
  editAvatarBtn: { position: 'absolute', bottom: 0, right: '35%', width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  editAvatarIcon: { fontSize: 14 },
  card: { borderRadius: radius.xl, padding: spacing.xxl },
});
