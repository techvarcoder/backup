import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import LinearGradient from 'react-native-linear-gradient';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { usePremiumStore } from '../../store/usePremiumStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';
import { gradients } from '../../theme/colors';
import { PrimaryButton } from '../../components/buttons/PrimaryButton';

type Props = NativeStackScreenProps<ProfileStackParamList, 'Subscription'>;

export default function SubscriptionScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const { isPremium, expiryDate } = usePremiumStore();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>My Plan</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {isPremium ? (
          <LinearGradient colors={gradients.premium} style={styles.activeCard}>
            <Text style={styles.activeIcon}>👑</Text>
            <Text style={styles.activePlan}>ResumePro AI Pro</Text>
            <Text style={styles.activeStatus}>Active Subscription</Text>
            {expiryDate ? (
              <View style={styles.renewRow}>
                <Text style={styles.renewLabel}>Renews on</Text>
                <Text style={styles.renewDate}>
                  {new Date(expiryDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </Text>
              </View>
            ) : null}
          </LinearGradient>
        ) : (
          <View style={[styles.freePlanCard, { backgroundColor: colors.surface }, shadow.md]}>
            <Text style={styles.freeIcon}>📋</Text>
            <Text style={[styles.freePlanName, { color: colors.text }]}>Free Plan</Text>
            <Text style={[styles.freePlanSubtitle, { color: colors.textSecondary }]}>
              You are currently on the free plan with limited features.
            </Text>
            <PrimaryButton
              label="Upgrade to Pro"
              onPress={() => navigation.navigate('Premium')}
              style={styles.upgradeBtn}
            />
          </View>
        )}

        <View style={[styles.featuresCard, { backgroundColor: colors.surface }, shadow.sm]}>
          <Text style={[styles.sectionTitle, { color: colors.text }]}>
            {isPremium ? 'Your Benefits' : 'Free Plan Includes'}
          </Text>
          {[
            { label: '3 Resume Slots', included: true },
            { label: '5 Basic Templates', included: true },
            { label: 'PDF Export', included: true },
            { label: 'AI Writing Assistant', included: isPremium },
            { label: 'All Premium Templates', included: isPremium },
            { label: 'ATS Score Checker', included: isPremium },
            { label: 'Cover Letter Generator', included: isPremium },
          ].map(f => (
            <View key={f.label} style={styles.featureRow}>
              <Text style={{ color: f.included ? colors.success : colors.border, fontSize: 16 }}>
                {f.included ? '✓' : '✕'}
              </Text>
              <Text style={[styles.featureText, { color: f.included ? colors.text : colors.textMuted }]}>
                {f.label}
              </Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  activeCard: { borderRadius: radius.xl, padding: spacing.xxl, alignItems: 'center', marginBottom: spacing.xl },
  activeIcon: { fontSize: 48, marginBottom: spacing.md },
  activePlan: { fontSize: fontSize.xl, fontFamily: fontFamily.bold, color: '#FFF', marginBottom: spacing.xs },
  activeStatus: { fontSize: fontSize.sm, fontFamily: fontFamily.regular, color: 'rgba(255,255,255,0.8)', marginBottom: spacing.lg },
  renewRow: { flexDirection: 'row', gap: spacing.md },
  renewLabel: { fontSize: fontSize.sm, color: 'rgba(255,255,255,0.7)', fontFamily: fontFamily.regular },
  renewDate: { fontSize: fontSize.sm, color: '#FFF', fontFamily: fontFamily.semiBold },
  freePlanCard: { borderRadius: radius.xl, padding: spacing.xxl, alignItems: 'center', marginBottom: spacing.xl },
  freeIcon: { fontSize: 40, marginBottom: spacing.md },
  freePlanName: { fontSize: fontSize.xl, fontFamily: fontFamily.bold, marginBottom: spacing.xs },
  freePlanSubtitle: { fontSize: fontSize.base, fontFamily: fontFamily.regular, textAlign: 'center', lineHeight: 22, marginBottom: spacing.xl },
  upgradeBtn: {},
  featuresCard: { borderRadius: radius.xl, padding: spacing.xxl },
  sectionTitle: { fontSize: fontSize.base, fontFamily: fontFamily.semiBold, marginBottom: spacing.lg },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md, marginBottom: spacing.md },
  featureText: { fontSize: fontSize.base, fontFamily: fontFamily.regular },
});
