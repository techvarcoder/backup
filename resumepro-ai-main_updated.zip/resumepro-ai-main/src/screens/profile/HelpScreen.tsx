import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Linking } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { ProfileStackParamList } from '../../navigation/types';
import { useThemeStore } from '../../store/useThemeStore';
import { fontFamily, fontSize } from '../../theme/typography';
import { spacing, radius, shadow } from '../../theme/spacing';

type Props = NativeStackScreenProps<ProfileStackParamList, 'Help'>;

const FAQS = [
  { q: 'How do I create a resume?', a: "Tap 'Create New Resume' on the Home screen, choose a template, and fill in your details using the editor." },
  { q: 'Can I export my resume as PDF?', a: 'Yes! Open your resume, tap the download icon in Preview, and select PDF format.' },
  { q: 'What is ATS Score?', a: "ATS (Applicant Tracking System) score shows how well your resume would perform in automated screening systems used by employers." },
  { q: 'How does AI Resume Writer work?', a: 'Enter your job role and skills, and our AI generates a professional resume summary tailored to your profile.' },
  { q: 'How to upgrade to Premium?', a: "Go to Profile → Upgrade to Premium, choose your plan, and complete the payment." },
];

export default function HelpScreen({ navigation }: Props) {
  const { colors } = useThemeStore();
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const handleEmailUs = () => {
    Linking.openURL('mailto:support@resumeproai.com?subject=' + encodeURIComponent('ResumePro AI Support'));
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} accessibilityLabel="Go back">
          <Text style={[styles.backText, { color: colors.text }]}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: colors.text }]}>Help & Support</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        {/* Contact Options */}
        <View style={[styles.contactRow, { gap: spacing.md }]}>
          <TouchableOpacity
            style={[styles.contactCard, { backgroundColor: colors.surface, flex: 1 }, shadow.sm]}
            onPress={handleEmailUs}
            accessibilityRole="button">
            <View style={[styles.contactIcon, { backgroundColor: '#16A34A15' }]}>
              <Text style={{ fontSize: 24 }}>📧</Text>
            </View>
            <Text style={[styles.contactLabel, { color: colors.text }]}>Email Us</Text>
          </TouchableOpacity>
        </View>

        {/* FAQs */}
        <Text style={[styles.sectionTitle, { color: colors.text }]}>FAQs</Text>
        {FAQS.map((faq, idx) => (
          <TouchableOpacity
            key={idx}
            style={[styles.faqCard, { backgroundColor: colors.surface }, shadow.sm]}
            onPress={() => setExpandedFaq(expandedFaq === idx ? null : idx)}
            accessibilityRole="button"
            accessibilityState={{ expanded: expandedFaq === idx }}>
            <View style={styles.faqRow}>
              <Text style={[styles.faqQ, { color: colors.text }]} numberOfLines={expandedFaq === idx ? undefined : 2}>
                {faq.q}
              </Text>
              <Text style={[styles.chevron, { color: colors.textMuted }]}>
                {expandedFaq === idx ? '▲' : '▼'}
              </Text>
            </View>
            {expandedFaq === idx ? (
              <Text style={[styles.faqA, { color: colors.textSecondary, borderTopColor: colors.border }]}>
                {faq.a}
              </Text>
            ) : null}
          </TouchableOpacity>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', padding: spacing.xxl, paddingBottom: spacing.md, gap: spacing.lg },
  backText: { fontSize: 24 },
  title: { fontSize: fontSize.xl, fontFamily: fontFamily.bold },
  content: { padding: spacing.xxl, paddingTop: 0, paddingBottom: 40 },
  contactRow: { flexDirection: 'row', marginBottom: spacing.xxl },
  contactCard: { borderRadius: radius.xl, padding: spacing.lg, alignItems: 'center' },
  contactIcon: { width: 52, height: 52, borderRadius: radius.lg, alignItems: 'center', justifyContent: 'center', marginBottom: spacing.sm },
  contactLabel: { fontSize: fontSize.xs, fontFamily: fontFamily.medium, textAlign: 'center' },
  sectionTitle: { fontSize: fontSize.lg, fontFamily: fontFamily.semiBold, marginBottom: spacing.lg },
  faqCard: { borderRadius: radius.xl, padding: spacing.lg, marginBottom: spacing.md },
  faqRow: { flexDirection: 'row', alignItems: 'flex-start', gap: spacing.md },
  faqQ: { flex: 1, fontSize: fontSize.base, fontFamily: fontFamily.medium },
  chevron: { fontSize: 12, marginTop: 4 },
  faqA: { marginTop: spacing.md, paddingTop: spacing.md, borderTopWidth: 1, fontSize: fontSize.sm, fontFamily: fontFamily.regular, lineHeight: 20 },
});
