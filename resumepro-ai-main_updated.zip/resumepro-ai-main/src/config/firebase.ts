// ─────────────────────────────────────────────────────────────────────────────
// Firebase / Google Sign-In Configuration
//
// Steps to activate:
//   1. Create a Firebase project at https://console.firebase.google.com
//   2. Add an Android app with package name "com.resumeproai.app" and
//      download google-services.json into android/app/
//   3. In the Firebase console, enable Authentication → Sign-in method → Google
//   4. Copy the "Web client ID" (OAuth client type 3) from
//      Google Cloud Console → APIs & Services → Credentials
//      (Firebase also shows it under Authentication → Sign-in method → Google)
//   5. Paste it below
//
// When GOOGLE_WEB_CLIENT_ID is empty, or google-services.json is missing,
// Google Sign-In throws a clear "not configured" error — there is no fake
// fallback user.
// ─────────────────────────────────────────────────────────────────────────────

export const FIREBASE_CONFIG = {
  GOOGLE_WEB_CLIENT_ID: '', // TODO: paste your Firebase Web Client ID here
};

export const isFirebaseConfigured = () => !!FIREBASE_CONFIG.GOOGLE_WEB_CLIENT_ID.trim();
