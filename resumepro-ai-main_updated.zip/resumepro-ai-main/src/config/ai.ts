// ─────────────────────────────────────────────────────────────────────────────
// AI Configuration — Google Gemini
//
// Steps to activate:
//   1. Go to https://aistudio.google.com → Get API Key
//   2. Replace the empty string below with your key
//   3. (Recommended) Restrict the key to package "com.resumeproai.app" in
//      Google Cloud Console → APIs & Services → Credentials
//
// When GEMINI_API_KEY is empty, AI features throw AINotConfiguredError and
// the relevant screens show an empty/not-configured state — no fallback.
// ─────────────────────────────────────────────────────────────────────────────

export const AI_CONFIG = {
  GEMINI_API_KEY: '', // TODO: paste your key here

  GEMINI_MODEL: 'gemini-2.0-flash',
  TIMEOUT_MS: 30000,
};
