import { usePremiumStore } from '../store/usePremiumStore';

export const APP_NAME = 'ResumePro AI';
export const APP_VERSION = '1.0.0';

/** Returns true if the feature should be locked behind PRO. */
export const isProLocked = (isPremiumFeature: boolean): boolean =>
  isPremiumFeature && !usePremiumStore.getState().isPremium;

export const STORAGE_KEYS = {
  THEME: '@resumepro/theme',
  USER: '@resumepro/user',
  RESUMES: '@resumepro/resumes',
  ONBOARDING_DONE: '@resumepro/onboarding_done',
  SETTINGS: '@resumepro/settings',
};

export const RESUME_SECTIONS = [
  'personalInfo',
  'summary',
  'workExperience',
  'education',
  'skills',
  'projects',
  'certificates',
  'languages',
  'awards',
  'references',
] as const;

export type ResumeSection = typeof RESUME_SECTIONS[number];

export const TEMPLATE_CATEGORIES = ['All', 'Professional', 'Creative', 'Modern', 'Minimal', 'ATS'] as const;

export const SKILL_LEVELS = ['Beginner', 'Intermediate', 'Advanced', 'Expert'] as const;

export const LANGUAGE_PROFICIENCIES = [
  'Beginner',
  'Elementary',
  'Intermediate',
  'Professional',
  'Native',
] as const;
