import type { Meta, StoryObj } from '@storybook/react';
import ButtonGroup from './ButtonGroup';

const meta = {
  title: 'Synaptix/Buttons/ButtonGroup',
  component: ButtonGroup,
  tags: ['autodocs'],
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component: `
The ButtonGroup component allows you to render multiple buttons or text links with a unified size.

## Usage

\`\`\`tsx
<ButtonGroup
  items={[
    { label: 'Save', bgColor: '#0066ff', textColor: '#ffffff' },
    { label: 'Cancel', bordered: true, borderColor: '#666' }
  ]}
  size="medium"
/>
\`\`\`
        `,
      },
    },
  },
  argTypes: {
    items: {
      control: 'object',
      description: 'Array of button or text link props',
      table: { category: 'Props' },
    },
    size: {
      control: 'select',
      options: ['small', 'medium', 'large', 'xlarge', 'xxlarge'],
      description: 'Size applied to all items in the group',
      table: { category: 'Props', defaultValue: { summary: 'medium' } },
    },
    className: {
      control: 'text',
      description: 'Custom CSS class name',
      table: { category: 'Props' },
    },
  },
} satisfies Meta<typeof ButtonGroup>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    items: [
      { label: 'First', bgColor: '#000000', textColor: '#ffffff' },
      { label: 'Second', bgColor: '#000000', textColor: '#ffffff' },
      { label: 'Third', bgColor: '#000000', textColor: '#ffffff' },
    ],
    size: 'medium',
  },
};

export const Mixed: Story = {
  args: {
    items: [],
    size: 'medium',
  },
  render: () => (
    <ButtonGroup
      items={[
        { label: 'Button 1', bgColor: '#0066ff', textColor: '#ffffff' },
        { label: 'Button 2', bgColor: '#0066ff', textColor: '#ffffff' },
        { label: 'Link', href: '#', labelColor: '#0066ff' },
      ]}
      size="medium"
    />
  ),
};

export const Bordered: Story = {
  args: {
    items: [],
    size: 'medium',
  },
  render: () => (
    <ButtonGroup
      items={[
        { label: 'Accept', bordered: true, borderColor: '#00cc66', textColor: '#00cc66', bgColor: '#ffffff' },
        { label: 'Decline', bordered: true, borderColor: '#cc0000', textColor: '#cc0000', bgColor: '#ffffff' },
      ]}
      size="medium"
    />
  ),
};

export const AllSizes: Story = {
  args: {
    items: [],
    size: 'medium',
  },
  render: () => (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
      <div>
        <h3>Small</h3>
        <ButtonGroup
          items={[
            { label: 'One', bgColor: '#000000', textColor: '#ffffff' },
            { label: 'Two', bgColor: '#000000', textColor: '#ffffff' },
          ]}
          size="small"
        />
      </div>
      <div>
        <h3>Medium</h3>
        <ButtonGroup
          items={[
            { label: 'One', bgColor: '#000000', textColor: '#ffffff' },
            { label: 'Two', bgColor: '#000000', textColor: '#ffffff' },
          ]}
          size="medium"
        />
      </div>
      <div>
        <h3>Large</h3>
        <ButtonGroup
          items={[
            { label: 'One', bgColor: '#000000', textColor: '#ffffff' },
            { label: 'Two', bgColor: '#000000', textColor: '#ffffff' },
          ]}
          size="large"
        />
      </div>
      <div>
        <h3>XLarge</h3>
        <ButtonGroup
          items={[
            { label: 'One', bgColor: '#000000', textColor: '#ffffff' },
            { label: 'Two', bgColor: '#000000', textColor: '#ffffff' },
          ]}
          size="xlarge"
        />
      </div>
      <div>
        <h3>XXLarge</h3>
        <ButtonGroup
          items={[
            { label: 'One', bgColor: '#000000', textColor: '#ffffff' },
            { label: 'Two', bgColor: '#000000', textColor: '#ffffff' },
             { label: 'Link', href: '#', labelColor: '#000000' },
          ]}
          size="xxlarge"
        />
      </div>
    </div>
  ),
};