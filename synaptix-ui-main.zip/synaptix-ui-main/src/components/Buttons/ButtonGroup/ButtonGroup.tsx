import React from "react";
import { Button, type ButtonProps } from "../Button";
import styles from './ButtonGroup.module.scss';
import { TextLink, type TextLinkProps } from "../TextLink";



export interface ButtonGroupProps {
  items: Array<Omit<ButtonProps, 'size'> | Omit<TextLinkProps, 'size'>>;
  size: ButtonProps['size'];
  className?: string;
  gap?: string;
}

export const ButtonGroup: React.FC<ButtonGroupProps> = ({
  items,
  size,
  className,
  ...rest
}) => {
  return (
    <div className={`${styles.buttonGroup} ${className || ''}`} {...rest}>
        {items.map((item,index) => {
            if ('href' in item) {
                return <TextLink key={index} {...item} size={size} />;
            } else {
                return <Button key={index} {...item} size={size} />;
            }
        })}
    </div>
  );
};

export default ButtonGroup;