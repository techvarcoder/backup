'use client';

import {
    type ComponentPropsWithoutRef,
    type CSSProperties,
    type ReactNode,
    forwardRef 
} from "react";
import styles from './Button.module.scss';

/**
 * Props for the Button component.
 */
export type ButtonProps = {
  /**
   * The text label displayed inside the button. This is the primary content of the component.
   * @example 'Click Me'
   */
  label: string;

  /**
   * The color of the label text.
   * Accepts any valid CSS color value (hex, rgb, hsl, etc.).
   * @example '#ffffff'
   * @default '#ffffff'
   */
  textColor?: string;

  /**
   * Whether the button is disabled.
   * When true, the component becomes non-interactive.
   * @default false
   */
  disabled?: boolean;

  /**
   * The size of the button.
   * @default 'medium'
   */
  size?: 'small' | 'medium' | 'large' | 'xlarge' | 'xxlarge';

  /**
   * Custom CSS class name to apply to the component.
   * @example 'my-custom-button'
   */
  className?: string;

  /**
   * Callback function triggered when the button is clicked.
   * @example () => console.log('Button clicked')
   */
  onClick?: () => void;

  /**
   * The background color of the button.
   * Accepts any valid CSS color value (hex, rgb, hsl, etc.).
   * @example '#0066ff'
   * @default '#000000'
   */
  bgColor?: string;

  /**
   * Whether to display a border around the button.
   * When true, the button will have a border with the specified borderColor.
   * Background color is independent and always customizable.
   * @example true
   * @default false
   */
  bordered?: boolean;

  /**
   * The color of the button border (only used when bordered is true).
   * Accepts any valid CSS color value.
   * @example '#0066ff'
   * @default '#000000'
   */
  borderColor?: string;

  /**
   * Sets the width of the button.
   * Accepts a number (interpreted as pixels) or a string with units.
   * @example 200 or '300px' or '100%' or '20rem'
   */
  width?: string | number;

  /**
   * Sets the role attribute for accessibility. 'button' for interactive elements, 'link' for navigation elements. Defaults to 'button' for button elements and 'link' for anchor elements if not specified.
   */
  role?: 'link' | 'button';
  
  /**
   * Aria label for accessibility purposes. If not provided, falls back to aria-label attribute or button text content. Defaults to 'Button' if no accessible text is found.
   */
  ariaLabel?: string;

  /**
   * Sets the border radius of the button.
   * Accepts any valid CSS border-radius value.
   * @example '20px' or '50%' or '0.5rem'
   */
  radius?: string;

  /**
   * HTML button type attribute.
   * @default 'button'
   */
  type?: 'button' | 'submit' | 'reset';

  /**
   * Icon element to display inside the button.
   * @example <IconComponent />
   */
  icon?: ReactNode;

  /**
   * Position of the icon within the button.
   * @default 'left'
   */
  iconPosition?: 'left' | 'right';
} & ComponentPropsWithoutRef<'button'>;


export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
(props, ref) => {
    const {
        label,
        textColor = '#ffffff',
        disabled = false,
        size = 'medium',
        onClick = () => {},
        bordered = false,
        borderColor = '#000000',
        bgColor = '#000000',
        className,
        width,
        role = 'button',
        ariaLabel,
        radius,
        type = 'button',
        icon,
        iconPosition = 'left',
        ...rest
    } = props;

    const buttonStyles = [styles.button];
    if (bordered) buttonStyles.push(styles.bordered);
    if (size === 'small') buttonStyles.push(styles.small);
    if (size === 'medium') buttonStyles.push(styles.medium);
    if (size === 'large') buttonStyles.push(styles.large);
    if (size === 'xlarge') buttonStyles.push(styles.xlarge);
    if (size === 'xxlarge') buttonStyles.push(styles.xxlarge);
    if (className) buttonStyles.push(className);
    
    const buttonStyle = {
        '--button-bg': bgColor,
        ...(bordered && { '--button-border-color': borderColor }),
        '--button-label-color': textColor,
        ...(width && { width: typeof width === 'number' ? `${width}px` : width }),
        ...(radius && { borderRadius: radius }),
    } as CSSProperties;

    return (
        <button 
            ref={ref}
            onClick={onClick}
            className={buttonStyles.join(' ')}
            style={buttonStyle}
            disabled={disabled}
            type={type}
            role={role}
            aria-label={ariaLabel || label}
            {...rest}
        >
            {icon && iconPosition === 'left' && <span style={{ marginRight: '8px', display: 'inline-flex', alignItems: 'center' }}>{icon}</span>}
            {label}
            {icon && iconPosition === 'right' && <span style={{ marginLeft: '8px', display: 'inline-flex', alignItems: 'center' }}>{icon}</span>}
        </button>
    );
});

Button.displayName = 'Button';

export default Button;