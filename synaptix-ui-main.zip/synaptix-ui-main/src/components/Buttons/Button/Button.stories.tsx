import type { Meta, StoryObj } from '@storybook/react';
import Button from './Button';

const meta = {
  title: 'Synaptix/Buttons/Button',
  component: Button,
  tags: ['autodocs'],
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component: `
The Button component is used for clickable actions in your application.

## Usage

\`\`\`tsx
<Button 
  label="Click Me"
  textColor="#ffffff"
  bgColor="#000000"
  bordered={false}
  borderColor="#000000"
  disabled={false}
  size="medium"
  className="custom-button"
  onClick={() => console.log('clicked')}
/>
\`\`\`
        `,
      },
    },
  },
  argTypes: {
    label: {
      control: 'text',
      description: 'The text displayed inside the button',
      table: { category: 'Props' },
    },
    textColor: {
      control: 'color',
      description: 'The color of the label text',
      table: { category: 'Props', defaultValue: { summary: '#ffffff' } },
    },
    bgColor: {
      control: 'color',
      description: 'Background color of the button',
      table: { category: 'Props', defaultValue: { summary: '#000000' } },
    },
    bordered: {
      control: 'boolean',
      description: 'Whether to display a border around the button',
      table: { category: 'Props', defaultValue: { summary: 'false' } },
    },
    borderColor: {
      control: 'color',
      description: 'Color of the button border',
      table: { category: 'Props', defaultValue: { summary: '#000000' } },
    },
    disabled: {
      control: 'boolean',
      description: 'Whether the button is disabled',
      table: { category: 'Props', defaultValue: { summary: 'false' } },
    },
    size: {
      control: 'select',
      options: ['small', 'medium', 'large', 'xlarge', 'xxlarge'],
      description: 'Size of the button. Controls padding and font-size',
      table: { category: 'Props', defaultValue: { summary: 'medium' } },
    },
    className: {
      control: 'text',
      description: 'Custom CSS class name',
      table: { category: 'Props' },
    },
  },
} satisfies Meta<typeof Button>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    label: 'Default Button',
    size: 'medium',
  },
};

export const CustomColor: Story = {
  args: {
    label: 'Custom Button',
    bgColor: '#0066ff',
    textColor: '#ffffff',
    size: 'medium',
  },
};

export const BorderedButton: Story = {
  args: {
    label: 'Bordered Button',
    bordered: true,
    borderColor: '#0066ff',
    textColor: '#0066ff',
    bgColor: '#ffffff',
    size: 'medium',
  },
};

export const Disabled: Story = {
  args: {
    label: 'Disabled Button',
    disabled: true,
    size: 'medium',
  },
};

export const AllSizes: Story = {
  args: {
    label: '',
  },
  render: () => (
    <div style={{ display: 'grid', gap: 16 }}>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center', flexWrap: 'wrap' }}>
        <Button label="Small" size="small" />
        <Button label="Medium" size="medium" />
        <Button label="Large" size="large" />
        <Button label="XLarge" size="xlarge" />
        <Button label="XXLarge" size="xxlarge" />
      </div>
    </div>
  ),
};