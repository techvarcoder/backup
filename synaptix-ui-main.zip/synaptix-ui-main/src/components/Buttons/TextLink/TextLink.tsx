'use client';

import {
    type ComponentPropsWithoutRef,
    type CSSProperties,
    forwardRef 
} from "react";
import styles from './TextLink.module.scss';

/**
 * Props for the TextLink component.
 */
export type TextLinkProps = {
  /**
   * The text label displayed inside the link. This is the primary content of the component.
   * @example 'Click Me'
   */
  label: string;

  /**
   * The URL to navigate to when the link is clicked.
   * @example '/home'
   */
  href: string;

  /**
   * The color of the label text.
   * Accepts any valid CSS color value (hex, rgb, hsl, etc.).
   * @example '#0066ff'
   * @default '#000000'
   */
  labelColor?: string;

  /**
   * Whether the link is disabled.
   * When true, the component becomes non-interactive.
   * @default false
   */
  disabled?: boolean;

  /**
   * The size of the link.
   * @default 'medium'
   */
  size?: 'small' | 'medium' | 'large' | 'xlarge' | 'xxlarge';

    /**
     * Display kind of the link.
     * - `standalone`: uses component size styles.
     * - `inline`: inherits font size from parent element.
     * @default 'standalone'
     */
    kind?: 'inline' | 'standalone';

  /**
   * Custom CSS class name to apply to the component.
   * @example 'my-custom-link'
   */
  className?: string;

  /**
   * Callback function triggered when the link is clicked.
   * @example () => console.log('Link clicked')
   */
  onClick?: () => void;
} & ComponentPropsWithoutRef<'a'>;


export const TextLink = forwardRef<HTMLAnchorElement, TextLinkProps>(
(props, ref) => {
    const {
        label,
        href,
        labelColor = '#000000',
        disabled = false,
        size = 'medium',
        kind = 'standalone',
        onClick = () => {},
        className,
        ...rest
    } = props;

    const linkStyles = [styles.textlink];
    if (kind === 'inline') {
        linkStyles.push(styles.inline);
    } else {
        linkStyles.push(styles.standalone);
        if (size === 'small') linkStyles.push(styles.small);
        if (size === 'medium') linkStyles.push(styles.medium);
        if (size === 'large') linkStyles.push(styles.large);
        if (size === 'xlarge') linkStyles.push(styles.xlarge);
        if (size === 'xxlarge') linkStyles.push(styles.xxlarge);
    }
    if (className) linkStyles.push(className);
    
    const linkStyle = {
        '--button-label-color': labelColor,
    } as CSSProperties;

    return (
        <a 
            ref={ref}
            href={href}
            onClick={onClick} 
            className={linkStyles.join(' ')}
            style={linkStyle}
            aria-disabled={disabled}
            {...rest}
        >
         {label}
        </a>
    );
});

TextLink.displayName = 'TextLink';

export default TextLink;
