import type { Meta, StoryObj } from '@storybook/react';
import TextLink from './TextLink';

const meta = {
  title: 'Synaptix/Buttons/TextLink',
  component: TextLink,
  tags: ['autodocs'],
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component: `
The TextLink component is used for clickable links in your application. It renders as an HTML anchor (\`<a>\`) element.

## Usage

\`\`\`tsx
<TextLink 
  label="Click Me"
  href="/page"
  labelColor="#000000"
  disabled={false}
  kind="standalone"
  size="medium"
  className="custom-link"
  onClick={() => console.log('clicked')}
/>
\`\`\`
        `,
      },
    },
  },
  argTypes: {
    label: {
      control: 'text',
      description: 'The text displayed inside the link',
      table: { category: 'Props' },
    },
    href: {
      control: 'text',
      description: 'The URL to navigate to when clicked',
      table: { category: 'Props' },
    },
    labelColor: {
      control: 'color',
      description: 'The color of the link text',
      table: { category: 'Props', defaultValue: { summary: '#000000' } },
    },
    disabled: {
      control: 'boolean',
      description: 'Whether the link is disabled',
      table: { category: 'Props', defaultValue: { summary: 'false' } },
    },
    kind: {
      control: 'select',
      options: ['inline', 'standalone'],
      description: 'Display kind. Inline inherits parent font size; standalone uses component sizing.',
      table: { category: 'Props', defaultValue: { summary: 'standalone' } },
    },
    size: {
      control: 'select',
      options: ['small', 'medium', 'large', 'xlarge', 'xxlarge'],
      description: 'Size of the link. Controls font-size',
      table: { category: 'Props', defaultValue: { summary: 'medium' } },
    },
    className: {
      control: 'text',
      description: 'Custom CSS class name',
      table: { category: 'Props' },
    },
  },
} satisfies Meta<typeof TextLink>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    label: 'Click here',
    href: '/docs',
    kind: 'standalone',
    size: 'medium',
  },
};

export const CustomColor: Story = {
  args: {
    label: 'Colored link',
    href: '/docs',
    labelColor: '#0066ff',
    size: 'medium',
  },
};

export const Disabled: Story = {
  args: {
    label: 'Disabled link',
    href: '/docs',
    disabled: true,
    size: 'medium',
  },
};

export const Inline: Story = {
  args: {
    label: '',
    href: '',
  },
  render: () => (
    <p style={{ fontSize: 24 }}>
      Read our <TextLink label="documentation" href="#" kind="inline" /> for more details.
    </p>
  ),
};

export const AllSizes: Story = {
  args: {
    label: '',
    href: '',
  },
  render: () => (
    <div style={{ display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap' }}>
      <TextLink label="Small" href="#" size="small" />
      <TextLink label="Medium" href="#" size="medium" />
      <TextLink label="Large" href="#" size="large" />
      <TextLink label="XLarge" href="#" size="xlarge" />
      <TextLink label="XXLarge" href="#" size="xxlarge" />
    </div>
  ),
};
