import React, { useState, useEffect } from 'react';
import type { HTMLAttributes } from 'react';
import styles from './HeroTypewriter.module.scss';

/**
 * Props for the HeroTypewriter component.
 * Extends HTMLAttributes<HTMLDivElement> for standard div element attributes.
 */
export interface HeroTypewriterProps extends HTMLAttributes<HTMLDivElement> {
  /**
   * The static part of the headline that remains constant.
   * This text is displayed before the animated words.
   * @default ''
   */
  title?: string;

  /**
   * Comma-separated list of words to cycle through with typewriter effect.
   * Each word will be typed out, held briefly, then erased before moving to the next.
   * @example 'Initializing..., Loading Modules..., System Online...'
   * @default ''
   */
  words?: string;

  /**
   * The color of the dynamically typed text and cursor.
   * Accepts any valid CSS color value (hex, rgb, hsl, etc.).
   * @example '#00ffcc'
   * @default '#00ffcc'
   */
  dynamicTextColor?: string;

  /**
   * Speed of typing animation in milliseconds per character.
   * Lower values create faster typing effects.
   * @example 100
   * @default 100
   */
  typeSpeed?: number;

  /**
   * Delay in milliseconds before the typed word begins to erase.
   * This is the pause time before the word disappears.
   * @example 2000
   * @default 2000
   */
  eraseDelay?: number;

  /**
   * Enable the text-shadow glow effect on the animated text.
   * Creates a glowing/neon appearance around the typed text.
   * @default false
   */
  textShadow?: boolean;

  /**
   * Enable the drop-shadow filter effect on the animated text.
   * Creates a shadow beneath and around the typed text.
   * @default false
   */
  dropShadow?: boolean;

  /**
   * Color of the text-shadow glow effect.
   * Only applies when textShadow is true.
   * Accepts any valid CSS color value.
   * @example 'rgba(0, 255, 204, 0.3)'
   * @default 'rgba(0, 255, 204, 0.3)'
   */
  textShadowColor?: string;

  /**
   * Color of the drop-shadow filter effect.
   * Only applies when dropShadow is true.
   * Accepts any valid CSS color value.
   * @example '#00ffcc'
   * @default '#00ffcc'
   */
  dropShadowColor?: string;
}

const HeroTypewriter = ({
  title = '',
  words = '',
  dynamicTextColor = '#00ffcc',
  typeSpeed = 100,
  eraseDelay = 2000,
  textShadow = false,
  dropShadow = false,
  textShadowColor = 'rgba(0, 255, 204, 0.3)',
  dropShadowColor = '#00ffcc',
  className,
  style,
  ...rest
}: HeroTypewriterProps) => {
    const wordList = words
      .split(',')
      .map((w) => w.trim())
      .filter((w) => w.length > 0);

    const [currentWordIndex, setCurrentWordIndex] = useState(0);
    const [displayText, setDisplayText] = useState('');
    const [isTyping, setIsTyping] = useState(true);

    useEffect(() => {
      if (wordList.length === 0) return;

      const currentWord = wordList[currentWordIndex];
      let timeout: NodeJS.Timeout;

      if (isTyping) {
        // Typing effect
        if (displayText.length < currentWord.length) {
          timeout = setTimeout(() => {
            setDisplayText(currentWord.substring(0, displayText.length + 1));
          }, typeSpeed);
        } else {
          // Word is fully typed, start erasing after delay
          timeout = setTimeout(() => {
            setIsTyping(false);
          }, eraseDelay);
        }
      } else {
        // Erasing effect
        if (displayText.length > 0) {
          timeout = setTimeout(() => {
            setDisplayText(displayText.substring(0, displayText.length - 1));
          }, typeSpeed / 2); // Erase faster than typing
        } else {
          // Move to next word
          setCurrentWordIndex((prev) => (prev + 1) % wordList.length);
          setIsTyping(true);
        }
      }

      return () => clearTimeout(timeout);
    }, [displayText, isTyping, currentWordIndex, wordList, typeSpeed, eraseDelay]);

    const containerStyle = {
      ...style,
      '--accent-color': dynamicTextColor,
      '--text-shadow-color': textShadowColor,
      '--drop-shadow-color': dropShadowColor,
    } as React.CSSProperties & Record<string, string>;

    const dynamicTextClassName = [
      styles.dynamicText,
      textShadow && styles.textShadow,
      dropShadow && styles.dropShadow,
    ]
      .filter(Boolean)
      .join(' ');

    return (
      <div
        className={`${styles.container} ${className || ''}`.trim()}
        style={containerStyle}
        {...rest}
      >
        <h1 className={styles.headline}>
          <span className={styles.staticText}>{title}</span>
          <span className={dynamicTextClassName}>
            {displayText}
            <span className={styles.cursor}>|</span>
          </span>
        </h1>
      </div>
    );
};

HeroTypewriter.displayName = 'HeroTypewriter';

export default HeroTypewriter;
