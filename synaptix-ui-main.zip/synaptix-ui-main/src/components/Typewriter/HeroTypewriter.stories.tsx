import type { Meta, StoryObj } from '@storybook/react';
import HeroTypewriter from './HeroTypewriter';

const meta = {
  title: 'Synaptix/Typewriter',
  component: HeroTypewriter,
  tags: ['autodocs'],
  argTypes: {
    title: { control: 'text', description: 'The static part of the headline' },
    words: { control: 'text', description: 'Comma-separated strings to cycle through' },
    dynamicTextColor: { control: 'color', description: 'Custom color for dynamic text and cursor' },
    typeSpeed: { control: 'number', description: 'Speed of typing in milliseconds' },
    eraseDelay: { control: 'number', description: 'Delay before erasing in milliseconds' },
    textShadow: { control: 'boolean', description: 'Enable text-shadow glow effect' },
    dropShadow: { control: 'boolean', description: 'Enable drop-shadow filter effect' },
    textShadowColor: { control: 'color', description: 'Color for text-shadow glow' },
    dropShadowColor: { control: 'color', description: 'Color for drop-shadow filter' },
  },
} satisfies Meta<typeof HeroTypewriter>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    title: 'Synaptix System Online...',
    words: 'Initializing..., Loading Modules..., System Online...',
    dynamicTextColor: '#00ffcc',
    typeSpeed: 150,
    eraseDelay: 3000,
  },
};

export const WithGlowEffects: Story = {
  args: {
    title: 'Experience the Future',
    words: 'Innovation, Technology, Tomorrow',
    dynamicTextColor: '#ff0080',
    typeSpeed: 100,
    eraseDelay: 2000,
    textShadow: true,
    dropShadow: true,
    textShadowColor: 'rgba(255, 0, 128, 0.3)',
    dropShadowColor: '#ff0080',
  },
};

export const FastTyping: Story = {
  args: {
    title: 'Speed Test',
    words: 'Fast, Quick, Rapid, Swift',
    dynamicTextColor: '#00ff00',
    typeSpeed: 50,
    eraseDelay: 1000,
  },
};
