<HeroTypewriter
  title={"Example Title"}
  words={"Word 1, Word 2, Word 3"}
  accentColor={"accentColor"}
  typingSpeed={100}
/>;
