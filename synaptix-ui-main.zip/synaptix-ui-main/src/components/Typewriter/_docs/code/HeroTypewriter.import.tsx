import { HeroTypewriter } from '@synaptix-ui/core';
