import * as path from 'path';
import * as fs from 'fs';
import {
  withCustomConfig,
  type ComponentDoc,
  type PropItem,
} from 'react-docgen-typescript';

interface PropDocumentation {
  name: string;
  urlPath: string;
  required: boolean;
  types: { name: string }[];
  description: string;
  defaultValue?: string;
}

interface ComponentDocumentation {
  name: string;
  props: PropDocumentation[];
}

interface OutputFormat {
  components: ComponentDocumentation[];
}

// Configuration
const COMPONENTS_DIR = path.resolve(process.cwd(), 'src/components');
const PACKAGE_JSON_PATH = path.resolve(process.cwd(), 'package.json');

// Read package name from package.json
let PACKAGE_NAME = '@synaptix-ui/core';
try {
  const packageJson = JSON.parse(fs.readFileSync(PACKAGE_JSON_PATH, 'utf-8'));
  PACKAGE_NAME = packageJson.name || PACKAGE_NAME;
} catch (error) {
  console.warn('⚠️  Could not read package.json, using default package name');
}

// TypeScript parser options
const parserOptions = {
  shouldExtractLiteralValuesFromEnum: true,
  shouldRemoveUndefinedFromOptional: true,
  propFilter: (prop: PropItem) => {
    // Exclude HTMLAttributes from documentation
    if (prop.parent) {
      const isHTMLAttribute = prop.parent.fileName.includes('node_modules');
      return !isHTMLAttribute;
    }
    return true;
  },
};

// Create parser
const parser = withCustomConfig(
  path.resolve(process.cwd(), 'tsconfig.json'),
  parserOptions
);

/**
 * Convert prop name to URL-friendly path
 */
function toUrlPath(componentName: string, propName: string): string {
  const kebabComponent = componentName
    .replace(/([a-z])([A-Z])/g, '$1-$2')
    .toLowerCase();
  const kebabProp = propName.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
  return `${kebabComponent}-props-${kebabProp}`;
}

/**
 * Parse component props and generate documentation
 */
function parseComponent(filePath: string): OutputFormat | null {
  try {
    const docs = parser.parse(filePath);

    if (docs.length === 0) {
      console.log(`⚠️  No components found in ${filePath}`);
      return null;
    }

    const components: ComponentDocumentation[] = docs.map((doc: ComponentDoc) => {
      const props: PropDocumentation[] = Object.entries(doc.props).map(
        ([propName, propData]) => {
          // Extract type information
          const types = propData.type.name
            .split('|')
            .map((t) => t.trim())
            .map((t) => ({ name: t }));

          return {
            name: propName,
            urlPath: toUrlPath(doc.displayName, propName),
            required: propData.required,
            types,
            description: propData.description || '',
            ...(propData.defaultValue && {
              defaultValue: propData.defaultValue.value,
            }),
          };
        }
      );

      return {
        name: doc.displayName,
        props,
      };
    });

    return { components };
  } catch (error) {
    console.error(`❌ Error parsing ${filePath}:`, error);
    return null;
  }
}

/**
 * Generate import code example
 */
function generateImportCode(componentName: string): string {
  return `import { ${componentName} } from '${PACKAGE_NAME}';\n`;
}

/**
 * Generate editor/usage code example
 */
function generateEditorCode(
  componentName: string,
  doc: OutputFormat
): string {
  const component = doc.components[0];
  if (!component || component.props.length === 0) {
    return `<${componentName} />;`;
  }

  // Pick a few interesting props for the example
  const exampleProps = component.props
    .slice(0, 4)
    .map((prop) => {
      let exampleValue = 'undefined';

      // Generate reasonable example values based on type
      if (prop.types[0].name.includes('string')) {
        exampleValue = prop.name === 'title' 
          ? '"Example Title"'
          : prop.name === 'words'
          ? '"Word 1, Word 2, Word 3"'
          : `"${prop.name}"`;
      } else if (prop.types[0].name.includes('number')) {
        exampleValue = prop.defaultValue || '100';
      } else if (prop.types[0].name.includes('boolean')) {
        exampleValue = 'true';
      } else if (prop.name.toLowerCase().includes('color')) {
        exampleValue = '"#00ffcc"';
      }

      return `  ${prop.name}={${exampleValue}}`;
    })
    .join('\n');

  return `<${componentName}\n${exampleProps}\n/>;\n`;
}

/**
 * Ensure directory exists
 */
function ensureDir(dir: string): void {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

/**
 * Find all component files
 */
function findComponentFiles(dir: string): string[] {
  const files: string[] = [];

  function traverse(currentDir: string) {
    const entries = fs.readdirSync(currentDir, { withFileTypes: true });

    for (const entry of entries) {
      const fullPath = path.join(currentDir, entry.name);

      // Skip _docs folders
      if (entry.isDirectory() && entry.name === '_docs') {
        continue;
      }

      if (entry.isDirectory()) {
        traverse(fullPath);
      } else if (
        entry.isFile() &&
        entry.name.endsWith('.tsx') &&
        !entry.name.includes('.stories.') &&
        !entry.name.includes('.test.') &&
        !entry.name.includes('index.')
      ) {
        files.push(fullPath);
      }
    }
  }

  traverse(dir);
  return files;
}

/**
 * Main execution
 */
function main() {
  console.log('🔍 Scanning for components...\n');

  // Find all component files
  const componentFiles = findComponentFiles(COMPONENTS_DIR);

  if (componentFiles.length === 0) {
    console.error('❌ No component files found');
    process.exit(1);
  }

  console.log(`📝 Found ${componentFiles.length} component file(s):\n`);

  let successCount = 0;

  for (const filePath of componentFiles) {
    const relativePath = path.relative(COMPONENTS_DIR, filePath);
    console.log(`   Processing: ${relativePath}`);

    const doc = parseComponent(filePath);

    if (!doc || doc.components.length === 0) {
      continue;
    }

    const component = doc.components[0];
    const componentName = component.name;
    const kebabName = componentName
      .replace(/([a-z])([A-Z])/g, '$1-$2')
      .toLowerCase();

    // Get component folder (e.g., src/components/Typewriter)
    const componentDir = path.dirname(filePath);
    const docsDir = path.join(componentDir, '_docs');
    const propsDir = path.join(docsDir, 'props');
    const codeDir = path.join(docsDir, 'code');

    // Ensure output directories exist for this component
    ensureDir(propsDir);
    ensureDir(codeDir);

    // Write props JSON
    const propsFile = path.join(propsDir, `${kebabName}.json`);
    fs.writeFileSync(propsFile, JSON.stringify(doc, null, 2));
    console.log(`   ✅ Generated: _docs/props/${kebabName}.json`);

    // Write import code
    const importFile = path.join(codeDir, `${componentName}.import.tsx`);
    const importCode = generateImportCode(componentName);
    fs.writeFileSync(importFile, importCode);
    console.log(`   ✅ Generated: _docs/code/${componentName}.import.tsx`);

    // Write editor code
    const editorFile = path.join(codeDir, `${componentName}.editor.tsx`);
    const editorCode = generateEditorCode(componentName, doc);
    fs.writeFileSync(editorFile, editorCode);
    console.log(`   ✅ Generated: _docs/code/${componentName}.editor.tsx`);

    console.log(`   📦 ${component.props.length} props documented\n`);
    successCount++;
  }

  console.log(`\n✨ Documentation generated successfully!`);
  console.log(`   ${successCount} component(s) processed`);
  console.log(`   📁 Each component folder now has a _docs/ directory\n`);
}

// Run
main();
