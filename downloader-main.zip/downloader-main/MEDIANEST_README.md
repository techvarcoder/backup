# MediaNest - Universal Video Downloader & Offline Media Manager

A production-grade React Native application for downloading, managing, and playing videos offline. Built with TypeScript, Zustand, SQLite, and modern animations.

## 📱 Features

### Core Functionality
- **Universal Video Downloads** — YouTube, TikTok, Instagram, Twitter/X, Facebook, Vimeo, Dailymotion, Reddit, Twitch
- **Offline Media Management** — Local video/audio library with grid/list views, favorites, playlists
- **Built-in Player** — Video and audio playback with full controls, speed adjustment, sleep timer
- **Batch Downloads** — Queue multiple URLs for parallel downloading  
- **Search & History** — Global search, download history, playback history, recent searches
- **Settings** — Theme, quality preferences, notifications, storage management
- **Browser** — Built-in browser with video detection and floating download button

### Technical Highlights
- **Dark Premium Design** — Glassmorphism UI with Poppins typography
- **Reanimated 3 Animations** — Smooth transitions, progress bars, splash screen
- **Full Offline** — No backend, no authentication, all data stored locally
- **Production Architecture** — Clean separation: types → database → stores → services → components → screens
- **Stub Pattern** — Missing native packages (react-native-video, webview, fs) have no-op stubs; zero code changes when packages installed

## 🏗️ Architecture

```
src/
├── types/                    # All domain interfaces
├── theme/                    # Design tokens (colors, typography, spacing)
├── constants/                # App constants, platform list, quality options
├── db/                       # SQLite
│   ├── database.ts          # Singleton, migrations
│   ├── schema.ts            # CREATE TABLE statements
│   └── repositories/        # Data access layer (6 repos)
├── services/                 # Business logic
│   ├── downloadService.ts   # Axios-based queue manager
│   ├── mediaAnalysisService.ts  # URL parsing, platform detection
│   ├── stubs/               # Missing packages stubs
│   └── ...
├── stores/                   # Zustand state management
│   ├── downloadStore.ts
│   ├── libraryStore.ts
│   ├── settingsStore.ts
│   └── playerStore.ts
├── navigation/               # React Navigation
│   ├── types.ts            # Route params
│   ├── AppNavigator.tsx    # Root stack
│   ├── MainTabNavigator.tsx  # 5 bottom tabs
│   └── *StackNavigator.tsx # Per-tab stacks
├── components/              # Reusable UI
│   ├── common/             # 14 design system atoms
│   ├── download/           # Download-specific
│   ├── media/              # Media library
│   ├── player/             # Playback controls
│   ├── home/               # Home features
│   └── browser/            # Browser features
└── screens/                 # Full screen implementations
    ├── SplashScreen
    ├── HomeScreen
    ├── VideoAnalysisScreen
    ├── DownloadOptionsScreen
    ├── DownloadManagerScreen
    ├── MediaLibraryScreen
    ├── VideoPlayerScreen
    ├── AudioPlayerScreen
    ├── BrowserScreen
    ├── SearchScreen
    ├── FavoritesScreen
    ├── HistoryScreen
    └── SettingsScreen
```

## 🗄️ Database Schema

**8 Tables:**
- `downloads` — Download items with progress tracking
- `media_items` — Local media library
- `playlists` — User-created playlists
- `playlist_items` — Playlist membership
- `favorites` — Favorite media items
- `history` — Download/play history
- `recent_searches` — Search history
- `app_settings` — App-level settings (key-value store)

All tables use timestamps (Unix epoch) and foreign keys with CASCADE delete.

## 🎨 Design System

### Colors (Dark Premium)
- Background: `#0B1020`
- Surface: `#141A2F`
- Card: `#1D2440`
- Primary: `#7C4DFF` (Purple)
- Secondary: `#00E5FF` (Cyan)
- Success: `#00C853`
- Error: `#FF5252`

### Typography
- Font: Poppins (300, 400, 500, 600, 700)
- Sizes: Hero (40), Heading (32), Title (24), Subtitle (18), Body (16), Caption (12), Tiny (10)

### Icons
- MaterialCommunityIcons (react-native-vector-icons)
- 24dp default, 28dp for primary actions

## ⚡ State Management (Zustand)

### downloadStore
- `activeDownloads`, `completedDownloads`, `failedDownloads`
- Actions: `addDownload`, `updateProgress`, `pause`, `resume`, `cancel`, `retry`, `pauseAll`, `resumeAll`

### libraryStore  
- `allMedia`, `filteredMedia` (computed)
- Tabs, sorting, search, multi-select
- Actions: `loadMedia`, `setActiveTab`, `toggleFavorite`, `deleteMedia`

### settingsStore
- `settings`, `isHydrated`
- AsyncStorage-backed persistence
- Actions: `loadSettings`, `updateSetting`, `resetSettings`

### playerStore
- Video: `currentVideoId`, `isVideoPlaying`, `videoPosition`, `videoDuration`
- Audio: `currentAudioId`, `audioQueue`, `repeatMode`, `isShuffle`, `sleepTimerMs`
- Actions: `playVideo`, `pauseVideo`, `nextTrack`, `previousTrack`, etc.

## 🚀 Download Engine

**Architecture:**
- `DownloadQueue` with `maxConcurrent = 3` slots
- Uses `axios` with `onDownloadProgress` callbacks
- Pause/resume via `Range: bytes=N-` headers
- Duplicate detection via `downloadRepository.getDownloadByUrl()`
- Speed calculated as rolling 1-second average

**Flow:**
1. User pastes URL → `mediaAnalysisService` detects platform
2. Tap "Analyze" → fetches og:meta tags, detects available qualities
3. Select quality/format → `downloadStore.addDownload()`
4. Service enqueues → starts when slot available
5. Progress updates UI in real-time
6. On complete → creates `MediaItem`, adds history entry

## 🔧 Stub Pattern (for Missing Native Packages)

When `react-native-video`, `react-native-webview`, or `react-native-fs` are not installed:
- Stubs in `src/services/stubs/` provide mock implementations
- UI renders, showing "Install X to enable Y" placeholders
- Zero code changes needed in screens/components
- When real packages are installed, only stub imports change

Example: `VideoPlayer` component tries `require('react-native-video')` at runtime, falls back to stub with play-circle icon and message.

## 📋 Navigation Structure

```
RootStack (native-stack)
├── Splash (2s animation, replaces to MainTabs)
├── MainTabs (bottom-tabs, 5 tabs)
│   ├── HomeTab
│   │   └── HomeMain
│   ├── DownloadsTab
│   │   └── DownloadManager (active/paused/completed/failed tabs)
│   ├── LibraryTab
│   │   ├── MediaLibrary (videos/audio/images/reels tabs)
│   │   ├── Favorites
│   │   └── History
│   ├── BrowserTab
│   │   └── BrowserMain
│   └── SettingsTab
│       └── SettingsMain
├── VideoAnalysis { url: string }      (modal)
├── DownloadOptions { analysis }       (modal)
├── VideoPlayer { mediaId }            (full-screen)
├── AudioPlayer { mediaId }            (full-screen)
├── Search { initialQuery? }           (modal)
└── BatchDownload                      (modal)
```

Tab badges show active download count.

## 🎯 Screens (14 Total)

### 1. Splash
- 2-second animated entry
- Logo scale/pulse/fade with Reanimated
- LinearGradient background
- Auto-navigates to MainTabs

### 2. Home
- URL input card with paste button
- Platform instant detection
- "Analyze" button → VideoAnalysis screen
- Quick action buttons (Downloads, Browser, Batch)
- Recent downloads carousel
- Supported platforms grid (9 platforms)

### 3. Video Analysis
- Fetches video metadata from og: tags
- Displays thumbnail, title, channel, duration
- Shows available quality/format options
- "Download Options" button → download selection screen

### 4. Download Options
- Quality selector (4K down to 144p)
- Format tabs (Video / Audio Only)
- Optional thumbnail download toggle
- Free space indicator
- "Start Download" → enqueues and navigates to Download Manager

### 5. Download Manager
- 4 status tabs: Active | Paused | Completed | Failed
- Per-download card: thumbnail, title, progress bar, speed, ETA
- Action buttons (pause/resume/cancel/delete/play)
- "Pause All" / "Resume All" FABs
- Real-time speed display

### 6. Media Library
- 4 filter tabs: Videos | Audio | Images | Reels
- Grid/List view toggle
- Search bar (300ms debounce)
- Sort menu (date/name/size/platform, asc/desc)
- Long-press multi-select
- Pull-to-refresh

### 7. Video Player
- Full-screen with status bar hidden
- Gesture controls (double-tap seek, swipe brightness/volume)
- Control overlay (auto-hide after 3s)
- SeekBar with time display
- Speed selector (0.5x-2x)
- Fullscreen + PiP buttons (PiP stub message if not installed)
- Picture-in-Picture support (when available)

### 8. Audio Player
- Full-screen with album art
- Large thumbnail with gradient background
- SeekBar + current/total time
- Play/pause + prev/next buttons
- Shuffle + Repeat cycle buttons
- Speed selector
- Queue list (expandable bottom sheet)
- Sleep timer (bottom sheet picker)

### 9. Browser
- URL bar with go/back/forward/refresh buttons
- Multiple tab support (up to 10 tabs)
- Video detection on loaded page
- Floating download button (shows detected videos)
- Detects platform from current URL
- WebView stub shows "Install react-native-webview" when not available

### 10. Batch Download
- Multiline text input for URLs
- "Parse URLs" button → validates and deduplicates
- Lists parsed URLs with platform icons
- Shows analysis progress per URL
- "Download All" → enqueues all
- Pause/Resume/Retry All controls

### 11. Search
- SearchBar auto-focused on mount
- Recent searches section (chips, tap to refill)
- Live search as user types (debounced)
- Results show grid/list of matching media
- Platform quick-filter buttons when query empty

### 12. Favorites
- Tabs: All | Videos | Audio | Playlists
- Grid/List toggles
- "New Playlist" FAB → bottom sheet name input
- Playlist cards: cover + name + item count
- Long-press: rename/delete options

### 13. History
- Download History section (grouped by date: Today, Yesterday, Older)
- Playback History section (same grouping)
- Swipe-to-delete per item
- "Clear All" button with confirmation
- Re-download action for download history

### 14. Settings
- **Appearance:** Dark/Light theme toggle
- **Downloads:** Path display, default quality/format picker, max concurrent downloads (1-5 slider), Wi-Fi only toggle
- **Player:** Auto-Play Next toggle
- **Notifications:** Enable toggle (requests permission)
- **Storage:** Used/Total display, clear cache, clear history buttons
- **About:** App version, missing packages info
- All settings persist to AsyncStorage + SQLite

## 📦 Dependencies

### Runtime
- `react-native@0.80.3` — latest stable
- `react@19.1.0`
- `zustand@^5.0.2` — state management
- `react-native-sqlite-storage@^6.0.1` — local database
- `@react-navigation/*` — routing  
- `react-native-reanimated@^3.16.2` — animations
- `react-native-gesture-handler@^2.21.0` — gestures
- `react-native-linear-gradient@^2.8.3` — backgrounds
- `react-native-vector-icons@^10.2.0` — icons (MaterialCommunityIcons)
- `react-native-svg@^15.8.0` — SVG support
- `@gorhom/bottom-sheet@^4.6.4` — modal sheets
- `@react-native-async-storage/async-storage@^2.1.0` — key-value storage
- `@react-native-community/slider@^4.5.5` — seekbar
- `axios@^1.7.9` — HTTP downloads
- `htmlparser2@^12.0.0` — HTML parsing for og: tags

### Missing (Stubs in place)
- `react-native-video` — VideoPlayer renders stub when absent
- `react-native-webview` — Browser renders stub when absent
- `react-native-fs` — file ops stubbed, downloads work in-memory
- `react-native-background-downloader` — foreground-only until installed

### Dev
- `typescript@5.0.4`
- `@react-native/typescript-config`
- `eslint`, `prettier`
- `jest` — testing framework

## 🛠️ Building & Running

```bash
# Install dependencies
npm install
# or yarn install

# Link native modules
npx react-native-asset  # for fonts

# Android
npx react-native run-android

# iOS
npx react-native run-ios

# TypeScript check
npx tsc --noEmit

# Tests
npm test
```

## 🔐 Permissions (Android)

```xml
<!-- storage -->
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="29"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
<uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
<uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
<!-- foreground service -->
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>
<!-- download -->
<uses-permission android:name="android.permission.WAKE_LOCK"/>
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
```

## 📱 Device Support

- **Android:** API 24+ (Android 7.0+)
- **iOS:** 14.0+ (via CocoaPods)
- **New Architecture (Fabric):** Enabled, Hermes engine ready

## 🚀 Production Checklist

- [ ] Install missing packages (react-native-video, react-native-webview, react-native-fs, react-native-background-downloader) — zero code changes needed
- [ ] Update app icons in ios/MediaNest/Images.xcassets and android/app/src/main/res
- [ ] Generate signing keys for release builds
- [ ] Test all 14 screens on physical devices
- [ ] Verify permissions flow (camera, storage, notifications)
- [ ] Profile performance: Memory usage, download speed, UI responsiveness
- [ ] Configure app analytics (optional Firebase)
- [ ] Set up crash reporting (optional Sentry)
- [ ] Prepare store listing (icon, screenshots, description)
- [ ] Sign and upload to Google Play Store / App Store

## 📝 Code Quality

- **TypeScript:** Strict mode enabled, no `any` types
- **Linting:** ESLint with React Native preset
- **Formatting:** Prettier (2-space indent, single quotes)
- **Architecture:** Clean separation of concerns (types → db → stores → services → components → screens)
- **Naming:** Clear, descriptive names; no abbreviations except UI
- **Comments:** Only for non-obvious logic; WHY not WHAT
- **Testing:** Jest for utilities, integration tests for critical paths

## 🤝 Contributing

1. Create feature branch: `git checkout -b feature/amazing-feature`
2. Make changes following code quality guidelines
3. Run tests: `npm test`
4. Check types: `npx tsc --noEmit`
5. Commit with descriptive message
6. Push and create pull request

## 📄 License

MIT License — See LICENSE file for details

---

**Built with ❤️ using React Native, TypeScript, and modern best practices.**
