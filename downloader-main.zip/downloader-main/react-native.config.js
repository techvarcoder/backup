module.exports = {
  assets: ['./src/assets/fonts/'],
  dependencies: {
    'react-native-linear-gradient': {
      platforms: {
        android: null,
        ios: null,
      },
    },
  },
};
