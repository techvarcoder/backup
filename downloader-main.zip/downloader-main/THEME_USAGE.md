# Theme System Usage Guide

## Setup

The theme system is already integrated in `App.tsx` with the `ThemeProvider` component. It automatically hydrates settings from AsyncStorage and gates rendering until initialization is complete.

## Basic Usage

### Get all theme values

```tsx
import { useTheme } from 'src/theme';

export const MyComponent = () => {
  const { colors, typography, spacing, radius, shadow, mode } = useTheme();
  
  return (
    <View style={{ backgroundColor: colors.primaryBackground }}>
      <Text style={{ color: colors.primaryText }}>Hello</Text>
    </View>
  );
};
```

### Use specific theme hooks

```tsx
import { 
  useColors, 
  useTypography, 
  useSpacing, 
  useRadius, 
  useShadow 
} from 'src/theme';

export const MyComponent = () => {
  const colors = useColors();
  const typography = useTypography();
  const spacing = useSpacing();
  const radius = useRadius();
  const shadow = useShadow();
  
  return (
    <View style={{ 
      backgroundColor: colors.primary,
      padding: spacing.md,
      borderRadius: radius.lg,
      ...shadow.md
    }}>
      <Text style={{ 
        fontSize: typography.fontSize.body,
        fontFamily: typography.fontFamily.primary
      }}>
        Styled Text
      </Text>
    </View>
  );
};
```

### Minimal consumption example

```tsx
import { useTheme } from 'src/theme';

export const SimpleCard = () => {
  const { colors } = useTheme();
  
  return (
    <View style={{ backgroundColor: colors.primary }}>
      <Text style={{ color: colors.primaryText }}>Content</Text>
    </View>
  );
};
```

## Settings Management

```tsx
import { useSettingsStore } from 'src/stores/settingsStore';

export const ThemeToggle = () => {
  const theme = useSettingsStore((state) => state.theme);
  const setTheme = useSettingsStore((state) => state.setTheme);
  
  return (
    <TouchableOpacity onPress={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
      <Text>Current: {theme}</Text>
    </TouchableOpacity>
  );
};
```

## Available Colors

- **Backgrounds**: `primaryBackground`, `secondaryBackground`, `cardBackground`, `elevatedCard`
- **Text**: `primaryText`, `secondaryText`, `mutedText`
- **Accents**: `primary`, `primaryLight`, `accentYellow`, `accentOrange`
- **States**: `success`, `danger`
- **UI**: `border`, `overlay`, `white`, `black`, `tabBar`, `tabBarBorder`

## Available Spacing

- `xs: 4`, `sm: 8`, `md: 12`, `lg: 16`, `xl: 20`, `xxl: 24`, `xxxl: 32`, `huge: 40`, `massive: 48`

## Available Radius

- `sm: 8`, `md: 12`, `lg: 16`, `xl: 20`, `xxl: 24`, `full: 999`

## Available Shadows

- `sm`, `md`, `lg` - each with proper shadowColor, shadowOffset, shadowOpacity, shadowRadius, and elevation

## Typography

- **Font Families**: `primary`, `primaryBold`, `primarySemiBold`, `primaryRegular`, `secondary`, `secondaryMedium`, `secondarySemiBold`, `secondaryBold`
- **Font Sizes**: `h1`, `h2`, `h3`, `h4`, `bodyLarge`, `body`, `bodySmall`, `caption`, `buttonLarge`, `button`
- **Font Weights**: `regular`, `medium`, `semiBold`, `bold`
- **Line Heights**: Corresponding values for each font size
