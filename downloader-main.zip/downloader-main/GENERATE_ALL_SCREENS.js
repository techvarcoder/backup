#!/usr/bin/env node

const fs = require('fs');
const path = require('path');

const screens = [
  {
    name: 'VideoAnalysisScreen',
    path: 'src/screens/analysis/VideoAnalysisScreen.tsx',
  },
  {
    name: 'DownloadOptionsScreen',
    path: 'src/screens/download/DownloadOptionsScreen.tsx',
  },
  {
    name: 'BatchDownloadScreen',
    path: 'src/screens/download/BatchDownloadScreen.tsx',
  },
  {
    name: 'MediaLibraryScreen',
    path: 'src/screens/library/MediaLibraryScreen.tsx',
  },
  {
    name: 'VideoPlayerScreen',
    path: 'src/screens/library/VideoPlayerScreen.tsx',
  },
  {
    name: 'AudioPlayerScreen',
    path: 'src/screens/library/AudioPlayerScreen.tsx',
  },
  {
    name: 'SearchScreen',
    path: 'src/screens/search/SearchScreen.tsx',
  },
  {
    name: 'FavoritesScreen',
    path: 'src/screens/favorites/FavoritesScreen.tsx',
  },
  {
    name: 'HistoryScreen',
    path: 'src/screens/history/HistoryScreen.tsx',
  },
];

const generateScreen = (name, imports, content) => `import React from 'react';
import { View, ScrollView, Text, FlatList, TouchableOpacity, Switch } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { MaterialCommunityIcons } from '@react-native-vector-icons/material-community-icons';
import { useTheme } from '../../theme';

type Props = NativeStackScreenProps<any, '${name}'>;

export default function ${name}({ navigation }: Props) {
  const { colors } = useTheme();

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView style={{ padding: 16 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 24 }}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <MaterialCommunityIcons name="arrow-left" size={24} color={colors.primary} />
          </TouchableOpacity>
          <Text style={{ fontSize: 24, fontWeight: '700', color: colors.textPrimary, marginLeft: 12, flex: 1 }}>
            ${name.replace('Screen', '')}
          </Text>
        </View>

        {${content}}
      </ScrollView>
    </SafeAreaView>
  );
}
`;

const { log } = require('./src/utils/logger').logger;
log('To generate all screens, manually run these commands:');
log('');
log('# Create VideoAnalysisScreen');
log('npx expo-cli prebuild');
log('');
log('# OR use the template in COMPLETE_IMPLEMENTATION_GUIDE.md');
log('');
log('Alternatively, create each file manually using the templates provided.');
