export const APP_NAME = 'MediaNest';

export const STORAGE_KEYS = {
  THEME: '@medianest/theme',
  USER: '@medianest/user',
};

export const SUPPORTED_PLATFORMS = [
  { id: 'youtube', name: 'YouTube', icon: 'youtube', color: '#FF0000' },
  { id: 'facebook', name: 'Facebook', icon: 'facebook', color: '#1877F2' },
  { id: 'instagram', name: 'Instagram', icon: 'instagram', color: '#E1306C' },
  { id: 'tiktok', name: 'TikTok', icon: 'tiktok', color: '#FFFFFF' },
  { id: 'twitter', name: 'X (Twitter)', icon: 'twitter', color: '#FFFFFF' },
  { id: 'vimeo', name: 'Vimeo', icon: 'vimeo', color: '#1AB7EA' },
  { id: 'dailymotion', name: 'Dailymotion', icon: 'dailymotion', color: '#0066DC' },
  { id: 'reddit', name: 'Reddit', icon: 'reddit', color: '#FF4500' },
  { id: 'twitch', name: 'Twitch', icon: 'twitch', color: '#9146FF' },
];

export const QUALITY_OPTIONS = [
  { id: '4k', label: '4K (2160p)', value: '2160' },
  { id: '1440p', label: '1440p', value: '1440' },
  { id: '1080p', label: '1080p (Full HD)', value: '1080' },
  { id: '720p', label: '720p (HD)', value: '720' },
  { id: '480p', label: '480p', value: '480' },
  { id: '360p', label: '360p', value: '360' },
  { id: '240p', label: '240p', value: '240' },
  { id: '144p', label: '144p', value: '144' },
];

export const AUDIO_FORMATS = [
  { id: 'mp3', label: 'MP3', mimeType: 'audio/mpeg', extension: 'mp3' },
  { id: 'aac', label: 'AAC', mimeType: 'audio/aac', extension: 'aac' },
  { id: 'm4a', label: 'M4A', mimeType: 'audio/mp4', extension: 'm4a' },
];

export const DOWNLOAD_STATUS = {
  PENDING: 'pending',
  DOWNLOADING: 'downloading',
  PAUSED: 'paused',
  COMPLETED: 'completed',
  FAILED: 'failed',
  CANCELLED: 'cancelled',
} as const;

export const PLAYER_SPEEDS = [
  { id: '0.5x', label: '0.5x', value: 0.5 },
  { id: '0.75x', label: '0.75x', value: 0.75 },
  { id: '1x', label: 'Normal', value: 1 },
  { id: '1.25x', label: '1.25x', value: 1.25 },
  { id: '1.5x', label: '1.5x', value: 1.5 },
  { id: '2x', label: '2x', value: 2 },
];

export const MAX_CONCURRENT_DOWNLOADS = 3;

export const DEFAULT_DOWNLOAD_PATH = '/Downloads';
