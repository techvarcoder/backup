// Lightweight UUID wrapper: prefer 'uuid' package when available, otherwise fallback.
let usePkg = false;
let pkgV4: (() => string) | null = null;
try {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const u = require('uuid');
  pkgV4 = (u && (u.v4 || u.default?.v4 || u)) as any;
  if (typeof pkgV4 === 'function') usePkg = true;
} catch (e) {
  // package not available
}

export function v4(): string {
  if (usePkg && pkgV4) return pkgV4();
  // fallback simple random UUID (RFC4122 v4-like)
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

export default { v4 };
