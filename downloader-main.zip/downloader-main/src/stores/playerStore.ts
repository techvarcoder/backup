import { create } from 'zustand';
import { RepeatMode } from '../types';

interface PlayerStore {
  currentVideoId: string | null;
  isVideoPlaying: boolean;
  videoPosition: number;
  videoDuration: number;
  videoSpeed: number;
  isFullscreen: boolean;

  currentAudioId: string | null;
  isAudioPlaying: boolean;
  audioPosition: number;
  audioDuration: number;
  audioQueue: string[];
  queueIndex: number;
  isShuffle: boolean;
  repeatMode: RepeatMode;
  sleepTimerMs: number | null;
  showMiniPlayer: boolean;

  playVideo: (mediaId: string) => void;
  pauseVideo: () => void;
  seekVideo: (position: number) => void;
  setVideoSpeed: (speed: number) => void;
  toggleFullscreen: () => void;

  playAudio: (mediaId: string, queue?: string[]) => void;
  pauseAudio: () => void;
  seekAudio: (position: number) => void;
  nextTrack: () => void;
  previousTrack: () => void;
  toggleShuffle: () => void;
  cycleRepeat: () => void;
  setSleepTimer: (minutes: number | null) => void;
  dismissMiniPlayer: () => void;

  updateVideoPosition: (pos: number) => void;
  updateAudioPosition: (pos: number) => void;
}

export const usePlayerStore = create<PlayerStore>((set, get) => ({
  currentVideoId: null,
  isVideoPlaying: false,
  videoPosition: 0,
  videoDuration: 0,
  videoSpeed: 1,
  isFullscreen: false,

  currentAudioId: null,
  isAudioPlaying: false,
  audioPosition: 0,
  audioDuration: 0,
  audioQueue: [],
  queueIndex: 0,
  isShuffle: false,
  repeatMode: 'none' as RepeatMode,
  sleepTimerMs: null,
  showMiniPlayer: false,

  playVideo: (mediaId) => set({ currentVideoId: mediaId, isVideoPlaying: true }),
  pauseVideo: () => set({ isVideoPlaying: false }),
  seekVideo: (position) => set({ videoPosition: position }),
  setVideoSpeed: (speed) => set({ videoSpeed: speed }),
  toggleFullscreen: () => set((s) => ({ isFullscreen: !s.isFullscreen })),

  playAudio: (mediaId, queue) => {
    set({
      currentAudioId: mediaId,
      isAudioPlaying: true,
      audioQueue: queue || [mediaId],
      queueIndex: queue ? queue.indexOf(mediaId) : 0,
      showMiniPlayer: true,
    });
  },

  pauseAudio: () => set({ isAudioPlaying: false }),
  seekAudio: (position) => set({ audioPosition: position }),

  nextTrack: () => {
    const state = get();
    if (state.queueIndex + 1 < state.audioQueue.length) {
      set({
        queueIndex: state.queueIndex + 1,
        currentAudioId: state.audioQueue[state.queueIndex + 1],
      });
    }
  },

  previousTrack: () => {
    const state = get();
    if (state.queueIndex > 0) {
      set({
        queueIndex: state.queueIndex - 1,
        currentAudioId: state.audioQueue[state.queueIndex - 1],
      });
    }
  },

  toggleShuffle: () => set((s) => ({ isShuffle: !s.isShuffle })),

  cycleRepeat: () => {
    set((s) => {
      const modes: RepeatMode[] = ['none', 'all', 'one'];
      const idx = modes.indexOf(s.repeatMode);
      return { repeatMode: modes[(idx + 1) % modes.length] };
    });
  },

  setSleepTimer: (minutes) => set({ sleepTimerMs: minutes ? minutes * 60 * 1000 : null }),
  dismissMiniPlayer: () => set({ showMiniPlayer: false, isAudioPlaying: false }),
  updateVideoPosition: (pos) => set({ videoPosition: pos }),
  updateAudioPosition: (pos) => set({ audioPosition: pos }),
}));
