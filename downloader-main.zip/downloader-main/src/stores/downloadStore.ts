import { create } from 'zustand';
import { logger } from '../utils/logger';
import { DownloadItem } from '../types';
import * as downloadRepo from '../db/repositories/downloadRepository';
import { insertHistory } from '../db/repositories/historyRepository';
import { insertMediaItem } from '../db/repositories/mediaRepository';

import { downloadQueue } from '../services/downloadService';

interface DownloadStore {
  activeDownloads: DownloadItem[];
  completedDownloads: DownloadItem[];
  failedDownloads: DownloadItem[];
  totalBytesPerSecond: number;

  addDownload: (item: Omit<DownloadItem, 'id' | 'createdAt'>) => Promise<string>;
  updateProgress: (id: string, progress: number, downloadedBytes: number) => Promise<void>;
  updateStatus: (id: string, status: string, error?: string) => Promise<void>;
  pauseDownload: (id: string) => void;
  resumeDownload: (id: string) => void;
  cancelDownload: (id: string) => Promise<void>;
  clearCompleted: () => void;
  loadFromDatabase: () => Promise<void>;
}

export const useDownloadStore = create<DownloadStore>((set, get) => ({
  activeDownloads: [],
  completedDownloads: [],
  failedDownloads: [],
  totalBytesPerSecond: 0,

  addDownload: async (item) => {
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    const newItem: DownloadItem = {
      ...item,
      id,
      createdAt: Date.now(),
      completedAt: null,
    };
    await downloadRepo.insertDownload(newItem);
    set((state) => ({
      activeDownloads: [...state.activeDownloads, newItem],
    }));
    downloadQueue.startDownload(id, newItem.url, newItem.filePath);
    return id;
  },

  updateProgress: async (id, progress, downloadedBytes) => {
    await downloadRepo.updateDownloadProgress(id, progress, downloadedBytes);
    set((state) => ({
      activeDownloads: state.activeDownloads.map((d) =>
        d.id === id ? { ...d, progress, downloadedBytes } : d
      ),
    }));
  },

  updateStatus: async (id, status, error) => {
    await downloadRepo.updateDownloadStatus(id, status, error);

    if (status === 'completed' || status === 'failed') {
      try {
        const allItems = [...get().activeDownloads, ...get().completedDownloads, ...get().failedDownloads];
        const item = allItems.find((d) => d.id === id);
        if (item) {
          await insertHistory({
            mediaId: null,
            downloadId: item.id,
            title: item.title,
            thumbnailPath: item.thumbnailUrl || '',
            action: status === 'completed' ? 'downloaded' : 'failed',
            platform: item.platform || 'default',
            createdAt: Date.now(),
          });
          if (status === 'completed') {
            try {
              // create media item record for library
              await insertMediaItem({
                downloadId: item.id,
                title: item.title,
                platform: item.platform,
                thumbnailPath: item.thumbnailUrl || '',
                filePath: item.filePath,
                duration: item.duration || 0,
                fileSize: item.fileSize || 0,
                format: item.format || '',
                quality: item.quality || '',
                mediaType: 'video',
                isFavorite: false,
              });
            } catch (e) {
              logger.error('[downloadStore] failed to insert media item:', e);
            }
          }
        }
      } catch (e) {
        logger.error('[downloadStore] Failed to insert history entry:', e);
      }
    }

    set((state) => {
      const item = [...state.activeDownloads, ...state.completedDownloads, ...state.failedDownloads].find((d) => d.id === id);
      if (!item) return state;

      const updatedItem = { ...item, status: status as any, errorMessage: error } as DownloadItem;
      let newActive = state.activeDownloads.filter((d) => d.id !== id);
      let newCompleted = state.completedDownloads;
      let newFailed = state.failedDownloads;

      if (status === 'completed') {
        newCompleted = [...newCompleted, updatedItem];
      } else if (status === 'failed' || status === 'cancelled') {
        newFailed = [...newFailed, updatedItem];
      } else {
        newActive = [...newActive, updatedItem];
      }

      return { activeDownloads: newActive, completedDownloads: newCompleted, failedDownloads: newFailed };
    });
  },

  pauseDownload: (id) => {
    set((state) => ({
      activeDownloads: state.activeDownloads.map((d) => (d.id === id ? { ...d, status: 'paused' } : d)),
    }));
  },

  resumeDownload: (id) => {
    set((state) => ({
      activeDownloads: state.activeDownloads.map((d) => (d.id === id ? { ...d, status: 'downloading' } : d)),
    }));
  },

  cancelDownload: async (id) => {
    await downloadRepo.deleteDownload(id);
    set((state) => ({
      activeDownloads: state.activeDownloads.filter((d) => d.id !== id),
    }));
  },

  clearCompleted: () => {
    set({ completedDownloads: [] });
  },

  loadFromDatabase: async () => {
    try {
      const downloads = await downloadRepo.getDownloads();
      const active = downloads.filter((d) => ['pending', 'analyzing', 'downloading', 'paused'].includes(d.status));
      const completed = downloads.filter((d) => d.status === 'completed');
      const failed = downloads.filter((d) => ['failed', 'cancelled'].includes(d.status));
      set({ activeDownloads: active, completedDownloads: completed, failedDownloads: failed });
    } catch (error) {
      logger.error('Error loading downloads:', error);
    }
  },
}));
