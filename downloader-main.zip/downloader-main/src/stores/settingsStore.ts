import { create } from 'zustand';
import { logger } from '../utils/logger';
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export type ThemeMode = 'light' | 'dark' | 'system';

interface SettingsStore {
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => Promise<void>;
  isHydrated: boolean;
  hydrate: () => Promise<void>;
}

const SETTINGS_KEY = '@medianest_settings';

export const useSettingsStore = create<SettingsStore>((set) => ({
  theme: 'dark',
  isHydrated: false,
  setTheme: async (theme: ThemeMode) => {
    set({ theme });
    try {
      const settings = JSON.parse(
        (await AsyncStorage.getItem(SETTINGS_KEY)) || '{}'
      );
      await AsyncStorage.setItem(
        SETTINGS_KEY,
        JSON.stringify({ ...settings, theme })
      );
    } catch (error) {
      logger.error('Failed to save theme preference:', error);
    }
  },
  hydrate: async () => {
    try {
      const settings = JSON.parse(
        (await AsyncStorage.getItem(SETTINGS_KEY)) || '{}'
      );
      set({
        theme: settings.theme || 'dark',
        isHydrated: true,
      });
    } catch (error) {
      logger.error('Failed to hydrate settings:', error);
      set({ isHydrated: true });
    }
  },
}));

export const useSettingsHydration = () => {
  const [isHydrated, setIsHydrated] = useState(false);
  const hydrate = useSettingsStore((state) => state.hydrate);

  useEffect(() => {
    hydrate().then(() => setIsHydrated(true));
  }, [hydrate]);

  return isHydrated;
};
