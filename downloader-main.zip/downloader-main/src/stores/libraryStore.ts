import { create } from 'zustand';
import { logger } from '../utils/logger';
import { MediaItem } from '../types';
import { executeSql } from '../db/database';

interface LibraryStore {
  allMedia: MediaItem[];
  filteredMedia: MediaItem[];
  activeTab: 'video' | 'audio' | 'image' | 'reel';
  viewMode: 'grid' | 'list';
  sortBy: 'date' | 'name' | 'size';
  searchQuery: string;
  isLoading: boolean;

  loadMedia: () => Promise<void>;
  setActiveTab: (tab: 'video' | 'audio' | 'image' | 'reel') => void;
  setViewMode: (mode: 'grid' | 'list') => void;
  setSortBy: (field: 'date' | 'name' | 'size') => void;
  setSearchQuery: (query: string) => void;
  toggleFavorite: (mediaId: string) => Promise<void>;
  deleteMedia: (mediaId: string) => Promise<void>;
}

export const useLibraryStore = create<LibraryStore>((set, get) => ({
  allMedia: [],
  filteredMedia: [],
  activeTab: 'video',
  viewMode: 'grid',
  sortBy: 'date',
  searchQuery: '',
  isLoading: false,

  loadMedia: async () => {
    set({ isLoading: true });
    try {
      const result = await executeSql('SELECT * FROM media_items ORDER BY created_at DESC');
      const media = (result.rows._array || []) as MediaItem[];
      set({ allMedia: media, filteredMedia: media, isLoading: false });
    } catch (error) {
      logger.error('Error loading media:', error);
      set({ isLoading: false });
    }
  },

  setActiveTab: (tab) => {
    set((state) => {
      let filtered = state.allMedia.filter((m) => {
        if (tab === 'video') return m.mediaType === 'video';
        if (tab === 'audio') return m.mediaType === 'audio';
        if (tab === 'image') return m.mediaType === 'image';
        return true;
      });

      if (state.searchQuery) {
        const q = state.searchQuery.toLowerCase();
        filtered = filtered.filter((m) => m.title.toLowerCase().includes(q));
      }

      return { activeTab: tab, filteredMedia: filtered };
    });
  },

  setViewMode: (mode) => set({ viewMode: mode }),

  setSortBy: (field) => {
    set((state) => {
      const sorted = [...state.filteredMedia].sort((a, b) => {
        if (field === 'date') return b.createdAt - a.createdAt;
        if (field === 'name') return a.title.localeCompare(b.title);
        if (field === 'size') return b.fileSize - a.fileSize;
        return 0;
      });
      return { sortBy: field, filteredMedia: sorted };
    });
  },

  setSearchQuery: (query) => {
    set((state) => {
      let filtered = state.allMedia;
      if (state.activeTab !== 'reel') {
        filtered = filtered.filter((m) => {
          if (state.activeTab === 'video') return m.mediaType === 'video';
          if (state.activeTab === 'audio') return m.mediaType === 'audio';
          if (state.activeTab === 'image') return m.mediaType === 'image';
          return true;
        });
      }

      if (query) {
        const q = query.toLowerCase();
        filtered = filtered.filter((m) => m.title.toLowerCase().includes(q));
      }

      return { searchQuery: query, filteredMedia: filtered };
    });
  },

  toggleFavorite: async (mediaId) => {
    try {
      await executeSql('UPDATE media_items SET is_favorite = 1 - is_favorite WHERE id = ?', [mediaId]);
      get().loadMedia();
    } catch (error) {
      logger.error('Error toggling favorite:', error);
    }
  },

  deleteMedia: async (mediaId) => {
    try {
      await executeSql('DELETE FROM media_items WHERE id = ?', [mediaId]);
      get().loadMedia();
    } catch (error) {
      logger.error('Error deleting media:', error);
    }
  },
}));

// Backwards-compatible named export used across codebase
export const libraryStore = useLibraryStore;
