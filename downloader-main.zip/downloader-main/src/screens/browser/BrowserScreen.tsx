import React, { useRef, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';
import { WebView } from 'react-native-webview';

export default function BrowserScreen() {
  const colors = useColors();
  const [url, setUrl] = useState('https://www.youtube.com');
  const [loading, setLoading] = useState(false);
  const webviewRef = useRef<any>(null);
    const [canGoBack, setCanGoBack] = useState(false);
    const [canGoForward, setCanGoForward] = useState(false);

  const go = (u?: string) => {
    const to = (u || url).trim();
    if (!to) return;
    let final = to;
    if (!/^https?:\/\//i.test(final)) final = 'https://' + final;
    setUrl(final);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ flex: 1 }}>
        <View style={{ padding: 12, flexDirection: 'row', alignItems: 'center', backgroundColor: colors.card, borderBottomWidth: 1, borderBottomColor: colors.divider }}>
          <MaterialCommunityIcons name="web" size={20} color={colors.textMuted} />
          <TextInput
            placeholder="Enter URL..."
            placeholderTextColor={colors.textMuted}
            value={url}
            onChangeText={setUrl}
            onSubmitEditing={() => go()}
            style={{ flex: 1, color: colors.textPrimary, paddingVertical: 8, marginLeft: 8 }}
            returnKeyType="go"
            autoCapitalize="none"
            autoCorrect={false}
          />
          <TouchableOpacity onPress={() => webviewRef.current?.goBack()} style={{ marginHorizontal: 6 }}>
            <MaterialCommunityIcons name="arrow-left" size={20} color={colors.textSecondary} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => webviewRef.current?.goForward()} style={{ marginHorizontal: 6 }}>
            <MaterialCommunityIcons name="arrow-right" size={20} color={colors.textSecondary} />
          </TouchableOpacity>
          <TouchableOpacity onPress={() => go()} style={{ marginLeft: 6 }}>
            <MaterialCommunityIcons name="refresh" size={20} color={colors.primary} />
          </TouchableOpacity>
        </View>

        <View style={{ flex: 1 }}>
          <WebView
              key={url}
              ref={webviewRef}
              source={{ uri: url }}
              onLoadStart={() => setLoading(true)}
              onLoadEnd={() => setLoading(false)}
              onNavigationStateChange={(navState) => {
                setCanGoBack(!!navState.canGoBack);
                setCanGoForward(!!navState.canGoForward);
              }}
              startInLoadingState
              style={{ backgroundColor: colors.background }}
              userAgent={'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1'}
              javaScriptEnabled={true}
              domStorageEnabled={true}
              originWhitelist={["*"]}
              mixedContentMode="always"
              allowsInlineMediaPlayback={true}
              mediaPlaybackRequiresUserAction={false}
              onError={(e) => {
                console.warn('Browser WebView error', e);
              }}
          />
          {loading && (
            <View style={{ position: 'absolute', top: 12, right: 12 }}>
              <ActivityIndicator color={colors.primary} />
            </View>
          )}
        </View>
      </View>
    </SafeAreaView>
  );
}
