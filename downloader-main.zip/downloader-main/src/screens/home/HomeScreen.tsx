import React, { useState } from 'react';
import { View, ScrollView, Text, TextInput, TouchableOpacity, ActivityIndicator, Alert, Clipboard } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';
import { SUPPORTED_PLATFORMS } from '../../constants';
import { mediaAnalysisService } from '../../services/mediaAnalysisService';

const QUICK_ACTIONS = [
  { icon: 'history', label: 'History', route: 'History' },
  { icon: 'heart-outline', label: 'Favorites', route: 'Favorites' },
  { icon: 'download-multiple', label: 'Batch', route: 'BatchDownload' },
  { icon: 'magnify', label: 'Search', route: 'Search' },
  { icon: 'web', label: 'Browser', route: 'BrowserTab' },
  { icon: 'download', label: 'Downloads', route: 'DownloadsTab' },
];

export default function HomeScreen({ navigation }: any) {
  const colors = useColors();
  const [url, setUrl] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleAnalyze = async () => {
    const trimmed = url.trim();
    if (!trimmed) {
      Alert.alert('Error', 'Please enter a URL');
      return;
    }
    setIsAnalyzing(true);
    try {
      const metadata = await mediaAnalysisService.analyzeUrl(trimmed);
      navigation.navigate('VideoAnalysis', { url: trimmed, analysis: metadata });
    } catch (error: any) {
      Alert.alert('Error', error.message || 'Failed to analyze video');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handlePaste = async () => {
    try {
      const text = await Clipboard.getString();
      if (text) setUrl(text.trim());
    } catch {
      // clipboard unavailable
    }
  };

  const handleQuickAction = (route: string) => {
    if (route === 'BrowserTab' || route === 'DownloadsTab') {
      navigation.navigate('MainTabs', { screen: route });
    } else {
      navigation.navigate(route as any);
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView style={{ flex: 1 }} contentContainerStyle={{ padding: 16 }} showsVerticalScrollIndicator={false}>

        {/* Header */}
        <View style={{ marginBottom: 24, marginTop: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <View>
            <Text style={{ fontSize: 28, fontWeight: '700', color: colors.textPrimary, letterSpacing: -0.5 }}>MediaNest</Text>
            <Text style={{ fontSize: 13, color: colors.textSecondary, marginTop: 2 }}>Download videos & audio offline</Text>
          </View>
          <TouchableOpacity
            onPress={() => navigation.navigate('MainTabs', { screen: 'SettingsTab' })}
            style={{ width: 38, height: 38, borderRadius: 19, backgroundColor: colors.card, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border }}
          >
            <MaterialCommunityIcons name="cog-outline" size={20} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>

        {/* URL Input */}
        <View style={{ backgroundColor: colors.card, borderRadius: 16, padding: 16, marginBottom: 20, borderWidth: 1, borderColor: colors.border }}>
          <Text style={{ fontSize: 14, fontWeight: '600', color: colors.textPrimary, marginBottom: 10 }}>Paste Video URL</Text>
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', backgroundColor: colors.surface, borderRadius: 10, paddingHorizontal: 10, borderWidth: 1, borderColor: colors.border }}>
              <MaterialCommunityIcons name="link" size={18} color={colors.textMuted} />
              <TextInput
                placeholder="YouTube, TikTok, Instagram..."
                placeholderTextColor={colors.textMuted}
                value={url}
                onChangeText={setUrl}
                editable={!isAnalyzing}
                autoCapitalize="none"
                autoCorrect={false}
                keyboardType="url"
                style={{ flex: 1, color: colors.textPrimary, paddingVertical: 10, paddingHorizontal: 8, fontSize: 13 }}
              />
              {url.length > 0 && (
                <TouchableOpacity onPress={() => setUrl('')}>
                  <MaterialCommunityIcons name="close-circle" size={18} color={colors.textMuted} />
                </TouchableOpacity>
              )}
            </View>
            <TouchableOpacity
              onPress={handlePaste}
              style={{ backgroundColor: colors.surface, width: 42, height: 42, borderRadius: 10, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border }}
            >
              <MaterialCommunityIcons name="content-paste" size={20} color={colors.textSecondary} />
            </TouchableOpacity>
            <TouchableOpacity
              disabled={isAnalyzing || !url.trim()}
              onPress={handleAnalyze}
              style={{ backgroundColor: colors.primary, width: 42, height: 42, borderRadius: 10, justifyContent: 'center', alignItems: 'center', opacity: isAnalyzing || !url.trim() ? 0.5 : 1 }}
            >
              {isAnalyzing
                ? <ActivityIndicator color="#fff" size="small" />
                : <MaterialCommunityIcons name="arrow-right" size={22} color="#fff" />
              }
            </TouchableOpacity>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={{ marginBottom: 24 }}>
          <Text style={{ fontSize: 14, fontWeight: '600', color: colors.textPrimary, marginBottom: 12 }}>Quick Actions</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 10 }}>
            {QUICK_ACTIONS.map((action) => (
              <TouchableOpacity
                key={action.route}
                onPress={() => handleQuickAction(action.route)}
                style={{ width: '31.5%', backgroundColor: colors.card, borderRadius: 12, paddingVertical: 14, alignItems: 'center', borderWidth: 1, borderColor: colors.border, gap: 6 }}
              >
                <MaterialCommunityIcons name={action.icon as any} size={24} color={colors.primary} />
                <Text style={{ fontSize: 11, color: colors.textSecondary, fontWeight: '500' }}>{action.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Supported Platforms */}
        <View style={{ marginBottom: 16 }}>
          <Text style={{ fontSize: 14, fontWeight: '600', color: colors.textPrimary, marginBottom: 12 }}>Supported Platforms</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8 }}>
            {SUPPORTED_PLATFORMS.map((platform) => (
              <View
                key={platform.id}
                style={{ width: '31.5%', backgroundColor: colors.card, borderRadius: 12, paddingVertical: 12, justifyContent: 'center', alignItems: 'center', borderWidth: 1, borderColor: colors.border, gap: 6 }}
              >
                <MaterialCommunityIcons name={platform.icon as any} size={26} color={platform.color} />
                <Text style={{ fontSize: 11, color: colors.textSecondary }}>{platform.name}</Text>
              </View>
            ))}
          </View>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
}
