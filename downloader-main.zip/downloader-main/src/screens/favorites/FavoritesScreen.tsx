import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Alert,
  Animated,
  Dimensions,
  FlatList,
  Image,
  Modal,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';
import { getFavorites, removeFavorite } from '../../db/repositories/favoritesRepository';
import { getPlaylists } from '../../db/repositories/playlistRepository';
import { MediaItem, PlaylistItem } from '../../types';

// ─── Constants ────────────────────────────────────────────────────────────────

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const GRID_COLUMNS = 2;
const GRID_ITEM_MARGIN = 6;
const GRID_PADDING = 16;
const GRID_ITEM_WIDTH =
  (SCREEN_WIDTH - GRID_PADDING * 2 - GRID_ITEM_MARGIN * (GRID_COLUMNS - 1)) / GRID_COLUMNS;
const THUMBNAIL_ASPECT = 16 / 9;

type TabKey = 'all' | 'videos' | 'audio' | 'collections';
type ViewMode = 'grid' | 'list';
type SortOption = 'date' | 'name' | 'platform' | 'duration';

interface Tab {
  key: TabKey;
  label: string;
  icon: string;
}

const TABS: Tab[] = [
  { key: 'all', label: 'All', icon: 'heart' },
  { key: 'videos', label: 'Videos', icon: 'play-circle' },
  { key: 'audio', label: 'Audio', icon: 'music' },
  { key: 'collections', label: 'Collections', icon: 'folder-heart' },
];

const SORT_OPTIONS: { key: SortOption; label: string; icon: string }[] = [
  { key: 'date', label: 'Date Added', icon: 'calendar' },
  { key: 'name', label: 'Name', icon: 'sort-alphabetical-ascending' },
  { key: 'platform', label: 'Platform', icon: 'web' },
  { key: 'duration', label: 'Duration', icon: 'timer' },
];

const PLATFORM_ICONS: Record<string, { icon: string; color: string }> = {
  youtube: { icon: 'youtube', color: '#FF0000' },
  instagram: { icon: 'instagram', color: '#E1306C' },
  tiktok: { icon: 'music-note', color: '#69C9D0' },
  twitter: { icon: 'twitter', color: '#1DA1F2' },
  facebook: { icon: 'facebook', color: '#1877F2' },
  reddit: { icon: 'reddit', color: '#FF4500' },
  vimeo: { icon: 'vimeo', color: '#1AB7EA' },
  twitch: { icon: 'twitch', color: '#9146FF' },
  default: { icon: 'web', color: '#7C4DFF' },
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

function formatDuration(seconds: number): string {
  if (!seconds || seconds <= 0) return '0:00';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) {
    return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }
  return `${m}:${String(s).padStart(2, '0')}`;
}

function getPlatformMeta(platform: string): { icon: string; color: string } {
  const key = (platform || '').toLowerCase();
  return PLATFORM_ICONS[key] ?? PLATFORM_ICONS.default;
}

function formatFileSize(bytes: number): string {
  if (!bytes || bytes <= 0) return '';
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

// ─── Thumbnail ────────────────────────────────────────────────────────────────

interface ThumbnailProps {
  path: string;
  width: number;
  height: number;
  isVideo: boolean;
  colors: ReturnType<typeof useColors>;
}

function Thumbnail({ path, width, height, isVideo, colors }: ThumbnailProps) {
  const [hasError, setHasError] = useState(false);
  const uri =
    path && !hasError
      ? path.startsWith('file://') || path.startsWith('http')
        ? path
        : `file://${path}`
      : null;

  return (
    <View style={{ width, height, backgroundColor: colors.card, overflow: 'hidden' }}>
      {uri ? (
        <Image
          source={{ uri }}
          style={{ width, height }}
          resizeMode="cover"
          onError={() => setHasError(true)}
        />
      ) : (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <MaterialCommunityIcons
            name={isVideo ? 'video-outline' : 'music-circle-outline'}
            size={30}
            color={colors.textMuted}
          />
        </View>
      )}
    </View>
  );
}

// ─── Grid Item ────────────────────────────────────────────────────────────────

interface GridItemProps {
  item: MediaItem;
  selected: boolean;
  isMultiSelect: boolean;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
  onLongPress: () => void;
  onRemove: () => void;
}

function GridItem({
  item,
  selected,
  isMultiSelect,
  colors,
  onPress,
  onLongPress,
  onRemove,
}: GridItemProps) {
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const isVideo = item.mediaType === 'video' || item.mediaType === 'reel';
  const platformMeta = getPlatformMeta(item.platform);
  const thumbnailHeight = Math.round(GRID_ITEM_WIDTH / THUMBNAIL_ASPECT);

  const handlePressIn = () =>
    Animated.spring(scaleAnim, { toValue: 0.96, useNativeDriver: true }).start();
  const handlePressOut = () =>
    Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true }).start();

  return (
    <Animated.View style={{ transform: [{ scale: scaleAnim }] }}>
      <TouchableOpacity
        activeOpacity={0.9}
        onPress={onPress}
        onLongPress={onLongPress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        style={[
          styles.gridCard,
          {
            backgroundColor: colors.card,
            borderColor: selected ? colors.primary : colors.divider,
            borderWidth: selected ? 2 : 1,
            width: GRID_ITEM_WIDTH,
          },
        ]}
      >
        {/* Thumbnail area */}
        <View style={{ position: 'relative' }}>
          <Thumbnail
            path={item.thumbnailPath}
            width={GRID_ITEM_WIDTH - (selected ? 4 : 2)}
            height={thumbnailHeight}
            isVideo={isVideo}
            colors={colors}
          />

          {/* Semi-transparent play overlay */}
          <View
            style={[styles.playOverlay, { backgroundColor: 'rgba(0,0,0,0.25)' }]}
            pointerEvents="none"
          >
            <View style={[styles.playCircle, { backgroundColor: 'rgba(124,77,255,0.82)' }]}>
              <MaterialCommunityIcons
                name={isVideo ? 'play' : 'music-note'}
                size={15}
                color="#FFFFFF"
              />
            </View>
          </View>

          {/* Duration badge — bottom right */}
          {item.duration > 0 && (
            <View style={[styles.durationBadge, { backgroundColor: 'rgba(0,0,0,0.72)' }]}>
              <Text style={styles.durationText}>{formatDuration(item.duration)}</Text>
            </View>
          )}

          {/* Platform icon — bottom left */}
          <View style={[styles.platformBadge, { backgroundColor: 'rgba(0,0,0,0.65)' }]}>
            <MaterialCommunityIcons
              name={platformMeta.icon}
              size={11}
              color={platformMeta.color}
            />
          </View>

          {/* Multi-select checkbox — top left */}
          {isMultiSelect && (
            <View style={styles.checkboxOverlay}>
              <View
                style={[
                  styles.checkbox,
                  {
                    backgroundColor: selected ? colors.primary : 'rgba(0,0,0,0.45)',
                    borderColor: selected ? colors.primary : '#FFFFFF',
                  },
                ]}
              >
                {selected && (
                  <MaterialCommunityIcons name="check" size={11} color="#FFFFFF" />
                )}
              </View>
            </View>
          )}
        </View>

        {/* Info */}
        <View style={styles.gridInfo}>
          <Text style={[styles.gridTitle, { color: colors.textPrimary }]} numberOfLines={2}>
            {item.title}
          </Text>
          <View style={styles.gridMeta}>
            <Text
              style={[styles.gridPlatform, { color: colors.textSecondary }]}
              numberOfLines={1}
            >
              {item.platform}
            </Text>
            {!isMultiSelect && (
              <TouchableOpacity
                onPress={onRemove}
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              >
                <MaterialCommunityIcons name="heart" size={18} color="#FF5252" />
              </TouchableOpacity>
            )}
          </View>
        </View>
      </TouchableOpacity>
    </Animated.View>
  );
}

// ─── List Item ────────────────────────────────────────────────────────────────

interface ListItemProps {
  item: MediaItem;
  selected: boolean;
  isMultiSelect: boolean;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
  onLongPress: () => void;
  onRemove: () => void;
}

function ListItem({
  item,
  selected,
  isMultiSelect,
  colors,
  onPress,
  onLongPress,
  onRemove,
}: ListItemProps) {
  const isVideo = item.mediaType === 'video' || item.mediaType === 'reel';
  const platformMeta = getPlatformMeta(item.platform);
  const THUMB_W = 100;
  const THUMB_H = Math.round(THUMB_W / THUMBNAIL_ASPECT);
  const sizeStr = formatFileSize(item.fileSize);

  return (
    <TouchableOpacity
      activeOpacity={0.85}
      onPress={onPress}
      onLongPress={onLongPress}
      style={[
        styles.listCard,
        {
          backgroundColor: colors.card,
          borderColor: selected ? colors.primary : colors.divider,
          borderWidth: selected ? 2 : 1,
        },
      ]}
    >
      {/* Checkbox */}
      {isMultiSelect && (
        <View style={{ paddingLeft: 10 }}>
          <View
            style={[
              styles.checkbox,
              {
                backgroundColor: selected ? colors.primary : 'transparent',
                borderColor: selected ? colors.primary : colors.textSecondary,
              },
            ]}
          >
            {selected && <MaterialCommunityIcons name="check" size={11} color="#FFFFFF" />}
          </View>
        </View>
      )}

      {/* Thumbnail */}
      <View style={{ position: 'relative' }}>
        <Thumbnail
          path={item.thumbnailPath}
          width={THUMB_W}
          height={THUMB_H}
          isVideo={isVideo}
          colors={colors}
        />
        {item.duration > 0 && (
          <View style={[styles.durationBadge, { backgroundColor: 'rgba(0,0,0,0.72)' }]}>
            <Text style={styles.durationText}>{formatDuration(item.duration)}</Text>
          </View>
        )}
      </View>

      {/* Content */}
      <View style={styles.listItemContent}>
        <Text style={[styles.listTitle, { color: colors.textPrimary }]} numberOfLines={2}>
          {item.title}
        </Text>
        <View style={styles.listSubRow}>
          <MaterialCommunityIcons
            name={platformMeta.icon}
            size={12}
            color={platformMeta.color}
          />
          <Text style={[styles.listSub, { color: colors.textSecondary }]}>
            {'  '}{item.platform}
          </Text>
          {sizeStr ? (
            <Text style={[styles.listSub, { color: colors.textMuted }]}>
              {'  ·  '}{sizeStr}
            </Text>
          ) : null}
        </View>
        {(item.quality || item.format) ? (
          <Text style={[styles.listQuality, { color: colors.primary }]}>
            {[item.quality, item.format?.toUpperCase()].filter(Boolean).join(' · ')}
          </Text>
        ) : null}
      </View>

      {/* Remove button */}
      {!isMultiSelect && (
        <TouchableOpacity
          onPress={onRemove}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
          style={{ paddingHorizontal: 14, alignSelf: 'center' }}
        >
          <MaterialCommunityIcons name="heart" size={22} color="#FF5252" />
        </TouchableOpacity>
      )}
    </TouchableOpacity>
  );
}

// ─── Collection Card ──────────────────────────────────────────────────────────

interface CollectionCardProps {
  playlist: PlaylistItem;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
}

function CollectionCard({ playlist, colors, onPress }: CollectionCardProps) {
  const cardWidth = (SCREEN_WIDTH - GRID_PADDING * 2 - GRID_ITEM_MARGIN) / 2;
  const coverHeight = Math.round(cardWidth * 0.65);

  return (
    <TouchableOpacity
      activeOpacity={0.85}
      onPress={onPress}
      style={[
        styles.collectionCard,
        {
          backgroundColor: colors.card,
          borderColor: colors.divider,
          width: cardWidth,
        },
      ]}
    >
      <View
        style={[styles.collectionCover, { backgroundColor: colors.surface, height: coverHeight }]}
      >
        {playlist.coverPath ? (
          <Image
            source={{ uri: `file://${playlist.coverPath}` }}
            style={StyleSheet.absoluteFillObject}
            resizeMode="cover"
          />
        ) : (
          <MaterialCommunityIcons name="folder-play" size={38} color={colors.primary} />
        )}
        <View style={[styles.countBadge, { backgroundColor: colors.primary }]}>
          <Text style={styles.countText}>{playlist.itemCount}</Text>
        </View>
      </View>

      <View style={styles.collectionInfo}>
        <Text style={[styles.collectionName, { color: colors.textPrimary }]} numberOfLines={1}>
          {playlist.name}
        </Text>
        <Text style={[styles.collectionDesc, { color: colors.textSecondary }]} numberOfLines={1}>
          {playlist.description ||
            `${playlist.itemCount} ${playlist.itemCount === 1 ? 'item' : 'items'}`}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

// ─── Empty State ──────────────────────────────────────────────────────────────

const EMPTY_STATE_CONFIG: Record<TabKey, { icon: string; title: string; message: string }> = {
  all: {
    icon: 'heart-outline',
    title: 'No Favorites Yet',
    message:
      'Start adding your favorite videos and audio tracks — they will appear here for quick access.',
  },
  videos: {
    icon: 'video-outline',
    title: 'No Favorite Videos',
    message: 'Tap the heart icon on any video to save it to your favorites.',
  },
  audio: {
    icon: 'music-circle-outline',
    title: 'No Favorite Audio',
    message: 'Save your favorite music and podcasts to access them instantly.',
  },
  collections: {
    icon: 'folder-heart-outline',
    title: 'No Collections Yet',
    message: 'Create playlists to organize your favorite content into themed collections.',
  },
};

interface EmptyStateProps {
  tab: TabKey;
  colors: ReturnType<typeof useColors>;
  onBrowse: () => void;
}

function EmptyState({ tab, colors, onBrowse }: EmptyStateProps) {
  const cfg = EMPTY_STATE_CONFIG[tab];
  return (
    <View style={styles.emptyContainer}>
      <View style={[styles.emptyIconBg, { backgroundColor: `${colors.primary}18` }]}>
        <MaterialCommunityIcons name={cfg.icon} size={52} color={colors.primary} />
      </View>
      <Text style={[styles.emptyTitle, { color: colors.textPrimary }]}>{cfg.title}</Text>
      <Text style={[styles.emptyMessage, { color: colors.textSecondary }]}>{cfg.message}</Text>
      <TouchableOpacity
        onPress={onBrowse}
        activeOpacity={0.85}
        style={[styles.browseBtn, { backgroundColor: colors.primary }]}
      >
        <MaterialCommunityIcons name="library-shelves" size={17} color="#FFFFFF" />
        <Text style={styles.browseBtnText}>Browse Library</Text>
      </TouchableOpacity>
    </View>
  );
}

// ─── Sort Modal ───────────────────────────────────────────────────────────────

interface SortModalProps {
  visible: boolean;
  currentSort: SortOption;
  colors: ReturnType<typeof useColors>;
  onSelect: (sort: SortOption) => void;
  onClose: () => void;
}

function SortModal({ visible, currentSort, colors, onSelect, onClose }: SortModalProps) {
  return (
    <Modal
      transparent
      visible={visible}
      animationType="fade"
      statusBarTranslucent
      onRequestClose={onClose}
    >
      <TouchableOpacity style={styles.modalBackdrop} activeOpacity={1} onPress={onClose}>
        <View
          style={[
            styles.sortSheet,
            { backgroundColor: colors.surface, borderColor: colors.divider },
          ]}
        >
          <View style={[styles.sortHandle, { backgroundColor: colors.divider }]} />
          <Text style={[styles.sortTitle, { color: colors.textPrimary }]}>Sort By</Text>
          {SORT_OPTIONS.map((opt) => {
            const active = currentSort === opt.key;
            return (
              <TouchableOpacity
                key={opt.key}
                onPress={() => onSelect(opt.key)}
                style={[
                  styles.sortOption,
                  { backgroundColor: active ? `${colors.primary}22` : 'transparent' },
                ]}
              >
                <MaterialCommunityIcons
                  name={opt.icon}
                  size={20}
                  color={active ? colors.primary : colors.textSecondary}
                />
                <Text
                  style={[
                    styles.sortOptionText,
                    {
                      color: active ? colors.primary : colors.textPrimary,
                      fontWeight: active ? '700' : '400',
                      flex: 1,
                    },
                  ]}
                >
                  {opt.label}
                </Text>
                {active && (
                  <MaterialCommunityIcons name="check" size={18} color={colors.primary} />
                )}
              </TouchableOpacity>
            );
          })}
        </View>
      </TouchableOpacity>
    </Modal>
  );
}

// ─── Multi-select Toolbar ─────────────────────────────────────────────────────

interface MultiSelectToolbarProps {
  selectedCount: number;
  totalCount: number;
  colors: ReturnType<typeof useColors>;
  onSelectAll: () => void;
  onDeleteSelected: () => void;
  onAddToPlaylist: () => void;
  onCancel: () => void;
}

function MultiSelectToolbar({
  selectedCount,
  totalCount,
  colors,
  onSelectAll,
  onDeleteSelected,
  onAddToPlaylist,
  onCancel,
}: MultiSelectToolbarProps) {
  const allSelected = totalCount > 0 && selectedCount === totalCount;

  return (
    <View
      style={[
        styles.multiToolbar,
        { backgroundColor: colors.surface, borderTopColor: colors.divider },
      ]}
    >
      {/* Left side */}
      <View style={styles.multiLeft}>
        <TouchableOpacity onPress={onCancel} style={{ padding: 4 }}>
          <MaterialCommunityIcons name="close" size={22} color={colors.textSecondary} />
        </TouchableOpacity>
        <Text style={[styles.multiCount, { color: colors.textPrimary }]}>
          {selectedCount} selected
        </Text>
      </View>

      {/* Right side: action buttons */}
      <View style={styles.multiActions}>
        <TouchableOpacity
          onPress={onSelectAll}
          style={[
            styles.multiActionBtn,
            { borderColor: allSelected ? colors.primary : colors.divider },
          ]}
        >
          <MaterialCommunityIcons
            name={allSelected ? 'checkbox-multiple-marked' : 'checkbox-multiple-blank-outline'}
            size={17}
            color={allSelected ? colors.primary : colors.textSecondary}
          />
          <Text
            style={[
              styles.multiActionText,
              { color: allSelected ? colors.primary : colors.textSecondary },
            ]}
          >
            All
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={onAddToPlaylist}
          disabled={selectedCount === 0}
          style={[
            styles.multiActionBtn,
            {
              borderColor: selectedCount > 0 ? colors.secondary : colors.divider,
              opacity: selectedCount === 0 ? 0.4 : 1,
            },
          ]}
        >
          <MaterialCommunityIcons
            name="playlist-plus"
            size={17}
            color={selectedCount > 0 ? colors.secondary : colors.textSecondary}
          />
          <Text
            style={[
              styles.multiActionText,
              { color: selectedCount > 0 ? colors.secondary : colors.textSecondary },
            ]}
          >
            Playlist
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={onDeleteSelected}
          disabled={selectedCount === 0}
          style={[
            styles.multiActionBtn,
            {
              borderColor: selectedCount > 0 ? '#FF5252' : colors.divider,
              opacity: selectedCount === 0 ? 0.4 : 1,
            },
          ]}
        >
          <MaterialCommunityIcons
            name="heart-remove"
            size={17}
            color={selectedCount > 0 ? '#FF5252' : colors.textSecondary}
          />
          <Text
            style={[
              styles.multiActionText,
              { color: selectedCount > 0 ? '#FF5252' : colors.textSecondary },
            ]}
          >
            Remove
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

interface FavoritesScreenProps {
  navigation?: any;
}

export default function FavoritesScreen({ navigation }: FavoritesScreenProps) {
  const colors = useColors();

  // Data
  const [favorites, setFavorites] = useState<MediaItem[]>([]);
  const [playlists, setPlaylists] = useState<PlaylistItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // UI
  const [activeTab, setActiveTab] = useState<TabKey>('all');
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [sortBy, setSortBy] = useState<SortOption>('date');
  const [showSortModal, setShowSortModal] = useState(false);

  // Multi-select
  const [isMultiSelect, setIsMultiSelect] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // ── Data loading ───────────────────────────────────────────────────────────

  const loadData = useCallback(async (isRefresh = false) => {
    try {
      if (isRefresh) setRefreshing(true);
      else setLoading(true);

      const [favData, playlistData] = await Promise.all([
        getFavorites(),
        getPlaylists().catch(() => [] as PlaylistItem[]),
      ]);

      setFavorites(favData);
      setPlaylists(playlistData);
    } catch (error) {
      console.error('[FavoritesScreen] loadData error:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // ── Derived data ───────────────────────────────────────────────────────────

  const filteredItems = useMemo<MediaItem[]>(() => {
    let items = [...favorites];

    if (activeTab === 'videos') {
      items = items.filter((i) => i.mediaType === 'video' || i.mediaType === 'reel');
    } else if (activeTab === 'audio') {
      items = items.filter((i) => i.mediaType === 'audio');
    }

    items.sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return (a.title ?? '').localeCompare(b.title ?? '');
        case 'platform':
          return (a.platform ?? '').localeCompare(b.platform ?? '');
        case 'duration':
          return (b.duration ?? 0) - (a.duration ?? 0);
        case 'date':
        default:
          return (b.createdAt ?? 0) - (a.createdAt ?? 0);
      }
    });

    return items;
  }, [favorites, activeTab, sortBy]);

  // ── Event handlers ─────────────────────────────────────────────────────────

  const handleTabPress = (key: TabKey) => {
    setActiveTab(key);
    setIsMultiSelect(false);
    setSelectedIds(new Set());
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleItemPress = (item: MediaItem) => {
    if (isMultiSelect) {
      toggleSelect(item.id);
      return;
    }
    const isVideo = item.mediaType === 'video' || item.mediaType === 'reel';
    if (isVideo) {
      navigation?.navigate?.('VideoPlayer', { mediaId: item.id });
    } else {
      navigation?.navigate?.('AudioPlayer', { mediaId: item.id });
    }
  };

  const handleLongPress = (item: MediaItem) => {
    if (!isMultiSelect) {
      setIsMultiSelect(true);
      setSelectedIds(new Set([item.id]));
    }
  };

  const handleSelectAll = () => {
    if (selectedIds.size === filteredItems.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredItems.map((i) => i.id)));
    }
  };

  const handleCancelMultiSelect = () => {
    setIsMultiSelect(false);
    setSelectedIds(new Set());
  };

  const handleRemoveSingle = (item: MediaItem) => {
    Alert.alert(
      'Remove from Favorites',
      `Remove "${item.title}" from favorites?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              await removeFavorite(item.id);
              setFavorites((prev) => prev.filter((f) => f.id !== item.id));
            } catch (err) {
              console.error('[FavoritesScreen] removeFavorite error:', err);
            }
          },
        },
      ]
    );
  };

  const handleDeleteSelected = () => {
    if (selectedIds.size === 0) return;
    const count = selectedIds.size;
    Alert.alert(
      'Remove from Favorites',
      `Remove ${count} item${count > 1 ? 's' : ''} from favorites?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              await Promise.all(Array.from(selectedIds).map((id) => removeFavorite(id)));
              const removed = new Set(selectedIds);
              setFavorites((prev) => prev.filter((f) => !removed.has(f.id)));
              setIsMultiSelect(false);
              setSelectedIds(new Set());
            } catch (err) {
              console.error('[FavoritesScreen] batch remove error:', err);
            }
          },
        },
      ]
    );
  };

  const handleAddToPlaylist = () => {
    if (selectedIds.size === 0) return;
    navigation?.navigate?.('AddToPlaylist', { mediaIds: Array.from(selectedIds) });
  };

  const handleBrowseLibrary = () => {
    navigation?.navigate?.('Library');
  };

  // ── Render helpers ─────────────────────────────────────────────────────────

  const renderGridItem = useCallback(
    ({ item }: { item: MediaItem }) => (
      <GridItem
        item={item}
        selected={selectedIds.has(item.id)}
        isMultiSelect={isMultiSelect}
        colors={colors}
        onPress={() => handleItemPress(item)}
        onLongPress={() => handleLongPress(item)}
        onRemove={() => handleRemoveSingle(item)}
      />
    ),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [selectedIds, isMultiSelect, colors],
  );

  const renderListItem = useCallback(
    ({ item }: { item: MediaItem }) => (
      <ListItem
        item={item}
        selected={selectedIds.has(item.id)}
        isMultiSelect={isMultiSelect}
        colors={colors}
        onPress={() => handleItemPress(item)}
        onLongPress={() => handleLongPress(item)}
        onRemove={() => handleRemoveSingle(item)}
      />
    ),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [selectedIds, isMultiSelect, colors],
  );

  const renderCollectionItem = useCallback(
    ({ item }: { item: PlaylistItem }) => (
      <CollectionCard
        playlist={item}
        colors={colors}
        onPress={() => navigation?.navigate?.('PlaylistDetail', { playlistId: item.id })}
      />
    ),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [colors],
  );

  const keyExtractor = useCallback((item: MediaItem | PlaylistItem) => item.id, []);

  // ── Derived booleans ───────────────────────────────────────────────────────

  const isCollectionsTab = activeTab === 'collections';
  const showEmpty =
    !loading && (isCollectionsTab ? playlists.length === 0 : filteredItems.length === 0);

  // ── Render ─────────────────────────────────────────────────────────────────

  return (
    <SafeAreaView
      style={[styles.safeArea, { backgroundColor: colors.background }]}
      edges={['top']}
    >
      <StatusBar barStyle="light-content" backgroundColor={colors.background} />

      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.divider }]}>
        <Text style={[styles.headerTitle, { color: colors.textPrimary }]}>Favorites</Text>
        <View style={styles.headerActions}>
          {!isCollectionsTab && (
            <TouchableOpacity
              onPress={() => setViewMode((v) => (v === 'grid' ? 'list' : 'grid'))}
              style={[styles.headerIconBtn, { backgroundColor: colors.card }]}
            >
              <MaterialCommunityIcons
                name={viewMode === 'grid' ? 'view-list' : 'view-grid'}
                size={20}
                color={colors.primary}
              />
            </TouchableOpacity>
          )}
          <TouchableOpacity
            onPress={() => setShowSortModal(true)}
            style={[styles.headerIconBtn, { backgroundColor: colors.card }]}
          >
            <MaterialCommunityIcons name="sort-variant" size={20} color={colors.primary} />
          </TouchableOpacity>
        </View>
      </View>

      {/* Tab bar */}
      <View
        style={[styles.tabBar, { backgroundColor: colors.surface, borderBottomColor: colors.divider }]}
      >
        {TABS.map((tab) => {
          const active = activeTab === tab.key;
          return (
            <TouchableOpacity
              key={tab.key}
              onPress={() => handleTabPress(tab.key)}
              style={[
                styles.tabItem,
                active && { borderBottomColor: colors.primary, borderBottomWidth: 2 },
              ]}
            >
              <MaterialCommunityIcons
                name={tab.icon as any}
                size={15}
                color={active ? colors.primary : colors.textSecondary}
              />
              <Text
                style={[
                  styles.tabLabel,
                  {
                    color: active ? colors.primary : colors.textSecondary,
                    fontWeight: active ? '700' : '500',
                  },
                ]}
              >
                {tab.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {/* Content */}
      {loading ? (
        <View style={styles.loadingContainer}>
          <MaterialCommunityIcons name="heart-pulse" size={40} color={colors.primary} />
          <Text style={[styles.loadingText, { color: colors.textSecondary }]}>
            Loading favorites…
          </Text>
        </View>
      ) : showEmpty ? (
        <EmptyState tab={activeTab} colors={colors} onBrowse={handleBrowseLibrary} />
      ) : isCollectionsTab ? (
        <FlatList<PlaylistItem>
          data={playlists}
          keyExtractor={(item) => item.id}
          renderItem={renderCollectionItem}
          numColumns={2}
          columnWrapperStyle={styles.collectionColumnWrapper}
          contentContainerStyle={styles.gridContent}
          showsVerticalScrollIndicator={false}
          onRefresh={() => loadData(true)}
          refreshing={refreshing}
        />
      ) : viewMode === 'grid' ? (
        <FlatList<MediaItem>
          data={filteredItems}
          keyExtractor={keyExtractor}
          renderItem={renderGridItem}
          numColumns={GRID_COLUMNS}
          columnWrapperStyle={styles.gridColumnWrapper}
          contentContainerStyle={styles.gridContent}
          showsVerticalScrollIndicator={false}
          onRefresh={() => loadData(true)}
          refreshing={refreshing}
          removeClippedSubviews
          maxToRenderPerBatch={8}
          windowSize={10}
          initialNumToRender={6}
        />
      ) : (
        <FlatList<MediaItem>
          data={filteredItems}
          keyExtractor={keyExtractor}
          renderItem={renderListItem}
          contentContainerStyle={styles.listContentContainer}
          showsVerticalScrollIndicator={false}
          onRefresh={() => loadData(true)}
          refreshing={refreshing}
          removeClippedSubviews
          maxToRenderPerBatch={10}
          windowSize={12}
          initialNumToRender={8}
        />
      )}

      {/* Multi-select toolbar */}
      {isMultiSelect && (
        <MultiSelectToolbar
          selectedCount={selectedIds.size}
          totalCount={filteredItems.length}
          colors={colors}
          onSelectAll={handleSelectAll}
          onDeleteSelected={handleDeleteSelected}
          onAddToPlaylist={handleAddToPlaylist}
          onCancel={handleCancelMultiSelect}
        />
      )}

      {/* Sort modal */}
      <SortModal
        visible={showSortModal}
        currentSort={sortBy}
        colors={colors}
        onSelect={(sort) => {
          setSortBy(sort);
          setShowSortModal(false);
        }}
        onClose={() => setShowSortModal(false)}
      />
    </SafeAreaView>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safeArea: { flex: 1 },

  // Header
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
  },
  headerTitle: {
    fontSize: 26,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
  },
  headerIconBtn: {
    width: 38,
    height: 38,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // Tab bar
  tabBar: {
    flexDirection: 'row',
    borderBottomWidth: 1,
  },
  tabItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    gap: 5,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabLabel: {
    fontSize: 13,
  },

  // Grid layout
  gridContent: {
    padding: GRID_PADDING,
    paddingTop: 12,
  },
  gridColumnWrapper: {
    gap: GRID_ITEM_MARGIN,
    marginBottom: GRID_ITEM_MARGIN,
    justifyContent: 'space-between',
  },

  // Grid card
  gridCard: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  gridInfo: {
    padding: 9,
    paddingBottom: 8,
  },
  gridTitle: {
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 18,
    marginBottom: 5,
  },
  gridMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  gridPlatform: {
    fontSize: 11,
    fontWeight: '500',
    textTransform: 'capitalize',
    flex: 1,
    marginRight: 4,
  },

  // Thumbnail overlays
  playOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
  },
  playCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    paddingLeft: 2,
  },
  durationBadge: {
    position: 'absolute',
    bottom: 5,
    right: 5,
    borderRadius: 4,
    paddingHorizontal: 5,
    paddingVertical: 2,
  },
  durationText: {
    fontSize: 10,
    color: '#FFFFFF',
    fontWeight: '700',
  },
  platformBadge: {
    position: 'absolute',
    bottom: 5,
    left: 5,
    borderRadius: 4,
    padding: 3,
  },
  checkboxOverlay: {
    position: 'absolute',
    top: 6,
    left: 6,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
  },

  // List layout
  listContentContainer: {
    padding: 12,
    paddingTop: 8,
  },
  listCard: {
    flexDirection: 'row',
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 8,
    alignItems: 'center',
  },
  listItemContent: {
    flex: 1,
    paddingHorizontal: 12,
    paddingVertical: 9,
    justifyContent: 'center',
  },
  listTitle: {
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
    marginBottom: 4,
  },
  listSubRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 3,
    flexWrap: 'wrap',
  },
  listSub: {
    fontSize: 12,
  },
  listQuality: {
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.4,
  },

  // Collections
  collectionColumnWrapper: {
    gap: GRID_ITEM_MARGIN,
    marginBottom: GRID_ITEM_MARGIN,
    justifyContent: 'space-between',
  },
  collectionCard: {
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
  },
  collectionCover: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
    overflow: 'hidden',
  },
  countBadge: {
    position: 'absolute',
    bottom: 6,
    right: 6,
    borderRadius: 10,
    paddingHorizontal: 7,
    paddingVertical: 2,
  },
  countText: {
    fontSize: 11,
    color: '#FFFFFF',
    fontWeight: '700',
  },
  collectionInfo: {
    padding: 10,
  },
  collectionName: {
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 2,
  },
  collectionDesc: {
    fontSize: 12,
  },

  // Empty state
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 32,
  },
  emptyIconBg: {
    width: 96,
    height: 96,
    borderRadius: 48,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 10,
    textAlign: 'center',
  },
  emptyMessage: {
    fontSize: 14,
    lineHeight: 21,
    textAlign: 'center',
    marginBottom: 28,
    maxWidth: 280,
  },
  browseBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 24,
  },
  browseBtnText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },

  // Loading
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 14,
  },
  loadingText: {
    fontSize: 15,
    fontWeight: '500',
  },

  // Multi-select toolbar
  multiToolbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderTopWidth: 1,
  },
  multiLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  multiCount: {
    fontSize: 15,
    fontWeight: '600',
  },
  multiActions: {
    flexDirection: 'row',
    gap: 8,
  },
  multiActionBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
  },
  multiActionText: {
    fontSize: 12,
    fontWeight: '600',
  },

  // Sort modal
  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'flex-end',
  },
  sortSheet: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    paddingBottom: 36,
    borderWidth: 1,
    borderBottomWidth: 0,
  },
  sortHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    alignSelf: 'center',
    marginBottom: 14,
  },
  sortTitle: {
    fontSize: 17,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 12,
  },
  sortOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 13,
    paddingHorizontal: 12,
    borderRadius: 10,
    marginBottom: 2,
  },
  sortOptionText: {
    fontSize: 15,
  },
});
