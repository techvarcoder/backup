import React, { useEffect, useState, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Image,
  StyleSheet,
  Modal,
  Pressable,
  TextInput,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';
import { logger } from '../../utils/logger';
import { HistoryEntry } from '../../types/index';
import {
  getHistory,
  clearHistory,
  deleteHistoryEntry,
} from '../../db/repositories/historyRepository';
import { getDownloads } from '../../db/repositories/downloadRepository';

// ─── Types ────────────────────────────────────────────────────────────────────

type TabKey = 'download' | 'playback' | 'link';

type SectionItem =
  | { type: 'section'; label: string }
  | { type: 'entry'; data: HistoryEntry };

// ─── Constants ────────────────────────────────────────────────────────────────

const TABS: { key: TabKey; label: string }[] = [
  { key: 'download', label: 'Download History' },
  { key: 'playback', label: 'Playback History' },
  { key: 'link', label: 'Link History' },
];

const PLATFORM_ICONS: Record<string, { icon: string; color: string }> = {
  youtube:    { icon: 'youtube',          color: '#FF0000' },
  instagram:  { icon: 'instagram',        color: '#E1306C' },
  twitter:    { icon: 'twitter',          color: '#1DA1F2' },
  x:          { icon: 'twitter',          color: '#1DA1F2' },
  tiktok:     { icon: 'music-note',       color: '#010101' },
  facebook:   { icon: 'facebook',         color: '#1877F2' },
  reddit:     { icon: 'reddit',           color: '#FF4500' },
  vimeo:      { icon: 'vimeo',            color: '#1AB7EA' },
  twitch:     { icon: 'twitch',           color: '#9146FF' },
  dailymotion:{ icon: 'play-circle',      color: '#0055FF' },
  default:    { icon: 'web',              color: '#7C4DFF' },
};

// ─── Helper: relative time ────────────────────────────────────────────────────

function relativeTime(ts: number): string {
  const now = Date.now();
  const diff = now - ts;
  const minutes = Math.floor(diff / 60_000);
  const hours   = Math.floor(diff / 3_600_000);

  if (minutes < 1)  return 'Just now';
  if (minutes < 60) return `${minutes} minute${minutes === 1 ? '' : 's'} ago`;
  if (hours < 24)   return `${hours} hour${hours === 1 ? '' : 's'} ago`;

  const date    = new Date(ts);
  const today   = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);

  if (date.toDateString() === today.toDateString())     return 'Today';
  if (date.toDateString() === yesterday.toDateString()) return 'Yesterday';

  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

// ─── Helper: section label from timestamp ────────────────────────────────────

function sectionLabel(ts: number): string {
  const date     = new Date(ts);
  const today    = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);

  const startOfWeek = new Date();
  startOfWeek.setDate(today.getDate() - today.getDay());
  startOfWeek.setHours(0, 0, 0, 0);

  if (date.toDateString() === today.toDateString())     return 'Today';
  if (date.toDateString() === yesterday.toDateString()) return 'Yesterday';
  if (date >= startOfWeek)                              return 'This Week';
  return 'Older';
}

// ─── Helper: filter by active tab ────────────────────────────────────────────

function filterByTab(entries: HistoryEntry[], tab: TabKey): HistoryEntry[] {
  if (tab === 'download') return entries.filter(e => e.action === 'downloaded' || e.action === 'failed');
  if (tab === 'playback') return entries.filter(e => e.action === 'played');
  // link history: everything (alternate: only entries that originated from link sharing — here we show all as fallback)
  return entries;
}

// ─── Helper: build section list for FlatList ─────────────────────────────────

const SECTION_ORDER = ['Today', 'Yesterday', 'This Week', 'Older'] as const;

function buildSectionedList(entries: HistoryEntry[]): SectionItem[] {
  const grouped: Record<string, HistoryEntry[]> = {};
  for (const entry of entries) {
    const label = sectionLabel(entry.createdAt);
    if (!grouped[label]) grouped[label] = [];
    grouped[label].push(entry);
  }

  const items: SectionItem[] = [];
  for (const label of SECTION_ORDER) {
    if (grouped[label] && grouped[label].length > 0) {
      items.push({ type: 'section', label });
      for (const e of grouped[label]) {
        items.push({ type: 'entry', data: e });
      }
    }
  }
  return items;
}

// ─── Sub-components ───────────────────────────────────────────────────────────

interface SkeletonProps {
  colors: ReturnType<typeof useColors>;
}

function SkeletonItem({ colors }: SkeletonProps) {
  return (
    <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.divider }]}>
      <View style={[styles.thumbnailPlaceholder, { backgroundColor: colors.divider }]} />
      <View style={styles.cardBody}>
        <View style={[styles.skeletonLine, { backgroundColor: colors.divider, width: '70%' }]} />
        <View style={[styles.skeletonLine, { backgroundColor: colors.divider, width: '40%', marginTop: 8 }]} />
        <View style={[styles.skeletonLine, { backgroundColor: colors.divider, width: '30%', marginTop: 8 }]} />
      </View>
    </View>
  );
}

interface EmptyStateProps {
  tab: TabKey;
  colors: ReturnType<typeof useColors>;
}

function EmptyState({ tab, colors }: EmptyStateProps) {
  const messages: Record<TabKey, { icon: string; title: string; description: string }> = {
    download: {
      icon: 'download-off',
      title: 'No download history',
      description: 'Videos you download will appear here.',
    },
    playback: {
      icon: 'play-circle-outline',
      title: 'No playback history',
      description: 'Videos you play will appear here.',
    },
    link: {
      icon: 'link-off',
      title: 'No link history',
      description: 'Links you process will appear here.',
    },
  };
  const { icon, title, description } = messages[tab];

  return (
    <View style={styles.emptyState}>
      <MaterialCommunityIcons name={icon} size={64} color={colors.textMuted} />
      <Text style={[styles.emptyTitle, { color: colors.textSecondary }]}>{title}</Text>
      <Text style={[styles.emptyDescription, { color: colors.textMuted }]}>{description}</Text>
    </View>
  );
}

interface ActionBadgeProps {
  action: HistoryEntry['action'];
  colors: ReturnType<typeof useColors>;
}

function ActionBadge({ action, colors }: ActionBadgeProps) {
  const config = {
    downloaded: { label: 'Downloaded', color: colors.success },
    played:     { label: 'Played',      color: colors.primary  },
    failed:     { label: 'Failed',       color: colors.error   },
  }[action];

  return (
    <View style={[styles.badge, { backgroundColor: config.color + '22', borderColor: config.color + '55' }]}>
      <Text style={[styles.badgeText, { color: config.color }]}>{config.label}</Text>
    </View>
  );
}

interface HistoryCardProps {
  entry: HistoryEntry;
  colors: ReturnType<typeof useColors>;
  onDelete: (id: string) => void;
}

function HistoryCard({ entry, colors, onDelete }: HistoryCardProps) {
  const [showDelete, setShowDelete] = useState(false);

  const platformKey = (entry.platform || '').toLowerCase();
  const platformInfo = PLATFORM_ICONS[platformKey] ?? PLATFORM_ICONS.default;

  const hasThumbnail = entry.thumbnailPath && entry.thumbnailPath.length > 0;

  const handleDelete = useCallback(() => {
    Alert.alert(
      'Delete Entry',
      'Remove this item from history?',
      [
        { text: 'Cancel', style: 'cancel', onPress: () => setShowDelete(false) },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            setShowDelete(false);
            onDelete(entry.id);
          },
        },
      ],
    );
  }, [entry.id, onDelete]);

  return (
    <TouchableOpacity
      activeOpacity={0.85}
      onPress={() => setShowDelete(s => !s)}
      onLongPress={() => setShowDelete(true)}
      style={[
        styles.card,
        {
          backgroundColor: colors.card,
          borderColor: showDelete ? colors.error + '55' : colors.divider,
        },
      ]}
    >
      {/* Thumbnail */}
      <View style={[styles.thumbnailContainer, { backgroundColor: platformInfo.color + '22' }]}>
        {hasThumbnail ? (
          <Image
            source={{ uri: entry.thumbnailPath }}
            style={styles.thumbnail}
            resizeMode="cover"
          />
        ) : (
          <MaterialCommunityIcons name={platformInfo.icon} size={28} color={platformInfo.color} />
        )}
      </View>

      {/* Content */}
      <View style={styles.cardBody}>
        <Text style={[styles.cardTitle, { color: colors.textPrimary }]} numberOfLines={2}>
          {entry.title || 'Untitled'}
        </Text>
        <View style={styles.cardMeta}>
          <MaterialCommunityIcons name={platformInfo.icon} size={12} color={colors.textMuted} style={{ marginRight: 4 }} />
          <Text style={[styles.cardMetaText, { color: colors.textMuted }]}>
            {entry.platform || 'Unknown'}
          </Text>
          <Text style={[styles.cardMetaText, { color: colors.textMuted }]}>  ·  </Text>
          <Text style={[styles.cardMetaText, { color: colors.textMuted }]}>
            {relativeTime(entry.createdAt)}
          </Text>
        </View>
        <ActionBadge action={entry.action} colors={colors} />
      </View>

      {/* Delete button (shown on press) */}
      {showDelete && (
        <TouchableOpacity
          onPress={handleDelete}
          style={[styles.deleteButton, { backgroundColor: colors.error }]}
          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
        >
          <MaterialCommunityIcons name="delete" size={18} color="#FFFFFF" />
        </TouchableOpacity>
      )}
    </TouchableOpacity>
  );
}

interface ClearDialogProps {
  visible: boolean;
  colors: ReturnType<typeof useColors>;
  onConfirm: () => void;
  onCancel: () => void;
}

function ClearDialog({ visible, colors, onConfirm, onCancel }: ClearDialogProps) {
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
      <Pressable style={styles.modalOverlay} onPress={onCancel}>
        <Pressable
          style={[styles.dialogBox, { backgroundColor: colors.card, borderColor: colors.divider }]}
          onPress={() => {/* prevent dismiss */}}
        >
          <MaterialCommunityIcons name="trash-can-outline" size={40} color={colors.error} style={{ marginBottom: 12 }} />
          <Text style={[styles.dialogTitle, { color: colors.textPrimary }]}>Clear History</Text>
          <Text style={[styles.dialogMessage, { color: colors.textSecondary }]}>
            Are you sure you want to clear all history? This action cannot be undone.
          </Text>
          <View style={styles.dialogActions}>
            <TouchableOpacity
              onPress={onCancel}
              style={[styles.dialogBtn, { backgroundColor: colors.divider }]}
            >
              <Text style={[styles.dialogBtnText, { color: colors.textSecondary }]}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={onConfirm}
              style={[styles.dialogBtn, { backgroundColor: colors.error }]}
            >
              <Text style={[styles.dialogBtnText, { color: '#FFFFFF' }]}>Clear All</Text>
            </TouchableOpacity>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function HistoryScreen() {
  const colors = useColors();

  const [allEntries, setAllEntries]         = useState<HistoryEntry[]>([]);
  const [loading, setLoading]               = useState(true);
  const [activeTab, setActiveTab]           = useState<TabKey>('download');
  const [searchQuery, setSearchQuery]       = useState('');
  const [searchVisible, setSearchVisible]   = useState(false);
  const [clearDialogVisible, setClearDialogVisible] = useState(false);

  // ── Load data ────────────────────────────────────────────────────────────────

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [history, downloads] = await Promise.all([getHistory(), getDownloads()]);

      // Backfill: surface completed/failed downloads that have no history row yet
      // (history was not recorded for downloads created before this feature).
      const existingDownloadIds = new Set(
        history.map(h => h.downloadId).filter(Boolean) as string[],
      );

      const synthetic: HistoryEntry[] = downloads
        .filter(d => (d.status === 'completed' || d.status === 'failed') && !existingDownloadIds.has(d.id))
        .map(d => ({
          id: `dl-${d.id}`,
          mediaId: null,
          downloadId: d.id,
          title: d.title,
          thumbnailPath: d.thumbnailUrl || '',
          action: d.status === 'completed' ? 'downloaded' : 'failed',
          platform: d.platform || 'default',
          createdAt: d.completedAt || d.createdAt,
        }));

      const merged = [...history, ...synthetic].sort((a, b) => b.createdAt - a.createdAt);
      setAllEntries(merged);
    } catch (err) {
      logger.error('[HistoryScreen] Failed to load history:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // Refresh whenever the screen regains focus (e.g. after a new download completes)
  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData]),
  );

  // ── Delete single entry ───────────────────────────────────────────────────────

  const handleDelete = useCallback(async (id: string) => {
    try {
      await deleteHistoryEntry(id);
      setAllEntries(prev => prev.filter(e => e.id !== id));
    } catch (err) {
      logger.error('[HistoryScreen] Failed to delete entry:', err);
      Alert.alert('Error', 'Could not delete entry. Please try again.');
    }
  }, []);

  // ── Clear all ────────────────────────────────────────────────────────────────

  const handleClearConfirm = useCallback(async () => {
    setClearDialogVisible(false);
    try {
      await clearHistory();
      setAllEntries([]);
    } catch (err) {
      logger.error('[HistoryScreen] Failed to clear history:', err);
      Alert.alert('Error', 'Could not clear history. Please try again.');
    }
  }, []);

  // ── Derived data ──────────────────────────────────────────────────────────────

  const filteredEntries = useMemo(() => {
    let entries = filterByTab(allEntries, activeTab);
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      entries = entries.filter(
        e =>
          e.title.toLowerCase().includes(q) ||
          (e.platform || '').toLowerCase().includes(q),
      );
    }
    return entries;
  }, [allEntries, activeTab, searchQuery]);

  const sectionedList = useMemo(() => buildSectionedList(filteredEntries), [filteredEntries]);

  // ── Render helpers ────────────────────────────────────────────────────────────

  const renderItem = useCallback(
    ({ item }: { item: SectionItem }) => {
      if (item.type === 'section') {
        return (
          <Text style={[styles.sectionHeader, { color: colors.textMuted, borderBottomColor: colors.divider }]}>
            {item.label}
          </Text>
        );
      }
      return (
        <HistoryCard
          entry={item.data}
          colors={colors}
          onDelete={handleDelete}
        />
      );
    },
    [colors, handleDelete],
  );

  const keyExtractor = useCallback((item: SectionItem, index: number) => {
    if (item.type === 'section') return `section-${item.label}`;
    return `entry-${item.data.id}`;
  }, []);

  const getItemLayout = useCallback((_: any, index: number) => ({
    length: 88,
    offset: 88 * index,
    index,
  }), []);

  // ── Skeleton ──────────────────────────────────────────────────────────────────

  if (loading) {
    return (
      <SafeAreaView style={[styles.root, { backgroundColor: colors.background }]}>
        <Header
          colors={colors}
          searchVisible={false}
          searchQuery=""
          onSearchToggle={() => {}}
          onSearchChange={() => {}}
          onClearPress={() => {}}
          hasItems={false}
        />
        <TabBar activeTab={activeTab} onTabChange={setActiveTab} colors={colors} />
        <View style={styles.skeletonContainer}>
          {[...Array(6)].map((_, i) => (
            <SkeletonItem key={i} colors={colors} />
          ))}
        </View>
      </SafeAreaView>
    );
  }

  // ── Main render ───────────────────────────────────────────────────────────────

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: colors.background }]}>
      <Header
        colors={colors}
        searchVisible={searchVisible}
        searchQuery={searchQuery}
        onSearchToggle={() => {
          setSearchVisible(v => !v);
          if (searchVisible) setSearchQuery('');
        }}
        onSearchChange={setSearchQuery}
        onClearPress={() => setClearDialogVisible(true)}
        hasItems={allEntries.length > 0}
      />

      <TabBar activeTab={activeTab} onTabChange={setActiveTab} colors={colors} />

      {sectionedList.length === 0 ? (
        <EmptyState tab={activeTab} colors={colors} />
      ) : (
        <FlatList
          data={sectionedList}
          renderItem={renderItem}
          keyExtractor={keyExtractor}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          removeClippedSubviews
        />
      )}

      <ClearDialog
        visible={clearDialogVisible}
        colors={colors}
        onConfirm={handleClearConfirm}
        onCancel={() => setClearDialogVisible(false)}
      />
    </SafeAreaView>
  );
}

// ─── Header ───────────────────────────────────────────────────────────────────

interface HeaderProps {
  colors: ReturnType<typeof useColors>;
  searchVisible: boolean;
  searchQuery: string;
  onSearchToggle: () => void;
  onSearchChange: (q: string) => void;
  onClearPress: () => void;
  hasItems: boolean;
}

function Header({
  colors,
  searchVisible,
  searchQuery,
  onSearchToggle,
  onSearchChange,
  onClearPress,
  hasItems,
}: HeaderProps) {
  return (
    <View style={[styles.header, { borderBottomColor: colors.divider }]}>
      {searchVisible ? (
        <View style={[styles.searchBar, { backgroundColor: colors.card, borderColor: colors.divider }]}>
          <MaterialCommunityIcons name="magnify" size={20} color={colors.textMuted} style={{ marginRight: 8 }} />
          <TextInput
            autoFocus
            value={searchQuery}
            onChangeText={onSearchChange}
            placeholder="Search history..."
            placeholderTextColor={colors.textMuted}
            style={[styles.searchInput, { color: colors.textPrimary }]}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity onPress={() => onSearchChange('')}>
              <MaterialCommunityIcons name="close-circle" size={18} color={colors.textMuted} />
            </TouchableOpacity>
          )}
        </View>
      ) : (
        <Text style={[styles.headerTitle, { color: colors.textPrimary }]}>History</Text>
      )}

      <View style={styles.headerActions}>
        <TouchableOpacity onPress={onSearchToggle} style={styles.iconButton} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <MaterialCommunityIcons
            name={searchVisible ? 'close' : 'magnify'}
            size={22}
            color={colors.textSecondary}
          />
        </TouchableOpacity>
        {hasItems && !searchVisible && (
          <TouchableOpacity onPress={onClearPress} style={styles.iconButton} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <MaterialCommunityIcons name="trash-can-outline" size={22} color={colors.error} />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

// ─── TabBar ───────────────────────────────────────────────────────────────────

interface TabBarProps {
  activeTab: TabKey;
  onTabChange: (key: TabKey) => void;
  colors: ReturnType<typeof useColors>;
}

function TabBar({ activeTab, onTabChange, colors }: TabBarProps) {
  return (
    <View style={[styles.tabBar, { backgroundColor: colors.surface, borderBottomColor: colors.divider }]}>
      {TABS.map(tab => {
        const isActive = tab.key === activeTab;
        return (
          <TouchableOpacity
            key={tab.key}
            onPress={() => onTabChange(tab.key)}
            style={[
              styles.tab,
              isActive && { borderBottomColor: colors.primary, borderBottomWidth: 2 },
            ]}
          >
            <Text
              style={[
                styles.tabLabel,
                { color: isActive ? colors.primary : colors.textMuted },
              ]}
            >
              {tab.label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  // Header
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: '700',
    flex: 1,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  iconButton: {
    padding: 6,
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 10,
    paddingVertical: 6,
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    padding: 0,
    margin: 0,
  },
  // TabBar
  tabBar: {
    flexDirection: 'row',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
  },
  tabLabel: {
    fontSize: 12,
    fontWeight: '600',
  },
  // List
  listContent: {
    paddingHorizontal: 16,
    paddingBottom: 32,
  },
  sectionHeader: {
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginTop: 20,
    marginBottom: 8,
    paddingBottom: 6,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  // Card
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 10,
    borderWidth: 1,
    marginBottom: 8,
    padding: 10,
    overflow: 'hidden',
  },
  thumbnailContainer: {
    width: 60,
    height: 60,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
    flexShrink: 0,
  },
  thumbnail: {
    width: '100%',
    height: '100%',
  },
  thumbnailPlaceholder: {
    width: 60,
    height: 60,
    borderRadius: 8,
  },
  cardBody: {
    flex: 1,
    marginLeft: 12,
    justifyContent: 'center',
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 18,
  },
  cardMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  cardMetaText: {
    fontSize: 11,
  },
  // Badge
  badge: {
    alignSelf: 'flex-start',
    marginTop: 6,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
    borderWidth: 1,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  // Delete button
  deleteButton: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
    flexShrink: 0,
  },
  // Skeleton
  skeletonContainer: {
    paddingHorizontal: 16,
    paddingTop: 16,
  },
  skeletonLine: {
    height: 12,
    borderRadius: 6,
  },
  // Empty state
  emptyState: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
  },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginTop: 16,
    textAlign: 'center',
  },
  emptyDescription: {
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
    lineHeight: 20,
  },
  // Clear dialog
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  dialogBox: {
    width: 300,
    borderRadius: 16,
    borderWidth: 1,
    padding: 24,
    alignItems: 'center',
  },
  dialogTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 8,
  },
  dialogMessage: {
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  dialogActions: {
    flexDirection: 'row',
    gap: 12,
  },
  dialogBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  dialogBtnText: {
    fontSize: 14,
    fontWeight: '600',
  },
});
