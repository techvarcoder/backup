import React, { useEffect } from 'react';
import { View, Text } from 'react-native';
import { useColors } from '../../theme';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../navigation/types';

type Props = NativeStackScreenProps<RootStackParamList, 'Splash'>;

export default function SplashScreen({ navigation }: Props) {
  const colors = useColors();

  useEffect(() => {
      const timer = setTimeout(() => {
      (navigation as any).replace('MainTabs', undefined);
    }, 2000);
    return () => clearTimeout(timer);
  }, [navigation]);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 48, fontWeight: '700', color: colors.primary, marginBottom: 20 }}>🎬</Text>
      <Text style={{ fontSize: 32, fontWeight: '600', color: colors.textPrimary, marginBottom: 8 }}>MediaNest</Text>
      <Text style={{ fontSize: 14, color: colors.textSecondary }}>Universal Video Downloader</Text>
    </View>
  );
}
