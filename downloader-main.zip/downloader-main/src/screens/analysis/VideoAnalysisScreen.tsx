import React, { useRef, useState } from 'react';
import { View, ScrollView, Text, TouchableOpacity, Image, Dimensions, Animated, Alert, Linking } from 'react-native';
import { WebView } from 'react-native-webview';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';

export default function VideoAnalysisScreen({ route, navigation }: any) {
  const colors = useColors();
  const { url, analysis } = route.params;
  const [playing, setPlaying] = useState(false);
  const opacityRef = useRef(new Animated.Value(0));
  const normalized = {
    url: analysis?.url || url,
    title: analysis?.title || analysis?.name || `YouTube video`,
    channelName: analysis?.channelName || analysis?.channel || analysis?.uploader || '',
    thumbnailUrl: analysis?.thumbnailUrl || analysis?.thumbnail || '',
    duration: analysis?.duration || 0,
    viewCount: analysis?.viewCount || analysis?.views || null,
    availableQualities: analysis?.availableQualities || (analysis?.quality ? [{ label: analysis.quality, value: analysis.quality }] : []),
  } as any;

  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView style={{ padding: 16 }}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginBottom: 16 }}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={colors.primary} />
        </TouchableOpacity>

        <View style={{ width: '100%', height: 220, backgroundColor: colors.card, borderRadius: 12, marginBottom: 16, justifyContent: 'center', alignItems: 'center', overflow: 'hidden' }}>
          {(() => {
            const embed = getEmbedUrl(url);
            const screenW = Dimensions.get('window').width - 32; // account for padding
            const height = Math.round((screenW / 16) * 9);
            if (embed) {
              if (!playing) {
                // show thumbnail with play overlay
                return (
                  <TouchableOpacity onPress={() => setPlaying(true)} style={{ width: '100%', height }}>
                    { (normalized.thumbnailUrl || getYouTubeId(url)) ? (
                      <Image source={{ uri: normalized.thumbnailUrl || `https://img.youtube.com/vi/${getYouTubeId(url)}/hqdefault.jpg` }} style={{ width: '100%', height: '100%' }} />
                    ) : (
                      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                        <MaterialCommunityIcons name="play-circle" size={64} color={colors.primary} />
                      </View>
                    )}
                    <View style={{ position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, justifyContent: 'center', alignItems: 'center' }}>
                      <MaterialCommunityIcons name="play" size={48} color="rgba(255,255,255,0.9)" />
                    </View>
                  </TouchableOpacity>
                );
              }

              return (
                <Animated.View renderToHardwareTextureAndroid style={{ width: '100%', height, opacity: opacityRef.current }}>
                  <WebView
                    source={{ uri: embed }}
                    userAgent={'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.0 Mobile/15E148 Safari/604.1'}
                    style={{ width: '100%', height }}
                    javaScriptEnabled={true}
                    domStorageEnabled={true}
                    originWhitelist={["*"]}
                    mixedContentMode="always"
                    allowsInlineMediaPlayback={true}
                    mediaPlaybackRequiresUserAction={false}
                    allowsFullscreenVideo={true}
                    onError={async (syntheticEvent) => {
                      const { nativeEvent } = syntheticEvent as any;
                      console.warn('WebView onError', nativeEvent, 'embed=', embed);
                      // try open in YouTube app first, then fallback to browser
                      const id = getYouTubeId(url);
                      if (id) {
                        const appUrl = `vnd.youtube:${id}`;
                        const webUrl = `https://www.youtube.com/watch?v=${id}`;
                        try {
                          const opened = await Linking.openURL(appUrl);
                          if (!opened) await Linking.openURL(webUrl);
                        } catch (e) {
                          await Linking.openURL(webUrl);
                        }
                      } else {
                        await Linking.openURL(url);
                      }
                      setPlaying(false);
                    }}
                    onHttpError={(syntheticEvent) => {
                      const { nativeEvent } = syntheticEvent as any;
                      console.warn('WebView http error', nativeEvent, 'embed=', embed);
                    }}
                    onLoadProgress={({ nativeEvent }) => {
                      const p = nativeEvent.progress ?? 0;
                      if (p >= 0 && p <= 1) {
                        Animated.timing(opacityRef.current, { toValue: Math.min(1, p * 1.2), duration: 120, useNativeDriver: true }).start();
                      }
                    }}
                  />
                </Animated.View>
              );
            }
            return normalized.thumbnailUrl ? (
              <Image source={{ uri: normalized.thumbnailUrl }} style={{ width: '100%', height: '100%', borderRadius: 12 }} />
            ) : (
              <MaterialCommunityIcons name="play-circle" size={64} color={colors.primary} />
            );
          })()}
        </View>

        <Text style={{ fontSize: 20, fontWeight: '700', color: colors.textPrimary, marginBottom: 8 }}>{normalized.title}</Text>
        <Text style={{ fontSize: 14, color: colors.textSecondary, marginBottom: 16 }}>{normalized.channelName}</Text>

        <View style={{ flexDirection: 'row', gap: 16, marginBottom: 24 }}>
          <View style={{ flex: 1, backgroundColor: colors.card, padding: 12, borderRadius: 8 }}>
            <Text style={{ fontSize: 12, color: colors.textMuted }}>Duration</Text>
            <Text style={{ fontSize: 16, fontWeight: '600', color: colors.textPrimary }}>{formatDuration(normalized.duration || 0)}</Text>
          </View>
          <View style={{ flex: 1, backgroundColor: colors.card, padding: 12, borderRadius: 8 }}>
            <Text style={{ fontSize: 12, color: colors.textMuted }}>Quality</Text>
            <Text style={{ fontSize: 16, fontWeight: '600', color: colors.textPrimary }}>{normalized.availableQualities?.[0]?.label ?? '-'}</Text>
          </View>
        </View>

        <TouchableOpacity
          onPress={() => navigation.navigate('DownloadOptions', { analysis, url })}
          style={{ backgroundColor: colors.primary, padding: 14, borderRadius: 8, alignItems: 'center', marginBottom: 16 }}
        >
          <Text style={{ color: '#fff', fontWeight: '600', fontSize: 16 }}>Download</Text>
        </TouchableOpacity>

        <View style={{ marginTop: 16, padding: 12, backgroundColor: colors.card, borderRadius: 8 }}>
          <Text style={{ fontSize: 12, color: colors.textMuted, fontFamily: 'monospace', lineHeight: 18 }}>{url}</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function getEmbedUrl(rawUrl: string) {
  if (!rawUrl) return null;
  try {
    const u = new URL(rawUrl);
    const host = u.hostname.replace('www.', '').toLowerCase();
    let videoId: string | null = null;

    if (host.includes('youtube.com')) {
      if (u.pathname.startsWith('/shorts/')) {
        videoId = u.pathname.split('/')[2];
      } else {
        videoId = u.searchParams.get('v');
      }
    } else if (host.includes('youtu.be')) {
      videoId = u.pathname.replace('/', '');
    }

    if (videoId) {
      // use youtube-nocookie to reduce third-party cookie/embed restrictions
      // include an origin param to satisfy some embed restrictions
      const origin = `https://www.youtube.com`;
      return `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&playsinline=1&enablejsapi=1&rel=0&modestbranding=1&origin=${encodeURIComponent(origin)}`;
    }
    
    return null;
  } catch {
    return null;
  }
}

function getYouTubeId(rawUrl: string) {
  if (!rawUrl) return null;
  try {
    const u = new URL(rawUrl);
    const host = u.hostname.replace('www.', '').toLowerCase();
    if (host.includes('youtube.com')) {
      if (u.pathname.startsWith('/shorts/')) return u.pathname.split('/')[2];
      return u.searchParams.get('v');
    }
    if (host.includes('youtu.be')) return u.pathname.replace('/', '');
    return null;
  } catch {
    return null;
  }
}
