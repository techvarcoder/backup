import React from 'react';
import { View, Text, TouchableOpacity, Linking } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';
import { APP_NAME } from '../../constants';

const APP_VERSION = '1.0.0';

export default function AboutScreen({ navigation }: any) {
  const colors = useColors();

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ padding: 16, flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 24 }}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginRight: 12 }}>
            <MaterialCommunityIcons name="arrow-left" size={24} color={colors.primary} />
          </TouchableOpacity>
          <Text style={{ color: colors.textPrimary, fontSize: 20, fontWeight: '700' }}>About</Text>
        </View>

        <View style={{ alignItems: 'center', marginVertical: 24 }}>
          <View
            style={{
              width: 88,
              height: 88,
              borderRadius: 22,
              backgroundColor: 'rgba(124,77,255,0.13)',
              justifyContent: 'center',
              alignItems: 'center',
              marginBottom: 12,
            }}
          >
            <MaterialCommunityIcons name="download-box" size={48} color={colors.primary} />
          </View>
          <Text style={{ color: colors.textPrimary, fontSize: 22, fontWeight: '700' }}>
            {APP_NAME}
          </Text>
          <Text style={{ color: colors.textMuted, fontSize: 14, marginTop: 4 }}>
            Version {APP_VERSION}
          </Text>
        </View>

        <Text style={{ color: colors.textSecondary, fontSize: 14, lineHeight: 22, textAlign: 'center', marginBottom: 24 }}>
          {APP_NAME} lets you download and manage videos and audio from your favorite
          platforms, all in one place.
        </Text>

        {[
          { icon: 'shield-lock', label: 'Privacy Policy', url: 'https://example.com/privacy' },
          { icon: 'file-document', label: 'Terms of Service', url: 'https://example.com/terms' },
          { icon: 'email', label: 'Contact Support', url: 'mailto:support@example.com' },
        ].map((row) => (
          <TouchableOpacity
            key={row.label}
            onPress={() => Linking.openURL(row.url).catch(() => {})}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              padding: 14,
              backgroundColor: colors.card,
              marginBottom: 8,
              borderRadius: 10,
            }}
          >
            <MaterialCommunityIcons name={row.icon} size={20} color={colors.primary} />
            <Text style={{ color: colors.textPrimary, fontSize: 15, marginLeft: 12, flex: 1 }}>
              {row.label}
            </Text>
            <MaterialCommunityIcons name="chevron-right" size={18} color={colors.textMuted} />
          </TouchableOpacity>
        ))}

        <Text style={{ color: colors.textMuted, fontSize: 12, textAlign: 'center', marginTop: 24 }}>
          © {new Date().getFullYear()} {APP_NAME}. All rights reserved.
        </Text>
      </View>
    </SafeAreaView>
  );
}
