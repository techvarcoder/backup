import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColors } from '../../theme';
import { loadSettings, saveSettings } from '../../services/storageService';

const OPTIONS = ['144p','240p','360p','480p','720p','1080p','best'];

export default function VideoQualityScreen({ navigation }: any) {
  const colors = useColors();
  const [selected, setSelected] = useState('1080p');

  useEffect(() => {
    (async () => {
      const s = await loadSettings();
      setSelected(s.defaultVideoQuality || '1080p');
    })();
  }, []);

  const save = async (v: string) => {
    try {
      const s = await loadSettings();
      await saveSettings({ ...s, defaultVideoQuality: v });
      setSelected(v);
      navigation.goBack();
    } catch (e) {
      Alert.alert('Error', 'Failed to save setting');
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ padding: 16 }}>
        <Text style={{ color: colors.textPrimary, fontSize: 18, marginBottom: 12 }}>Default Video Quality</Text>
        {OPTIONS.map((o) => (
          <TouchableOpacity key={o} onPress={() => save(o)} style={{ padding: 12, backgroundColor: selected === o ? colors.primary : colors.card, marginBottom: 8, borderRadius: 8 }}>
            <Text style={{ color: selected === o ? '#fff' : colors.textPrimary }}>{o}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}
