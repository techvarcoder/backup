import React, { useState, useEffect } from 'react';
import {
  View,
  ScrollView,
  Text,
  TouchableOpacity,
  Switch,
  StyleSheet,
  Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';
import { useSettingsStore, ThemeMode } from '../../stores/settingsStore';
import RNFS from 'react-native-fs';
import { clearStorage, saveSettings, loadSettings } from '../../services/storageService';
import { Share, Alert, Linking } from 'react-native';

// ─── Types ───────────────────────────────────────────────────────────────────

interface RowItem {
  icon: string;
  label: string;
  value?: string;
  isToggle?: boolean;
  toggleValue?: boolean;
  onToggle?: (v: boolean) => void;
  onPress?: () => void;
  isDanger?: boolean;
  isLast?: boolean;
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function SectionHeader({ title, colors }: { title: string; colors: ReturnType<typeof useColors> }) {
  return (
    <Text
      style={{
        fontFamily: 'Poppins-SemiBold',
        fontSize: 11,
        letterSpacing: 1.2,
        textTransform: 'uppercase',
        color: colors.textMuted,
        marginTop: 24,
        marginBottom: 8,
        marginLeft: 4,
      }}
    >
      {title}
    </Text>
  );
}

function SettingsRow({
  icon,
  label,
  value,
  isToggle,
  toggleValue,
  onToggle,
  onPress,
  isDanger,
  isLast,
  colors,
}: RowItem & { colors: ReturnType<typeof useColors> }) {
  const labelColor = isDanger ? colors.error : colors.textPrimary;

  const inner = (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 16,
        paddingVertical: 14,
        borderBottomWidth: isLast ? 0 : StyleSheet.hairlineWidth,
        borderBottomColor: colors.divider,
      }}
    >
      {/* Left icon */}
      <View
        style={{
          width: 36,
          height: 36,
          borderRadius: 10,
          backgroundColor: isDanger
            ? 'rgba(255,82,82,0.12)'
            : 'rgba(124,77,255,0.13)',
          justifyContent: 'center',
          alignItems: 'center',
          marginRight: 14,
        }}
      >
        <MaterialCommunityIcons
          name={icon}
          size={20}
          color={isDanger ? colors.error : colors.primary}
        />
      </View>

      {/* Label */}
      <Text
        style={{
          fontFamily: 'Poppins-Medium',
          fontSize: 14,
          color: labelColor,
          flex: 1,
        }}
        numberOfLines={1}
      >
        {label}
      </Text>

      {/* Right side */}
      {isToggle ? (
        <Switch
          value={toggleValue}
          onValueChange={onToggle}
          trackColor={{ false: colors.divider, true: colors.primary }}
          thumbColor={Platform.OS === 'android' ? (toggleValue ? '#fff' : '#ccc') : undefined}
          ios_backgroundColor={colors.divider}
        />
      ) : value !== undefined ? (
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Text
            style={{
              fontFamily: 'Poppins-Regular',
              fontSize: 13,
              color: colors.textMuted,
            }}
          >
            {value}
          </Text>
          {onPress && (
            <MaterialCommunityIcons
              name="chevron-right"
              size={18}
              color={colors.textMuted}
            />
          )}
        </View>
      ) : onPress ? (
        <MaterialCommunityIcons
          name="chevron-right"
          size={18}
          color={colors.textMuted}
        />
      ) : null}
    </View>
  );

  if (isToggle || !onPress) {
    return inner;
  }

  return (
    <TouchableOpacity activeOpacity={0.7} onPress={onPress}>
      {inner}
    </TouchableOpacity>
  );
}

function SettingsCard({
  rows,
  colors,
}: {
  rows: RowItem[];
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View
      style={{
        backgroundColor: colors.card,
        borderRadius: 16,
        overflow: 'hidden',
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: colors.divider,
      }}
    >
      {rows.map((row, index) => (
        <SettingsRow
          key={row.label}
          {...row}
          isLast={index === rows.length - 1}
          colors={colors}
        />
      ))}
    </View>
  );
}

// ─── Premium Banner ──────────────────────────────────────────────────────────

function PremiumBanner({ colors }: { colors: ReturnType<typeof useColors> }) {
  return (
    <View
      style={{
        borderRadius: 20,
        overflow: 'hidden',
        marginBottom: 4,
      }}
    >
      {/* Gradient simulation via stacked layers */}
      <View
        style={{
          position: 'absolute',
          inset: 0,
          backgroundColor: '#3B1FA8',
        }}
      />
      <View
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: '#5B2EFF',
          opacity: 0.7,
        }}
      />
      {/* Decorative blobs */}
      <View
        style={{
          position: 'absolute',
          width: 140,
          height: 140,
          borderRadius: 70,
          backgroundColor: 'rgba(255,193,7,0.12)',
          top: -30,
          right: -30,
        }}
      />
      <View
        style={{
          position: 'absolute',
          width: 90,
          height: 90,
          borderRadius: 45,
          backgroundColor: 'rgba(0,229,255,0.08)',
          bottom: -20,
          left: 20,
        }}
      />

      {/* Content */}
      <View style={{ padding: 20 }}>
        {/* Crown row */}
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            gap: 10,
            marginBottom: 8,
          }}
        >
          <View
            style={{
              width: 42,
              height: 42,
              borderRadius: 12,
              backgroundColor: 'rgba(255,193,7,0.2)',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <MaterialCommunityIcons name="crown" size={24} color="#FFC107" />
          </View>
          <View>
            <Text
              style={{
                fontFamily: 'Poppins-Bold',
                fontSize: 18,
                color: '#FFFFFF',
                lineHeight: 22,
              }}
            >
              Go Premium
            </Text>
            <Text
              style={{
                fontFamily: 'Poppins-Regular',
                fontSize: 12,
                color: 'rgba(255,255,255,0.75)',
              }}
            >
              Unlock all features & remove ads
            </Text>
          </View>
        </View>

        {/* Feature pills */}
        <View
          style={{
            flexDirection: 'row',
            flexWrap: 'wrap',
            gap: 8,
            marginBottom: 16,
          }}
        >
          {[
            { icon: 'infinity', label: 'Unlimited Downloads' },
            { icon: 'quality-high', label: '4K / 8K Quality' },
            { icon: 'lightning-bolt', label: 'Faster Speed' },
          ].map((feat) => (
            <View
              key={feat.label}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 5,
                backgroundColor: 'rgba(255,255,255,0.12)',
                paddingHorizontal: 10,
                paddingVertical: 5,
                borderRadius: 20,
              }}
            >
              <MaterialCommunityIcons
                name={feat.icon}
                size={14}
                color="rgba(255,255,255,0.9)"
              />
              <Text
                style={{
                  fontFamily: 'Poppins-Medium',
                  fontSize: 11,
                  color: 'rgba(255,255,255,0.9)',
                }}
              >
                {feat.label}
              </Text>
            </View>
          ))}
        </View>

        {/* CTA button */}
        <TouchableOpacity
          activeOpacity={0.85}
          onPress={() =>
            Alert.alert(
              'Go Premium',
              'Premium unlocks unlimited downloads, 4K/8K quality, faster speeds, and removes ads. Coming soon!',
            )
          }
          style={{
            backgroundColor: '#FFC107',
            borderRadius: 12,
            paddingVertical: 13,
            alignItems: 'center',
            shadowColor: '#FFC107',
            shadowOpacity: 0.45,
            shadowRadius: 10,
            shadowOffset: { width: 0, height: 4 },
            elevation: 6,
          }}
        >
          <Text
            style={{
              fontFamily: 'Poppins-Bold',
              fontSize: 15,
              color: '#1A0A00',
              letterSpacing: 0.3,
            }}
          >
            Unlock All Features
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

// ─── Storage Usage Row ────────────────────────────────────────────────────────

function StorageUsageRow({
  colors,
  usedGB,
  totalGB,
}: {
  colors: ReturnType<typeof useColors>;
  usedGB: number;
  totalGB: number;
}) {
  const usedPercent = totalGB > 0 ? Math.min(1, usedGB / totalGB) : 0;

  return (
    <View
      style={{
        paddingHorizontal: 16,
        paddingVertical: 14,
        borderBottomWidth: StyleSheet.hairlineWidth,
        borderBottomColor: colors.divider,
      }}
    >
      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          marginBottom: 10,
        }}
      >
        <View
          style={{
            width: 36,
            height: 36,
            borderRadius: 10,
            backgroundColor: 'rgba(124,77,255,0.13)',
            justifyContent: 'center',
            alignItems: 'center',
            marginRight: 14,
          }}
        >
          <MaterialCommunityIcons
            name="chart-donut"
            size={20}
            color={colors.primary}
          />
        </View>
        <Text
          style={{
            fontFamily: 'Poppins-Medium',
            fontSize: 14,
            color: colors.textPrimary,
            flex: 1,
          }}
        >
          Storage Usage
        </Text>
        <Text
          style={{
            fontFamily: 'Poppins-Regular',
            fontSize: 12,
            color: colors.textMuted,
          }}
        >
          {usedGB} GB / {totalGB} GB
        </Text>
      </View>

      {/* Progress bar */}
      <View
        style={{
          height: 6,
          backgroundColor: colors.divider,
          borderRadius: 3,
          overflow: 'hidden',
          marginLeft: 50,
        }}
      >
        <View
          style={{
            height: '100%',
            width: `${usedPercent * 100}%`,
            backgroundColor: colors.primary,
            borderRadius: 3,
          }}
        />
      </View>
      <Text
        style={{
          fontFamily: 'Poppins-Regular',
          fontSize: 11,
          color: colors.textMuted,
          marginTop: 4,
          marginLeft: 50,
        }}
      >
        {Math.round(usedPercent * 100)}% used
      </Text>
    </View>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function SettingsScreen({ navigation }: { navigation: any }) {
  const colors = useColors();
  const { theme, setTheme } = useSettingsStore();

  const [autoDetect, setAutoDetect] = useState(true);
  const [clipboardMonitor, setClipboardMonitor] = useState(true);
  const [wifiOnly, setWifiOnly] = useState(false);
  const [autoRetry, setAutoRetry] = useState(true);
  const [language, setLanguage] = useState('English');
  const [videoQuality, setVideoQuality] = useState('1080p');
  const [audioFormat, setAudioFormat] = useState('mp3');
  const [maxConcurrent, setMaxConcurrent] = useState(3);
  const [usedGB, setUsedGB] = useState(0);
  const [totalGB, setTotalGB] = useState(0);
  const [cacheSize, setCacheSize] = useState('0 MB');

  const bytesToGB = (b: number) => Math.round((b / (1024 * 1024 * 1024)) * 10) / 10;

  // Compute total size of a directory (one level) in bytes
  const dirSize = async (path: string): Promise<number> => {
    try {
      const exists = await RNFS.exists(path);
      if (!exists) return 0;
      const items = await RNFS.readDir(path);
      let total = 0;
      for (const it of items) {
        if (it.isFile()) total += Number(it.size) || 0;
      }
      return total;
    } catch {
      return 0;
    }
  };

  const refreshStorage = React.useCallback(async () => {
    try {
      const info = await RNFS.getFSInfo();
      const used = info.totalSpace - info.freeSpace;
      setUsedGB(bytesToGB(used));
      setTotalGB(bytesToGB(info.totalSpace));
    } catch (e) {
      // ignore
    }
    try {
      const cacheBytes = await dirSize(RNFS.CachesDirectoryPath);
      const mb = Math.round((cacheBytes / (1024 * 1024)) * 10) / 10;
      setCacheSize(`${mb} MB`);
    } catch (e) {
      // ignore
    }
  }, []);

  const loadAll = React.useCallback(async () => {
    try {
      const s = await loadSettings();
      setAutoDetect(s.autoDetectLinks !== false);
      setClipboardMonitor(s.clipboardMonitor !== false);
      setWifiOnly(!!s.wifiOnlyDownload);
      setAutoRetry(s.autoRetryFailed !== false);
      setLanguage(s.language || 'English');
      setVideoQuality(s.defaultVideoQuality || '1080p');
      setAudioFormat(s.defaultAudioFormat || 'mp3');
      setMaxConcurrent(s.maxConcurrentDownloads || 3);
    } catch (e) {
      // ignore
    }
  }, []);

  // Reload settings + storage whenever the screen gains focus
  useEffect(() => {
    loadAll();
    refreshStorage();
    const unsub = navigation.addListener('focus', () => {
      loadAll();
      refreshStorage();
    });
    return unsub;
  }, [navigation, loadAll, refreshStorage]);

  // Persist a partial settings update
  const persist = React.useCallback(async (patch: Record<string, any>) => {
    try {
      const s = await loadSettings();
      await saveSettings({ ...s, ...patch });
    } catch (e) {
      console.warn('Failed to persist settings', e);
    }
  }, []);

  const themeLabel: Record<ThemeMode, string> = {
    dark: 'Dark',
    light: 'Light',
    system: 'System',
  };

  // Theme cycling on tap: dark -> light -> system -> dark
  const handleThemeTap = () => {
    const next: Record<ThemeMode, ThemeMode> = {
      dark: 'light',
      light: 'system',
      system: 'dark',
    };
    setTheme(next[theme]);
    persist({ themeMode: next[theme] });
  };

  return (
    <SafeAreaView
      style={{ flex: 1, backgroundColor: colors.background }}
      edges={['top', 'left', 'right']}
    >
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 40 }}
        showsVerticalScrollIndicator={false}
      >
        {/* ── Header ── */}
        <View style={{ marginTop: 16, marginBottom: 20 }}>
          <Text
            style={{
              fontFamily: 'Poppins-Bold',
              fontSize: 26,
              color: colors.textPrimary,
            }}
          >
            Settings
          </Text>
          <Text
            style={{
              fontFamily: 'Poppins-Regular',
              fontSize: 13,
              color: colors.textMuted,
              marginTop: 2,
            }}
          >
            Manage your preferences
          </Text>
        </View>

        {/* ── Premium Banner ── */}
        <PremiumBanner colors={colors} />

        {/* ── General ── */}
        <SectionHeader title="General" colors={colors} />
        <SettingsCard
          colors={colors}
          rows={[
            {
              icon: 'theme-light-dark',
              label: 'Theme',
              value: themeLabel[theme],
              onPress: handleThemeTap,
            },
            {
              icon: 'translate',
              label: 'Language',
              value: language,
              onPress: () => navigation.navigate('Language'),
            },
            {
              icon: 'auto-fix',
              label: 'Auto Detect Links',
              isToggle: true,
              toggleValue: autoDetect,
              onToggle: (v) => {
                setAutoDetect(v);
                persist({ autoDetectLinks: v });
              },
            },
            {
              icon: 'clipboard-pulse',
              label: 'Clipboard Monitor',
              isToggle: true,
              toggleValue: clipboardMonitor,
              onToggle: (v) => {
                setClipboardMonitor(v);
                persist({ clipboardMonitor: v });
              },
            },
            {
              icon: 'folder-download',
              label: 'Download Location',
              value: 'Internal Storage',
              onPress: () => {
                Alert.alert('Download Location', 'Downloads are saved to internal app storage and copied to /sdcard/Download for visibility.');
              },
            },
          ]}
        />

        {/* ── Download ── */}
        <SectionHeader title="Download" colors={colors} />
        <SettingsCard
          colors={colors}
          rows={[
            {
              icon: 'quality-high',
              label: 'Default Video Quality',
              value: videoQuality,
              onPress: () => navigation.navigate('VideoQuality'),
            },
            {
              icon: 'music-box',
              label: 'Default Audio Format',
              value: audioFormat.toUpperCase(),
              onPress: () => navigation.navigate('AudioFormat'),
            },
            {
              icon: 'download-multiple',
              label: 'Max Concurrent Downloads',
              value: String(maxConcurrent),
              onPress: () => navigation.navigate('MaxConcurrent'),
            },
            {
              icon: 'wifi',
              label: 'WiFi Only Download',
              isToggle: true,
              toggleValue: wifiOnly,
              onToggle: (v) => {
                setWifiOnly(v);
                persist({ wifiOnlyDownload: v });
              },
            },
            {
              icon: 'refresh',
              label: 'Auto Retry Failed',
              isToggle: true,
              toggleValue: autoRetry,
              onToggle: (v) => {
                setAutoRetry(v);
                persist({ autoRetryFailed: v });
              },
            },
          ]}
        />

        {/* ── Storage ── */}
        <SectionHeader title="Storage" colors={colors} />
        <View
          style={{
            backgroundColor: colors.card,
            borderRadius: 16,
            overflow: 'hidden',
            borderWidth: StyleSheet.hairlineWidth,
            borderColor: colors.divider,
          }}
        >
          <StorageUsageRow colors={colors} usedGB={usedGB} totalGB={totalGB} />

          {/* Clear Cache */}
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={async () => {
                Alert.alert('Clear Cache', 'This will clear cached data. Continue?', [
                  { text: 'Cancel', style: 'cancel' },
                  {
                    text: 'Clear',
                    style: 'destructive',
                    onPress: async () => {
                      try {
                        // remove cache directory contents
                        const cacheDir = RNFS.CachesDirectoryPath;
                        const items = await RNFS.readDir(cacheDir).catch(() => []);
                        for (const it of items) {
                          await RNFS.unlink(it.path).catch(() => {});
                        }
                        await refreshStorage();
                        Alert.alert('Done', 'Cache cleared');
                      } catch (e) {
                        console.warn('Clear cache failed', e);
                        Alert.alert('Error', 'Failed to clear cache');
                      }
                    },
                  },
                ]);
              }}
          >
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: 16,
                paddingVertical: 14,
              }}
            >
              <View
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 10,
                  backgroundColor: 'rgba(124,77,255,0.13)',
                  justifyContent: 'center',
                  alignItems: 'center',
                  marginRight: 14,
                }}
              >
                <MaterialCommunityIcons
                  name="broom"
                  size={20}
                  color={colors.primary}
                />
              </View>
              <Text
                style={{
                  fontFamily: 'Poppins-Medium',
                  fontSize: 14,
                  color: colors.textPrimary,
                  flex: 1,
                }}
              >
                Clear Cache
              </Text>
              <Text
                style={{
                  fontFamily: 'Poppins-Regular',
                  fontSize: 13,
                  color: colors.textMuted,
                  marginRight: 6,
                }}
              >
                {cacheSize}
              </Text>
              <MaterialCommunityIcons
                name="chevron-right"
                size={18}
                color={colors.textMuted}
              />
            </View>
          </TouchableOpacity>
        </View>

        {/* ── Others ── */}
        <SectionHeader title="Others" colors={colors} />
        <SettingsCard
          colors={colors}
          rows={[
            {
              icon: 'star',
              label: 'Rate Us',
              onPress: () => {
                const pkg = Platform.OS === 'android' ? 'com.medianest' : ''; // replace with actual bundle id if known
                const url = Platform.OS === 'android' ? `market://details?id=${pkg}` : 'https://apps.apple.com';
                Linking.openURL(url).catch(() => {
                  const web = Platform.OS === 'android' ? `https://play.google.com/store/apps/details?id=${pkg}` : 'https://apps.apple.com';
                  Linking.openURL(web).catch(() => {});
                });
              },
            },
            {
              icon: 'share-variant',
              label: 'Share App',
              onPress: async () => {
                try {
                  await Share.share({
                    title: 'Check out this app',
                    message: 'Check out this app: https://example.com',
                  });
                } catch (e) {
                  console.warn('Share failed', e);
                }
              },
            },
            {
              icon: 'shield-lock',
              label: 'Privacy Policy',
              onPress: () => Linking.openURL('https://example.com/privacy').catch(() => {}),
            },
            {
              icon: 'file-document',
              label: 'Terms of Service',
              onPress: () => Linking.openURL('https://example.com/terms').catch(() => {}),
            },
            {
              icon: 'information',
              label: 'About',
              value: 'v1.0.0',
              onPress: () => navigation.navigate('About'),
            },
          ]}
        />
      </ScrollView>
    </SafeAreaView>
  );
}
