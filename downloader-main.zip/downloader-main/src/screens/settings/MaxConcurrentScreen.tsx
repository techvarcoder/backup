import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';
import { loadSettings, saveSettings } from '../../services/storageService';

const OPTIONS = [1, 2, 3, 4, 5];

export default function MaxConcurrentScreen({ navigation }: any) {
  const colors = useColors();
  const [selected, setSelected] = useState(3);

  useEffect(() => {
    (async () => {
      const s = await loadSettings();
      setSelected(s.maxConcurrentDownloads || 3);
    })();
  }, []);

  const save = async (v: number) => {
    try {
      const s = await loadSettings();
      await saveSettings({ ...s, maxConcurrentDownloads: v });
      setSelected(v);
      navigation.goBack();
    } catch (e) {
      Alert.alert('Error', 'Failed to save setting');
    }
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ padding: 16, flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginRight: 12 }}>
            <MaterialCommunityIcons name="arrow-left" size={24} color={colors.primary} />
          </TouchableOpacity>
          <Text style={{ color: colors.textPrimary, fontSize: 20, fontWeight: '700' }}>
            Max Concurrent Downloads
          </Text>
        </View>
        {OPTIONS.map((o) => (
          <TouchableOpacity
            key={o}
            onPress={() => save(o)}
            style={{
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'space-between',
              padding: 14,
              backgroundColor: colors.card,
              marginBottom: 8,
              borderRadius: 10,
            }}
          >
            <Text style={{ color: colors.textPrimary, fontSize: 15 }}>
              {o} {o === 1 ? 'download' : 'downloads'}
            </Text>
            {selected === o && (
              <MaterialCommunityIcons name="check" size={20} color={colors.primary} />
            )}
          </TouchableOpacity>
        ))}
      </View>
    </SafeAreaView>
  );
}
