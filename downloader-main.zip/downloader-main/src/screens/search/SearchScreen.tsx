import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  clearSearches,
  deleteSearch,
  getRecentSearches,
  insertSearch,
} from '../../db/repositories/searchRepository';
import { useColors } from '../../theme';
import { libraryStore } from '../../stores/libraryStore';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

interface RecentSearch {
  id: string;
  query: string;
  createdAt: number;
}

type FilterType = 'All' | 'Videos' | 'Audio' | 'Downloads';

interface MediaItem {
  id: string;
  title: string;
  platform?: string;
  fileSize?: number;
  date?: number;
  type?: 'video' | 'audio';
  isDownloaded?: boolean;
  thumbnailUri?: string;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const SUGGESTED_SEARCHES = [
  'YouTube 4K',
  'Instagram Reels',
  'TikTok videos',
  'Twitter clips',
  'Facebook videos',
  'Shorts',
  'Music playlist',
  'Documentary',
];

function formatFileSize(bytes?: number): string {
  if (!bytes) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

function formatDate(timestamp?: number): string {
  if (!timestamp) return '';
  const d = new Date(timestamp);
  return d.toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

// ---------------------------------------------------------------------------
// SearchHeader
// ---------------------------------------------------------------------------

interface SearchHeaderProps {
  query: string;
  onChangeQuery: (text: string) => void;
  onClear: () => void;
  onBack: () => void;
  inputRef: React.RefObject<TextInput | null>;
  colors: ReturnType<typeof useColors>;
}

function SearchHeader({
  query,
  onChangeQuery,
  onClear,
  onBack,
  inputRef,
  colors,
}: SearchHeaderProps) {
  const styles = useMemo(() => makeHeaderStyles(colors), [colors]);

  return (
    <View style={styles.headerRow}>
      <Pressable
        onPress={onBack}
        hitSlop={8}
        accessibilityLabel="Go back"
        style={styles.backBtn}
      >
        <MaterialCommunityIcons name="arrow-left" size={24} color={colors.textPrimary} />
      </Pressable>

      <View style={styles.inputContainer}>
        <MaterialCommunityIcons
          name="magnify"
          size={20}
          color={colors.textSecondary}
          style={styles.searchIcon}
        />
        <TextInput
          ref={inputRef}
          style={styles.input}
          placeholder="Search videos, audio, downloads…"
          placeholderTextColor={colors.textSecondary}
          value={query}
          onChangeText={onChangeQuery}
          returnKeyType="search"
          autoCorrect={false}
          autoCapitalize="none"
          selectionColor={colors.primary}
          cursorColor={colors.primary}
          underlineColorAndroid="transparent"
          accessibilityLabel="Search input"
        />
        {query.length > 0 && (
          <Pressable
            onPress={onClear}
            hitSlop={8}
            accessibilityLabel="Clear search"
            style={styles.clearBtn}
          >
            <MaterialCommunityIcons
              name="close-circle"
              size={18}
              color={colors.textSecondary}
            />
          </Pressable>
        )}
      </View>
    </View>
  );
}

function makeHeaderStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    headerRow: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 12,
      paddingVertical: 10,
      backgroundColor: colors.surface,
      borderBottomWidth: 1,
      borderBottomColor: colors.divider,
    },
    backBtn: {
      padding: 4,
      marginRight: 8,
    },
    inputContainer: {
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.card,
      borderRadius: 10,
      paddingHorizontal: 10,
      height: 42,
    },
    searchIcon: {
      marginRight: 6,
    },
    input: {
      flex: 1,
      color: colors.textPrimary,
      fontSize: 15,
      paddingVertical: 0,
    },
    clearBtn: {
      padding: 2,
      marginLeft: 6,
    },
  });
}

// ---------------------------------------------------------------------------
// FilterChips
// ---------------------------------------------------------------------------

interface FilterChipsProps {
  active: FilterType;
  onSelect: (f: FilterType) => void;
  colors: ReturnType<typeof useColors>;
}

const FILTERS: FilterType[] = ['All', 'Videos', 'Audio', 'Downloads'];

function FilterChips({ active, onSelect, colors }: FilterChipsProps) {
  const styles = useMemo(() => makeFilterStyles(colors), [colors]);

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      contentContainerStyle={styles.row}
      style={styles.container}
    >
      {FILTERS.map(f => {
        const isActive = f === active;
        return (
          <Pressable
            key={f}
            onPress={() => onSelect(f)}
            style={[styles.chip, isActive && styles.chipActive]}
            accessibilityRole="button"
            accessibilityState={{ selected: isActive }}
          >
            <Text style={[styles.chipText, isActive && styles.chipTextActive]}>
              {f}
            </Text>
          </Pressable>
        );
      })}
    </ScrollView>
  );
}

function makeFilterStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: {
      backgroundColor: colors.surface,
      borderBottomWidth: 1,
      borderBottomColor: colors.divider,
    },
    row: {
      paddingHorizontal: 16,
      paddingVertical: 10,
      gap: 8,
      flexDirection: 'row',
      alignItems: 'center',
    },
    chip: {
      paddingHorizontal: 16,
      paddingVertical: 6,
      borderRadius: 20,
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.divider,
    },
    chipActive: {
      backgroundColor: colors.primary,
      borderColor: colors.primary,
    },
    chipText: {
      color: colors.textSecondary,
      fontSize: 13,
      fontWeight: '500',
    },
    chipTextActive: {
      color: '#FFFFFF',
      fontWeight: '700',
    },
  });
}

// ---------------------------------------------------------------------------
// ResultItem
// ---------------------------------------------------------------------------

interface ResultItemProps {
  item: MediaItem;
  onPress: (item: MediaItem) => void;
  colors: ReturnType<typeof useColors>;
}

function ResultItem({ item, onPress, colors }: ResultItemProps) {
  const styles = useMemo(() => makeResultStyles(colors), [colors]);

  return (
    <Pressable
      style={({ pressed }) => [styles.container, pressed && styles.pressed]}
      onPress={() => onPress(item)}
      accessibilityRole="button"
      accessibilityLabel={`Result: ${item.title}`}
    >
      <View style={styles.thumb}>
        {item.thumbnailUri ? (
          <Image
            source={{ uri: item.thumbnailUri }}
            style={styles.thumbImage}
            resizeMode="cover"
          />
        ) : (
          <View style={styles.thumbPlaceholder}>
            <MaterialCommunityIcons
              name={item.type === 'audio' ? 'music' : 'video'}
              size={24}
              color={colors.primary}
            />
          </View>
        )}
        {item.type === 'video' && (
          <View style={styles.typeTag}>
            <MaterialCommunityIcons name="play" size={10} color="#fff" />
          </View>
        )}
        {item.type === 'audio' && (
          <View style={[styles.typeTag, styles.typeTagAudio]}>
            <MaterialCommunityIcons name="music-note" size={10} color="#fff" />
          </View>
        )}
      </View>

      <View style={styles.meta}>
        <Text style={styles.title} numberOfLines={2}>
          {item.title}
        </Text>
        <View style={styles.metaRow}>
          {item.platform ? (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{item.platform}</Text>
            </View>
          ) : null}
          {item.fileSize ? (
            <Text style={styles.detail}>{formatFileSize(item.fileSize)}</Text>
          ) : null}
          {item.date ? (
            <Text style={styles.detail}>{formatDate(item.date)}</Text>
          ) : null}
        </View>
      </View>

      {item.isDownloaded && (
        <MaterialCommunityIcons
          name="check-circle"
          size={18}
          color={colors.secondary}
          style={styles.downloadedIcon}
        />
      )}
    </Pressable>
  );
}

function makeResultStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 16,
      paddingVertical: 12,
      gap: 12,
    },
    pressed: {
      backgroundColor: colors.card,
    },
    thumb: {
      width: 72,
      height: 52,
      borderRadius: 6,
      overflow: 'hidden',
      backgroundColor: colors.card,
      justifyContent: 'center',
      alignItems: 'center',
    },
    thumbImage: {
      width: '100%',
      height: '100%',
    },
    thumbPlaceholder: {
      width: '100%',
      height: '100%',
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: colors.card,
    },
    typeTag: {
      position: 'absolute',
      bottom: 3,
      right: 3,
      backgroundColor: colors.primary,
      borderRadius: 3,
      padding: 2,
    },
    typeTagAudio: {
      backgroundColor: colors.secondary,
    },
    meta: {
      flex: 1,
      gap: 4,
    },
    title: {
      color: colors.textPrimary,
      fontSize: 14,
      fontWeight: '600',
      lineHeight: 18,
    },
    metaRow: {
      flexDirection: 'row',
      alignItems: 'center',
      flexWrap: 'wrap',
      gap: 6,
    },
    badge: {
      backgroundColor: colors.card,
      borderRadius: 4,
      paddingHorizontal: 6,
      paddingVertical: 2,
      borderWidth: 1,
      borderColor: colors.divider,
    },
    badgeText: {
      color: colors.secondary,
      fontSize: 11,
      fontWeight: '600',
    },
    detail: {
      color: colors.textSecondary,
      fontSize: 12,
    },
    downloadedIcon: {
      marginLeft: 4,
    },
  });
}

// ---------------------------------------------------------------------------
// EmptyState (no query entered)
// ---------------------------------------------------------------------------

interface EmptyStateProps {
  recentSearches: RecentSearch[];
  onSelectRecent: (query: string) => void;
  onDeleteRecent: (id: string) => void;
  onClearAll: () => void;
  onSelectSuggested: (query: string) => void;
  colors: ReturnType<typeof useColors>;
}

function EmptyState({
  recentSearches,
  onSelectRecent,
  onDeleteRecent,
  onClearAll,
  onSelectSuggested,
  colors,
}: EmptyStateProps) {
  const styles = useMemo(() => makeEmptyStyles(colors), [colors]);

  return (
    <ScrollView style={styles.scroll} showsVerticalScrollIndicator={false}>
      {recentSearches.length > 0 && (
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Recent Searches</Text>
            <Pressable
              onPress={onClearAll}
              hitSlop={8}
              accessibilityLabel="Clear all recent searches"
            >
              <Text style={styles.clearAllText}>Clear all</Text>
            </Pressable>
          </View>
          <View style={styles.chipRow}>
            {recentSearches.map(rs => (
              <View key={rs.id} style={styles.recentChip}>
                <Pressable
                  onPress={() => onSelectRecent(rs.query)}
                  style={styles.recentChipLabel}
                  accessibilityRole="button"
                  accessibilityLabel={`Search for ${rs.query}`}
                >
                  <MaterialCommunityIcons
                    name="history"
                    size={14}
                    color={colors.textSecondary}
                    style={styles.historyIcon}
                  />
                  <Text style={styles.recentChipText} numberOfLines={1}>
                    {rs.query}
                  </Text>
                </Pressable>
                <Pressable
                  onPress={() => onDeleteRecent(rs.id)}
                  hitSlop={6}
                  accessibilityLabel={`Remove ${rs.query} from recent searches`}
                  style={styles.deleteBtn}
                >
                  <MaterialCommunityIcons
                    name="close"
                    size={12}
                    color={colors.textSecondary}
                  />
                </Pressable>
              </View>
            ))}
          </View>
        </View>
      )}

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Suggested Searches</Text>
        <View style={styles.chipRow}>
          {SUGGESTED_SEARCHES.map(s => (
            <Pressable
              key={s}
              style={styles.suggestedChip}
              onPress={() => onSelectSuggested(s)}
              accessibilityRole="button"
              accessibilityLabel={`Search for ${s}`}
            >
              <MaterialCommunityIcons
                name="magnify"
                size={14}
                color={colors.primary}
                style={styles.suggestIcon}
              />
              <Text style={styles.suggestedText}>{s}</Text>
            </Pressable>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}

function makeEmptyStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    scroll: {
      flex: 1,
    },
    section: {
      paddingHorizontal: 16,
      paddingTop: 24,
      paddingBottom: 8,
    },
    sectionHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 12,
    },
    sectionTitle: {
      color: colors.textPrimary,
      fontSize: 16,
      fontWeight: '700',
    },
    clearAllText: {
      color: colors.primary,
      fontSize: 13,
      fontWeight: '600',
    },
    chipRow: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: 8,
    },
    recentChip: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.card,
      borderRadius: 20,
      paddingLeft: 10,
      paddingRight: 6,
      paddingVertical: 6,
      borderWidth: 1,
      borderColor: colors.divider,
      maxWidth: 200,
    },
    recentChipLabel: {
      flexDirection: 'row',
      alignItems: 'center',
      flexShrink: 1,
    },
    historyIcon: {
      marginRight: 4,
    },
    recentChipText: {
      color: colors.textPrimary,
      fontSize: 13,
      flexShrink: 1,
    },
    deleteBtn: {
      marginLeft: 6,
      padding: 2,
    },
    suggestedChip: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: colors.card,
      borderRadius: 20,
      paddingHorizontal: 12,
      paddingVertical: 7,
      borderWidth: 1,
      borderColor: colors.divider,
    },
    suggestIcon: {
      marginRight: 4,
    },
    suggestedText: {
      color: colors.textSecondary,
      fontSize: 13,
    },
  });
}

// ---------------------------------------------------------------------------
// NoResults state
// ---------------------------------------------------------------------------

interface NoResultsProps {
  query: string;
  onSelectSuggested: (query: string) => void;
  colors: ReturnType<typeof useColors>;
}

function NoResults({ query, onSelectSuggested, colors }: NoResultsProps) {
  const styles = useMemo(() => makeNoResultsStyles(colors), [colors]);

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.illustration}>
        <MaterialCommunityIcons
          name="magnify-remove-outline"
          size={72}
          color={colors.divider}
        />
      </View>
      <Text style={styles.title}>No results for "{query}"</Text>
      <Text style={styles.subtitle}>
        Try a different keyword or browse suggestions below.
      </Text>

      <View style={styles.suggestions}>
        <Text style={styles.suggestLabel}>Try searching for</Text>
        <View style={styles.chipRow}>
          {SUGGESTED_SEARCHES.slice(0, 6).map(s => (
            <Pressable
              key={s}
              style={styles.chip}
              onPress={() => onSelectSuggested(s)}
              accessibilityRole="button"
            >
              <Text style={styles.chipText}>{s}</Text>
            </Pressable>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}

function makeNoResultsStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: {
      flex: 1,
    },
    content: {
      alignItems: 'center',
      paddingHorizontal: 32,
      paddingTop: 60,
      paddingBottom: 40,
    },
    illustration: {
      width: 120,
      height: 120,
      borderRadius: 60,
      backgroundColor: colors.card,
      justifyContent: 'center',
      alignItems: 'center',
      marginBottom: 24,
    },
    title: {
      color: colors.textPrimary,
      fontSize: 20,
      fontWeight: '700',
      textAlign: 'center',
      marginBottom: 10,
    },
    subtitle: {
      color: colors.textSecondary,
      fontSize: 14,
      textAlign: 'center',
      lineHeight: 20,
      marginBottom: 36,
    },
    suggestions: {
      width: '100%',
    },
    suggestLabel: {
      color: colors.textSecondary,
      fontSize: 13,
      fontWeight: '600',
      marginBottom: 12,
      textTransform: 'uppercase',
      letterSpacing: 0.5,
    },
    chipRow: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      gap: 8,
    },
    chip: {
      backgroundColor: colors.card,
      borderRadius: 20,
      paddingHorizontal: 14,
      paddingVertical: 7,
      borderWidth: 1,
      borderColor: colors.divider,
    },
    chipText: {
      color: colors.textSecondary,
      fontSize: 13,
    },
  });
}

// ---------------------------------------------------------------------------
// SearchScreen (main export)
// ---------------------------------------------------------------------------

interface SearchScreenProps {
  navigation?: {
    goBack: () => void;
    navigate: (screen: string, params?: Record<string, unknown>) => void;
  };
}

export default function SearchScreen({ navigation }: SearchScreenProps) {
  const colors = useColors();

  // State
  const [rawQuery, setRawQuery] = useState('');
  const [debouncedQuery, setDebouncedQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<FilterType>('All');
  const [recentSearches, setRecentSearches] = useState<RecentSearch[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Refs
  const inputRef = useRef<TextInput>(null);
  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Media from store
  const allMedia: MediaItem[] = (libraryStore as any)().allMedia ?? [];

  // Auto-focus input on mount
  useEffect(() => {
    const t = setTimeout(() => inputRef.current?.focus(), 100);
    return () => clearTimeout(t);
  }, []);

  // Load recent searches on mount
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const searches = await getRecentSearches();
        if (!cancelled) setRecentSearches(searches);
      } catch {
        // recent searches are non-critical — silently ignore errors
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Cleanup debounce timer on unmount
  useEffect(() => {
    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
    };
  }, []);

  // Debounced query update (300 ms)
  const handleQueryChange = useCallback((text: string) => {
    setRawQuery(text);

    if (debounceTimer.current) clearTimeout(debounceTimer.current);

    if (text.trim() === '') {
      setDebouncedQuery('');
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    debounceTimer.current = setTimeout(() => {
      setDebouncedQuery(text.trim());
      setIsSearching(false);
    }, 300);
  }, []);

  // Persist each settled search to history
  useEffect(() => {
    if (!debouncedQuery) return;
    let cancelled = false;
    (async () => {
      try {
        await insertSearch(debouncedQuery);
        const updated = await getRecentSearches();
        if (!cancelled) setRecentSearches(updated);
      } catch {
        // non-critical
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [debouncedQuery]);

  // Filtered results
  const filteredResults = useMemo<MediaItem[]>(() => {
    if (!debouncedQuery) return [];
    const q = debouncedQuery.toLowerCase();
    return allMedia.filter(item => {
      const matchesQuery = item.title?.toLowerCase().includes(q);
      if (!matchesQuery) return false;
      switch (activeFilter) {
        case 'Videos':
          return item.type === 'video';
        case 'Audio':
          return item.type === 'audio';
        case 'Downloads':
          return item.isDownloaded === true;
        default:
          return true;
      }
    });
  }, [debouncedQuery, allMedia, activeFilter]);

  // Handlers
  const handleBack = useCallback(() => {
    navigation?.goBack();
  }, [navigation]);

  const handleClear = useCallback(() => {
    setRawQuery('');
    setDebouncedQuery('');
    setIsSearching(false);
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    inputRef.current?.focus();
  }, []);

  const handleSelectRecent = useCallback(
    (query: string) => {
      setRawQuery(query);
      handleQueryChange(query);
    },
    [handleQueryChange],
  );

  const handleDeleteRecent = useCallback(async (id: string) => {
    try {
      await deleteSearch(id);
      setRecentSearches(prev => prev.filter(r => r.id !== id));
    } catch {
      // non-critical
    }
  }, []);

  const handleClearAll = useCallback(async () => {
    try {
      await clearSearches();
      setRecentSearches([]);
    } catch {
      // non-critical
    }
  }, []);

  const handleSelectSuggested = useCallback(
    (query: string) => {
      setRawQuery(query);
      handleQueryChange(query);
    },
    [handleQueryChange],
  );

  const handleResultPress = useCallback(
    (item: MediaItem) => {
      navigation?.navigate('MediaDetail', { id: item.id });
    },
    [navigation],
  );

  // FlatList helpers
  const renderResult = useCallback(
    ({ item }: { item: MediaItem }) => (
      <ResultItem item={item} onPress={handleResultPress} colors={colors} />
    ),
    [handleResultPress, colors],
  );

  const keyExtractor = useCallback((item: MediaItem) => item.id, []);

  const styles = useMemo(() => makeStyles(colors), [colors]);

  const ItemSeparator = useCallback(
    () => <View style={styles.separator} />,
    [styles],
  );

  const ListHeader = useMemo(
    () => (
      <Text style={styles.resultCount}>
        {filteredResults.length} result
        {filteredResults.length !== 1 ? 's' : ''}
      </Text>
    ),
    [filteredResults.length, styles.resultCount],
  );

  // Derived view state
  const showResults = debouncedQuery.length > 0;
  const hasResults = filteredResults.length > 0;

  return (
    <View style={styles.container}>
      <SearchHeader
        query={rawQuery}
        onChangeQuery={handleQueryChange}
        onClear={handleClear}
        onBack={handleBack}
        inputRef={inputRef}
        colors={colors}
      />

      {isSearching ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : !showResults ? (
        <EmptyState
          recentSearches={recentSearches}
          onSelectRecent={handleSelectRecent}
          onDeleteRecent={handleDeleteRecent}
          onClearAll={handleClearAll}
          onSelectSuggested={handleSelectSuggested}
          colors={colors}
        />
      ) : (
        <>
          <FilterChips
            active={activeFilter}
            onSelect={setActiveFilter}
            colors={colors}
          />

          {hasResults ? (
            <FlatList
              data={filteredResults}
              renderItem={renderResult}
              keyExtractor={keyExtractor}
              ItemSeparatorComponent={ItemSeparator}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={styles.listContent}
              ListHeaderComponent={ListHeader}
            />
          ) : (
            <NoResults
              query={debouncedQuery}
              onSelectSuggested={handleSelectSuggested}
              colors={colors}
            />
          )}
        </>
      )}
    </View>
  );
}

// ---------------------------------------------------------------------------
// Root styles
// ---------------------------------------------------------------------------

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    loadingContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    separator: {
      height: 1,
      backgroundColor: colors.divider,
      // indent past thumbnail + gap to align with text column
      marginLeft: 16 + 72 + 12,
    },
    listContent: {
      paddingBottom: 24,
    },
    resultCount: {
      color: colors.textSecondary,
      fontSize: 13,
      paddingHorizontal: 16,
      paddingTop: 14,
      paddingBottom: 4,
    },
  });
}
