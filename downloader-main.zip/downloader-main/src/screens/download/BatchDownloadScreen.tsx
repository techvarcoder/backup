import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Alert,
  Clipboard,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';
import { useDownloadStore } from '../../stores/downloadStore';
import { mediaAnalysisService } from '../../services/mediaAnalysisService';

type UrlStatus = 'pending' | 'analyzing' | 'queued' | 'downloading' | 'completed' | 'failed';

interface BatchItem {
  id: string;
  url: string;
  status: UrlStatus;
  title?: string;
  error?: string;
  progress?: number;
}

const STATUS_ICON: Record<UrlStatus, string> = {
  pending: 'clock-outline',
  analyzing: 'loading',
  queued: 'timer-sand',
  downloading: 'download',
  completed: 'check-circle',
  failed: 'alert-circle',
};

const STATUS_COLOR: Record<UrlStatus, string> = {
  pending: '#6B7280',
  analyzing: '#7C4DFF',
  queued: '#FFC107',
  downloading: '#00E5FF',
  completed: '#00C853',
  failed: '#FF5252',
};

export default function BatchDownloadScreen({ navigation }: any) {
  const colors = useColors();
  const { addDownload } = useDownloadStore();

  const [inputText, setInputText] = useState('');
  const [items, setItems] = useState<BatchItem[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  const parseUrls = (text: string): string[] =>
    text
      .split(/[\n,]/)
      .map((u) => u.trim())
      .filter((u) => u.startsWith('http'));

  const updateItem = useCallback((id: string, update: Partial<BatchItem>) => {
    setItems((prev) => prev.map((item) => (item.id === id ? { ...item, ...update } : item)));
  }, []);

  const handleAddUrls = () => {
    const urls = parseUrls(inputText);
    if (urls.length === 0) {
      Alert.alert('No URLs', 'Enter at least one valid URL (http/https)');
      return;
    }
    const newItems: BatchItem[] = urls.map((url) => ({
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      url,
      status: 'pending',
    }));
    setItems((prev) => {
      const existingUrls = new Set(prev.map((i) => i.url));
      return [...prev, ...newItems.filter((i) => !existingUrls.has(i.url))];
    });
    setInputText('');
  };

  const handlePaste = async () => {
    try {
      const text = await Clipboard.getString();
      if (text) setInputText((prev) => (prev ? `${prev}\n${text.trim()}` : text.trim()));
    } catch {
      // clipboard unavailable
    }
  };

  const handleRemove = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  const handleRetry = (id: string) => {
    updateItem(id, { status: 'pending', error: undefined });
  };

  const handleDownloadAll = async () => {
    const pending = items.filter((i) => i.status === 'pending' || i.status === 'failed');
    if (pending.length === 0) {
      Alert.alert('Nothing to download', 'All items are already queued or completed.');
      return;
    }

    setIsRunning(true);

    for (const item of pending) {
      updateItem(item.id, { status: 'analyzing' });
      try {
        const analysis = await mediaAnalysisService.analyzeUrl(item.url);
        const title = analysis?.title || item.url;
        updateItem(item.id, { status: 'queued', title });

        await addDownload({
          url: item.url,
          title,
          thumbnailUrl: analysis?.thumbnail || '',
          platform: analysis?.platform || 'unknown',
          duration: analysis?.duration || 0,
          quality: '720p',
          format: 'mp4',
          fileSize: 0,
          downloadedBytes: 0,
          progress: 0,
          status: 'pending',
          filePath: '',
          errorMessage: null,
          retryCount: 0,
        });

        updateItem(item.id, { status: 'completed' });
      } catch (err: any) {
        updateItem(item.id, { status: 'failed', error: err?.message || 'Failed to analyze' });
      }
    }

    setIsRunning(false);
  };

  const handlePauseAll = () => {
    setItems((prev) =>
      prev.map((i) => (i.status === 'downloading' ? { ...i, status: 'pending' } : i))
    );
  };

  const handleClearAll = () => {
    if (items.length === 0) return;
    Alert.alert('Clear All', 'Remove all items from the queue?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Clear', style: 'destructive', onPress: () => setItems([]) },
    ]);
  };

  const pendingCount = items.filter((i) => i.status === 'pending' || i.status === 'failed').length;
  const completedCount = items.filter((i) => i.status === 'completed').length;
  const failedCount = items.filter((i) => i.status === 'failed').length;

  const renderItem = ({ item }: { item: BatchItem }) => (
    <View
      style={{
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: colors.card,
        borderRadius: 10,
        padding: 12,
        marginBottom: 8,
        borderWidth: 1,
        borderColor: colors.border,
        gap: 10,
      }}
    >
      {item.status === 'analyzing' ? (
        <ActivityIndicator size="small" color={STATUS_COLOR[item.status]} />
      ) : (
        <MaterialCommunityIcons
          name={STATUS_ICON[item.status] as any}
          size={20}
          color={STATUS_COLOR[item.status]}
        />
      )}

      <View style={{ flex: 1 }}>
        <Text style={{ color: colors.textPrimary, fontSize: 12, fontWeight: '500' }} numberOfLines={1}>
          {item.title || item.url}
        </Text>
        {item.title && (
          <Text style={{ color: colors.textMuted, fontSize: 10, marginTop: 2 }} numberOfLines={1}>
            {item.url}
          </Text>
        )}
        {item.error && (
          <Text style={{ color: STATUS_COLOR.failed, fontSize: 10, marginTop: 2 }}>{item.error}</Text>
        )}
        <Text style={{ color: STATUS_COLOR[item.status], fontSize: 10, marginTop: 2, textTransform: 'capitalize' }}>
          {item.status}
        </Text>
      </View>

      <View style={{ flexDirection: 'row', gap: 4 }}>
        {item.status === 'failed' && (
          <TouchableOpacity
            onPress={() => handleRetry(item.id)}
            style={{ padding: 6, borderRadius: 6, backgroundColor: `${STATUS_COLOR.failed}22` }}
          >
            <MaterialCommunityIcons name="refresh" size={16} color={STATUS_COLOR.failed} />
          </TouchableOpacity>
        )}
        {(item.status === 'pending' || item.status === 'failed') && (
          <TouchableOpacity
            onPress={() => handleRemove(item.id)}
            style={{ padding: 6, borderRadius: 6, backgroundColor: `${colors.border}` }}
          >
            <MaterialCommunityIcons name="close" size={16} color={colors.textMuted} />
          </TouchableOpacity>
        )}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      {/* Header */}
      <View style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingTop: 12, paddingBottom: 12, gap: 12 }}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={{ flex: 1, fontSize: 18, fontWeight: '700', color: colors.textPrimary }}>Batch Download</Text>
        {items.length > 0 && (
          <TouchableOpacity onPress={handleClearAll}>
            <Text style={{ color: colors.error, fontSize: 13, fontWeight: '500' }}>Clear All</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Stats row */}
      {items.length > 0 && (
        <View style={{ flexDirection: 'row', paddingHorizontal: 16, gap: 8, marginBottom: 12 }}>
          {[
            { label: 'Total', count: items.length, color: colors.textSecondary },
            { label: 'Done', count: completedCount, color: STATUS_COLOR.completed },
            { label: 'Failed', count: failedCount, color: STATUS_COLOR.failed },
            { label: 'Pending', count: pendingCount, color: STATUS_COLOR.pending },
          ].map((stat) => (
            <View
              key={stat.label}
              style={{ flex: 1, backgroundColor: colors.card, borderRadius: 8, padding: 8, alignItems: 'center', borderWidth: 1, borderColor: colors.border }}
            >
              <Text style={{ color: stat.color, fontWeight: '700', fontSize: 16 }}>{stat.count}</Text>
              <Text style={{ color: colors.textMuted, fontSize: 10 }}>{stat.label}</Text>
            </View>
          ))}
        </View>
      )}

      {/* URL Input */}
      <View style={{ paddingHorizontal: 16, marginBottom: 12 }}>
        <View style={{ backgroundColor: colors.card, borderRadius: 12, padding: 12, borderWidth: 1, borderColor: colors.border }}>
          <TextInput
            placeholder="Paste URLs here (one per line)..."
            placeholderTextColor={colors.textMuted}
            multiline
            numberOfLines={4}
            value={inputText}
            onChangeText={setInputText}
            style={{
              color: colors.textPrimary,
              fontSize: 12,
              fontFamily: 'monospace',
              minHeight: 80,
              textAlignVertical: 'top',
            }}
          />
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 10 }}>
            <TouchableOpacity
              onPress={handlePaste}
              style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: colors.surface, borderRadius: 8, paddingVertical: 10, gap: 6, borderWidth: 1, borderColor: colors.border }}
            >
              <MaterialCommunityIcons name="content-paste" size={16} color={colors.textSecondary} />
              <Text style={{ color: colors.textSecondary, fontSize: 13, fontWeight: '500' }}>Paste</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleAddUrls}
              disabled={!inputText.trim()}
              style={{ flex: 2, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: colors.primary, borderRadius: 8, paddingVertical: 10, gap: 6, opacity: inputText.trim() ? 1 : 0.5 }}
            >
              <MaterialCommunityIcons name="plus" size={16} color="#fff" />
              <Text style={{ color: '#fff', fontSize: 13, fontWeight: '600' }}>Add to Queue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {/* Queue List */}
      <FlatList
        data={items}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 100 }}
        ListEmptyComponent={
          <View style={{ alignItems: 'center', paddingTop: 48 }}>
            <MaterialCommunityIcons name="download-multiple" size={64} color={colors.border} />
            <Text style={{ color: colors.textMuted, marginTop: 12, fontSize: 14 }}>No URLs in queue</Text>
            <Text style={{ color: colors.textMuted, fontSize: 12, marginTop: 4 }}>Paste URLs above to get started</Text>
          </View>
        }
      />

      {/* Bottom Action Bar */}
      {items.length > 0 && (
        <View style={{ position: 'absolute', bottom: 0, left: 0, right: 0, backgroundColor: colors.background, borderTopWidth: 1, borderTopColor: colors.border, padding: 16, flexDirection: 'row', gap: 10 }}>
          <TouchableOpacity
            onPress={handlePauseAll}
            disabled={!isRunning}
            style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: colors.card, borderRadius: 10, paddingVertical: 14, gap: 6, borderWidth: 1, borderColor: colors.border, opacity: isRunning ? 1 : 0.4 }}
          >
            <MaterialCommunityIcons name="pause" size={20} color={colors.textPrimary} />
            <Text style={{ color: colors.textPrimary, fontWeight: '600', fontSize: 14 }}>Pause All</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={handleDownloadAll}
            disabled={isRunning || pendingCount === 0}
            style={{ flex: 2, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: colors.primary, borderRadius: 10, paddingVertical: 14, gap: 6, opacity: isRunning || pendingCount === 0 ? 0.5 : 1 }}
          >
            {isRunning ? (
              <ActivityIndicator color="#fff" size="small" />
            ) : (
              <MaterialCommunityIcons name="download" size={20} color="#fff" />
            )}
            <Text style={{ color: '#fff', fontWeight: '700', fontSize: 14 }}>
              {isRunning ? 'Running...' : `Download All (${pendingCount})`}
            </Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
}
