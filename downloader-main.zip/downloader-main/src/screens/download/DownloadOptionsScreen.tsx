import React, { useState } from 'react';
import { View, ScrollView, Text, TouchableOpacity, Alert, Linking } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';
import { useDownloadStore } from '../../stores/downloadStore';
import { requestDownloadPermissions } from '../../services/permissionService';
import { StreamFormat } from '../../services/mediaAnalysisService';

type Props = NativeStackScreenProps<any, 'DownloadOptions'>;

interface DownloadChoice {
  key: string;
  label: string;
  format: StreamFormat;
  kind: 'video' | 'audio';
}

export default function DownloadOptionsScreen({ route, navigation }: Props) {
  const colors = useColors();
  const { analysis, url } = (route.params as any) || {};
  const addDownload = useDownloadStore((state) => state.addDownload);

  // Build the list of real, downloadable options from the analyzed stream formats.
  const formats: StreamFormat[] = analysis?.formats || [];
  const videoFormats = formats
    .filter((f) => f.hasVideo && f.hasAudio && f.url)
    .sort((a, b) => parseInt(b.quality) - parseInt(a.quality));
  const audioFormat = formats.find((f) => !f.hasVideo && f.hasAudio && f.url);

  const choices: DownloadChoice[] = [
    ...videoFormats.map((f) => ({
      key: `v-${f.itag}`,
      label: `${f.quality || 'Video'} · MP4`,
      format: f,
      kind: 'video' as const,
    })),
    ...(audioFormat
      ? [
          {
            key: `a-${audioFormat.itag}`,
            label: 'Audio only · M4A',
            format: audioFormat,
            kind: 'audio' as const,
          },
        ]
      : []),
  ];

  const [selectedKey, setSelectedKey] = useState(choices[0]?.key);

  const sanitize = (name: string) =>
    (name || 'video').replace(/[^a-z0-9]+/gi, '_').replace(/^_+|_+$/g, '').slice(0, 60) || 'video';

  const handleStartDownload = async () => {
    if (!analysis) {
      Alert.alert('Error', 'Video data is not available.');
      return;
    }

    const choice = choices.find((c) => c.key === selectedKey);
    if (!choice || !choice.format?.url) {
      Alert.alert(
        'Unavailable',
        'No downloadable stream was found for this video. It may be age-restricted or protected.',
      );
      return;
    }

    const ok = await requestDownloadPermissions();
    if (!ok) {
      Alert.alert(
        'Permissions required',
        'Storage permissions are required to save downloads. Please grant permissions in Settings.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Open Settings', onPress: () => Linking.openSettings() },
        ],
      );
      return;
    }

    const fmt = choice.format;
    const safeTitle = sanitize(analysis.title);
    const qualityTag = choice.kind === 'audio' ? 'audio' : fmt.quality || 'video';
    const fileName = `${safeTitle}_${qualityTag}.${fmt.ext}`;

    await addDownload({
      url: fmt.url, // real stream URL, not the watch page
      title: analysis.title,
      platform: analysis.platform,
      thumbnailUrl: analysis.thumbnailUrl || analysis.thumbnail,
      duration: analysis.duration,
      fileSize: fmt.contentLength || 0,
      downloadedBytes: 0,
      progress: 0,
      status: 'pending',
      quality: qualityTag,
      format: fmt.ext,
      filePath: `/downloads/${fileName}`,
      errorMessage: null,
      retryCount: 0,
    });
    navigation.navigate('DownloadsTab', { screen: 'DownloadManager' });
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView style={{ padding: 16 }}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginBottom: 20 }}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={colors.primary} />
        </TouchableOpacity>

        <Text style={{ fontSize: 20, fontWeight: '700', color: colors.textPrimary, marginBottom: 12 }}>
          Choose Quality & Format
        </Text>

        {choices.length === 0 ? (
          <View style={{ backgroundColor: colors.card, padding: 16, borderRadius: 8 }}>
            <Text style={{ color: colors.textSecondary }}>
              No downloadable streams were found for this video. It may be age-restricted,
              private, or unsupported.
            </Text>
          </View>
        ) : (
          choices.map((c) => (
            <TouchableOpacity
              key={c.key}
              onPress={() => setSelectedKey(c.key)}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                backgroundColor: selectedKey === c.key ? colors.primary : colors.card,
                padding: 14,
                marginBottom: 8,
                borderRadius: 8,
              }}
            >
              <MaterialCommunityIcons
                name={selectedKey === c.key ? 'radiobox-marked' : 'radiobox-blank'}
                size={20}
                color={selectedKey === c.key ? '#fff' : colors.primary}
              />
              <Text
                style={{
                  marginLeft: 12,
                  fontWeight: '600',
                  flex: 1,
                  color: selectedKey === c.key ? '#fff' : colors.textPrimary,
                }}
              >
                {c.label}
              </Text>
              <MaterialCommunityIcons
                name={c.kind === 'audio' ? 'music' : 'video'}
                size={18}
                color={selectedKey === c.key ? '#fff' : colors.textMuted}
              />
            </TouchableOpacity>
          ))
        )}

        <TouchableOpacity
          onPress={handleStartDownload}
          disabled={choices.length === 0}
          style={{
            backgroundColor: choices.length === 0 ? colors.card : colors.primary,
            padding: 14,
            borderRadius: 8,
            alignItems: 'center',
            marginTop: 24,
            opacity: choices.length === 0 ? 0.6 : 1,
          }}
        >
          <Text style={{ color: '#fff', fontWeight: '600', fontSize: 16 }}>Start Download</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}
