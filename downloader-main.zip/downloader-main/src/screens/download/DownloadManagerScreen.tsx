import React, { useEffect } from 'react';
import { View, ScrollView, Text, TouchableOpacity, FlatList } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';
import { useDownloadStore } from '../../stores/downloadStore';

export default function DownloadManagerScreen() {
  const colors = useColors();
  const { activeDownloads, completedDownloads, loadFromDatabase } = useDownloadStore();

  useEffect(() => {
    loadFromDatabase();
  }, []);

  const renderDownloadItem = (item: any) => (
    <View style={{ backgroundColor: colors.card, borderRadius: 8, padding: 12, marginBottom: 8, borderWidth: 1, borderColor: colors.divider }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <Text style={{ fontSize: 14, fontWeight: '600', color: colors.textPrimary, flex: 1 }} numberOfLines={1}>{item.title}</Text>
        <MaterialCommunityIcons name="download" size={20} color={colors.primary} />
      </View>
      <View style={{ height: 6, backgroundColor: colors.surface, borderRadius: 3, marginBottom: 8, overflow: 'hidden' }}>
        <View style={{ height: '100%', backgroundColor: colors.primary, width: `${item.progress}%` }} />
      </View>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={{ fontSize: 12, color: colors.textMuted }}>{item.progress}%</Text>
        <Text style={{ fontSize: 12, color: colors.textMuted }}>{Math.round(item.downloadedBytes / 1024 / 1024)}MB</Text>
      </View>
    </View>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView style={{ padding: 16 }}>
        <Text style={{ fontSize: 24, fontWeight: '700', color: colors.textPrimary, marginBottom: 16 }}>Downloads</Text>

        {activeDownloads.length > 0 && (
          <>
            <Text style={{ fontSize: 14, fontWeight: '600', color: colors.textSecondary, marginBottom: 12 }}>Active ({activeDownloads.length})</Text>
            {activeDownloads.map((item) => (
              <View key={item.id}>{renderDownloadItem(item)}</View>
            ))}
          </>
        )}

        {completedDownloads.length > 0 && (
          <>
            <Text style={{ fontSize: 14, fontWeight: '600', color: colors.textSecondary, marginBottom: 12, marginTop: 16 }}>Completed ({completedDownloads.length})</Text>
            {completedDownloads.map((item) => (
              <View key={item.id} style={{ backgroundColor: colors.card, borderRadius: 8, padding: 12, marginBottom: 8, borderWidth: 1, borderColor: colors.divider }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                  <Text style={{ fontSize: 14, fontWeight: '600', color: colors.textPrimary, flex: 1 }} numberOfLines={1}>{item.title}</Text>
                  <MaterialCommunityIcons name="check-circle" size={20} color={colors.success} />
                </View>
              </View>
            ))}
          </>
        )}

        {activeDownloads.length === 0 && completedDownloads.length === 0 && (
          <View style={{ alignItems: 'center', paddingVertical: 40 }}>
            <MaterialCommunityIcons name="download-outline" size={48} color={colors.textMuted} />
            <Text style={{ marginTop: 12, color: colors.textMuted }}>No downloads yet</Text>
            <Text style={{ fontSize: 12, color: colors.textMuted, marginTop: 8 }}>Start by pasting a URL on the Home screen</Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}
