import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';
import Slider from '@react-native-community/slider';
import { usePlayerStore } from '../../stores/playerStore';

export default function AudioPlayerScreen({ navigation }: any) {
  const colors = useColors();
  const [isPlaying, setIsPlaying] = useState(false);
  const [sleepTimer, setSleepTimer] = useState(0);
  const { playAudio, pauseAudio, setSleepTimer: storeSleepTimer } = usePlayerStore();

  const togglePlay = () => {
    if (isPlaying) pauseAudio();
    else playAudio('media-id');
    setIsPlaying(!isPlaying);
  };

  const handleSleepTimer = (minutes: number) => {
    setSleepTimer(minutes);
    storeSleepTimer(minutes);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView style={{ padding: 16 }}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginBottom: 20 }}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={colors.primary} />
        </TouchableOpacity>

        <View style={{ height: 300, backgroundColor: colors.card, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginBottom: 24 }}>
          <MaterialCommunityIcons name="music" size={100} color={colors.primary} />
        </View>

        <Text style={{ fontSize: 20, fontWeight: '700', color: colors.textPrimary, marginBottom: 8, textAlign: 'center' }}>Song Title</Text>
        <Text style={{ fontSize: 14, color: colors.textSecondary, marginBottom: 24, textAlign: 'center' }}>Artist Name</Text>

        <Slider style={{ height: 40, marginBottom: 12 }} minimumValue={0} maximumValue={100} minimumTrackTintColor={colors.primary} maximumTrackTintColor={colors.divider} />

        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 24 }}>
          <Text style={{ fontSize: 12, color: colors.textMuted }}>2:34</Text>
          <Text style={{ fontSize: 12, color: colors.textMuted }}>5:48</Text>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: 'space-around', marginBottom: 24 }}>
          <TouchableOpacity style={{ alignItems: 'center' }}>
            <MaterialCommunityIcons name="shuffle" size={28} color={colors.textSecondary} />
          </TouchableOpacity>
          <TouchableOpacity style={{ alignItems: 'center' }}>
            <MaterialCommunityIcons name="skip-previous" size={32} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity onPress={togglePlay} style={{ alignItems: 'center' }}>
            <MaterialCommunityIcons name={isPlaying ? 'pause-circle' : 'play-circle'} size={48} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity style={{ alignItems: 'center' }}>
            <MaterialCommunityIcons name="skip-next" size={32} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity style={{ alignItems: 'center' }}>
            <MaterialCommunityIcons name="repeat" size={28} color={colors.textSecondary} />
          </TouchableOpacity>
        </View>

        <View style={{ backgroundColor: colors.card, borderRadius: 8, padding: 12, marginBottom: 16, borderWidth: 1, borderColor: colors.divider }}>
          <Text style={{ fontSize: 12, fontWeight: '600', color: colors.textPrimary, marginBottom: 12 }}>Sleep Timer</Text>
          <View style={{ flexDirection: 'row', gap: 8 }}>
            {[0, 5, 10, 30].map((mins) => (
              <TouchableOpacity
                key={mins}
                onPress={() => handleSleepTimer(mins)}
                style={{ flex: 1, backgroundColor: sleepTimer === mins ? colors.primary : colors.surface, padding: 8, borderRadius: 6, alignItems: 'center' }}
              >
                <Text style={{ color: sleepTimer === mins ? '#fff' : colors.textPrimary, fontWeight: '600' }}>{mins || 'Off'}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
