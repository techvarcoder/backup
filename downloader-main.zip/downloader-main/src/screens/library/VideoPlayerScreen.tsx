import React, { useState } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import Slider from '@react-native-community/slider';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';
import { usePlayerStore } from '../../stores/playerStore';

export default function VideoPlayerScreen({ route, navigation }: any) {
  const colors = useColors();
  const { mediaId } = route.params;
  const [isPlaying, setIsPlaying] = useState(false);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(100);
  const { playVideo, pauseVideo, seekVideo, updateVideoPosition } = usePlayerStore();

  const togglePlay = () => {
    if (isPlaying) {
      pauseVideo();
    } else {
      playVideo(mediaId);
    }
    setIsPlaying(!isPlaying);
  };

  const handleSeek = (value: number) => {
    setPosition(value);
    seekVideo(value);
    updateVideoPosition(value);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ flex: 1, padding: 16 }}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={{ marginBottom: 20 }}>
          <MaterialCommunityIcons name="arrow-left" size={24} color={colors.primary} />
        </TouchableOpacity>

        <View style={{ flex: 0.5, backgroundColor: colors.card, borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginBottom: 20 }}>
          <MaterialCommunityIcons name="play-circle" size={80} color={colors.primary} />
        </View>

        <Text style={{ fontSize: 18, fontWeight: '700', color: colors.textPrimary, marginBottom: 12 }}>Video Title</Text>

        <Slider
          style={{ height: 40, marginBottom: 12 }}
          minimumValue={0}
          maximumValue={duration}
          value={position}
          onValueChange={handleSeek}
          minimumTrackTintColor={colors.primary}
          maximumTrackTintColor={colors.divider}
        />

        <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 }}>
          <Text style={{ fontSize: 12, color: colors.textMuted }}>{formatTime(position)}</Text>
          <Text style={{ fontSize: 12, color: colors.textMuted }}>{formatTime(duration)}</Text>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: 'space-around', marginBottom: 20 }}>
          <TouchableOpacity style={{ alignItems: 'center' }}>
            <MaterialCommunityIcons name="skip-previous" size={32} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity onPress={togglePlay} style={{ alignItems: 'center' }}>
            <MaterialCommunityIcons name={isPlaying ? 'pause-circle' : 'play-circle'} size={48} color={colors.primary} />
          </TouchableOpacity>
          <TouchableOpacity style={{ alignItems: 'center' }}>
            <MaterialCommunityIcons name="skip-next" size={32} color={colors.primary} />
          </TouchableOpacity>
        </View>

        <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
          <TouchableOpacity style={{ alignItems: 'center' }}>
            <MaterialCommunityIcons name="speedometer" size={28} color={colors.textSecondary} />
            <Text style={{ fontSize: 12, color: colors.textMuted, marginTop: 4 }}>1x</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{ alignItems: 'center' }}>
            <MaterialCommunityIcons name="fullscreen" size={28} color={colors.textSecondary} />
            <Text style={{ fontSize: 12, color: colors.textMuted, marginTop: 4 }}>Fullscreen</Text>
          </TouchableOpacity>
          <TouchableOpacity style={{ alignItems: 'center' }}>
            <MaterialCommunityIcons name="share-variant" size={28} color={colors.textSecondary} />
            <Text style={{ fontSize: 12, color: colors.textMuted, marginTop: 4 }}>Share</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}
