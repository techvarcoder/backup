import React, { useEffect, useState } from 'react';
import { View, ScrollView, Text, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../../theme';
import { useLibraryStore } from '../../stores/libraryStore';

export default function MediaLibraryScreen({ navigation }: any) {
  const colors = useColors();
  const { allMedia, loadMedia } = useLibraryStore();
  const [viewMode, setViewMode] = useState('grid');

  useEffect(() => {
    loadMedia();
  }, []);

  const renderMediaItem = (item: any) => (
    <TouchableOpacity
      onPress={() => navigation.navigate('VideoPlayer', { mediaId: item.id })}
      style={{ backgroundColor: colors.card, borderRadius: 8, overflow: 'hidden', marginBottom: 12, borderWidth: 1, borderColor: colors.divider }}
    >
      <View style={{ height: 150, backgroundColor: colors.surface, justifyContent: 'center', alignItems: 'center' }}>
        <MaterialCommunityIcons name={item.mediaType === 'video' ? 'play-circle' : 'music'} size={40} color={colors.primary} />
      </View>
      <View style={{ padding: 12 }}>
        <Text style={{ fontSize: 14, fontWeight: '600', color: colors.textPrimary }} numberOfLines={1}>{item.title}</Text>
        <Text style={{ fontSize: 12, color: colors.textMuted, marginTop: 4 }}>{item.platform}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <View style={{ padding: 16, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={{ fontSize: 24, fontWeight: '700', color: colors.textPrimary }}>Library</Text>
        <TouchableOpacity onPress={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}>
          <MaterialCommunityIcons name={viewMode === 'grid' ? 'view-list' : 'view-grid'} size={24} color={colors.primary} />
        </TouchableOpacity>
      </View>

      {allMedia.length === 0 ? (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <MaterialCommunityIcons name="folder-open" size={48} color={colors.textMuted} />
          <Text style={{ marginTop: 12, color: colors.textMuted }}>No media yet</Text>
          <Text style={{ fontSize: 12, color: colors.textMuted, marginTop: 8 }}>Download videos to see them here</Text>
        </View>
      ) : (
        <ScrollView style={{ flex: 1, padding: 16, paddingTop: 0 }}>
          {allMedia.map((item) => (
            <View key={item.id}>{renderMediaItem(item)}</View>
          ))}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}
