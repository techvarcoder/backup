import axios, { AxiosInstance, CancelTokenSource } from 'axios';
import RNFS from 'react-native-fs';
import { useDownloadStore } from '../stores/downloadStore';

interface ActiveDownload {
  controller: CancelTokenSource;
  startTime: number;
  lastBytes: number;
}

class DownloadQueue {
  private activeDownloads: Map<string, ActiveDownload> = new Map();
  private maxConcurrent = 3;
  private queue: string[] = [];
  private axios: AxiosInstance;

  constructor() {
    this.axios = axios.create({
      timeout: 30000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      },
    });
  }

  async startDownload(downloadId: string, url: string, filePath: string) {
    const store = useDownloadStore.getState();
    const cancelSource = axios.CancelToken.source();
    this.activeDownloads.set(downloadId, {
      controller: cancelSource,
      startTime: Date.now(),
      lastBytes: 0,
    });

    try {
      await store.updateStatus(downloadId, 'downloading');
      // Ensure destination path is under app document directory
      const baseDir = RNFS.DocumentDirectoryPath;
      const relativePath = filePath.startsWith('/') ? filePath.slice(1) : filePath;
      const destPath = `${baseDir}/${relativePath}`;
      const dir = destPath.substring(0, destPath.lastIndexOf('/'));
      // create directory if missing
      const exists = await RNFS.exists(dir);
      if (!exists) await RNFS.mkdir(dir);

      console.log(`[DownloadQueue] starting download ${downloadId} -> ${destPath}`);

      const downloadJob = RNFS.downloadFile({
        fromUrl: url,
        toFile: destPath,
        background: true,
        discretionary: false,
        connectionTimeout: 30000,
        readTimeout: 60000,
        // googlevideo stream URLs expect a YouTube client User-Agent.
        headers: {
          'User-Agent': 'com.google.android.youtube/19.09.37 (Linux; U; Android 11) gzip',
        },
        // emit progress updates regularly (every 250ms / every 1%)
        progressInterval: 250,
        progressDivider: 1,
        begin: (res) => {
          // res.contentLength may be -1 if unknown
          console.log(`[DownloadQueue] begin ${downloadId}`, res.statusCode, res.contentLength);
        },
        progress: (res) => {
          try {
            const { bytesWritten, contentLength } = res;
            let progress = 0;
            if (contentLength && contentLength > 0) {
              progress = Math.round((bytesWritten / contentLength) * 100);
            } else {
              // contentLength unknown: estimate using MB downloaded, clamp to 99
              const mb = Math.floor(bytesWritten / (1024 * 1024));
              progress = Math.min(99, mb);
            }
            progress = Math.max(0, Math.min(100, progress));
            store.updateProgress(downloadId, progress, bytesWritten);
          } catch (e) {
            console.warn('[DownloadQueue] progress parse error', e);
          }
        },
      });

      const result = await downloadJob.promise;
      if (result && result.statusCode >= 200 && result.statusCode < 300) {
        console.log(`[DownloadQueue] completed ${downloadId}`);
        // ensure the store shows 100% before marking complete
        await store.updateProgress(downloadId, 100, 0);
        await store.updateStatus(downloadId, 'completed');
        // copy to public Download folder so it's visible in file explorer
        try {
          const publicDir = '/sdcard/Download';
          const filename = destPath.substring(destPath.lastIndexOf('/') + 1);
          const publicPath = `${publicDir}/${filename}`;
          await RNFS.copyFile(destPath, publicPath);
          console.log(`[DownloadQueue] copied to public path ${publicPath}`);
        } catch (e) {
          console.warn('[DownloadQueue] failed to copy to public folder', e);
        }
      } else {
        console.warn('[DownloadQueue] download failed', result);
        await store.updateStatus(downloadId, 'failed', `HTTP ${result?.statusCode}`);
      }
    } catch (error: any) {
      if (axios.isCancel(error)) {
        // Download was cancelled or paused
      } else {
        await store.updateStatus(downloadId, 'failed', error.message);
      }
    } finally {
      this.activeDownloads.delete(downloadId);
    }
  }

  pauseDownload(downloadId: string) {
    const activeDownload = this.activeDownloads.get(downloadId);
    if (activeDownload) {
      activeDownload.controller.cancel('Download paused');
      useDownloadStore.getState().updateStatus(downloadId, 'paused');
    }
  }

  resumeDownload(downloadId: string, url: string, filePath: string) {
    const store = useDownloadStore.getState();
    store.resumeDownload(downloadId);
    this.startDownload(downloadId, url, filePath);
  }

  cancelDownload(downloadId: string) {
    const activeDownload = this.activeDownloads.get(downloadId);
    if (activeDownload) {
      activeDownload.controller.cancel('Download cancelled');
      this.activeDownloads.delete(downloadId);
    }
  }

  getActiveDownloadsCount() {
    return this.activeDownloads.size;
  }
}

export const downloadQueue = new DownloadQueue();
