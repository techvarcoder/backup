import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppSettings } from '../types';

const SETTINGS_KEY = '@app_settings';
const RECENT_URLS_KEY = '@recent_urls';

// Default app settings
const DEFAULT_SETTINGS: AppSettings = {
  themeMode: 'dark',
  language: 'English',
  downloadPath: '/Downloads',
  defaultVideoQuality: '1080p',
  defaultAudioFormat: 'mp3',
  maxConcurrentDownloads: 3,
  notificationsEnabled: true,
  wifiOnlyDownload: false,
  autoRetryFailed: true,
  autoDetectLinks: true,
  clipboardMonitor: true,
  autoPlayNext: false,
  sleepTimerMinutes: 0,
  storageWarningThreshold: 85,
};

/**
 * Save app settings to async storage
 * @param settings - The app settings to save
 * @throws Error if JSON stringification fails or storage operation fails
 */
export const saveSettings = async (settings: AppSettings): Promise<void> => {
  try {
    const jsonString = JSON.stringify(settings);
    await AsyncStorage.setItem(SETTINGS_KEY, jsonString);
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`Failed to save settings: ${error.message}`);
    }
    throw new Error('Failed to save settings: Unknown error');
  }
};

/**
 * Load app settings from async storage with defaults
 * @returns The loaded settings or defaults if not found
 */
export const loadSettings = async (): Promise<AppSettings> => {
  try {
    const jsonString = await AsyncStorage.getItem(SETTINGS_KEY);

    if (!jsonString) {
      return DEFAULT_SETTINGS;
    }

    const settings = JSON.parse(jsonString) as AppSettings;

    // Merge with defaults to handle missing properties
    return {
      ...DEFAULT_SETTINGS,
      ...settings,
    };
  } catch (error) {
    const { warn } = require('../utils/logger').logger;
    warn('Failed to load settings, using defaults:', error);
    return DEFAULT_SETTINGS;
  }
};

/**
 * Save recent URLs to async storage
 * @param urls - Array of URLs to save
 * @throws Error if JSON stringification fails or storage operation fails
 */
export const saveRecentUrls = async (urls: string[]): Promise<void> => {
  try {
    const jsonString = JSON.stringify(urls);
    await AsyncStorage.setItem(RECENT_URLS_KEY, jsonString);
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`Failed to save recent URLs: ${error.message}`);
    }
    throw new Error('Failed to save recent URLs: Unknown error');
  }
};

/**
 * Load recent URLs from async storage
 * @returns Array of recent URLs or empty array if not found
 */
export const loadRecentUrls = async (): Promise<string[]> => {
  try {
    const jsonString = await AsyncStorage.getItem(RECENT_URLS_KEY);

    if (!jsonString) {
      return [];
    }

    const urls = JSON.parse(jsonString) as string[];

    // Ensure it's an array
    if (!Array.isArray(urls)) {
      return [];
    }

    return urls;
  } catch (error) {
    const { warn: warn2 } = require('../utils/logger').logger;
    warn2('Failed to load recent URLs, returning empty array:', error);
    return [];
  }
};

/**
 * Clear all app storage
 * Removes all stored data including settings and recent URLs
 * @throws Error if storage operation fails
 */
export const clearStorage = async (): Promise<void> => {
  try {
    await AsyncStorage.multiRemove([SETTINGS_KEY, RECENT_URLS_KEY]);
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`Failed to clear storage: ${error.message}`);
    }
    throw new Error('Failed to clear storage: Unknown error');
  }
};
