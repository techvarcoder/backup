import React from 'react';
import { View, Text } from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

export interface IWebViewProps {
  source: {
    uri: string;
  };
  onLoad?: () => void;
  onNavigationStateChange?: (navState: any) => void;
  injectedJavaScript?: string;
}

let RealWebView: any = null;

try {
  RealWebView = require('react-native-webview').WebView;
} catch (e) {
  // react-native-webview not installed, will use stub
}

export const WebView: React.FC<IWebViewProps> = ({
  source,
  onLoad,
  onNavigationStateChange,
  injectedJavaScript,
}) => {
  if (RealWebView) {
    return (
      <RealWebView
        source={source}
        onLoad={onLoad}
        onNavigationStateChange={onNavigationStateChange}
        injectedJavaScript={injectedJavaScript}
      />
    );
  }

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: '#0B1020',
        justifyContent: 'center',
        alignItems: 'center',
        paddingHorizontal: 20,
      }}
    >
      <MaterialCommunityIcons name="web" size={64} color="#ffffff" style={{ marginBottom: 16 }} />
      <Text
        style={{
          color: '#ffffff',
          fontSize: 16,
          textAlign: 'center',
          marginBottom: 12,
        }}
      >
        Install react-native-webview to enable browsing
      </Text>
      <Text
        style={{
          color: '#888888',
          fontSize: 14,
          textAlign: 'center',
        }}
      >
        {source?.uri || 'No URL provided'}
      </Text>
    </View>
  );
};

export default WebView;
