import React, { useMemo } from 'react';
import { View, Text, StyleSheet, Platform } from 'react-native';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';

/**
 * Interface matching react-native-video props
 */
export interface IVideoPlayerProps {
  source?: { uri: string } | number;
  onBuffer?: () => void;
  onLoad?: (data: any) => void;
  onEnd?: () => void;
  onError?: (error: any) => void;
  onProgress?: (data: any) => void;
  paused?: boolean;
  resizeMode?: 'cover' | 'contain' | 'stretch';
  poster?: string;
  rate?: number;
  controls?: boolean;
  fullscreen?: boolean;
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    aspectRatio: 16 / 9,
    backgroundColor: '#141A2F',
    justifyContent: 'center',
    alignItems: 'center',
  },
  contentContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: {
    color: '#FFFFFF',
    fontSize: 14,
    marginTop: 12,
    textAlign: 'center',
    paddingHorizontal: 20,
  },
});

/**
 * VideoPlayer component - Stub implementation
 * Attempts to load react-native-video if available, otherwise renders placeholder
 */
export const VideoPlayer = React.forwardRef<View, IVideoPlayerProps>(
  (props, ref) => {
    const RealVideoPlayer = useMemo(() => {
      try {
        const module = require('react-native-video');
        return module.default || module;
      } catch (e) {
        const { warn } = require('../../utils/logger').logger;
        warn(
          'react-native-video not found. Using VideoPlayer stub. ' +
          'Install react-native-video to enable video playback.'
        );
        return null;
      }
    }, []);

    if (RealVideoPlayer) {
      return (
        <RealVideoPlayer
          ref={ref}
          source={props.source}
          onBuffer={props.onBuffer}
          onLoad={props.onLoad}
          onEnd={props.onEnd}
          onError={props.onError}
          onProgress={props.onProgress}
          paused={props.paused}
          rate={props.rate}
          resizeMode={props.resizeMode}
          poster={props.poster}
          fullscreen={props.fullscreen}
          controls={props.controls}
          style={styles.container}
        />
      );
    }

    return (
      <View ref={ref} style={styles.container}>
        <View style={styles.contentContainer}>
          <MaterialCommunityIcons
            name="play-circle"
            size={64}
            color="#7C4DFF"
          />
          <Text style={styles.text}>
            Install react-native-video to enable playback
          </Text>
        </View>
      </View>
    );
  }
);

VideoPlayer.displayName = 'VideoPlayer';

export default VideoPlayer;
