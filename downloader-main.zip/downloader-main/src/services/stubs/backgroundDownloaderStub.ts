/**
 * Background Downloader Service
 *
 * This is a stub implementation for background download functionality.
 * It maintains an in-memory Map of active downloads and works in foreground only.
 *
 * In production, this would wrap react-native-background-downloader for true background support.
 */

import { DownloadItem } from '../../types';
import { logger } from '../../utils/logger';

/**
 * Represents a download task to be executed
 */
export interface DownloadTask {
  id: string;
  url: string;
  title: string;
  platform: string;
  filePath: string;
  onProgress?: (bytesWritten: number, contentLength: number) => void;
  onComplete?: () => void;
  onError?: (error: Error) => void;
}

/**
 * Background download service interface
 */
export interface IBackgroundDownload {
  /**
   * Start a new download task
   */
  startDownload(task: DownloadTask): Promise<void>;

  /**
   * Pause an active download by ID
   */
  pauseDownload(id: string): Promise<void>;

  /**
   * Resume a paused download by ID
   */
  resumeDownload(id: string): Promise<void>;

  /**
   * Cancel a download by ID
   */
  cancelDownload(id: string): Promise<void>;

  /**
   * Get the current status of a download
   */
  getDownloadStatus(id: string): DownloadItem | null;

  /**
   * Get all active downloads
   */
  getAllDownloads(): DownloadItem[];
}

/**
 * In-memory download status tracker
 */
interface DownloadStatus {
  task: DownloadTask;
  status: 'active' | 'paused' | 'completed' | 'failed';
  progress: number;
  downloadedBytes: number;
  totalBytes: number;
  error: Error | null;
}

/**
 * Stub implementation of IBackgroundDownload
 *
 * This implementation:
 * - Stores downloads in an in-memory Map
 * - Does NOT support true background downloads (only foreground)
 * - Attempts to require 'react-native-background-downloader' but falls back gracefully
 * - Provides all required interface methods
 */
class BackgroundDownloaderStub implements IBackgroundDownload {
  private downloads: Map<string, DownloadStatus> = new Map();
  private nativeDownloader: any = null;

  constructor() {
    this.initializeNativeDownloader();
  }

  /**
   * Attempt to load the native background downloader
   */
  private initializeNativeDownloader(): void {
    try {
      this.nativeDownloader = require('react-native-background-downloader');
      logger.log('Native background downloader loaded successfully');
    } catch (error) {
      logger.warn(
        'react-native-background-downloader not available. Using stub implementation.',
        error
      );
      this.nativeDownloader = null;
    }
  }

  /**
   * Start a new download task
   * Note: This runs in foreground only in the stub implementation
   */
  async startDownload(task: DownloadTask): Promise<void> {
    try {
      // Initialize download tracking
      this.downloads.set(task.id, {
        task,
        status: 'active',
        progress: 0,
        downloadedBytes: 0,
        totalBytes: 0,
        error: null,
      });

      logger.log(`[BackgroundDownloader] Starting download: ${task.id}`);

      // If native downloader is available, use it
      if (this.nativeDownloader) {
        await this.startNativeDownload(task);
        return;
      }

      // Otherwise, simulate foreground download
      await this.simulateForegroundDownload(task);
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      const download = this.downloads.get(task.id);
      if (download) {
        download.status = 'failed';
        download.error = err;
      }
      logger.error(`[BackgroundDownloader] Failed to start download ${task.id}:`, err);
      task.onError?.(err);
      throw err;
    }
  }

  /**
   * Pause an active download
   */
  async pauseDownload(id: string): Promise<void> {
    const download = this.downloads.get(id);
    if (!download) {
      throw new Error(`Download not found: ${id}`);
    }

    if (download.status === 'active') {
      download.status = 'paused';
      logger.log(`[BackgroundDownloader] Paused download: ${id}`);

      if (this.nativeDownloader && this.nativeDownloader.pause) {
        try {
          await this.nativeDownloader.pause(id);
        } catch (error) {
          logger.warn(`Failed to pause native download ${id}:`, error);
        }
      }
    }
  }

  /**
   * Resume a paused download
   */
  async resumeDownload(id: string): Promise<void> {
    const download = this.downloads.get(id);
    if (!download) {
      throw new Error(`Download not found: ${id}`);
    }

    if (download.status === 'paused') {
      download.status = 'active';
      logger.log(`[BackgroundDownloader] Resumed download: ${id}`);

      if (this.nativeDownloader && this.nativeDownloader.resume) {
        try {
          await this.nativeDownloader.resume(id);
        } catch (error) {
          logger.warn(`Failed to resume native download ${id}:`, error);
        }
      }
    }
  }

  /**
   * Cancel a download
   */
  async cancelDownload(id: string): Promise<void> {
    const download = this.downloads.get(id);
    if (!download) {
      throw new Error(`Download not found: ${id}`);
    }

    logger.log(`[BackgroundDownloader] Cancelled download: ${id}`);

    if (this.nativeDownloader && this.nativeDownloader.stop) {
      try {
        await this.nativeDownloader.stop(id);
      } catch (error) {
        logger.warn(`Failed to cancel native download ${id}:`, error);
      }
    }

    this.downloads.delete(id);
  }

  /**
   * Get the download status of a specific download
   */
  getDownloadStatus(id: string): DownloadItem | null {
    const download = this.downloads.get(id);
    if (!download) {
      return null;
    }

    return {
      id: download.task.id,
      url: download.task.url,
      title: download.task.title,
      platform: download.task.platform,
      thumbnailUrl: '',
      duration: 0,
      fileSize: download.totalBytes,
      downloadedBytes: download.downloadedBytes,
      progress: download.progress,
      status: this.mapDownloadStatus(download.status),
      quality: '',
      format: '',
      filePath: download.task.filePath,
      createdAt: Date.now(),
      completedAt: download.status === 'completed' ? Date.now() : null,
      errorMessage: download.error?.message || null,
      retryCount: 0,
    };
  }

  /**
   * Get all active downloads
   */
  getAllDownloads(): DownloadItem[] {
    return Array.from(this.downloads.values()).map((download) => ({
      id: download.task.id,
      url: download.task.url,
      title: download.task.title,
      platform: download.task.platform,
      thumbnailUrl: '',
      duration: 0,
      fileSize: download.totalBytes,
      downloadedBytes: download.downloadedBytes,
      progress: download.progress,
      status: this.mapDownloadStatus(download.status),
      quality: '',
      format: '',
      filePath: download.task.filePath,
      createdAt: Date.now(),
      completedAt: download.status === 'completed' ? Date.now() : null,
      errorMessage: download.error?.message || null,
      retryCount: 0,
    }));
  }

  /**
   * Map internal status to DownloadStatus type
   */
  private mapDownloadStatus(
    status: 'active' | 'paused' | 'completed' | 'failed'
  ): 'pending' | 'analyzing' | 'downloading' | 'paused' | 'completed' | 'failed' | 'cancelled' {
    switch (status) {
      case 'active':
        return 'downloading';
      case 'paused':
        return 'paused';
      case 'completed':
        return 'completed';
      case 'failed':
        return 'failed';
      default:
        return 'pending';
    }
  }

  /**
   * Start a native download using react-native-background-downloader
   */
  private async startNativeDownload(task: DownloadTask): Promise<void> {
    if (!this.nativeDownloader) {
      throw new Error('Native downloader not available');
    }

    try {
      const downloadTask = this.nativeDownloader.download({
        id: task.id,
        url: task.url,
        destination: task.filePath,
        onProgress: (bytesWritten: number, contentLength: number) => {
          const download = this.downloads.get(task.id);
          if (download) {
            download.downloadedBytes = bytesWritten;
            download.totalBytes = contentLength;
            download.progress = contentLength > 0 ? bytesWritten / contentLength : 0;
          }
          task.onProgress?.(bytesWritten, contentLength);
        },
        onResume: () => {
          logger.log(`[BackgroundDownloader] Native download resumed: ${task.id}`);
        },
        onDone: () => {
          const download = this.downloads.get(task.id);
          if (download) {
            download.status = 'completed';
            download.progress = 1;
          }
          logger.log(`[BackgroundDownloader] Native download completed: ${task.id}`);
          task.onComplete?.();
        },
        onError: (errorCode: number, description: string) => {
          const error = new Error(`Native download error: ${description}`);
          const download = this.downloads.get(task.id);
          if (download) {
            download.status = 'failed';
            download.error = error;
          }
          logger.error(`[BackgroundDownloader] Native download failed: ${task.id}`, error);
          task.onError?.(error);
        },
      });

      await downloadTask.begin();
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      logger.error(`[BackgroundDownloader] Failed to start native download:`, err);
      throw err;
    }
  }

  /**
   * Simulate a foreground download (stub behavior)
   */
  private async simulateForegroundDownload(task: DownloadTask): Promise<void> {
    const download = this.downloads.get(task.id);
    if (!download) {
      return;
    }

    try {
      // Simulate download progress
      const totalSize = 100 * 1024 * 1024; // 100MB
      download.totalBytes = totalSize;

      for (let i = 0; i <= 100; i += 10) {
        if (download.status !== 'active') {
          break;
        }

        const bytesWritten = (totalSize * i) / 100;
        download.downloadedBytes = bytesWritten;
        download.progress = i / 100;

        task.onProgress?.(bytesWritten, totalSize);

        // Simulate network delay
        await new Promise((resolve) => setTimeout(resolve, 500));
      }

      if (download.status === 'active') {
        download.status = 'completed';
        download.progress = 1;
        logger.log(`[BackgroundDownloader] Foreground download completed: ${task.id}`);
        task.onComplete?.();
      }
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      download.status = 'failed';
      download.error = err;
      logger.error(`[BackgroundDownloader] Foreground download failed: ${task.id}`, err);
      task.onError?.(err);
    }
  }
}

/**
 * Singleton instance of the background downloader
 */
let backgroundDownloaderInstance: BackgroundDownloaderStub | null = null;

/**
 * Get or create the background downloader singleton
 */
export const getBackgroundDownloader = (): IBackgroundDownload => {
  if (!backgroundDownloaderInstance) {
    backgroundDownloaderInstance = new BackgroundDownloaderStub();
  }
  return backgroundDownloaderInstance;
};

/**
 * Reset the singleton (useful for testing)
 */
export const resetBackgroundDownloader = (): void => {
  backgroundDownloaderInstance = null;
};
