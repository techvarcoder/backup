export interface IFileSystem {
  mkdir(path: string): Promise<void>;
  exists(path: string): Promise<boolean>;
  unlink(path: string): Promise<void>;
  stat(path: string): Promise<{ size: number; isFile: boolean }>;
  moveFile(src: string, dest: string): Promise<void>;
  readDir(path: string): Promise<Array<{ name: string; path: string; size: number }>>;
  getFreeDiskStorage(): Promise<number>;
  DocumentDirectoryPath: string;
  ExternalStorageDirectoryPath: string;
  DownloadDirectoryPath: string;
}

function getFileSystem(): IFileSystem {
  try {
    const RNFS = require("react-native-fs");
    return {
      mkdir: (path: string) => RNFS.mkdir(path),
      exists: (path: string) => RNFS.exists(path),
      unlink: (path: string) => RNFS.unlink(path),
      stat: (path: string) => RNFS.stat(path),
      moveFile: (src: string, dest: string) => RNFS.moveFile(src, dest),
      readDir: (path: string) => RNFS.readDir(path),
      getFreeDiskStorage: () => RNFS.getFSInfo(),
      DocumentDirectoryPath: RNFS.DocumentDirectoryPath,
      ExternalStorageDirectoryPath: RNFS.ExternalStorageDirectoryPath,
      DownloadDirectoryPath: RNFS.DownloadDirectoryPath,
    };
  } catch (error) {
    const ONE_GB = 1024 * 1024 * 1024;
    return {
      mkdir: async () => {},
      exists: async () => false,
      unlink: async () => {},
      stat: async () => ({ size: 0, isFile: false }),
      moveFile: async () => {},
      readDir: async () => [],
      getFreeDiskStorage: async () => ONE_GB,
      DocumentDirectoryPath: "",
      ExternalStorageDirectoryPath: "",
      DownloadDirectoryPath: "",
    };
  }
}

export { getFileSystem };
