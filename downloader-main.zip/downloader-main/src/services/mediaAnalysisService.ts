import axios from 'axios';

export interface StreamFormat {
  itag: number;
  label: string; // e.g. "720p", "360p", "Audio"
  quality: string;
  url: string;
  mimeType: string;
  hasAudio: boolean;
  hasVideo: boolean;
  contentLength?: number;
  ext: string;
}

interface VideoMetadata {
  title: string;
  channel: string;
  duration: number; // seconds
  thumbnail: string;
  viewCount: string;
  platform: string;
  quality: string;
  downloadUrl: string | null; // best progressive (muxed) stream
  audioUrl: string | null; // best audio-only stream
  formats: StreamFormat[];
}

// Public InnerTube key used by the web/Android YouTube clients.
const INNERTUBE_KEY = 'AIzaSyA8eiZmM1FaDVjRy-df2KTyQ_vz_yYM39w';
const ANDROID_CLIENT = {
  clientName: 'ANDROID',
  clientVersion: '19.09.37',
  androidSdkVersion: 30,
  hl: 'en',
  gl: 'US',
};

class MediaAnalysisService {
  async analyzeUrl(url: string): Promise<VideoMetadata> {
    const platform = this.detectPlatform(url);

    try {
      switch (platform) {
        case 'youtube':
          return await this.analyzeYouTube(url);
        default:
          return this.getDefaultMetadata(url, platform);
      }
    } catch (error) {
      console.error('[mediaAnalysis] error:', error);
      return this.getDefaultMetadata(url, platform);
    }
  }

  private detectPlatform(url: string): string {
    if (url.includes('youtube.com') || url.includes('youtu.be')) return 'youtube';
    if (url.includes('tiktok.com')) return 'tiktok';
    if (url.includes('instagram.com')) return 'instagram';
    if (url.includes('twitter.com') || url.includes('x.com')) return 'twitter';
    if (url.includes('facebook.com')) return 'facebook';
    if (url.includes('vimeo.com')) return 'vimeo';
    return 'unknown';
  }

  private async analyzeYouTube(url: string): Promise<VideoMetadata> {
    const videoId = this.extractYouTubeId(url);
    if (videoId === 'unknown') {
      return this.getDefaultMetadata(url, 'youtube');
    }

    // Query the InnerTube player endpoint with the ANDROID client. This returns
    // streaming URLs directly (no signature cipher to decode).
    const resp = await axios.post(
      `https://www.youtube.com/youtubei/v1/player?key=${INNERTUBE_KEY}`,
      {
        context: { client: ANDROID_CLIENT },
        videoId,
        contentCheckOk: true,
        racyCheckOk: true,
      },
      {
        timeout: 20000,
        headers: {
          'Content-Type': 'application/json',
          'User-Agent':
            'com.google.android.youtube/19.09.37 (Linux; U; Android 11) gzip',
          'X-Goog-Api-Format-Version': '2',
        },
      },
    );

    const data = resp.data || {};
    const details = data.videoDetails || {};
    const streaming = data.streamingData || {};

    const progressive: any[] = streaming.formats || [];
    const adaptive: any[] = streaming.adaptiveFormats || [];

    const formats: StreamFormat[] = [];

    const pushFormat = (f: any) => {
      if (!f || !f.url) return;
      const mimeType: string = f.mimeType || '';
      const hasVideo = mimeType.startsWith('video');
      const hasAudio =
        mimeType.startsWith('audio') || !!f.audioQuality || mimeType.includes('mp4a');
      const ext = mimeType.includes('webm')
        ? 'webm'
        : mimeType.startsWith('audio')
        ? 'm4a'
        : 'mp4';
      formats.push({
        itag: f.itag,
        label: f.qualityLabel || (mimeType.startsWith('audio') ? 'Audio' : f.quality || ''),
        quality: f.qualityLabel || f.quality || '',
        url: f.url,
        mimeType,
        hasAudio: hasVideo ? true : hasAudio, // progressive formats include audio
        hasVideo,
        contentLength: f.contentLength ? Number(f.contentLength) : undefined,
        ext,
      });
    };

    // Progressive formats are muxed (video + audio) and directly playable.
    progressive.forEach(pushFormat);
    // Adaptive audio-only formats (for MP3/audio downloads).
    adaptive.filter((f) => (f.mimeType || '').startsWith('audio')).forEach(pushFormat);

    // Best progressive: highest qualityLabel among muxed formats.
    const progressiveFormats = formats.filter((f) => f.hasVideo && f.hasAudio);
    const best = progressiveFormats.sort(
      (a, b) => parseInt(b.quality) - parseInt(a.quality),
    )[0];

    const audioOnly = formats
      .filter((f) => !f.hasVideo && f.hasAudio)
      .sort((a, b) => (b.contentLength || 0) - (a.contentLength || 0))[0];

    const duration = Number(details.lengthSeconds) || 0;
    const thumbs = details.thumbnail?.thumbnails || [];
    const thumbnail =
      thumbs.length > 0
        ? thumbs[thumbs.length - 1].url
        : `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;

    return {
      title: details.title || `YouTube Video`,
      channel: details.author || '',
      duration,
      thumbnail,
      viewCount: details.viewCount || '0',
      platform: 'youtube',
      quality: best?.quality || progressiveFormats[0]?.quality || '720p',
      downloadUrl: best?.url || null,
      audioUrl: audioOnly?.url || null,
      formats,
    };
  }

  private getDefaultMetadata(url: string, platform: string): VideoMetadata {
    return {
      title: `${platform.charAt(0).toUpperCase() + platform.slice(1)} Video`,
      channel: '',
      duration: 0,
      thumbnail: '',
      viewCount: '0',
      platform,
      quality: '',
      downloadUrl: null,
      audioUrl: null,
      formats: [],
    };
  }

  private extractYouTubeId(url: string): string {
    const match = url.match(
      /(?:youtube\.com\/(?:watch\?v=|shorts\/|embed\/)|youtu\.be\/)([^&?#/]+)/,
    );
    return match ? match[1] : 'unknown';
  }
}

export const mediaAnalysisService = new MediaAnalysisService();
