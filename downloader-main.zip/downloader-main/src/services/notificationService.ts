/**
 * Notification Service
 * Handles application notifications (web/desktop)
 * Stub implementation - logs to console in dev, silent in prod
 */

const isDev = process.env.NODE_ENV === 'development';
import { logger } from '../utils/logger';

/**
 * Show a general notification
 */
export async function showNotification(
  title: string,
  body: string,
  icon?: string
): Promise<void> {
  if (isDev) {
    logger.log('[Notification]', { title, body, icon });
  }
}

/**
 * Show download progress notification
 */
export async function showDownloadProgress(
  downloadId: string,
  progress: number,
  speed: string
): Promise<void> {
  if (isDev) {
    logger.log('[Download Progress]', { downloadId, progress: `${progress}%`, speed });
  }
}

/**
 * Show download complete notification
 */
export async function showDownloadComplete(title: string): Promise<void> {
  if (isDev) {
    logger.log('[Download Complete]', { title });
  }
}

/**
 * Show download error notification
 */
export async function showDownloadError(
  title: string,
  error: string | Error
): Promise<void> {
  const errorMessage = error instanceof Error ? error.message : error;
  if (isDev) {
    logger.error('[Download Error]', { title, error: errorMessage });
  }
}
