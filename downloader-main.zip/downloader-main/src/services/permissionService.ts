import { PermissionsAndroid, Platform } from 'react-native';
import { logger } from '../utils/logger';

const DOWNLOAD_PERMISSIONS = [
  PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
  PermissionsAndroid.PERMISSIONS.READ_EXTERNAL_STORAGE,
];

const MEDIA_PERMISSIONS = [
  PermissionsAndroid.PERMISSIONS.READ_MEDIA_IMAGES,
  PermissionsAndroid.PERMISSIONS.READ_MEDIA_VIDEO,
  PermissionsAndroid.PERMISSIONS.READ_MEDIA_AUDIO,
];

const NOTIFICATION_PERMISSION = PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS;

/**
 * Request download permissions
 * API < 29: WRITE_EXTERNAL_STORAGE + READ_EXTERNAL_STORAGE
 * API >= 13: READ_MEDIA_* permissions
 * Returns true if all permissions are granted, false otherwise
 */
export async function requestDownloadPermissions(): Promise<boolean> {
  if (Platform.OS !== 'android') {
    return true;
  }

  try {
    // Build permission list relevant to this Android version
    const permissions: string[] = [];
    // For older APIs include legacy external storage permissions
    if (Platform.Version < 33) {
      permissions.push(...DOWNLOAD_PERMISSIONS);
    }

    // Android 13+ uses granular media permissions
    if (Platform.Version >= 33) {
      permissions.push(...MEDIA_PERMISSIONS);
      // notifications are optional; don't block download flow on this
    }

    // If no permissions are required for this API, consider granted
    if (permissions.length === 0) return true;

    const results = await PermissionsAndroid.requestMultiple(permissions);
    // Log results for debugging
    console.log('[permissionService] requestDownloadPermissions results:', results);

    // Check if all permissions were granted. requestMultiple returns strings like 'granted' | 'denied'
    const allGranted = Object.values(results).every(
      (r) => r === PermissionsAndroid.RESULTS.GRANTED
    );

    return allGranted;
  } catch (error) {
    logger.error('Error requesting download permissions:', error);
    return false;
  }
}

/**
 * Request notification permission (POST_NOTIFICATIONS on API >= 13)
 * Returns true if permission is granted, false otherwise
 */
export async function requestNotificationPermission(): Promise<boolean> {
  if (Platform.OS !== 'android') {
    return true;
  }

  // POST_NOTIFICATIONS permission only needed on API 13+ (Android 13+)
  if (Platform.Version < 13) {
    return true;
  }

  try {
    const result = await PermissionsAndroid.request(NOTIFICATION_PERMISSION);
    return result === PermissionsAndroid.RESULTS.GRANTED;
  } catch (error) {
    logger.error('Error requesting notification permission:', error);
    return false;
  }
}

/**
 * Check all permissions and return their status
 * API < 29: checks WRITE/READ_EXTERNAL_STORAGE
 * API >= 13: also checks READ_MEDIA_* and POST_NOTIFICATIONS
 * Returns a record of permission names to their granted status
 */
export async function checkAllPermissions(): Promise<Record<string, boolean>> {
  if (Platform.OS !== 'android') {
    return {
      WRITE_EXTERNAL_STORAGE: true,
      READ_EXTERNAL_STORAGE: true,
      READ_MEDIA_IMAGES: true,
      READ_MEDIA_VIDEO: true,
      READ_MEDIA_AUDIO: true,
      POST_NOTIFICATIONS: true,
    };
  }

  try {
    const permissions = [...DOWNLOAD_PERMISSIONS];

    // Add media permissions for API 13+
    if (Platform.Version >= 13) {
      permissions.push(...MEDIA_PERMISSIONS);
    }

    // Only check POST_NOTIFICATIONS on API 13+
    if (Platform.Version >= 13) {
      permissions.push(NOTIFICATION_PERMISSION);
    }

    const results = await PermissionsAndroid.checkMultiple(permissions);
    // checkMultiple returns a map of permission -> boolean
    const permissionMap: Record<string, boolean> = {};
    Object.entries(results).forEach(([permission, status]) => {
      const permissionName = permission.split('.').pop() || permission;
      permissionMap[permissionName] = !!status;
    });

    console.log('[permissionService] checkAllPermissions:', permissionMap);

    return permissionMap;
  } catch (error) {
    logger.error('Error checking permissions:', error);
    return {};
  }
}
