// Database schema definitions
// Contains SQL CREATE TABLE statements for all database tables

export const DOWNLOADS_TABLE = `
CREATE TABLE IF NOT EXISTS downloads (
  id TEXT PRIMARY KEY,
  url TEXT NOT NULL,
  title TEXT NOT NULL,
  platform TEXT NOT NULL,
  thumbnail_url TEXT,
  duration INTEGER,
  file_size INTEGER,
  downloaded_bytes INTEGER DEFAULT 0,
  progress REAL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending',
  quality TEXT,
  format TEXT,
  file_path TEXT,
  created_at TEXT NOT NULL,
  completed_at TEXT,
  error_message TEXT,
  retry_count INTEGER DEFAULT 0
);
`;

export const MEDIA_ITEMS_TABLE = `
CREATE TABLE IF NOT EXISTS media_items (
  id TEXT PRIMARY KEY,
  download_id TEXT NOT NULL,
  title TEXT NOT NULL,
  platform TEXT NOT NULL,
  thumbnail_path TEXT,
  file_path TEXT NOT NULL,
  duration INTEGER,
  file_size INTEGER,
  format TEXT,
  quality TEXT,
  media_type TEXT NOT NULL,
  is_favorite INTEGER DEFAULT 0,
  play_count INTEGER DEFAULT 0,
  last_played_at TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (download_id) REFERENCES downloads(id) ON DELETE CASCADE
);
`;

export const PLAYLISTS_TABLE = `
CREATE TABLE IF NOT EXISTS playlists (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  cover_path TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
`;

export const PLAYLIST_ITEMS_TABLE = `
CREATE TABLE IF NOT EXISTS playlist_items (
  id TEXT PRIMARY KEY,
  playlist_id TEXT NOT NULL,
  media_id TEXT NOT NULL,
  position INTEGER NOT NULL,
  added_at TEXT NOT NULL,
  FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE,
  FOREIGN KEY (media_id) REFERENCES media_items(id) ON DELETE CASCADE
);
`;

export const FAVORITES_TABLE = `
CREATE TABLE IF NOT EXISTS favorites (
  id TEXT PRIMARY KEY,
  media_id TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL,
  FOREIGN KEY (media_id) REFERENCES media_items(id) ON DELETE CASCADE
);
`;

export const HISTORY_TABLE = `
CREATE TABLE IF NOT EXISTS history (
  id TEXT PRIMARY KEY,
  media_id TEXT,
  download_id TEXT,
  title TEXT NOT NULL,
  thumbnail_path TEXT,
  action TEXT NOT NULL,
  platform TEXT,
  created_at TEXT NOT NULL,
  FOREIGN KEY (media_id) REFERENCES media_items(id) ON DELETE SET NULL,
  FOREIGN KEY (download_id) REFERENCES downloads(id) ON DELETE SET NULL
);
`;

export const RECENT_SEARCHES_TABLE = `
CREATE TABLE IF NOT EXISTS recent_searches (
  id TEXT PRIMARY KEY,
  query TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL
);
`;

export const APP_SETTINGS_TABLE = `
CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
`;

// Index definitions for performance optimization
export const DOWNLOADS_STATUS_CREATED_INDEX = `
CREATE INDEX IF NOT EXISTS idx_downloads_status_created_at
ON downloads(status, created_at);
`;

export const MEDIA_ITEMS_TYPE_FAVORITE_PLATFORM_INDEX = `
CREATE INDEX IF NOT EXISTS idx_media_items_type_favorite_platform
ON media_items(media_type, is_favorite, platform);
`;

export const HISTORY_CREATED_INDEX = `
CREATE INDEX IF NOT EXISTS idx_history_created_at
ON history(created_at);
`;

// Helper function to get all create statements in order
export const getAllCreateStatements = () => [
  DOWNLOADS_TABLE,
  MEDIA_ITEMS_TABLE,
  PLAYLISTS_TABLE,
  PLAYLIST_ITEMS_TABLE,
  FAVORITES_TABLE,
  HISTORY_TABLE,
  RECENT_SEARCHES_TABLE,
  APP_SETTINGS_TABLE,
];

// Helper function to get all index statements
export const getAllIndexStatements = () => [
  DOWNLOADS_STATUS_CREATED_INDEX,
  MEDIA_ITEMS_TYPE_FAVORITE_PLATFORM_INDEX,
  HISTORY_CREATED_INDEX,
];

// Helper function to initialize database
import { logger } from '../utils/logger';

export const initializeDatabase = async (db: any) => {
  try {
    // Create all tables
    for (const createStatement of getAllCreateStatements()) {
      await db.execute({ sql: createStatement });
    }

    // Create all indexes
    for (const indexStatement of getAllIndexStatements()) {
      await db.execute({ sql: indexStatement });
    }

    return true;
  } catch (error) {
    logger.error('Database initialization error:', error);
    throw error;
  }
};
