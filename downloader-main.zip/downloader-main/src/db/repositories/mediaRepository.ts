import { MediaItem } from '../../types';
import { getDatabase } from '../database';
import { v4 as uuid } from '../../utils/uuid';
import { logger } from '../../utils/logger';

/**
 * Insert a media item into media_items table (used when download completes)
 */
export async function insertMediaItem(item: Omit<MediaItem, 'id' | 'createdAt' | 'playCount' | 'lastPlayedAt'>): Promise<string> {
  try {
    const db = await getDatabase();
    const id = uuid();
    const createdAt = Date.now();

    return new Promise((resolve, reject) => {
      db.transaction((tx) => {
        tx.executeSql(
          `INSERT INTO media_items (id, download_id, title, platform, thumbnail_path, file_path, duration, file_size, format, quality, media_type, is_favorite, play_count, last_played_at, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            id,
            item.downloadId || null,
            item.title || '',
            item.platform || 'unknown',
            item.thumbnailPath || '',
            item.filePath || '',
            item.duration || 0,
            item.fileSize || 0,
            item.format || '',
            item.quality || '',
            item.mediaType || 'video',
            item.isFavorite ? 1 : 0,
            0,
            null,
            createdAt,
          ],
          () => {
            logger.log('[MediaRepo] inserted media item', id);
            resolve(id);
          },
          (_, error) => {
            logger.error('[MediaRepo] insert error', error);
            reject(error);
            return true;
          }
        );
      }, (err) => {
        logger.error('[MediaRepo] transaction failed', err);
        reject(err);
      });
    });
  } catch (error) {
    logger.error('[MediaRepo] insertMediaItem error', error);
    throw error;
  }
}
