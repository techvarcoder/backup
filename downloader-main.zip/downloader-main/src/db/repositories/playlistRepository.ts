import { getDatabase, transaction } from '../database';
import { PlaylistItem, MediaItem } from '../../types';
import { v4 as uuid } from '../../utils/uuid';

/**
 * Creates a new playlist and returns it
 */
export async function createPlaylist(name: string, description?: string): Promise<PlaylistItem> {
  const playlistId = uuid();
  const now = Date.now();

  return new Promise(async (resolve, reject) => {
    try {
      const db = await getDatabase();
      db.transaction(
        (tx) => {
          tx.executeSql(
            `INSERT INTO playlists (id, name, description, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?)`,
            [playlistId, name, description || '', now, now],
            () => {
              // Fetch and return the created playlist
              tx.executeSql(
                `SELECT id, name, description, cover_path, created_at,
                        (SELECT COUNT(*) FROM playlist_items WHERE playlist_id = playlists.id) as item_count
                 FROM playlists WHERE id = ?`,
                [playlistId],
                (_: any, result: any) => {
                  const first = Array.isArray(result) ? result[0] : result;
                  const rows = first && first.rows ? first.rows : { length: 0, item: () => null };
                  if (rows.length > 0) {
                    const row = rows.item(0);
                    const playlist: PlaylistItem = {
                      id: row.id,
                      name: row.name,
                      description: row.description,
                      coverPath: row.cover_path,
                      itemCount: row.item_count,
                      createdAt: row.created_at,
                    };
                    resolve(playlist);
                  } else {
                    reject(new Error('Failed to create playlist'));
                  }
                },
                (_, error) => {
                  reject(error);
                  return true;
                }
              );
            },
            (_, error) => {
              reject(error);
              return true;
            }
          );
        },
        (error) => reject(error)
      );
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Deletes a playlist by ID
 */
export async function deletePlaylist(id: string): Promise<void> {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await getDatabase();
      db.transaction(
        (tx) => {
          // Delete all playlist items first (cascade handled by FK but explicit for clarity)
          tx.executeSql(
            `DELETE FROM playlist_items WHERE playlist_id = ?`,
            [id],
            () => {
              // Delete the playlist
              tx.executeSql(
                `DELETE FROM playlists WHERE id = ?`,
                [id],
                () => resolve(),
                (_, error) => {
                  reject(error);
                  return true;
                }
              );
            },
            (_, error) => {
              reject(error);
              return true;
            }
          );
        },
        (error) => reject(error)
      );
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Retrieves all playlists with item count
 */
export async function getPlaylists(): Promise<PlaylistItem[]> {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await getDatabase();
      db.executeSql(
        `SELECT id, name, description, cover_path, created_at,
                (SELECT COUNT(*) FROM playlist_items WHERE playlist_id = playlists.id) as item_count
         FROM playlists
         ORDER BY created_at DESC`,
        [],
        (_: any, result: any) => {
          const first = Array.isArray(result) ? result[0] : result;
          const rows = first && first.rows ? first.rows : { length: 0, item: () => null };
          const playlists: PlaylistItem[] = [];
          for (let i = 0; i < rows.length; i++) {
            const row = rows.item(i);
            playlists.push({
              id: row.id,
              name: row.name,
              description: row.description,
              coverPath: row.cover_path,
              itemCount: row.item_count,
              createdAt: row.created_at,
            });
          }
          resolve(playlists);
        },
        (error) => {
          reject(error);
          return true;
        }
      );
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Adds a media item to a playlist
 */
export async function addToPlaylist(playlistId: string, mediaId: string): Promise<void> {
  const playlistItemId = uuid();
  const now = Date.now();

  return new Promise(async (resolve, reject) => {
    try {
      const db = await getDatabase();
      db.transaction(
        (tx) => {
          // Get the current max position for this playlist
          tx.executeSql(
            `SELECT MAX(position) as max_position FROM playlist_items WHERE playlist_id = ?`,
            [playlistId],
            (_: any, result: any) => {
              const first = Array.isArray(result) ? result[0] : result;
              const rows = first && first.rows ? first.rows : { length: 0, item: () => ({ max_position: null }) };
              const maxPosition = rows.length > 0 && rows.item(0).max_position !== null
                ? rows.item(0).max_position
                : -1;

              // Insert the playlist item
              tx.executeSql(
                `INSERT INTO playlist_items (id, playlist_id, media_id, position, added_at)
                 VALUES (?, ?, ?, ?, ?)`,
                [playlistItemId, playlistId, mediaId, maxPosition + 1, now],
                () => {
                  // Update playlist updated_at
                  tx.executeSql(
                    `UPDATE playlists SET updated_at = ? WHERE id = ?`,
                    [now, playlistId],
                    () => resolve(),
                    (_, error) => {
                      reject(error);
                      return true;
                    }
                  );
                },
                (_, error) => {
                  reject(error);
                  return true;
                }
              );
            },
            (_, error) => {
              reject(error);
              return true;
            }
          );
        },
        (error) => reject(error)
      );
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Removes a media item from a playlist
 */
export async function removeFromPlaylist(playlistId: string, mediaId: string): Promise<void> {
  const now = Date.now();

  return new Promise(async (resolve, reject) => {
    try {
      const db = await getDatabase();
      db.transaction(
        (tx) => {
          // Delete the playlist item
          tx.executeSql(
            `DELETE FROM playlist_items WHERE playlist_id = ? AND media_id = ?`,
            [playlistId, mediaId],
            () => {
              // Update playlist updated_at
              tx.executeSql(
                `UPDATE playlists SET updated_at = ? WHERE id = ?`,
                [now, playlistId],
                () => resolve(),
                (_, error) => {
                  reject(error);
                  return true;
                }
              );
            },
            (_, error) => {
              reject(error);
              return true;
            }
          );
        },
        (error) => reject(error)
      );
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Gets all media items in a playlist, ordered by position
 */
export async function getPlaylistItems(playlistId: string): Promise<MediaItem[]> {
  return new Promise(async (resolve, reject) => {
    try {
      const db = await getDatabase();
      db.executeSql(
        `SELECT
           m.id, m.download_id, m.title, m.platform, m.thumbnail_path, m.file_path,
           m.duration, m.file_size, m.format, m.quality, m.media_type, m.is_favorite,
           m.play_count, m.last_played_at, m.created_at
         FROM media_items m
         INNER JOIN playlist_items pi ON m.id = pi.media_id
         WHERE pi.playlist_id = ?
         ORDER BY pi.position ASC`,
        [playlistId],
        (result) => {
          const mediaItems: MediaItem[] = [];
          for (let i = 0; i < result.rows.length; i++) {
            const row = result.rows.item(i);
            mediaItems.push({
              id: row.id,
              downloadId: row.download_id,
              title: row.title,
              platform: row.platform,
              thumbnailPath: row.thumbnail_path,
              filePath: row.file_path,
              duration: row.duration,
              fileSize: row.file_size,
              format: row.format,
              quality: row.quality,
              mediaType: row.media_type,
              isFavorite: row.is_favorite === 1,
              playCount: row.play_count,
              lastPlayedAt: row.last_played_at,
              createdAt: row.created_at,
            });
          }
          resolve(mediaItems);
        },
        (error) => {
          reject(error);
          return true;
        }
      );
    } catch (error) {
      reject(error);
    }
  });
}

/**
 * Reorders a media item within a playlist to a new position
 */
export async function reorderPlaylistItem(
  playlistId: string,
  mediaId: string,
  newPosition: number
): Promise<void> {
  const now = Date.now();

  return new Promise(async (resolve, reject) => {
    try {
      const db = await getDatabase();
      db.transaction(
        (tx) => {
          // Get the current position of the item
          tx.executeSql(
            `SELECT position FROM playlist_items WHERE playlist_id = ? AND media_id = ?`,
            [playlistId, mediaId],
            (_: any, result: any) => {
              const first = Array.isArray(result) ? result[0] : result;
              const rows = first && first.rows ? first.rows : { length: 0, item: () => null };
              if (rows.length === 0) {
                reject(new Error('Playlist item not found'));
                return;
              }

              const currentPosition = rows.item(0).position;

              if (currentPosition === newPosition) {
                // No change needed
                resolve();
                return;
              }

              // Determine direction of reordering
              const minPosition = Math.min(currentPosition, newPosition);
              const maxPosition = Math.max(currentPosition, newPosition);

              if (currentPosition < newPosition) {
                // Moving down: shift items between currentPosition+1 and newPosition up by 1
                tx.executeSql(
                  `UPDATE playlist_items
                   SET position = position - 1
                   WHERE playlist_id = ? AND position > ? AND position <= ?`,
                  [playlistId, currentPosition, newPosition],
                  () => {
                    // Update the item to the new position
                    tx.executeSql(
                      `UPDATE playlist_items
                       SET position = ?, added_at = ?
                       WHERE playlist_id = ? AND media_id = ?`,
                      [newPosition, now, playlistId, mediaId],
                      () => {
                        // Update playlist updated_at
                        tx.executeSql(
                          `UPDATE playlists SET updated_at = ? WHERE id = ?`,
                          [now, playlistId],
                          () => resolve(),
                          (_, error) => {
                            reject(error);
                            return true;
                          }
                        );
                      },
                      (_, error) => {
                        reject(error);
                        return true;
                      }
                    );
                  },
                  (_, error) => {
                    reject(error);
                    return true;
                  }
                );
              } else {
                // Moving up: shift items between newPosition and currentPosition-1 down by 1
                tx.executeSql(
                  `UPDATE playlist_items
                   SET position = position + 1
                   WHERE playlist_id = ? AND position >= ? AND position < ?`,
                  [playlistId, newPosition, currentPosition],
                  () => {
                    // Update the item to the new position
                    tx.executeSql(
                      `UPDATE playlist_items
                       SET position = ?, added_at = ?
                       WHERE playlist_id = ? AND media_id = ?`,
                      [newPosition, now, playlistId, mediaId],
                      () => {
                        // Update playlist updated_at
                        tx.executeSql(
                          `UPDATE playlists SET updated_at = ? WHERE id = ?`,
                          [now, playlistId],
                          () => resolve(),
                          (_, error) => {
                            reject(error);
                            return true;
                          }
                        );
                      },
                      (_, error) => {
                        reject(error);
                        return true;
                      }
                    );
                  },
                  (_, error) => {
                    reject(error);
                    return true;
                  }
                );
              }
            },
            (_, error) => {
              reject(error);
              return true;
            }
          );
        },
        (error) => reject(error)
      );
    } catch (error) {
      reject(error);
    }
  });
}
