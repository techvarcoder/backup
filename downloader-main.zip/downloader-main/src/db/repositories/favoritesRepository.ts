// use flexible DB types from ../database
import { MediaItem } from '../../types';
import { getDatabase } from '../database';
import { v4 as uuid } from '../../utils/uuid';

/**
 * Add a media item to favorites
 */
export async function addFavorite(mediaId: string): Promise<void> {
  try {
    const db = await getDatabase();

    return new Promise((resolve, reject) => {
      db.transaction((tx) => {
        // First, update the media_items table to mark as favorite
        tx.executeSql(
          'UPDATE media_items SET is_favorite = 1 WHERE id = ?',
          [mediaId],
          () => {
            // Then insert into favorites table
            tx.executeSql(
              'INSERT OR IGNORE INTO favorites (id, media_id, created_at) VALUES (?, ?, ?)',
              [uuid(), mediaId, Date.now()],
              () => {
                console.log(`[Favorites] Added favorite: ${mediaId}`);
                resolve();
              },
              (_, error) => {
                console.error('[Favorites] Error inserting favorite:', error);
                reject(error);
                return true;
              }
            );
          },
          (_, error) => {
            console.error('[Favorites] Error updating media_items:', error);
            reject(error);
            return true;
          }
        );
      }, reject);
    });
  } catch (error) {
    console.error('[Favorites] addFavorite error:', error);
    throw error;
  }
}

/**
 * Remove a media item from favorites
 */
export async function removeFavorite(mediaId: string): Promise<void> {
  try {
    const db = await getDatabase();

    return new Promise((resolve, reject) => {
      db.transaction((tx) => {
        // First, update the media_items table to mark as not favorite
        tx.executeSql(
          'UPDATE media_items SET is_favorite = 0 WHERE id = ?',
          [mediaId],
          () => {
            // Then delete from favorites table
            tx.executeSql(
              'DELETE FROM favorites WHERE media_id = ?',
              [mediaId],
              () => {
                console.log(`[Favorites] Removed favorite: ${mediaId}`);
                resolve();
              },
              (_, error) => {
                console.error('[Favorites] Error deleting favorite:', error);
                reject(error);
                return true;
              }
            );
          },
          (_, error) => {
            console.error('[Favorites] Error updating media_items:', error);
            reject(error);
            return true;
          }
        );
      }, reject);
    });
  } catch (error) {
    console.error('[Favorites] removeFavorite error:', error);
    throw error;
  }
}

/**
 * Check if a media item is favorited
 */
export async function isFavorite(mediaId: string): Promise<boolean> {
  try {
    const db = await getDatabase();

    return new Promise((resolve, reject) => {
      db.transaction((tx) => {
        tx.executeSql(
          'SELECT COUNT(*) as count FROM favorites WHERE media_id = ?',
          [mediaId],
          (_: any, result: any) => {
            const first = Array.isArray(result) ? result[0] : result;
            const rows = first && first.rows ? first.rows : { length: 0, item: () => ({ count: 0 }) };
            const isFav = rows.item(0).count > 0;
            resolve(isFav);
          },
          (_, error) => {
            console.error('[Favorites] Error checking favorite:', error);
            reject(error);
            return true;
          }
        );
      }, reject);
    });
  } catch (error) {
    console.error('[Favorites] isFavorite error:', error);
    throw error;
  }
}

/**
 * Get all favorited media items with full details
 */
export async function getFavorites(): Promise<MediaItem[]> {
  try {
    const db = await getDatabase();

    return new Promise((resolve, reject) => {
      db.transaction((tx) => {
        tx.executeSql(
          `SELECT
            m.id,
            m.download_id as downloadId,
            m.title,
            m.platform,
            m.thumbnail_path as thumbnailPath,
            m.file_path as filePath,
            m.duration,
            m.file_size as fileSize,
            m.format,
            m.quality,
            m.media_type as mediaType,
            m.is_favorite as isFavorite,
            m.play_count as playCount,
            m.last_played_at as lastPlayedAt,
            m.created_at as createdAt
          FROM media_items m
          INNER JOIN favorites f ON m.id = f.media_id
          ORDER BY f.created_at DESC`,
          [],
          (_: any, result: any) => {
            const first = Array.isArray(result) ? result[0] : result;
            const rows = first && first.rows ? first.rows : { length: 0, item: () => null };
            const favorites: MediaItem[] = [];
            for (let i = 0; i < rows.length; i++) {
              const row = rows.item(i);
              favorites.push({
                id: row.id,
                downloadId: row.downloadId,
                title: row.title,
                platform: row.platform,
                thumbnailPath: row.thumbnailPath,
                filePath: row.filePath,
                duration: row.duration,
                fileSize: row.fileSize,
                format: row.format,
                quality: row.quality,
                mediaType: row.mediaType,
                isFavorite: row.isFavorite === 1,
                playCount: row.playCount,
                lastPlayedAt: row.lastPlayedAt,
                createdAt: row.createdAt,
              });
            }
            console.log(`[Favorites] Retrieved ${favorites.length} favorites`);
            resolve(favorites);
          },
          (_, error) => {
            console.error('[Favorites] Error fetching favorites:', error);
            reject(error);
            return true;
          }
        );
      }, reject);
    });
  } catch (error) {
    console.error('[Favorites] getFavorites error:', error);
    throw error;
  }
}
