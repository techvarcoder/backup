import { getDatabase, transaction } from '../database';

export async function getSetting(key: string): Promise<string | null> {
  try {
    const db = await getDatabase();
    return new Promise((resolve, reject) => {
      db.transaction(
        (tx) => {
          tx.executeSql(
            'SELECT value FROM app_settings WHERE key = ?',
            [key],
            (_: any, result: any) => {
              const first = Array.isArray(result) ? result[0] : result;
              const rows = first && first.rows ? first.rows : { length: 0, item: () => null };
              if (rows.length > 0) {
                resolve(rows.item(0).value);
              } else {
                resolve(null);
              }
            },
            (_, error) => {
              reject(error);
              return true;
            }
          );
        },
        (error) => reject(error)
      );
    });
  } catch (error) {
    console.error(`[SettingsRepository] Error getting setting ${key}:`, error);
    throw error;
  }
}

export async function setSetting(key: string, value: string): Promise<void> {
  try {
    const db = await getDatabase();
    return new Promise((resolve, reject) => {
      db.transaction(
        (tx) => {
          tx.executeSql(
            'INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES (?, ?, ?)',
            [key, value, Date.now()],
            () => resolve(),
            (_, error) => {
              reject(error);
              return true;
            }
          );
        },
        (error) => reject(error)
      );
    });
  } catch (error) {
    console.error(`[SettingsRepository] Error setting ${key}:`, error);
    throw error;
  }
}

export async function getAllSettings(): Promise<Record<string, string>> {
  try {
    const db = await getDatabase();
    return new Promise((resolve, reject) => {
      db.transaction(
        (tx) => {
          tx.executeSql(
            'SELECT key, value FROM app_settings',
            [],
            (_: any, result: any) => {
              const first = Array.isArray(result) ? result[0] : result;
              const rows = first && first.rows ? first.rows : { length: 0, item: () => null };
              const settings: Record<string, string> = {};
              for (let i = 0; i < rows.length; i++) {
                const row = rows.item(i);
                settings[row.key] = row.value;
              }
              resolve(settings);
            },
            (_, error) => {
              reject(error);
              return true;
            }
          );
        },
        (error) => reject(error)
      );
    });
  } catch (error) {
    console.error('[SettingsRepository] Error getting all settings:', error);
    throw error;
  }
}
