import { getDatabase } from '../database';
import { HistoryEntry } from '../../types/index';
import { v4 as uuid } from '../../utils/uuid';
import { logger } from '../../utils/logger';

/**
 * Insert a new history entry into the history table
 * @param entry The history entry data (without id)
 * @returns Promise that resolves when insertion is complete
 */
export async function insertHistory(entry: Omit<HistoryEntry, 'id'>): Promise<void> {
  try {
    const db = await getDatabase();

    return new Promise((resolve, reject) => {
      db.transaction(
        (tx) => {
          tx.executeSql(
            `INSERT INTO history (id, media_id, download_id, title, thumbnail_path, action, platform, created_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
            [
              uuid(),
              entry.mediaId,
              entry.downloadId,
              entry.title,
              entry.thumbnailPath,
              entry.action,
              entry.platform,
              entry.createdAt,
            ],
            () => {
              logger.log('[HistoryRepo] History entry inserted successfully');
              resolve();
            },
            (_, error) => {
              logger.error('[HistoryRepo] Error inserting history entry:', error);
              reject(error);
              return true;
            }
          );
        },
        (error) => {
          logger.error('[HistoryRepo] Transaction failed:', error);
          reject(error);
        }
      );
    });
  } catch (error) {
    logger.error('[HistoryRepo] insertHistory error:', error);
    throw error;
  }
}

/**
 * Retrieve history entries, optionally limited by count
 * @param limit Optional limit on number of entries to retrieve (max 10000)
 * @returns Promise resolving to array of HistoryEntry objects
 */
export async function getHistory(limit?: number): Promise<HistoryEntry[]> {
  try {
    const db = await getDatabase();

    return new Promise((resolve, reject) => {
      const limitValue = limit ? Math.max(1, Math.min(limit, 10000)) : undefined;
      const limitClause = limitValue ? ` LIMIT ${limitValue}` : '';

      db.transaction(
        (tx) => {
          tx.executeSql(
            `SELECT id, media_id, download_id, title, thumbnail_path, action, platform, created_at
             FROM history
             ORDER BY created_at DESC${limitClause}`,
            [],
            (_: any, result: any) => {
              const entries: HistoryEntry[] = [];
              const first = Array.isArray(result) ? result[0] : result;
              const rows = first && first.rows ? first.rows : { length: 0, item: () => null };
              for (let i = 0; i < rows.length; i++) {
                const row = rows.item(i);
                entries.push({
                  id: row.id,
                  mediaId: row.media_id,
                  downloadId: row.download_id,
                  title: row.title,
                  thumbnailPath: row.thumbnail_path,
                  action: row.action,
                  platform: row.platform,
                  createdAt: row.created_at,
                });
              }
              logger.log(`[HistoryRepo] Retrieved ${entries.length} history entries`);
              resolve(entries);
            },
            (_, error) => {
              logger.error('[HistoryRepo] Error fetching history:', error);
              reject(error);
              return true;
            }
          );
        },
        (error) => {
          logger.error('[HistoryRepo] Transaction failed:', error);
          reject(error);
        }
      );
    });
  } catch (error) {
    logger.error('[HistoryRepo] getHistory error:', error);
    throw error;
  }
}

/**
 * Clear all history entries from the history table
 * @returns Promise that resolves when all entries are deleted
 */
export async function clearHistory(): Promise<void> {
  try {
    const db = await getDatabase();

    return new Promise((resolve, reject) => {
      db.transaction(
        (tx) => {
          tx.executeSql(
            'DELETE FROM history',
            [],
            () => {
              logger.log('[HistoryRepo] History cleared successfully');
              resolve();
            },
            (_, error) => {
              logger.error('[HistoryRepo] Error clearing history:', error);
              reject(error);
              return true;
            }
          );
        },
        (error) => {
          logger.error('[HistoryRepo] Transaction failed:', error);
          reject(error);
        }
      );
    });
  } catch (error) {
    logger.error('[HistoryRepo] clearHistory error:', error);
    throw error;
  }
}

/**
 * Delete a specific history entry by ID
 * @param id The ID of the history entry to delete
 * @returns Promise that resolves when the entry is deleted
 */
export async function deleteHistoryEntry(id: string): Promise<void> {
  try {
    const db = await getDatabase();

    return new Promise((resolve, reject) => {
      db.transaction(
        (tx) => {
          tx.executeSql(
            'DELETE FROM history WHERE id = ?',
            [id],
            () => {
              logger.log(`[HistoryRepo] History entry deleted: ${id}`);
              resolve();
            },
            (_, error) => {
              logger.error('[HistoryRepo] Error deleting history entry:', error);
              reject(error);
              return true;
            }
          );
        },
        (error) => {
          logger.error('[HistoryRepo] Transaction failed:', error);
          reject(error);
        }
      );
    });
  } catch (error) {
    logger.error('[HistoryRepo] deleteHistoryEntry error:', error);
    throw error;
  }
}
