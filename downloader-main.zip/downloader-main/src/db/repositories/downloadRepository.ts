import { getDatabase } from '../database';
import { DownloadItem, DownloadStats } from '../../types/index';

// Minimal, clear implementations to avoid transform/parser issues
export async function insertDownload(item: DownloadItem): Promise<void> {
  const db = await getDatabase();
  return new Promise((resolve, reject) => {
    try {
      db.transaction(
        (tx) => {
          const sql =
            'INSERT INTO downloads (id, url, title, platform, thumbnail_url, duration, file_size, downloaded_bytes, progress, status, quality, format, file_path, created_at, completed_at, error_message, retry_count) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
          const params = [
            item.id,
            item.url,
            item.title,
            item.platform,
            item.thumbnailUrl,
            item.duration || 0,
            item.fileSize || 0,
            item.downloadedBytes || 0,
            item.progress || 0,
            item.status || 'pending',
            item.quality || null,
            item.format || null,
            item.filePath || null,
            item.createdAt || Date.now(),
            item.completedAt || null,
            item.errorMessage || null,
            item.retryCount || 0,
          ];
          tx.executeSql(
            sql,
            params,
            () => resolve(),
            (_, error) => {
              reject(error);
              return true;
            }
          );
        },
        (err) => reject(err)
      );
    } catch (err) {
      reject(err);
    }
  });
}

export async function updateDownloadProgress(id: string, progress: number, downloadedBytes: number): Promise<void> {
  const db = await getDatabase();
  return new Promise((resolve, reject) => {
    db.transaction(
      (tx) => {
        tx.executeSql(
          'UPDATE downloads SET progress = ?, downloaded_bytes = ? WHERE id = ?',
          [progress, downloadedBytes, id],
          () => resolve(),
          (_, error) => {
            reject(error);
            return true;
          }
        );
      },
      (err) => reject(err)
    );
  });
}

export async function updateDownloadStatus(id: string, status: string, errorMessage?: string): Promise<void> {
  const db = await getDatabase();
  const completedAt = status === 'completed' ? Date.now() : null;
  return new Promise((resolve, reject) => {
    db.transaction(
      (tx) => {
        tx.executeSql(
          'UPDATE downloads SET status = ?, error_message = ?, completed_at = ? WHERE id = ?',
          [status, errorMessage || null, completedAt, id],
          () => resolve(),
          (_, error) => {
            reject(error);
            return true;
          }
        );
      },
      (err) => reject(err)
    );
  });
}

export async function deleteDownload(id: string): Promise<void> {
  const db = await getDatabase();
  return new Promise((resolve, reject) => {
    db.transaction(
      (tx) => {
        tx.executeSql(
          'DELETE FROM downloads WHERE id = ?',
          [id],
          () => resolve(),
          (_, error) => {
            reject(error);
            return true;
          }
        );
      },
      (err) => reject(err)
    );
  });
}

export async function getDownloads(): Promise<DownloadItem[]> {
  const db = await getDatabase();
  return new Promise((resolve, reject) => {
    db.transaction(
      (tx) => {
        const sql =
          'SELECT id, url, title, platform, thumbnail_url, duration, file_size, downloaded_bytes, progress, status, quality, format, file_path, created_at, completed_at, error_message, retry_count FROM downloads ORDER BY created_at DESC';
        tx.executeSql(
          sql,
          [],
          (_: any, result: any) => {
            const first = Array.isArray(result) ? result[0] : result;
            const rows = first && first.rows ? first.rows : { length: 0, item: () => null };
            const items: DownloadItem[] = [];
            for (let i = 0; i < rows.length; i++) {
              const row = rows.item(i);
              items.push({
                id: row.id,
                url: row.url,
                title: row.title,
                platform: row.platform,
                thumbnailUrl: row.thumbnail_url,
                duration: row.duration,
                fileSize: row.file_size,
                downloadedBytes: row.downloaded_bytes,
                progress: row.progress,
                status: row.status,
                quality: row.quality,
                format: row.format,
                filePath: row.file_path,
                createdAt: row.created_at,
                completedAt: row.completed_at,
                errorMessage: row.error_message,
                retryCount: row.retry_count,
              });
            }
            resolve(items);
          },
          (_, error) => {
            reject(error);
            return true;
          }
        );
      },
      (err) => reject(err)
    );
  });
}

export async function getDownloadById(id: string): Promise<DownloadItem | null> {
  const db = await getDatabase();
  return new Promise((resolve, reject) => {
    db.transaction(
      (tx) => {
        tx.executeSql(
          'SELECT * FROM downloads WHERE id = ? LIMIT 1',
          [id],
          (_: any, result: any) => {
            const first = Array.isArray(result) ? result[0] : result;
            const rows = first && first.rows ? first.rows : { length: 0, item: () => null };
            if (rows.length === 0) return resolve(null);
            const row = rows.item(0);
            resolve({
              id: row.id,
              url: row.url,
              title: row.title,
              platform: row.platform,
              thumbnailUrl: row.thumbnail_url,
              duration: row.duration,
              fileSize: row.file_size,
              downloadedBytes: row.downloaded_bytes,
              progress: row.progress,
              status: row.status,
              quality: row.quality,
              format: row.format,
              filePath: row.file_path,
              createdAt: row.created_at,
              completedAt: row.completed_at,
              errorMessage: row.error_message,
              retryCount: row.retry_count,
            });
          },
          (_, error) => {
            reject(error);
            return true;
          }
        );
      },
      (err) => reject(err)
    );
  });
}

export async function getDownloadStats(): Promise<DownloadStats> {
  const db = await getDatabase();
  return new Promise((resolve, reject) => {
    db.transaction(
      (tx) => {
        tx.executeSql(
          `SELECT
            COUNT(*) AS total_downloads,
            SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS total_completed,
            SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS total_failed,
            SUM(CASE WHEN status = 'completed' THEN file_size ELSE 0 END) AS total_size
          FROM downloads`,
          [],
          (_: any, result: any) => {
            const first = Array.isArray(result) ? result[0] : result;
            const rows = first && first.rows ? first.rows : { length: 0, item: () => ({}) };
            const row = rows.item(0);
            resolve({
              totalDownloads: row.total_downloads || 0,
              totalCompleted: row.total_completed || 0,
              totalFailed: row.total_failed || 0,
              totalSize: row.total_size || 0,
            });
          },
          (_, error) => {
            reject(error);
            return true;
          }
        );
      },
      (err) => reject(err)
    );
  });
}

export async function getDownloadByUrl(url: string): Promise<DownloadItem | null> {
  const db = await getDatabase();
  return new Promise((resolve, reject) => {
    db.transaction(
      (tx) => {
        tx.executeSql(
          'SELECT * FROM downloads WHERE url = ? LIMIT 1',
          [url],
          (_, result) => {
            if (result.rows.length === 0) return resolve(null);
            const row = result.rows.item(0);
            resolve({
              id: row.id,
              url: row.url,
              title: row.title,
              platform: row.platform,
              thumbnailUrl: row.thumbnail_url,
              duration: row.duration,
              fileSize: row.file_size,
              downloadedBytes: row.downloaded_bytes,
              progress: row.progress,
              status: row.status,
              quality: row.quality,
              format: row.format,
              filePath: row.file_path,
              createdAt: row.created_at,
              completedAt: row.completed_at,
              errorMessage: row.error_message,
              retryCount: row.retry_count,
            });
          },
          (_, error) => {
            reject(error);
            return true;
          }
        );
      },
      (err) => reject(err)
    );
  });
}
