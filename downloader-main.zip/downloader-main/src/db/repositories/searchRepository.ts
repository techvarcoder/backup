import { getDatabase } from '../database';
import { RecentSearch } from '../../types';

const MAX_RECENT_SEARCHES = 20;

export async function saveSearch(query: string): Promise<void> {
  try {
    const db = await getDatabase();
    return new Promise((resolve, reject) => {
      db.transaction(
        (tx) => {
          // Insert or update the search query
          tx.executeSql(
            `INSERT OR REPLACE INTO recent_searches (id, query, created_at)
             VALUES (?, ?, ?)`,
            [query, query, Date.now()],
            () => {
              // After insert/update, delete old entries if exceeding max
              tx.executeSql(
                `DELETE FROM recent_searches WHERE id NOT IN (
                   SELECT id FROM recent_searches ORDER BY created_at DESC LIMIT ?
                 )`,
                [MAX_RECENT_SEARCHES],
                () => resolve(),
                (_, error) => {
                  reject(error);
                  return true;
                }
              );
            },
            (_, error) => {
              reject(error);
              return true;
            }
          );
        },
        (error) => reject(error)
      );
    });
  } catch (error) {
    console.error('[SearchRepository] Error saving search:', error);
    throw error;
  }
}

export async function getRecentSearches(): Promise<RecentSearch[]> {
  try {
    const db = await getDatabase();
    return new Promise((resolve, reject) => {
      db.transaction(
        (tx) => {
          tx.executeSql(
            `SELECT id, query, created_at FROM recent_searches
             ORDER BY created_at DESC`,
            [],
            (_: any, result: any) => {
              const first = Array.isArray(result) ? result[0] : result;
              const rows = first && first.rows ? first.rows : { length: 0, item: () => null };
              const searches: RecentSearch[] = [];
              for (let i = 0; i < rows.length; i++) {
                const row = rows.item(i);
                searches.push({
                  id: row.id,
                  query: row.query,
                  createdAt: row.created_at,
                });
              }
              resolve(searches);
            },
            (_, error) => {
              reject(error);
              return true;
            }
          );
        },
        (error) => reject(error)
      );
    });
  } catch (error) {
    console.error('[SearchRepository] Error getting recent searches:', error);
    throw error;
  }
}

export async function clearRecentSearches(): Promise<void> {
  try {
    const db = await getDatabase();
    return new Promise((resolve, reject) => {
      db.transaction(
        (tx) => {
          tx.executeSql(
            'DELETE FROM recent_searches',
            [],
            () => resolve(),
            (_, error) => {
              reject(error);
              return true;
            }
          );
        },
        (error) => reject(error)
      );
    });
  } catch (error) {
    console.error('[SearchRepository] Error clearing recent searches:', error);
    throw error;
  }
}

// Backwards-compatible aliases expected by some callers
export const insertSearch = saveSearch;
export const clearSearches = clearRecentSearches;

export async function deleteSearch(id: string): Promise<void> {
  try {
    const db = await getDatabase();
    return new Promise((resolve, reject) => {
      db.transaction(
        (tx: any) => {
          tx.executeSql('DELETE FROM recent_searches WHERE id = ?', [id], () => resolve(), (_: any, error: any) => { reject(error); return true; });
        },
        (error: any) => reject(error)
      );
    });
  } catch (error) {
    console.error('[SearchRepository] Error deleting search:', error);
    throw error;
  }
}
