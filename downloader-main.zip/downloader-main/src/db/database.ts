import { SQLiteDatabase, openDatabase } from 'react-native-sqlite-storage';
import { logger } from '../utils/logger';
import { getAllCreateStatements, getAllIndexStatements } from './schema';

let db: any = null;
let dbPromise: Promise<any> | null = null;

export async function getDatabase(): Promise<any> {
  if (db) {
    return db;
  }

  if (dbPromise) {
    return dbPromise;
  }

  dbPromise = initializeDatabase();

  try {
    const database = await dbPromise;
    db = database;
    return database;
  } catch (error) {
    dbPromise = null;
    throw error;
  }
}

async function initializeDatabase(): Promise<any> {
  try {
    logger.log('[DB] Opening database');
    const database = await openDatabase({
      name: 'medianest.db',
      location: 'default',
    });

    logger.log('[DB] Creating tables and indexes');
    const createStatements = getAllCreateStatements();
    for (const sql of createStatements) {
      await database.executeSql(sql);
    }

    const indexStatements = getAllIndexStatements();
    for (const sql of indexStatements) {
      await database.executeSql(sql);
    }

    logger.log('[DB] Database initialized');
    return database;
  } catch (error) {
    logger.error('[DB] Init error:', error);
    throw error;
  }
}

export async function closeDatabase(): Promise<void> {
  if (!db) return;
  try {
    await db.close();
    db = null;
    dbPromise = null;
  } catch (error) {
    db = null;
    dbPromise = null;
  }
}

export async function executeSql(sql: string, params: any[] = []): Promise<any> {
  const database = await getDatabase();
  return database.executeSql(sql, params);
}

// Helper to run a transaction with a callback
export async function transaction(fn: (tx: any) => void | Promise<void>): Promise<void> {
  const database = await getDatabase();
  return new Promise<void>((resolve, reject) => {
    database.transaction(
      (tx: any) => {
        Promise.resolve(fn(tx)).catch(reject);
      },
      (err: any) => reject(err),
      () => resolve()
    );
  });
}
