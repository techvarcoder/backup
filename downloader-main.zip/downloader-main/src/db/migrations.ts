// Database migrations
// Handles versioning, schema migrations, and transactional updates
import { SQLiteDatabase } from 'react-native-sqlite-storage';
import {
  getAllCreateStatements,
  getAllIndexStatements,
} from './schema';

/**
 * Current database schema version.
 * Increment this when adding new migrations (v2, v3, etc).
 * Migrations are applied sequentially based on current version.
 */
export const DB_VERSION = 1;

/**
 * Migration state tracking for debugging
 */
interface MigrationState {
  currentVersion: number;
  targetVersion: number;
  pending: number[];
  applied: number[];
}

/**
 * Main migration entry point called by getDatabase()
 * Checks db_version and applies all pending migrations in a transaction
 * @param db - SQLiteDatabase instance
 * @throws Error if migrations fail
 */
export async function runMigrations(db: any): Promise<void> {
  try {
    // Ensure app_settings table exists (idempotent)
    await ensureSettingsTable(db);

    // Get current database version
    const currentVersion = await getDbVersion(db);
    const { log } = require('../utils/logger').logger;
    log(`[DB] Current schema version: ${currentVersion}, target: ${DB_VERSION}`);

    // Apply pending migrations if needed
    if (currentVersion < DB_VERSION) {
      const pendingVersions = getPendingMigrations(currentVersion, DB_VERSION);
      console.log(`[DB] Applying migrations: ${pendingVersions.join(' -> ')}`);

      // Run all pending migrations in a single transaction
      await applyPendingMigrations(db, pendingVersions);

      // Update version to target after successful migration
      await setDbVersion(db, DB_VERSION);
      console.log(`[DB] Migrations completed: version ${currentVersion} -> ${DB_VERSION}`);
    } else {
      console.log('[DB] Database is at current version, no migrations needed');
    }
  } catch (error) {
    console.error('[DB] Migration error:', error);
    throw error;
  }
}

/**
 * Ensures app_settings table exists with proper schema
 * Creates table if it doesn't exist (handles fresh database)
 */
async function ensureSettingsTable(db: any): Promise<void> {
  try {
    await db.executeSql(
      `CREATE TABLE IF NOT EXISTS app_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )`
    );
  } catch (error) {
    console.error('[DB] Error creating app_settings table:', error);
    throw error;
  }
}

/**
 * Retrieves current database version from app_settings
 * Returns 0 if not found (indicating fresh/uninitialized database)
 * @returns Current version number (0 if not set)
 */
async function getDbVersion(db: any): Promise<number> {
  try {
    const result: any = await db.executeSql(
      'SELECT value FROM app_settings WHERE key = ?',
      ['db_version']
    );

    // executeSql may return an array of ResultSet; normalize access
    const first = Array.isArray(result) ? result[0] : result;
    if (first && first.rows && first.rows.length > 0) {
      const version = parseInt(first.rows.item(0).value, 10);
      return isNaN(version) ? 0 : version;
    }

    return 0; // Not found = fresh database
  } catch (error) {
    // Handle "table doesn't exist" or query errors gracefully
    // This is expected on first run before app_settings is created
    console.warn('[DB] Could not read db_version (expected on first run):', error);
    return 0;
  }
}

/**
 * Updates database version in app_settings
 * Uses INSERT OR REPLACE for idempotency
 */
async function setDbVersion(db: any, version: number): Promise<void> {
  try {
    await db.executeSql(
      'INSERT OR REPLACE INTO app_settings (key, value, updated_at) VALUES (?, ?, ?)',
      ['db_version', version.toString(), new Date().toISOString()]
    );
  } catch (error) {
    console.error('[DB] Error updating db_version:', error);
    throw error;
  }
}

/**
 * Calculates which migrations need to be applied
 * Returns array of version numbers to migrate to (e.g., [1] or [1, 2, 3])
 */
function getPendingMigrations(currentVersion: number, targetVersion: number): number[] {
  const pending: number[] = [];
  for (let v = currentVersion + 1; v <= targetVersion; v++) {
    pending.push(v);
  }
  return pending;
}

/**
 * Applies all pending migrations in a single transaction
 * Ensures atomicity: all migrate or all rollback on failure
 * @param db - SQLiteDatabase instance
 * @param versions - Array of version numbers to apply (e.g., [1, 2, 3])
 */
async function applyPendingMigrations(
  db: any,
  versions: number[]
): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    // Use database transaction for atomicity
    db.transaction(
      async (tx: any) => {
        try {
          for (const version of versions) {
            console.log(`[DB] Applying migration to v${version}...`);

            if (version === 1) {
              await applyV1Migration(tx);
            } else if (version === 2) {
              await applyV2Migration(tx);
            } else if (version === 3) {
              await applyV3Migration(tx);
            } else {
              throw new Error(`Unknown migration version: ${version}`);
            }

            console.log(`[DB] Migration to v${version} completed`);
          }
        } catch (error) {
          throw error; // Transaction will rollback
        }
      },
      (error) => {
        console.error('[DB] Transaction failed, rolling back:', error);
        reject(error);
      },
      () => {
        console.log('[DB] Migration transaction committed');
        resolve();
      }
    );
  });
}

/**
 * V1 Migration: Initial schema with all core tables
 * Runs schema creation statements from schema.ts
 */
async function applyV1Migration(tx: any): Promise<void> {
  try {
    // Create all tables
    const createStatements = getAllCreateStatements();
    for (const sql of createStatements) {
      await tx.executeSql(sql);
    }

    // Create all indexes
    const indexStatements = getAllIndexStatements();
    for (const sql of indexStatements) {
      await tx.executeSql(sql);
    }

    console.log('[DB] V1 migration: created tables and indexes');
  } catch (error) {
    console.error('[DB] Error in V1 migration:', error);
    throw error;
  }
}

/**
 * V2 Migration: Future-proof placeholder
 * Add schema changes here when needed
 * Example: ALTER TABLE downloads ADD COLUMN new_field TEXT;
 */
async function applyV2Migration(tx: any): Promise<void> {
  try {
    console.log('[DB] V2 migration: no changes (placeholder)');
    // TODO: Add migration statements here when V2 schema changes needed
    // Example:
    // await tx.executeSql('ALTER TABLE downloads ADD COLUMN new_field TEXT DEFAULT NULL;');
  } catch (error) {
    console.error('[DB] Error in V2 migration:', error);
    throw error;
  }
}

/**
 * V3 Migration: Future-proof placeholder
 * Add schema changes here when needed
 */
async function applyV3Migration(tx: any): Promise<void> {
  try {
    console.log('[DB] V3 migration: no changes (placeholder)');
    // TODO: Add migration statements here when V3 schema changes needed
  } catch (error) {
    console.error('[DB] Error in V3 migration:', error);
    throw error;
  }
}
