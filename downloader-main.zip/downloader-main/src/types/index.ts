// Enums & Types
export type DownloadStatus = 'pending' | 'analyzing' | 'downloading' | 'paused' | 'completed' | 'failed' | 'cancelled';
export type MediaType = 'video' | 'audio' | 'image' | 'reel';
export type ViewMode = 'grid' | 'list';
export type SortField = 'date' | 'name' | 'size' | 'platform';
export type SortOrder = 'asc' | 'desc';
export type RepeatMode = 'none' | 'one' | 'all';
export type ThemeMode = 'dark' | 'light';

// Download Item
export interface DownloadItem {
  id: string;
  url: string;
  title: string;
  platform: string;
  thumbnailUrl: string;
  duration: number;
  fileSize: number;
  downloadedBytes: number;
  progress: number;
  status: DownloadStatus;
  quality: string;
  format: string;
  filePath: string;
  createdAt: number;
  completedAt?: number | null;
  errorMessage: string | null;
  retryCount: number;
}

// Media Item (in local library)
export interface MediaItem {
  id: string;
  downloadId: string;
  title: string;
  platform: string;
  thumbnailPath: string;
  filePath: string;
  duration: number;
  fileSize: number;
  format: string;
  quality: string;
  mediaType: MediaType;
  isFavorite: boolean;
  playCount: number;
  lastPlayedAt: number | null;
  createdAt: number;
}

// Video Analysis (from URL)
export interface VideoAnalysis {
  url: string;
  platform: string;
  title: string;
  channelName: string;
  thumbnailUrl: string;
  duration: number;
  viewCount: number | null;
  availableQualities: QualityOption[];
  availableAudioFormats: AudioFormatOption[];
  hasThumbnailDownload: boolean;
  isPlaylist: boolean;
  playlistCount: number;
}

// Quality Option
export interface QualityOption {
  label: string;
  value: string;
  fileSize: number | null;
  fps: number | null;
  hasAudio: boolean;
}

// Audio Format Option
export interface AudioFormatOption {
  label: string;
  ext: string;
  bitrate: string;
  mimeType: string;
}

// Playlist
export interface PlaylistItem {
  id: string;
  name: string;
  description: string;
  coverPath: string | null;
  itemCount: number;
  createdAt: number;
}

// History Entry
export interface HistoryEntry {
  id: string;
  mediaId: string | null;
  downloadId: string | null;
  title: string;
  thumbnailPath: string;
  action: 'played' | 'downloaded' | 'failed';
  platform: string;
  createdAt: number;
}

// App Settings
export interface AppSettings {
  themeMode: ThemeMode;
  language: string;
  downloadPath: string;
  defaultVideoQuality: string;
  defaultAudioFormat: string;
  maxConcurrentDownloads: number;
  notificationsEnabled: boolean;
  wifiOnlyDownload: boolean;
  autoRetryFailed: boolean;
  autoDetectLinks: boolean;
  clipboardMonitor: boolean;
  autoPlayNext: boolean;
  sleepTimerMinutes: number;
  storageWarningThreshold: number;
}

// Browser Tab
export interface BrowserTab {
  id: string;
  url: string;
  title: string;
  isLoading: boolean;
  detectedVideos: DetectedVideo[];
}

// Detected Video
export interface DetectedVideo {
  url: string;
  title: string;
  platform: string;
  thumbnailUrl: string | null;
}

// Recent Search
export interface RecentSearch {
  id: string;
  query: string;
  createdAt: number;
}

// Supported Platform
export interface SupportedPlatform {
  id: string;
  label: string;
  icon: string;
  color: string;
}

// Native Modules Status
export interface NativeModulesStatus {
  videoPlayer: boolean;
  webView: boolean;
  fileSystem: boolean;
  backgroundDownloader: boolean;
}

// Download Stats
export interface DownloadStats {
  totalDownloads: number;
  totalCompleted: number;
  totalFailed: number;
  totalSize: number;
}
