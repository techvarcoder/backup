import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { LibraryStackParamList } from './types';
import MediaLibraryScreen from '../screens/library/MediaLibraryScreen';

const Stack = createNativeStackNavigator<LibraryStackParamList>();

export default function LibraryStackNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="MediaLibrary" component={MediaLibraryScreen} />
    </Stack.Navigator>
  );
}
