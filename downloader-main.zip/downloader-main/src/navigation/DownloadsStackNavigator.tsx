import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { DownloadsStackParamList } from './types';
import DownloadManagerScreen from '../screens/download/DownloadManagerScreen';

const Stack = createNativeStackNavigator<DownloadsStackParamList>();

export default function DownloadsStackNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="DownloadManager" component={DownloadManagerScreen} />
    </Stack.Navigator>
  );
}
