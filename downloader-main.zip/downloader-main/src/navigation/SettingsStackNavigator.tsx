import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SettingsStackParamList } from './types';
import SettingsScreen from '../screens/settings/SettingsScreen';
import VideoQualityScreen from '../screens/settings/VideoQualityScreen';
import AudioFormatScreen from '../screens/settings/AudioFormatScreen';
import LanguageScreen from '../screens/settings/LanguageScreen';
import MaxConcurrentScreen from '../screens/settings/MaxConcurrentScreen';
import AboutScreen from '../screens/settings/AboutScreen';

const Stack = createNativeStackNavigator<SettingsStackParamList>();

export default function SettingsStackNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="SettingsMain" component={SettingsScreen} />
      <Stack.Screen name="VideoQuality" component={VideoQualityScreen} />
      <Stack.Screen name="AudioFormat" component={AudioFormatScreen} />
      <Stack.Screen name="Language" component={LanguageScreen} />
      <Stack.Screen name="MaxConcurrent" component={MaxConcurrentScreen} />
      <Stack.Screen name="About" component={AboutScreen} />
    </Stack.Navigator>
  );
}
