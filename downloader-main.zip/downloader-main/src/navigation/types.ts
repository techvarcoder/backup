import { NavigatorScreenParams } from '@react-navigation/native';
import { VideoAnalysis } from '../types';

// Root Stack
export type RootStackParamList = {
  Splash: undefined;
  MainTabs: NavigatorScreenParams<MainTabParamList>;
  VideoAnalysis: { url: string };
  DownloadOptions: { analysis: VideoAnalysis };
  VideoPlayer: { mediaId: string; startPosition?: number };
  AudioPlayer: { mediaId: string };
  Search: { initialQuery?: string };
  BatchDownload: undefined;
  History: undefined;
  Favorites: undefined;
};

// Home Stack
export type HomeStackParamList = {
  HomeMain: undefined;
};

// Downloads Stack
export type DownloadsStackParamList = {
  DownloadManager: undefined;
};

// Library Stack
export type LibraryStackParamList = {
  MediaLibrary: undefined;
};

// Browser Stack
export type BrowserStackParamList = {
  BrowserMain: undefined;
};

// Settings Stack
export type SettingsStackParamList = {
  SettingsMain: undefined;
  VideoQuality: undefined;
  AudioFormat: undefined;
  Language: undefined;
  MaxConcurrent: undefined;
  About: undefined;
};

// Main Tab Navigator
export type MainTabParamList = {
  HomeTab: NavigatorScreenParams<HomeStackParamList>;
  DownloadsTab: NavigatorScreenParams<DownloadsStackParamList>;
  LibraryTab: NavigatorScreenParams<LibraryStackParamList>;
  BrowserTab: NavigatorScreenParams<BrowserStackParamList>;
  SettingsTab: NavigatorScreenParams<SettingsStackParamList>;
};
