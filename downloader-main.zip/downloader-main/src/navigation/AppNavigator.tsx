import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { RootStackParamList } from './types';
import SplashScreen from '../screens/splash/SplashScreen';
import MainTabNavigator from './MainTabNavigator';
import VideoAnalysisScreen from '../screens/analysis/VideoAnalysisScreen';
import DownloadOptionsScreen from '../screens/download/DownloadOptionsScreen';
import VideoPlayerScreen from '../screens/library/VideoPlayerScreen';
import AudioPlayerScreen from '../screens/library/AudioPlayerScreen';
import SearchScreen from '../screens/search/SearchScreen';
import BatchDownloadScreen from '../screens/download/BatchDownloadScreen';
import HistoryScreen from '../screens/history/HistoryScreen';
import FavoritesScreen from '../screens/favorites/FavoritesScreen';

const Stack = createNativeStackNavigator<RootStackParamList>();

export function AppNavigator() {
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="Splash" component={SplashScreen} options={{ animation: 'none' }} />
        <Stack.Screen name="MainTabs" component={MainTabNavigator} />
        <Stack.Screen name="VideoAnalysis" component={VideoAnalysisScreen} />
        <Stack.Screen name="DownloadOptions" component={DownloadOptionsScreen} />
        <Stack.Screen name="VideoPlayer" component={VideoPlayerScreen} options={{ presentation: 'fullScreenModal' }} />
        <Stack.Screen name="AudioPlayer" component={AudioPlayerScreen} options={{ presentation: 'modal' }} />
        <Stack.Screen name="Search" component={SearchScreen} />
        <Stack.Screen name="BatchDownload" component={BatchDownloadScreen} />
        <Stack.Screen name="History" component={HistoryScreen} />
        <Stack.Screen name="Favorites" component={FavoritesScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
