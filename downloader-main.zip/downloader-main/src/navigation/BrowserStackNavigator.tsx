import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { BrowserStackParamList } from './types';
import BrowserScreen from '../screens/browser/BrowserScreen';

const Stack = createNativeStackNavigator<BrowserStackParamList>();

export default function BrowserStackNavigator() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="BrowserMain" component={BrowserScreen} />
    </Stack.Navigator>
  );
}
