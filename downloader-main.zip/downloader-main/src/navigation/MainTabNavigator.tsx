import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import { useColors } from '../theme';
import { MainTabParamList } from './types';
import HomeStackNavigator from './HomeStackNavigator';
import DownloadsStackNavigator from './DownloadsStackNavigator';
import LibraryStackNavigator from './LibraryStackNavigator';
import BrowserStackNavigator from './BrowserStackNavigator';
import SettingsStackNavigator from './SettingsStackNavigator';

const Tab = createBottomTabNavigator<MainTabParamList>();

export default function MainTabNavigator() {
  const colors = useColors();

  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.textMuted,
        tabBarStyle: {
          backgroundColor: colors.surface,
          borderTopColor: colors.divider,
          borderTopWidth: 1,
          paddingBottom: 5,
        },
        tabBarIcon: ({ color, size }) => {
          let iconName = 'home';
          if (route.name === 'HomeTab') iconName = 'home-outline';
          if (route.name === 'DownloadsTab') iconName = 'download';
          if (route.name === 'LibraryTab') iconName = 'library';
          if (route.name === 'BrowserTab') iconName = 'web';
          if (route.name === 'SettingsTab') iconName = 'cog';
          return <MaterialCommunityIcons name={iconName as any} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen
        name="HomeTab"
        component={HomeStackNavigator}
        options={{ title: 'Home' }}
      />
      <Tab.Screen
        name="DownloadsTab"
        component={DownloadsStackNavigator}
        options={{ title: 'Downloads' }}
      />
      <Tab.Screen
        name="LibraryTab"
        component={LibraryStackNavigator}
        options={{ title: 'Library' }}
      />
      <Tab.Screen
        name="BrowserTab"
        component={BrowserStackNavigator}
        options={{ title: 'Browser' }}
      />
      <Tab.Screen
        name="SettingsTab"
        component={SettingsStackNavigator}
        options={{ title: 'Settings' }}
      />
    </Tab.Navigator>
  );
}
