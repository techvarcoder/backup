// Deprecated: Use useColors() from colors.ts instead
export { useColors as useTheme } from './colors';
