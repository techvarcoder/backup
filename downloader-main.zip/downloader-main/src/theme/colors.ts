export const darkColors = {
  primaryBackground: '#0B1020',
  secondaryBackground: '#141A2F',
  cardBackground: '#1D2440',
  elevatedCard: '#242B4A',

  primaryText: '#FFFFFF',
  secondaryText: '#B0B7D1',
  mutedText: '#6B7280',

  primary: '#7C4DFF',
  primaryLight: '#9B6DFF',
  secondary: '#00E5FF',

  accentYellow: '#FFC107',
  accentOrange: '#FB923C',

  success: '#00C853',
  danger: '#FF5252',
  warning: '#FFC107',

  border: '#2B3356',
  divider: '#2B3356',
  overlay: 'rgba(0,0,0,0.6)',

  white: '#FFFFFF',
  black: '#000000',

  tabBar: '#141A2F',
  tabBarBorder: '#2B3356',
};

export const lightColors = {
  primaryBackground: '#F7F8FC',
  secondaryBackground: '#FFFFFF',
  cardBackground: '#FFFFFF',
  elevatedCard: '#FFFFFF',

  primaryText: '#111827',
  secondaryText: '#4B5563',
  mutedText: '#9CA3AF',

  primary: '#7C4DFF',
  primaryLight: '#9B6DFF',
  secondary: '#00E5FF',

  accentYellow: '#FFC107',
  accentOrange: '#FB923C',

  success: '#00C853',
  danger: '#FF5252',
  warning: '#FFC107',

  border: 'rgba(0,0,0,0.08)',
  divider: 'rgba(0,0,0,0.08)',
  overlay: 'rgba(0,0,0,0.5)',

  white: '#FFFFFF',
  black: '#000000',

  tabBar: '#FFFFFF',
  tabBarBorder: 'rgba(0,0,0,0.06)',
};

export const gradients = {
  primary: ['#7C4DFF', '#5B2EFF'] as string[],
  secondary: ['#00E5FF', '#0090FF'] as string[],
  orange: ['#FB923C', '#FFC107'] as string[],
  blue: ['#3B82F6', '#1D4ED8'] as string[],
  green: ['#00C853', '#00BFA5'] as string[],
  pink: ['#EC4899', '#DB2777'] as string[],
  dark: ['#1D2440', '#141A2F'] as string[],
  splash: ['#0B1020', '#141A2F', '#1D2440'] as string[],
};

export type Colors = typeof darkColors;

export function useColors() {
  return {
    background: darkColors.primaryBackground,
    surface: darkColors.secondaryBackground,
    card: darkColors.cardBackground,
    elevatedCard: darkColors.elevatedCard,
    primary: darkColors.primary,
    primaryLight: darkColors.primaryLight,
    secondary: darkColors.secondary,
    textPrimary: darkColors.primaryText,
    textSecondary: darkColors.secondaryText,
    textMuted: darkColors.mutedText,
    divider: darkColors.divider,
    border: darkColors.border,
    success: darkColors.success,
    error: darkColors.danger,
    warning: darkColors.warning,
    tabBar: darkColors.tabBar,
    tabBarBorder: darkColors.tabBarBorder,
  };
}
