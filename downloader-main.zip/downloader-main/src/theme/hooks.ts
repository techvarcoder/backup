export { useColors } from './colors';
