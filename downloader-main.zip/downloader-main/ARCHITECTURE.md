# MediaNest - Architecture Overview

## 🏗️ Layered Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      APP.TSX ENTRY POINT                     │
│                  GestureHandlerRootView                       │
│                  SafeAreaProvider                             │
│                  ThemeProvider (theme context)                │
│                  BottomSheetModalProvider (modals)            │
│                  AppNavigator (React Navigation)              │
└─────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                        │
│                    (React Components)                        │
├─────────────────────────────────────────────────────────────┤
│  SCREENS (14)           │  COMPONENTS (33)                   │
│  ─────────────          │  ──────────────                    │
│  • Splash               │  Common (14):                       │
│  • Home                 │    ThemedText, GradientButton,     │
│  • VideoAnalysis        │    ProgressBar, Badge,             │
│  • DownloadOptions      │    SearchBar, etc.                 │
│  • DownloadManager      │                                    │
│  • MediaLibrary         │  Domain (19):                       │
│  • VideoPlayer          │    DownloadCard,                   │
│  • AudioPlayer          │    MediaCard, SeekBar,             │
│  • Browser              │    URLInputCard, etc.              │
│  • Search               │                                    │
│  • Favorites            │  All use useTheme() hook           │
│  • History              │  All use Zustand stores            │
│  • Settings             │  All call services                 │
└─────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    STATE MANAGEMENT LAYER                    │
│                   (Zustand Stores - RAM)                    │
├─────────────────────────────────────────────────────────────┤
│  downloadStore      │ libraryStore    │ settingsStore       │
│  ───────────────    │ ──────────────  │ ───────────────     │
│  • activeDownloads  │ • allMedia      │ • settings          │
│  • progress         │ • filteredMedia │ • isHydrated        │
│  • speed            │ • activeTab     │ • updateSetting()   │
│  • addDownload()    │ • viewMode      │ • resetSettings()   │
│  • pause/resume/    │ • loadMedia()   │ • hydrate()         │
│    cancel/retry     │ • toggleFav()   │                     │
│                     │ • deleteMedia() │  playerStore        │
│  +2 more stores     │                 │  ────────────       │
│   (user events)     │ +actions        │  • currentVideoId   │
│                     │                 │  • playVideo()      │
└─────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   BUSINESS LOGIC LAYER                       │
│                    (Services - Singletons)                  │
├─────────────────────────────────────────────────────────────┤
│  downloadService          │ mediaAnalysisService             │
│  ────────────────         │ ────────────────────             │
│  • enqueue(item)          │ • detectPlatform(url)            │
│  • startDownload(id)      │ • analyze(url)                   │
│  • pause(id)              │ • fetchMetadata()                │
│  • resume(id)             │ • parseOgTags()                  │
│  • cancel(id)             │ • mapQualityOptions()            │
│  • onProgress callback    │                                 │
│    → downloadStore        │  storageService                  │
│                           │  ───────────────                 │
│  +other services:         │  • saveSettings()                │
│  • notificationService    │  • loadSettings()                │
│  • permissionService      │  • loadRecentUrls()              │
│  • storageService         │                                 │
│  • stubs (FS, Video,      │  permissionService               │
│    WebView, BG Dl)        │  ──────────────────              │
│                           │  • requestStoragePerms()         │
│                           │  • requestNotifPerms()           │
└─────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────┐
│               DATA ACCESS LAYER                             │
│            (Repository Pattern - Promise-based)             │
├─────────────────────────────────────────────────────────────┤
│  downloadRepository        historyRepository                │
│  ──────────────────        ─────────────────                │
│  • insertDownload()        • insertHistory()                │
│  • updateProgress()        • getHistory()                   │
│  • getDownloadsByStatus()  • clearHistory()                 │
│  • getDownloadByUrl()      • deleteHistoryEntry()           │
│  • getAllDownloads()                                        │
│  • deleteDownload()        favoritesRepository              │
│                            ───────────────────              │
│  playlistRepository        • addFavorite()                  │
│  ──────────────────        • isFavorite()                   │
│  • createPlaylist()        • getFavorites()                 │
│  • addToPlaylist()                                          │
│  • getPlaylistItems()      searchRepository                 │
│                            ─────────────────                │
│  settingsRepository        • saveSearch()                   │
│  ──────────────────        • getRecentSearches()            │
│  • getSetting()                                            │
│  • setSetting()            All return Promise<Type>         │
│  • getAllSettings()        Parameterized queries             │
│                            Transaction support              │
└─────────────────────────────────────────────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────┐
│              DATABASE LAYER                                 │
│         (SQLite3 - Local Device Storage)                   │
├─────────────────────────────────────────────────────────────┤
│  medianest.db (8 tables with indexes)                       │
│  ─────────────────────────────────────                      │
│  • downloads (id, url, title, status, progress, ...)       │
│  • media_items (id, file_path, duration, is_favorite, ...) │
│  • history (id, action, platform, created_at, ...)         │
│  • favorites (id, media_id, created_at)                    │
│  • playlists (id, name, cover_path, ...)                   │
│  • playlist_items (id, playlist_id, media_id, position)    │
│  • recent_searches (id, query, created_at)                 │
│  • app_settings (key, value, updated_at) - K/V store       │
│                                                             │
│  Indexes on: status, created_at, media_type, platform,     │
│             is_favorite for fast queries                   │
│                                                             │
│  Foreign Keys with CASCADE DELETE for data integrity        │
│  Migrations tracked in app_settings table (db_version)      │
└─────────────────────────────────────────────────────────────┘
```

---

## 📱 Navigation Architecture

```
                          ROOT STACK
                    (NativeStackNavigator)
                              │
                ┌─────────────┼─────────────┐
                │             │             │
            Splash →    MainTabs ←──── Modal Screens
         (2s anim)   (BottomTabs)  (VideoPlayer,
                                    AudioPlayer,
                                    VideoAnalysis,
                                    DownloadOptions,
                                    Search,
                                    BatchDownload)
                          │
            ┌─────┬───────┼───────┬─────────┐
            │     │       │       │         │
         HomeTab Downloads Library Browser Settings
         (Stack) (Stack)  (Stack) (Stack)  (Stack)
            │     │       │       │         │
        HomeMain Mgr    Lib Fav  Browser  Settings
                     Hist         Main     Main
```

**Navigation Flow:**
1. App launches → Splash screen (Reanimated 2s animation)
2. After 2s → Replace to MainTabs (5 bottom tabs)
3. Each tab is a separate NativeStack for nested screens
4. Modal screens (VideoAnalysis, DownloadOptions, etc.) push onto root stack
5. Tab persistence: switching tabs keeps their state

---

## 🔄 Data Flow Example: Download a Video

```
User Input
    │
    ▼
HomeScreen.URLInputCard
    │ (user pastes URL)
    ├─ detectPlatform(url)
    │  └─ mediaAnalysisService.detectPlatform()
    │     └─ regex match + icon display (instant)
    │
    ▼ (user taps Analyze)
navigate('VideoAnalysis', { url })
    │
    ▼
VideoAnalysisScreen
    │ (mount effect)
    ├─ mediaAnalysisService.analyze(url)
    │  ├─ axios.get(url)
    │  ├─ htmlparser2.parse()
    │  ├─ extract og:title, og:image, og:duration
    │  ├─ map platform-specific qualities
    │  └─ return VideoAnalysis object
    │
    ├─ Display: thumbnail, title, channel, duration
    │
    ▼ (user taps Download)
navigate('DownloadOptions', { analysis })
    │
    ▼
DownloadOptionsScreen
    │ (user selects quality/format)
    │
    ▼ (user taps Start Download)
downloadStore.addDownload({
    url,
    title,
    platform,
    quality,
    format,
    status: 'pending'
})
    │
    ▼
downloadStore.addDownload() action
    │ ├─ generate UUID
    │ ├─ call downloadRepository.insertDownload()
    │ │  └─ SQLite: INSERT into downloads
    │ ├─ call downloadService.enqueue()
    │ │  └─ add to pending queue
    │ └─ return downloadId
    │
    ▼ (if slot available)
downloadService.start(downloadId)
    │ ├─ check duplicates (getDownloadByUrl)
    │ ├─ create axios CancelToken
    │ ├─ axios.get(url, { responseType: 'arraybuffer' })
    │ ├─ on progress: downloadStore.updateProgress()
    │ │  └─ update: progress, downloadedBytes, speed
    │ └─ on complete:
    │     ├─ write file via fileSystemStub
    │     ├─ downloadRepository.updateDownloadStatus()
    │     ├─ create MediaItem (libraryStore.addMedia)
    │     ├─ historyRepository.insertHistory()
    │     └─ downloadStore.updateStatus('completed')
    │
    ▼
DownloadManagerScreen
    │ (subscribed to downloadStore.activeDownloads)
    │ (re-renders on progress update)
    │ (displays: thumbnail, title, speed, progress bar, ETA)
    │
    ▼ (download completes)
    │ (status changes to 'completed')
    │ (moves from activeDownloads to completedDownloads)
    │
    ▼
User taps video in DownloadManager or LibraryScreen
    │
    ▼
navigate('VideoPlayer', { mediaId })
    │
    ▼
VideoPlayerScreen
    │ (uses VideoPlayer stub / real react-native-video)
    │ (playerStore.playVideo(mediaId))
    │ (playerStore tracks: position, duration, isPlaying, speed)
    │ (historyRepository.insertHistory action: 'played')
    │
    ▼
Video plays with controls
```

---

## 🎨 Theme System

```
ThemeProvider (React Context)
    │
    ├─ isHydrated = true (once settingsStore.hydrate() completes)
    │
    └─ wraps entire app
        │
        ▼
Any Component
    │
    ├─ useTheme() hook
    │  └─ returns { isDark, colors, typography, spacing, ... }
    │
    └─ No hardcoded colors
       └─ colors.primary = "#7C4DFF"
       └─ colors.surface = "#141A2F"
       └─ colors.success = "#00C853"
       └─ typography.fontFamily.poppins.semiBold = "Poppins-SemiBold"
       └─ spacing.md = 16
```

**One-line theme update:**
Edit `src/theme/colors.ts` → all components reflect change immediately

---

## 🔌 Stub Pattern: Graceful Degradation

```
Installation Status: ❌ react-native-video NOT installed
    │
    ├─ VideoPlayerScreen imports VideoPlayer
    │  └─ from src/services/stubs/videoPlayerStub.ts
    │
    ├─ VideoPlayer component renders stub
    │  └─ Dark View with play-circle icon
    │  └─ Text: "Install react-native-video to enable playback"
    │
    ├─ All video player controls still work
    │  └─ UI updates, UI animations work
    │  └─ Just no actual video frame
    │
    ▼
Installation Status: ✅ react-native-video IS installed
    │
    ├─ VideoPlayer stub detects real package at runtime
    │  └─ const RNVIDEO = require('react-native-video')
    │  └─ returns real component if found
    │
    ├─ VideoPlayerScreen imports same stub file (NO CHANGES)
    │  └─ Stub auto-switches to real implementation
    │
    ├─ Full video playback works
    │  └─ No code changes anywhere
    │
    └─ Pattern works for ALL missing packages:
       ├─ react-native-video
       ├─ react-native-webview
       ├─ react-native-fs
       └─ react-native-background-downloader
```

---

## 🗄️ Database Schema

```
downloads
├─ id (TEXT PRIMARY KEY)
├─ url (TEXT)
├─ title (TEXT)
├─ platform (TEXT)
├─ status (TEXT: pending|analyzing|downloading|paused|completed|failed|cancelled)
├─ progress (REAL: 0-100)
├─ downloadedBytes (INTEGER)
├─ fileSize (INTEGER)
├─ quality (TEXT: 1080p, 720p, etc.)
├─ format (TEXT: mp4, mp3, etc.)
├─ filePath (TEXT: /path/to/file)
├─ created_at (INTEGER: unix timestamp)
├─ completed_at (INTEGER: nullable)
├─ error_message (TEXT: nullable)
└─ retry_count (INTEGER: 0-3)

media_items (FK: download_id)
├─ id (TEXT PRIMARY KEY)
├─ download_id (TEXT FK)
├─ title (TEXT)
├─ platform (TEXT)
├─ file_path (TEXT)
├─ duration (INTEGER: seconds)
├─ fileSize (INTEGER)
├─ media_type (TEXT: video|audio|image|reel)
├─ is_favorite (INTEGER: 0|1)
├─ play_count (INTEGER)
├─ last_played_at (INTEGER: nullable)
└─ created_at (INTEGER)

favorites (FK: media_id)
├─ id (TEXT PRIMARY KEY)
├─ media_id (TEXT FK, unique)
└─ created_at (INTEGER)

history
├─ id (TEXT PRIMARY KEY)
├─ media_id (TEXT FK: nullable)
├─ download_id (TEXT FK: nullable)
├─ title (TEXT)
├─ action (TEXT: played|downloaded|failed)
├─ platform (TEXT)
└─ created_at (INTEGER)

playlists
├─ id (TEXT PRIMARY KEY)
├─ name (TEXT)
├─ description (TEXT)
├─ cover_path (TEXT: nullable)
├─ created_at (INTEGER)
└─ updated_at (INTEGER)

playlist_items (FK: playlist_id, media_id)
├─ id (TEXT PRIMARY KEY)
├─ playlist_id (TEXT FK)
├─ media_id (TEXT FK)
├─ position (INTEGER)
└─ added_at (INTEGER)

recent_searches
├─ id (TEXT PRIMARY KEY)
├─ query (TEXT: unique)
└─ created_at (INTEGER)

app_settings (K/V store)
├─ key (TEXT PRIMARY KEY)
├─ value (TEXT)
└─ updated_at (INTEGER)
```

**Indexes:**
- `idx_downloads_status` — fast status filtering
- `idx_downloads_created_at DESC` — chronological queries
- `idx_media_items_type_favorite_platform` — library filtering
- `idx_history_created_at DESC` — recent first

---

## 📊 State vs Storage

```
RAM (Zustand Stores - Fast, Volatile)
├─ downloadStore.activeDownloads
├─ downloadStore.completedDownloads
├─ libraryStore.filteredMedia (computed)
├─ playerStore.currentVideoId
├─ playerStore.audioQueue
└─ All updated frequently (UI animations)

AsyncStorage (Persistent, Small)
├─ theme preference
├─ app settings
└─ Loaded once at startup

SQLite (Persistent, Large)
├─ downloads (entire history)
├─ media_items (local library)
├─ history (all actions)
├─ favorites
├─ playlists
└─ Queried per screen, indexed for speed
```

**Why this split?**
- Zustand: Fast updates for UI animations
- AsyncStorage: Simple KV, small data
- SQLite: Complex queries, large datasets

---

## 🚀 Request Flow: URL → Download

```
URL PASTE
    ▼
useEffect in URLInputCard (debounced)
    ▼
mediaAnalysisService.detectPlatform(url)
    ├─ regex.test(url)
    └─ returns platform string or null
    ▼
UI shows platform icon (instant feedback)
    ▼
USER TAPS "ANALYZE"
    ▼
navigate('VideoAnalysis', { url })
    ▼
VideoAnalysisScreen useEffect
    ▼
mediaAnalysisService.analyze(url)
    ├─ axios.get(url, { timeout: 10s })
    ├─ parse HTML with htmlparser2
    ├─ extract og:title, og:image, og:video:duration
    ├─ determine platform
    ├─ map platform → quality options
    └─ return VideoAnalysis object
    ▼
Display metadata (thumbnail, title, channel, duration, options)
    ▼
USER SELECTS QUALITY/FORMAT
    ▼
USER TAPS "DOWNLOAD"
    ▼
downloadStore.addDownload({
    url, title, platform, quality, format, thumbnail_url
})
    ▼
downloadRepository.insertDownload() → SQLite
    ▼
downloadService.enqueue(id)
    ├─ Check: getDownloadByUrl(url) → if completed, warn
    ├─ Check: if space available in maxConcurrentDownloads
    └─ If yes → downloadService.start(id)
    ▼
downloadService.start(id)
    ├─ axios.get(url, { 
    │   responseType: 'arraybuffer', 
    │   onDownloadProgress: updateProgress
    │ })
    ├─ onDownloadProgress(event)
    │  ├─ progress = event.loaded / event.total * 100
    │  ├─ speed = bytes/second (rolling 1s avg)
    │  ├─ downloadStore.updateProgress(id, progress, loaded)
    │  └─ UI re-renders: DownloadCard updates
    ├─ On complete:
    │  ├─ write to file via fileSystemStub
    │  ├─ create MediaItem
    │  ├─ insertHistory(action: 'downloaded')
    │  └─ downloadStore.updateStatus(id, 'completed')
    └─ On error:
       ├─ downloadStore.updateStatus(id, 'failed')
       └─ show toast
    ▼
DownloadManagerScreen
    (subscribed to downloadStore changes)
    (displays live progress, can pause/resume/retry)
    ▼
DOWNLOAD COMPLETES
    ▼
libraryStore.loadMedia()
    └─ queries SQLite: SELECT * FROM media_items
    ▼
MediaLibraryScreen
    (subscribed to libraryStore.allMedia)
    (displays new video in grid)
    ▼
USER TAPS VIDEO
    ▼
navigate('VideoPlayer', { mediaId })
    ▼
VideoPlayerScreen plays video (or shows stub)
```

---

## 🧠 Type Safety Flow

```
User Input
    ▼
Screen Component
    │ const { params } = useRoute<RouteProp<RootStackParamList, 'VideoAnalysis'>>();
    │ //        ^^ typed as { url: string }
    │ //             ^^ VideoAnalysisScreenRouteProp typed
    │
    ▼
Service Call
    │ const analysis = await mediaAnalysisService.analyze(params.url);
    │ //                                                   ^ string type
    │ //                                                   ^ matches expected
    │
    ├─ analysis: VideoAnalysis
    │  └─ all properties typed
    │     ├─ url: string ✓
    │     ├─ title: string ✓
    │     ├─ availableQualities: QualityOption[] ✓
    │     └─ ...
    │
    ▼
Store Update
    │ downloadStore.addDownload({
    │   url: analysis.url,              // ✓ string
    │   title: analysis.title,          // ✓ string
    │   platform: analysis.platform,    // ✓ string
    │   quality: selectedQuality.value, // ✓ string
    │   format: selectedFormat.ext,     // ✓ string
    │   status: 'pending' as const      // ✓ literal type
    │ })
    │
    ├─ argument type: Omit<DownloadItem, 'id' | 'createdAt'>
    └─ returns Promise<string> (id)
    │
    ▼
Database Insert
    │ downloadRepository.insertDownload(item: DownloadItem)
    │ └─ all fields match table schema
    │    └─ TypeScript compiler verifies
    │
    ▼
Zero Runtime Type Errors
```

---

**This is a professional, production-grade architecture built for scale, maintainability, and type safety.**
