export const darkColors = {
  primaryBackground: '#050816',
  secondaryBackground: '#0B1023',
  cardBackground: '#111827',
  elevatedCard: '#1A2238',

  primaryText: '#FFFFFF',
  secondaryText: '#B8C0D4',
  mutedText: '#6B7280',

  primary: '#7C4DFF',
  primaryLight: '#9B6DFF',

  accentYellow: '#FBBF24',
  accentOrange: '#FB923C',

  success: '#22C55E',
  danger: '#EF4444',

  border: 'rgba(255,255,255,0.08)',
  overlay: 'rgba(0,0,0,0.6)',

  white: '#FFFFFF',
  black: '#000000',

  tabBar: '#0D1426',
  tabBarBorder: 'rgba(255,255,255,0.06)',
};

export const lightColors = {
  primaryBackground: '#F7F8FC',
  secondaryBackground: '#FFFFFF',
  cardBackground: '#FFFFFF',
  elevatedCard: '#FFFFFF',

  primaryText: '#111827',
  secondaryText: '#4B5563',
  mutedText: '#9CA3AF',

  primary: '#6D4AFF',
  primaryLight: '#8B6AFF',

  accentYellow: '#FBBF24',
  accentOrange: '#FB923C',

  success: '#22C55E',
  danger: '#EF4444',

  border: 'rgba(0,0,0,0.08)',
  overlay: 'rgba(0,0,0,0.5)',

  white: '#FFFFFF',
  black: '#000000',

  tabBar: '#FFFFFF',
  tabBarBorder: 'rgba(0,0,0,0.06)',
};

export const gradients = {
  purple: ['#7C4DFF', '#5B2EFF'] as string[],
  orange: ['#FB923C', '#FBBF24'] as string[],
  blue: ['#3B82F6', '#1D4ED8'] as string[],
  green: ['#22C55E', '#16A34A'] as string[],
  pink: ['#EC4899', '#DB2777'] as string[],
  dark: ['#1A2238', '#0B1023'] as string[],
  splash: ['#050816', '#0B1023', '#1A0050'] as string[],
};

export type Colors = typeof darkColors;
