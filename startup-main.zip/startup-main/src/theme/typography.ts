export const fontFamily = {
  primary: 'Poppins-Medium',
  primaryBold: 'Poppins-Bold',
  primarySemiBold: 'Poppins-SemiBold',
  primaryRegular: 'Poppins-Regular',
  secondary: 'Inter-Regular',
  secondaryMedium: 'Inter-Medium',
  secondarySemiBold: 'Inter-SemiBold',
  secondaryBold: 'Inter-Bold',
};

export const fontSize = {
  h1: 32,
  h2: 28,
  h3: 24,
  h4: 20,
  bodyLarge: 18,
  body: 16,
  bodySmall: 14,
  caption: 12,
  buttonLarge: 18,
  button: 16,
};

export const fontWeight = {
  regular: '400' as const,
  medium: '500' as const,
  semiBold: '600' as const,
  bold: '700' as const,
};

export const lineHeight = {
  h1: 40,
  h2: 36,
  h3: 32,
  h4: 28,
  bodyLarge: 28,
  body: 24,
  bodySmall: 22,
  caption: 18,
};
