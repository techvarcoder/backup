export const APP_NAME = 'MediaNest';

export const STORAGE_KEYS = {
  THEME: '@medianest/theme',
  USER: '@medianest/user',
};
