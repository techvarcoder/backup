"""
generate_moto_data.py
─────────────────────
Downloads the "emmanuelfwerr/motorcycle-technical-specifications" Kaggle dataset,
cleans and normalises every row, injects placeholder fields required by the
Motopedia mobile client, and writes a brand-grouped JSON bundle ready for
Firebase Firestore or direct in-app consumption.

Usage
─────
  pip install kagglehub pandas
  export KAGGLE_USERNAME="your_kaggle_username"
  export KAGGLE_KEY="your_kaggle_api_key"
  python scripts/generate_moto_data.py

The final file is written to:  <project_root>/scripts/grouped_motorcycles.json
"""

import json
import os
import random
import re
import sys
from pathlib import Path

# ── 3rd-party ────────────────────────────────────────────────────────────────
try:
    import kagglehub
except ImportError:
    sys.exit("❌  kagglehub not found. Run: pip install kagglehub pandas")

try:
    import pandas as pd
except ImportError:
    sys.exit("❌  pandas not found. Run: pip install kagglehub pandas")

# ─────────────────────────────────────────────────────────────────────────────
# 0.  CONFIG
# ─────────────────────────────────────────────────────────────────────────────

DATASET_HANDLE = "emmanuelfwerr/motorcycle-technical-specifications"
CSV_FILENAME   = "all_bikez_curated.csv"
OUTPUT_FILE    = Path(__file__).parent.parent / "src" / "data" / "grouped_motorcycles.json"

PRICE_MIN = 75_000
PRICE_MAX = 250_000

# Columns we expect in the CSV and the JS-friendly names we'll use.
# Any column not listed here is still kept — the map only renames.
COLUMN_RENAME: dict[str, str] = {
    "Make":          "brand",
    "Model":         "model",
    "Year":          "year",
    "Displacement":  "displacement_cc",
    "Power":         "power_hp",
    "Torque":        "torque_nm",
    "Weight":        "weight_kg",
    "Category":      "category",
    "Bore":          "bore_mm",
    "Stroke":        "stroke_mm",
    "Cooling":       "cooling",
    "Gearbox":       "gearbox",
    "Transmission":  "transmission",
    "Seat Height":   "seat_height_mm",
    "Fuel Capacity": "fuel_capacity_l",
    "Front Brake":   "front_brake",
    "Rear Brake":    "rear_brake",
    "Front Tire":    "front_tyre",
    "Rear Tire":     "rear_tyre",
    "Front Suspension": "front_suspension",
    "Rear Suspension":  "rear_suspension",
}

# Columns that must be numeric (int where possible, else float)
NUMERIC_COLS = [
    "year", "displacement_cc", "power_hp", "torque_nm",
    "weight_kg", "bore_mm", "stroke_mm",
    "seat_height_mm", "fuel_capacity_l",
]


# ─────────────────────────────────────────────────────────────────────────────
# 1.  HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def slugify(text: str) -> str:
    """'Royal Enfield'  →  'royal-enfield'"""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)   # strip punctuation
    text = re.sub(r"[\s_]+", "-", text)    # spaces/underscores → hyphen
    text = re.sub(r"-+", "-", text)        # collapse multiple hyphens
    return text.strip("-")


def coerce_numeric(value) -> int | float | None:
    """
    Extract the first numeric token from a messy string like '998 cc' or '13.5 hp'.
    Returns int if the value is whole, float otherwise, None if unparseable.
    """
    if pd.isna(value) or str(value).strip() in ("", "-", "N/A", "n/a"):
        return None
    # Pull the first number (including decimals) out of the string
    match = re.search(r"[\d]+(?:[.,]\d+)?", str(value).replace(",", "."))
    if not match:
        return None
    num = float(match.group())
    return int(num) if num == int(num) else num


def clean_string(value) -> str:
    """Return a clean string or empty string for missing/null values."""
    if pd.isna(value) or str(value).strip() in ("", "-", "N/A", "n/a"):
        return ""
    return str(value).strip()


# ─────────────────────────────────────────────────────────────────────────────
# 2.  DOWNLOAD DATASET
# ─────────────────────────────────────────────────────────────────────────────

def download_dataset() -> Path:
    # Validate credentials from env before hitting the network
    username = os.environ.get("KAGGLE_USERNAME")
    key      = os.environ.get("KAGGLE_KEY")

    if not username or not key:
        sys.exit(
            "❌  Kaggle credentials missing.\n"
            "    Set KAGGLE_USERNAME and KAGGLE_KEY as environment variables.\n"
            "    You can find your API key at https://www.kaggle.com/account"
        )

    # kagglehub reads credentials from env automatically; we surface them
    # explicitly here so errors are caught early with a clear message.
    os.environ["KAGGLE_USERNAME"] = username
    os.environ["KAGGLE_KEY"]      = key

    print(f"⬇️   Downloading dataset: {DATASET_HANDLE}")
    download_path = Path(kagglehub.dataset_download(DATASET_HANDLE))
    print(f"✅  Dataset saved to: {download_path}")
    return download_path


# ─────────────────────────────────────────────────────────────────────────────
# 3.  LOCATE CSV
# ─────────────────────────────────────────────────────────────────────────────

def find_csv(download_path: Path) -> Path:
    # kagglehub may unzip into a versioned sub-directory; walk to find the file
    matches = list(download_path.rglob(CSV_FILENAME))
    if not matches:
        # Fall back: list everything so the user can diagnose
        all_files = [str(p) for p in download_path.rglob("*.csv")]
        sys.exit(
            f"❌  '{CSV_FILENAME}' not found under {download_path}.\n"
            f"    CSVs present: {all_files or 'none'}"
        )
    if len(matches) > 1:
        print(f"⚠️   Multiple matches for {CSV_FILENAME}; using first: {matches[0]}")
    return matches[0]


# ─────────────────────────────────────────────────────────────────────────────
# 4.  LOAD & CLEAN DATA
# ─────────────────────────────────────────────────────────────────────────────

def load_and_clean(csv_path: Path) -> list[dict]:
    print(f"📄  Reading: {csv_path}")
    df = pd.read_csv(csv_path, low_memory=False)
    print(f"    Raw shape: {df.shape[0]:,} rows × {df.shape[1]} columns")

    # ── Rename columns to JS-friendly names ──────────────────────────────────
    present = {k: v for k, v in COLUMN_RENAME.items() if k in df.columns}
    df.rename(columns=present, inplace=True)

    # ── Drop rows with no brand or model ─────────────────────────────────────
    for required in ("brand", "model"):
        if required not in df.columns:
            sys.exit(f"❌  Required column '{required}' not found after rename. "
                     f"Available: {list(df.columns)}")
    df = df[df["brand"].notna() & df["model"].notna()]
    df = df[df["brand"].str.strip().ne("") & df["model"].str.strip().ne("")]
    print(f"    Rows after dropping empty brand/model: {len(df):,}")

    # ── Coerce numeric columns ────────────────────────────────────────────────
    for col in NUMERIC_COLS:
        if col in df.columns:
            df[col] = df[col].apply(coerce_numeric)

    # ── Build output records ──────────────────────────────────────────────────
    records: list[dict] = []
    for _, row in df.iterrows():
        brand_raw = clean_string(row.get("brand", ""))
        model_raw = clean_string(row.get("model", ""))
        if not brand_raw or not model_raw:
            continue

        brand_slug = slugify(brand_raw)
        model_slug = slugify(model_raw)

        record: dict = {
            "brand":     brand_raw,
            "model":     model_raw,
            # ── injected mobile-client fields ────────────────────────────────
            "price":     random.randint(PRICE_MIN, PRICE_MAX),
            "image_url": (
                f"https://images.motopedia-cdn.com/bikes/"
                f"{brand_slug}-{model_slug}.png"
            ),
        }

        # ── Add every remaining column ────────────────────────────────────────
        for col in df.columns:
            if col in ("brand", "model"):
                continue
            val = row.get(col)
            if col in NUMERIC_COLS:
                record[col] = val  # already coerced above (int/float/None)
            else:
                record[col] = clean_string(val) if not pd.isna(val) else ""

        records.append(record)

    print(f"    Clean records produced: {len(records):,}")
    return records


# ─────────────────────────────────────────────────────────────────────────────
# 5.  GROUP BY BRAND
# ─────────────────────────────────────────────────────────────────────────────

def group_by_brand(records: list[dict]) -> dict:
    """
    {
      "honda": {
        "brand": "Honda",
        "models": [ { ...bike_record }, ... ]
      },
      ...
    }
    """
    grouped: dict = {}
    for rec in records:
        key = slugify(rec["brand"])          # e.g. "royal-enfield"
        if key not in grouped:
            grouped[key] = {
                "brand":  rec["brand"],      # display-case original
                "models": [],
            }
        # Don't duplicate the brand field inside the model object
        model_rec = {k: v for k, v in rec.items() if k != "brand"}
        grouped[key]["models"].append(model_rec)

    # Sort brands alphabetically, models by year desc then model name
    for key in grouped:
        grouped[key]["models"].sort(
            key=lambda m: (-(m.get("year") or 0), m.get("model", ""))
        )

    return dict(sorted(grouped.items()))


# ─────────────────────────────────────────────────────────────────────────────
# 6.  WRITE OUTPUT
# ─────────────────────────────────────────────────────────────────────────────

def write_output(grouped: dict) -> None:
    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(grouped, f, ensure_ascii=False, indent=2, default=str)
    size_kb = OUTPUT_FILE.stat().st_size / 1024
    print(f"\n✅  Written: {OUTPUT_FILE}")
    print(f"    Brands:      {len(grouped):,}")
    print(f"    Total models: {sum(len(v['models']) for v in grouped.values()):,}")
    print(f"    File size:   {size_kb:,.1f} KB")


# ─────────────────────────────────────────────────────────────────────────────
# 7.  ENTRY POINT
# ─────────────────────────────────────────────────────────────────────────────

def main() -> None:
    random.seed(42)  # reproducible dummy prices across runs

    download_path = download_dataset()
    csv_path      = find_csv(download_path)
    records       = load_and_clean(csv_path)
    grouped       = group_by_brand(records)
    write_output(grouped)


if __name__ == "__main__":
    main()
